// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_WIN_TXTBOX_NAMESPACE     n_posix_literal( "Txtbox" )

#define N_WIN_TXTBOX_ALL           ( -1 )
#define N_WIN_TXTBOX_NOT_SELECTED  ( -1 )

#define N_WIN_TXTBOX_FOCUS_NONE    ( 0 )
#define N_WIN_TXTBOX_FOCUS_WAIT    ( 1 )
#define N_WIN_TXTBOX_FOCUS_GO      ( 2 )

#define N_WIN_TXTBOX_MENU_NONE     ( 0 )
#define N_WIN_TXTBOX_MENU_MAIN     ( 1 )
#define N_WIN_TXTBOX_MENU_LINE     ( 2 )


#define N_WIN_TXTBOX_STYLE_LISTBOX          ( 1 <<  0 )
#define N_WIN_TXTBOX_STYLE_ONELINE          ( 1 <<  1 )
#define N_WIN_TXTBOX_STYLE_EDITBOX          ( 1 <<  2 )
#define N_WIN_TXTBOX_STYLE_HSCROLL          ( 1 <<  3 )
#define N_WIN_TXTBOX_STYLE_VSCROLL          ( 1 <<  4 )
#define N_WIN_TXTBOX_STYLE_NO_BRDR          ( 1 <<  5 )
#define N_WIN_TXTBOX_STYLE_NO_PDNG          ( 1 <<  6 )
#define N_WIN_TXTBOX_STYLE_STRIPED          ( 1 <<  7 )
#define N_WIN_TXTBOX_STYLE_VISIBLE          ( 1 <<  8 )
#define N_WIN_TXTBOX_STYLE_TRANSBG          ( 1 <<  9 )
#define N_WIN_TXTBOX_STYLE_FLATBDR          ( 1 << 10 )
#define N_WIN_TXTBOX_STYLE_CMB_BDR          ( 1 << 11 )
#define N_WIN_TXTBOX_STYLE__DI_HDC          ( 1 << 12 )

#define N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS ( 1 <<  0 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL ( 1 <<  1 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL ( 1 <<  2 )
#define N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ( 1 <<  3 )
#define N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ( 1 <<  4 )
#define N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ( 1 <<  5 )
#define N_WIN_TXTBOX_OPTION_ONELINE_FADEOUT ( 1 <<  6 )
#define N_WIN_TXTBOX_OPTION_ONELINE_LNCACHE ( 1 <<  7 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ( 1 <<  8 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM ( 1 <<  9 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET ( 1 << 10 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ( 1 << 11 )
#define N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ( 1 << 12 )
#define N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ( 1 << 13 )
#define N_WIN_TXTBOX_OPTION_ZEROBASED_INDEX ( 1 << 14 )
#define N_WIN_TXTBOX_OPTION_NO_DELAYEDFOCUS ( 1 << 15 )


typedef struct {

	// Instance : you can control via methods

	HWND    hwnd;
	WNDPROC pfunc;
	n_txt   txt, txt_undo;
	int     style, style_option;
	bool    is_static_ownerdraw;

	n_win_scrollbar vscr, hscr;

	s32     scroll_pxl_tabbed_x, scroll_cch_tabbed_y;
	s32     select_cch_x, select_cch_y, select_cch_sx, select_cch_sy;
	s32       undo_cch_x,   undo_cch_y,   undo_cch_sx,   undo_cch_sy;
	s32     offset_pxl_y;

	bool    partial_selection_onoff;
	bool     updown_selection_onoff;
	bool    reverse_selection_onoff;
	bool    line_min_onoff, line_max_onoff;
	s32     line_min_cch_x, line_max_cch_x;
	bool    undo_line_min_onoff, undo_line_max_onoff;
	s32     undo_line_min_cch_x, undo_line_max_cch_x;
	s32     smallbutton_margin;
	bool    undo_onoff;


	// Optional

	n_posix_char *placeholder;
	n_posix_char *tab_mark;
	n_posix_char *eol_mark;

	s32           tabstop;

	bool          mouse_input_stop_onoff;


	// Internal : auto-filled by the system

	HDC      hdc;
	POINT    ime;
	int      vk;
	s32      scale;
	s32             hover_cch_x,        hover_cch_y;
	s32             hover_under;
	s32              drag_cch_x,         drag_cch_y;
	s32             font_pxl_sx,        font_pxl_sy;
	s32                                 cell_pxl_sy;
	s32             caret_pxl_x,        caret_pxl_y;
	s32            caret_pxl_sx,       caret_pxl_sy;
	s32           canvas_pxl_sx,      canvas_pxl_sy;
	s32      canvas_real_pxl_sx;
	s32      page_pxl_tabbed_sx, page_cch_tabbed_sy;
	s32      last_pxl_tabbed_sx, last_cch_tabbed_sy;
	s32      virtual_padding_pxl_sx;
	s32      txt_maxwidth_y;
	int      shift_dragging;
	bool     is_captured;
	bool     is_dragging;
	bool     is_caret_tail;
	bool     is_hovered_linenum;
	s32      empty_line_selection;

	int      focus_phase;
	bool     focus_phase_is_first;

	s32      oneline_cache_f;
	s32      oneline_cache_t;

	bool     is_font_monospace;
	SIZE     size_halfwidth;
	SIZE     size_fullwidth;

	s32      prv_scr_x,  prv_scr_y;
	s32      prv_txt_sx, prv_txt_sy;
	s32      prv_sel_x,  prv_sel_y;
	s32      prv_sel_sx, prv_sel_sy;
	s32      prv_drag;
	s32      prv_caret;
	n_bmp    prv_bmp;

	n_bmp    ime_bmp;

	n_win_simplemenu menu_editbox;
	n_win_simplemenu menu_linenum;
	bool             menu_onoff;
	int              menu_type;

	n_uxtheme uxtheme;

	n_bmp_fade fade;
	u32        fade_timer;
	n_bmp      fade_bmp;
	int        fade_vk;
	bool       fade_is_selected;


	// Metrics : once per session

	bool     is_9x;
	bool     is_nt;
	bool     is_2k_or_later;
	bool     is_classic;
	s32         number_pxl_sx, number_pad_pxl_sx;
	s32         client_pxl_sx,     client_pxl_sy;
	s32         border_pxl_sx,     border_pxl_sy;
	s32            pad_pxl_sx,        pad_pxl_sy;
	s32      scrollbar_pxl_sx,  scrollbar_pxl_sy;
	COLORREF color_base__padding;
	COLORREF color_base_selected;
	COLORREF color_back_selected;
	COLORREF color_text_selected;
	COLORREF color_back_noselect;
	COLORREF color_text_noselect;
	COLORREF color_back_striping;
	COLORREF color_text_tab_mark;
	COLORREF color_text_eol_mark;
	COLORREF color_caret_focused;
	COLORREF color_caret_nofocus;
	COLORREF color_text_backgrnd;
	COLORREF color_back_linenum1;
	COLORREF color_back_linenum2;
	COLORREF color_back_linenum3;
	COLORREF color_text_linenum1;
	COLORREF color_text_linenum2;
	COLORREF color___placeholder;
	COLORREF color___dwm_contour;
	COLORREF color___dwm_textclr;
	COLORREF color___ime_watcher;
	COLORREF color_back_disabled;
	COLORREF color_back__enabled;
	COLORREF color_border_normal;
	COLORREF color_border__focus;
	COLORREF color_border___flat;
	UINT     drawtext_modes;

	bool     drag_onoff;
	UINT     drag_timer;
	DWORD    drag_msec;

	bool     ime_onoff;
	bool     ime_composition_onoff;

	bool     caret_onoff;
	UINT     caret_timer;
	DWORD    caret_msec;

	bool     input_onoff;
	UINT     input_timer;
	DWORD    input_msec;


	// Debug Center

	bool   debug_onoff;
	n_bmp *debug_bmp;

} n_win_txtbox;

#define n_win_txtbox_zero( p ) n_memory_zero( p, sizeof( n_win_txtbox ) )


