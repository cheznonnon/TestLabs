// hunyapiyo3
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/click.c"
//#include "../nonnon/game/hmidiout.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"
//#include "../nonnon/game/transition.c"


#include "../nonnon/neutral/wav/filter.c"


#include "../nonnon/project/macro.c"




#define N_HUNYAPIYO3_APPNAME  n_posix_literal( "hunyapiyo3" )

#define N_HUNYAPIYO3_GO       n_posix_literal( "Go!" )
#define N_HUNYAPIYO3_OK       n_posix_literal( "OK"  )

#define HUNYAPIYO3_WAV_0      "N_PROJECT_SOUND_CLICK"
#define HUNYAPIYO3_WAV_1      "N_PROJECT_SOUND_GET"


#define N_HUNYAPIYO3_COLOR_BG       n_bmp_rgb(   0, 200, 255 )
#define N_HUNYAPIYO3_COLOR_FRAME    n_bmp_rgb(   0, 150, 200 )
#define N_HUNYAPIYO3_COLOR_FRAME_O  n_bmp_rgb( 255, 255,   0 )
#define N_HUNYAPIYO3_COLOR_FRAME_X  n_bmp_rgb(   1,   1,   1 )
#define N_HUNYAPIYO3_COLOR_MIXER_O  n_bmp_rgb( 255, 255, 255 )
#define N_HUNYAPIYO3_COLOR_MIXER_X  n_bmp_rgb(   1,   1,   1 )
#define N_HUNYAPIYO3_COLOR_TEXT     n_bmp_white
#define N_HUNYAPIYO3_COLOR_CONTOUR  n_bmp_rgb(   0, 150, 200 )
#define N_HUNYAPIYO3_COLOR_SHAFT    n_bmp_rgb(   0, 150, 200 )
#define N_HUNYAPIYO3_COLOR_PROGRESS n_bmp_rgb(   0, 200, 255 )


#define N_HUNYAPIYO3_BMP_ALL ( 5 )
#define N_HUNYAPIYO3_WAV_ALL ( 7 )


#define N_HUNYAPIYO3_SOUND_CLICK       ( 0 )
#define N_HUNYAPIYO3_SOUND_FANFARE     ( 1 )
#define N_HUNYAPIYO3_SOUND_ANSWER_O    ( 2 )
#define N_HUNYAPIYO3_SOUND_ANSWER_X    ( 3 )
#define N_HUNYAPIYO3_SOUND_COUNTDOWN_1 ( 4 )
#define N_HUNYAPIYO3_SOUND_COUNTDOWN_2 ( 5 )
#define N_HUNYAPIYO3_SOUND_COUNTDOWN_3 ( 6 )


#define N_HUNYAPIYO3_RANDOM  ( 4 )
#define N_HUNYAPIYO3_MAP_SX  ( 3 )
#define N_HUNYAPIYO3_MAP_SY  ( 3 )
#define N_HUNYAPIYO3_MAP_ALL ( N_HUNYAPIYO3_MAP_SX * N_HUNYAPIYO3_MAP_SY )


#define N_HUNYAPIYO3_PHASE_CLCK (  0 )
#define N_HUNYAPIYO3_PHASE_STRT (  1 )
#define N_HUNYAPIYO3_PHASE_CD_3 (  2 )
#define N_HUNYAPIYO3_PHASE_CD_2 (  3 )
#define N_HUNYAPIYO3_PHASE_CD_1 (  4 )
#define N_HUNYAPIYO3_PHASE_CD_0 (  5 )
#define N_HUNYAPIYO3_PHASE_INIT (  6 )
#define N_HUNYAPIYO3_PHASE_MAIN (  7 )
#define N_HUNYAPIYO3_PHASE_RSLT (  8 )
#define N_HUNYAPIYO3_PHASE_PERC (  9 )


#define N_HUNYAPIYO3_SHORTTERM_MSEC ( 1000 )
#define N_HUNYAPIYO3_RESULT_MSEC    (  200 )




// Instance

typedef struct {

	n_type_gfx    zoom;
	n_type_gfx    sx, sy;
	n_type_gfx    bar;
	n_type_gfx    unit;
	n_type_gfx    countdown_font_size;
	n_type_gfx    countdown_font_size_unit;
	n_type_gfx    countdown_font_size_max;
	n_type_gfx    contour_size;
	n_type_gfx    message_font_size;
	n_type_gfx    question_size;

	n_bmp         bmp[ N_HUNYAPIYO3_BMP_ALL ];
	n_bmp         bmp_bg;
	n_bmp         bmp_clickhere;
	n_bmp         bmp_message;
	n_bmp         bmp_question;
	n_bmp         bmp_percent;
	n_bmp         bmp_go;
	n_bmp         bmp_ok;
	n_bmp         bmp_result;

	n_game_sound  snd[ N_HUNYAPIYO3_WAV_ALL ];

	int           map[ N_HUNYAPIYO3_MAP_ALL ];
	int           ret[ N_HUNYAPIYO3_MAP_ALL ];
	int           prv[ N_HUNYAPIYO3_MAP_ALL ];

	int           phase;
	u32           phase_timer;

	n_bool        go_hover_onoff;
	n_bool        ok_hover_onoff;

	n_game_click  click_l;
	n_game_click  click_r;

	u32           result_timer;
	int           result_index;

	int           score;
	n_bool        is_fanfare;

	n_type_real   text_jump_coeff;
	u32           text_jump_timer;

	u32           progress;

	n_type_gfx    px, py;

	n_bool        is_first;

	u32           color_bg;
	u32           color_frame;
	u32           color_text;
	u32           color_contour;
	u32           color_shaft;
	u32           color_progress;

} n_hunyapiyo3;

static n_hunyapiyo3 hunyapiyo3;




#include "./hunyapiyo3_gdi.c"




void
n_hunyapiyo3_debug_map( n_hunyapiyo3 *p, int *map )
{

	n_posix_char str[ 1024 ];
	int          cch = 0;

	cch += n_posix_sprintf_literal( &str[ cch ], "%d %d %d \n", map[ 0 ], map[ 1 ], map[ 2 ] );
	cch += n_posix_sprintf_literal( &str[ cch ], "%d %d %d \n", map[ 3 ], map[ 4 ], map[ 5 ] );
	cch += n_posix_sprintf_literal( &str[ cch ], "%d %d %d \n", map[ 6 ], map[ 7 ], map[ 8 ] );

	n_posix_debug( str );

	return;
}

void
n_hunyapiyo3_metrics( n_hunyapiyo3 *p )
{

	n_type_gfx desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );
	n_type_gfx desktop_size = n_posix_min_n_type_gfx( desktop_sx, desktop_sy );


	p->unit = (n_type_gfx) n_posix_max_n_type_real( (n_type_real) 48 * 1.33, (n_type_real) desktop_size * 0.1 );
	p->sx   = p->unit * N_HUNYAPIYO3_MAP_SX;
	p->sy   = p->unit * N_HUNYAPIYO3_MAP_SY;

	n_type_gfx control_size; n_win_stdsize( game.hwnd, &control_size, NULL, NULL );
	p->bar = control_size;

//n_posix_debug_literal( " %d ", p->unit );
	p->contour_size             = p->unit / 30;
	p->countdown_font_size_unit = p->unit /  5;
	p->countdown_font_size_max  = (n_type_gfx) ( (n_type_real) p->sx * 0.8 );
	p->message_font_size        = p->sx   /  6;

	p->countdown_font_size_unit /= n_posix_max( 1, n_win_dpi( game.hwnd ) / 75 );


	if ( n_win_color_is_highcontrast() )
	{
		p->color_bg       = N_HUNYAPIYO3_COLOR_BG;
		p->color_frame    = N_HUNYAPIYO3_COLOR_FRAME;
		p->color_text     = N_HUNYAPIYO3_COLOR_TEXT;
		p->color_contour  = N_HUNYAPIYO3_COLOR_CONTOUR;
		p->color_shaft    = N_HUNYAPIYO3_COLOR_SHAFT;
		p->color_progress = N_HUNYAPIYO3_COLOR_PROGRESS;
	} else {
		p->color_bg       = n_win_dwm_windowcolor();
		p->color_frame    = n_bmp_blend_pixel( p->color_bg, n_bmp_black, 0.25 );
		p->color_text     = n_bmp_white;
		p->color_contour  = p->color_frame;
		p->color_shaft    = p->color_frame;
		p->color_progress = p->color_bg;
	}


	game.color = p->color_bg;


	return;
}

void
n_hunyapiyo3_rearrange( n_hunyapiyo3 *p )
{

	//n_bmp_flush( &game.bmp, p->color_bg );
	n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );


//n_hunyapiyo3_debug_map( p, p->map );
//n_hunyapiyo3_debug_map( p, p->ret );
//n_hunyapiyo3_debug_map( p, p->prv );

	int x = 0;
	int y = 0;
	int i = 0;
	n_posix_loop
	{

		n_type_gfx pxl_x = p->unit * x;
		n_type_gfx pxl_y = p->unit * y;

		extern void n_hunyapiyo3_draw_single( n_hunyapiyo3*, n_bmp*, int, n_type_gfx, n_type_gfx );
		n_hunyapiyo3_draw_single( p, &game.bmp, p->ret[ i ], pxl_x, pxl_y );

		extern void n_hunyapiyo3_frame( n_hunyapiyo3*, n_bmp*, n_type_gfx, n_type_gfx, u32, u32 );
		if ( p->map[ i ] == p->ret[ i ] )
		{
			n_bmp_mixer( &game.bmp, pxl_x,pxl_y,p->unit,p->unit, N_HUNYAPIYO3_COLOR_MIXER_O, 0.25 );
			n_hunyapiyo3_frame( p, &game.bmp, pxl_x,pxl_y, p->color_frame, N_HUNYAPIYO3_COLOR_FRAME_O );
		} else {
			n_bmp_mixer( &game.bmp, pxl_x,pxl_y,p->unit,p->unit, N_HUNYAPIYO3_COLOR_MIXER_X, 0.25 );
			n_hunyapiyo3_frame( p, &game.bmp, pxl_x,pxl_y, p->color_frame, N_HUNYAPIYO3_COLOR_FRAME_X );
		}

		i++;

		x++;
		if ( x >= N_HUNYAPIYO3_MAP_SX )
		{
			x = 0;
			y++;
			if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
		}
	}


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_on_settingchange( n_hunyapiyo3 *p )
{

	n_hunyapiyo3_metrics( p );


	n_hunyapiyo3_gdi_background( p, &p->bmp_bg );

	n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );


	n_hunyapiyo3_gdi_question( p, &p->bmp_question, p->unit, p->question_size, p->contour_size );
	n_hunyapiyo3_gdi_clickhere( p, &p->bmp_clickhere, p->message_font_size, p->contour_size );


	n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

	if ( p->phase == N_HUNYAPIYO3_PHASE_CLCK )
	{
//n_game_hwndprintf_literal( " Click! " );

		void n_hunyapiyo3_clickhere( n_hunyapiyo3* );
		n_hunyapiyo3_clickhere( p );
	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_MAIN )
	{
//n_game_hwndprintf_literal( " Main " );

		void n_hunyapiyo3_main( n_hunyapiyo3* );
		n_hunyapiyo3_main( p );
	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_PERC )
	{
//n_game_hwndprintf_literal( " Percent " );

		n_hunyapiyo3_rearrange( p );

		n_bmp_flush_fastcopy( &game.bmp, &p->bmp_result );

		int percent = (int) ( (n_type_real) p->score / N_HUNYAPIYO3_MAP_ALL * 100 );
		n_hunyapiyo3_gdi_percent( p, &p->bmp_percent, percent, p->message_font_size, p->contour_size );

		void n_hunyapiyo3_percent( n_hunyapiyo3* );
		n_hunyapiyo3_percent( p );
	} // else


	n_game_on_paint();
	//n_game_refresh_on();
	return;
}


#include "./hunyapiyo3_subclass.c"




n_type_gfx
n_hunyapiyo3_text_jump( n_hunyapiyo3 *p, n_type_real pos, n_type_real size, u32 speed, n_type_real step )
{

	if ( n_game_timer( &p->text_jump_timer, speed ) ) { p->text_jump_coeff += step; }

	return (n_type_gfx) ( pos - ( size * fabs( sin( 2.0 * M_PI * p->text_jump_coeff ) ) ) );
}

void
n_hunyapiyo3_frame( n_hunyapiyo3 *p, n_bmp *target, n_type_gfx x, n_type_gfx y, u32 color_frame_outer, u32 color_frame_inner )
{

	n_bmp b; n_bmp_zero( &b ); n_bmp_1st( &b, p->unit, p->unit );

	n_type_gfx u  = (n_type_gfx) trunc( n_win_scale( game.hwnd ) );
	n_type_gfx uu = u * 2;

	n_bmp_box( &b, 0  ,0  ,p->unit   ,p->unit   , color_frame_outer     ); u *= 2; uu = u * 2;
	n_bmp_box( &b, 0+u,0+u,p->unit-uu,p->unit-uu, color_frame_inner     ); u *= 2; uu = u * 2;
	n_bmp_box( &b, 0+u,0+u,p->unit-uu,p->unit-uu, n_bmp_white_invisible );

	n_bmp_transcopy( &b, target, 0,0,p->unit,p->unit, x, y );

	n_bmp_free( &b );


	return;
}

void
n_hunyapiyo3_draw_single( n_hunyapiyo3 *p, n_bmp *target, int index, n_type_gfx x, n_type_gfx y )
{

	if ( index != -1 )
	{
		n_bmp_transcopy( &p->bmp[ index ], target, 0,0,p->unit,p->unit, x, y );
	} else {
		n_bmp_transcopy( &p->bmp_question, target, 0,0,p->unit,p->unit, x, y );
	}


	return;
}

void
n_hunyapiyo3_reset_panel( n_hunyapiyo3 *p )
{

	// [!] : use 4 panels always


	const n_bool shuffle = n_true;


	int neko[ N_HUNYAPIYO3_RANDOM ];

	int i = 0;
	n_posix_loop
	{

		neko[ i ] = i;

		i++;
		if ( i >= N_HUNYAPIYO3_RANDOM ) { break; }
	}

	i = 0;
	while( shuffle )
	{

		//if ( 0 == n_random_range( 2 ) )
		{
			int r = n_random_range( N_HUNYAPIYO3_RANDOM );

			int swap  = neko[ i ];
			neko[ i ] = neko[ r ];
			neko[ r ] = swap;
		}

		i++;
		if ( i >= N_HUNYAPIYO3_RANDOM ) { break; }
	}


	int rest = N_HUNYAPIYO3_MAP_ALL;

	int panel_count[ N_HUNYAPIYO3_RANDOM ];

	i = 0;
	n_posix_loop
	{

		panel_count[ i ] = 1 + n_random_range( rest - ( N_HUNYAPIYO3_RANDOM - i ) );

		rest -= panel_count[ i ];

		i++;
		if ( i >= N_HUNYAPIYO3_RANDOM ) { break; }

	}

	if ( rest != 0 ) { panel_count[ i - 1 ] += rest; }


	    i = 0;
	int j = 0;
	int k = 0;
	n_posix_loop
	{

		p->map[ i ] = neko[ k ];

		i++;
		if ( i >= N_HUNYAPIYO3_MAP_ALL ) { break; }

		j++;
		if ( j >= panel_count[ k ] )
		{
			j = 0;
			k++;
			if ( k >= N_HUNYAPIYO3_RANDOM )
			{
//n_posix_debug_literal( "Never Come" );
				k--;
			}
		}

	}

	i = 0;
	while( shuffle )
	{


		{
			int r = n_random_range( N_HUNYAPIYO3_MAP_ALL );

			int swap    = p->map[ i ];
			p->map[ i ] = p->map[ r ];
			p->map[ r ] = swap;
		}

		i++;
		if ( i >= N_HUNYAPIYO3_MAP_ALL ) { break; }
	}


	return;
}

void
n_hunyapiyo3_reset( n_hunyapiyo3 *p )
{

	p->score = 0;

	p->go_hover_onoff = n_false;
	p->ok_hover_onoff = n_false;

	n_hunyapiyo3_gdi_button( p, &p->bmp_go, p->sx, p->bar, N_HUNYAPIYO3_GO, n_bmp_white_invisible, n_false );
	n_hunyapiyo3_gdi_button( p, &p->bmp_ok, p->sx, p->bar, N_HUNYAPIYO3_OK, n_bmp_white_invisible, n_false );

	n_hunyapiyo3_reset_panel( p );

	int i = 0;
	n_posix_loop
	{

		p->ret[ i ] = -1;
		p->prv[ i ] = -2;

		i++;
		if ( i >= N_HUNYAPIYO3_MAP_ALL ) { break; }
	}

	p->is_first = n_true;


	return;
}




void
n_hunyapiyo3_clickhere( n_hunyapiyo3 *p )
{

	if ( p->is_first )
	{
		p->is_first = n_false;
		n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );
	}


	n_type_gfx sx = N_BMP_SX( &p->bmp_clickhere );
	n_type_gfx sy = N_BMP_SY( &p->bmp_clickhere );
	n_type_gfx  x = n_game_centering( game.sx, sx );
	n_type_gfx  y = n_game_centering( game.sy, sy );

	y = n_hunyapiyo3_text_jump( p, y, sy / 2, 25, 0.01 );

	n_bmp_fastcopy( &p->bmp_bg, &game.bmp, p->px,p->py,sx,sy, p->px,p->py );

	n_bmp_transcopy( &p->bmp_clickhere, &game.bmp, 0,0,sx,sy, x,y );

	p->px = x;
	p->py = y;


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_countdown( n_hunyapiyo3 *p, int number )
{

	if ( p->countdown_font_size < p->countdown_font_size_max )
	{
		n_hunyapiyo3_gdi_countdown( p, &p->bmp_message, number, p->countdown_font_size, p->contour_size );
	}


	n_type_gfx sx = N_BMP_SX( &p->bmp_message );
	n_type_gfx sy = N_BMP_SY( &p->bmp_message );
	n_type_gfx  x = n_game_centering( game.sx, sx );
	n_type_gfx  y = n_game_centering( game.sy, sy );
//n_bmp_save_literal( &p->bmp_message, "ret.bmp" );

	n_bmp_fastcopy( &p->bmp_bg, &game.bmp, p->px,p->py,sx,sy, p->px,p->py );

	n_bmp_transcopy( &p->bmp_message, &game.bmp, 0,0,sx,sy, x,y );

	p->px = x;
	p->py = y;


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_short_term_memory( n_hunyapiyo3 *p )
{

	//n_bmp_flush( &game.bmp, p->color_bg );
	n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );


	int x = 0;
	int y = 0;
	n_posix_loop
	{

		n_type_gfx pxl_x = p->unit * x;
		n_type_gfx pxl_y = p->unit * y;

		int map = p->map[ x + ( N_HUNYAPIYO3_MAP_SX * y ) ];

		n_hunyapiyo3_draw_single( p, &game.bmp, map, pxl_x, pxl_y );

		x++;
		if ( x >= N_HUNYAPIYO3_MAP_SX )
		{
			x = 0;
			y++;
			if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
		}
	}


	n_game_refresh_on();
	return;
}

n_bool
n_hunyapiyo3_button( n_hunyapiyo3 *p, n_bool *onoff, n_bmp *bmp, n_posix_char *str )
{

	n_bool ret = n_false;


	n_type_gfx cursor_x, cursor_y; n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );

	if (
		( ( cursor_x >=     0 )&&( cursor_x <   p->sx ) )
		&&
		( ( cursor_y >= p->sy )&&( cursor_y < game.sy ) )
	)
	{

		if ( n_game_click_single( &p->click_l ) )
		{
			ret = n_true;
		}

		if ( p->click_l.phase == N_GAME_CLICK_PHASE_DOWN )
		{

			if ( (*onoff) )
			{
				n_hunyapiyo3_gdi_button( p, bmp, p->sx, p->bar, str, n_bmp_rgb( 229,151,0 ), n_true );
			}

		} else {

			if ( (*onoff) == n_false )
			{
				(*onoff) = n_true;
				n_hunyapiyo3_gdi_button( p, bmp, p->sx, p->bar, str, n_bmp_rgb( 229,151,0 ), n_false );
			}

		}

	} else {

		if ( (*onoff) )
		{
			(*onoff) = n_false;
			n_hunyapiyo3_gdi_button( p, bmp, p->sx, p->bar, str, n_bmp_white_invisible, n_false );
		}

	}

	n_bmp_box( &game.bmp, 0,p->sy,p->sx,p->bar, p->color_bg );

	n_bmp_transcopy( bmp, &game.bmp, 0,0,p->sx,p->bar, 0,p->sy );


	return ret;
}

void
n_hunyapiyo3_main( n_hunyapiyo3 *p )
{

	//n_bmp_flush( &game.bmp, p->color_bg );
	n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );


	n_bool ret = n_hunyapiyo3_button( p, &p->go_hover_onoff, &p->bmp_go, N_HUNYAPIYO3_GO );
	if ( ret )
	{
		p->phase = N_HUNYAPIYO3_PHASE_RSLT;

		p->result_timer = n_posix_tickcount();
		p->result_index = 0;

		p->text_jump_coeff = 0.0;

		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_CLICK ] );
	}


	int x = 0;
	int y = 0;
	n_posix_loop
	{

		n_type_gfx pxl_x = p->unit * x;
		n_type_gfx pxl_y = p->unit * y;

		n_type_gfx cursor_x, cursor_y; n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );

		int ret_pos = x + ( N_HUNYAPIYO3_MAP_SX * y );

		u32 color_frame = n_bmp_white_invisible;
		if (
			( ( cursor_x >= pxl_x )&&( cursor_x < ( pxl_x + p->unit ) ) )
			&&
			( ( cursor_y >= pxl_y )&&( cursor_y < ( pxl_y + p->unit ) ) )
		)
		{
			color_frame = N_HUNYAPIYO3_COLOR_FRAME_O;
			if ( n_game_click_single( &p->click_l ) )
			{
				p->ret[ ret_pos ]++;
				if ( p->ret[ ret_pos ] >= N_HUNYAPIYO3_RANDOM )
				{
					p->ret[ ret_pos ] = -1;
				}
			} else
			if ( n_game_click_single( &p->click_r ) )
			{
				p->ret[ ret_pos ]--;
				if ( p->ret[ ret_pos ] < -1 )
				{
					p->ret[ ret_pos ] = N_HUNYAPIYO3_RANDOM - 1;
				}
			}

		}

		n_hunyapiyo3_draw_single( p, &game.bmp, p->ret[ ret_pos ], pxl_x, pxl_y );

		n_hunyapiyo3_frame( p, &game.bmp, pxl_x, pxl_y, p->color_frame, color_frame );


		x++;
		if ( x >= N_HUNYAPIYO3_MAP_SX )
		{
			x = 0;
			y++;
			if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
		}
	}


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_progressbar( n_hunyapiyo3 *p, n_type_real percent_coeff )
{

	n_bmp_box( &game.bmp, 0,p->sy, p->sx,p->bar, n_bmp_black );


	n_type_gfx bar = ( p->bar / 6 );
	n_type_gfx   x = p->unit / 10;
	n_type_gfx   y = p->sy + n_game_centering( p->bar, bar );
	n_type_gfx  sx = p->sx - ( x * 2 );
	n_type_gfx  sy = bar;

	n_bmp_box( &game.bmp, x,y,sx,sy, p->color_shaft );

	sx = (n_type_gfx) ( (n_type_real) sx * percent_coeff );

	n_bmp_box( &game.bmp, x,y,sx,sy, p->color_progress );


	n_game_refresh_on();
	return;
}

void
n_hunyapiyo3_result( n_hunyapiyo3 *p )
{

	n_type_gfx pxl_x = p->unit * ( p->result_index % N_HUNYAPIYO3_MAP_SX );
	n_type_gfx pxl_y = p->unit * ( p->result_index / N_HUNYAPIYO3_MAP_SX );

	if ( p->map[ p->result_index ] == p->ret[ p->result_index ] )
	{
		p->score++;
		n_bmp_mixer( &game.bmp, pxl_x,pxl_y,p->unit,p->unit, N_HUNYAPIYO3_COLOR_MIXER_O, 0.25 );
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_O ] );
		n_hunyapiyo3_frame( p, &game.bmp, pxl_x,pxl_y, p->color_frame, N_HUNYAPIYO3_COLOR_FRAME_O );
	} else {
		n_bmp_mixer( &game.bmp, pxl_x,pxl_y,p->unit,p->unit, N_HUNYAPIYO3_COLOR_MIXER_X, 0.25 );
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_X ] );
		n_hunyapiyo3_frame( p, &game.bmp, pxl_x,pxl_y, p->color_frame, N_HUNYAPIYO3_COLOR_FRAME_X );
	}

	n_game_refresh_on();
	n_game_on_paint();


	if ( p->map[ p->result_index ] == p->ret[ p->result_index ] )
	{
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_O ] );
	} else {
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_X ] );
	}

	n_posix_loop
	{

		n_bool ret = n_false;
		if ( p->map[ p->result_index ] == p->ret[ p->result_index ] )
		{
			ret = n_game_sound_timer( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_O ] );
		} else {
			ret = n_game_sound_timer( &p->snd[ N_HUNYAPIYO3_SOUND_ANSWER_X ] );
		}

		if ( ret ) { break; }
	}

	p->result_index++;
	if ( p->result_index >= N_HUNYAPIYO3_MAP_ALL )
	{
		p->phase = N_HUNYAPIYO3_PHASE_PERC;

		n_bmp_flush_fastcopy( &game.bmp, &p->bmp_result );

		int percent = (int) ( (n_type_real) p->score / N_HUNYAPIYO3_MAP_ALL * 100 );
		n_hunyapiyo3_gdi_percent( p, &p->bmp_percent, percent, p->message_font_size, p->contour_size );

		if ( p->score == N_HUNYAPIYO3_MAP_ALL ) { p->is_fanfare = n_true; }
	}

//n_posix_debug_literal( "%d/%d", p->score, N_HUNYAPIYO3_MAP_ALL );


	return;
}

void
n_hunyapiyo3_answer_single( n_hunyapiyo3 *p, n_type_gfx x, n_type_gfx y )
{

	n_bool redraw = n_false;
	u32    color1 = 0;
	u32    color2 = 0;

	int pos = x + ( N_HUNYAPIYO3_MAP_SX * y );
	if ( p->ret[ pos ] == p->map[ pos ] )
	{
		//
	} else
	if ( p->prv[ pos ] == -2 )
	{
		p->prv[ pos ] = p->map[ pos ];

		redraw = n_true;
		color2 = n_bmp_white_invisible;
	} else
	if ( p->prv[ pos ] == p->ret[ pos ] )
	{
		p->prv[ pos ] = p->map[ pos ];

		redraw = n_true;
		color2 = n_bmp_white_invisible;
	} else
	if ( p->prv[ pos ] == p->map[ pos ] )
	{
		p->prv[ pos ] = p->ret[ pos ];

		redraw = n_true;
		color1 = N_HUNYAPIYO3_COLOR_MIXER_X;
		color2 = N_HUNYAPIYO3_COLOR_FRAME_X;
	}

	if ( redraw )
	{
		n_type_gfx pxl_x = p->unit * x;
		n_type_gfx pxl_y = p->unit * y;

		//n_bmp_box( &p->bmp_result, pxl_x,pxl_y,p->unit,p->unit, p->color_bg );
		n_bmp_fastcopy( &p->bmp_bg, &p->bmp_result, pxl_x,pxl_y,p->unit,p->unit, pxl_x,pxl_y );

		n_hunyapiyo3_draw_single( p, &p->bmp_result, p->prv[ pos ], pxl_x, pxl_y );

		if ( color1 != 0 )
		{
			n_bmp_mixer( &p->bmp_result, pxl_x,pxl_y,p->unit,p->unit, color1, 0.25 );
		}

		n_hunyapiyo3_frame( p, &p->bmp_result, pxl_x,pxl_y, p->color_frame, color2 );

		n_bmp_fastcopy( &p->bmp_result, &game.bmp, pxl_x,pxl_y,p->unit,p->unit, pxl_x,pxl_y );
	}


	return;
}

void
n_hunyapiyo3_percent( n_hunyapiyo3 *p )
{

	n_type_gfx cursor_x, cursor_y; n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );

	if (
		( ( cursor_x >= 0 )&&( cursor_x < p->sx ) )
		&&
		( ( cursor_y >= 0 )&&( cursor_y < p->sy ) )
	)
	{

		if ( n_game_click_single( &p->click_l ) )
		{

			n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_CLICK ] );

			int x = 0;
			int y = 0;
			n_posix_loop
			{

				n_hunyapiyo3_answer_single( p, x,y );

				x++;
				if ( x >= N_HUNYAPIYO3_MAP_SX )
				{
					x = 0;
					y++;
					if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
				}
			}

		}

	}

	{

		int x = 0;
		int y = 0;
		n_posix_loop
		{

			n_type_gfx pxl_x = p->unit * x;
			n_type_gfx pxl_y = p->unit * y;

			if (
				( ( cursor_x >= pxl_x )&&( cursor_x < ( pxl_x + p->unit ) ) )
				&&
				( ( cursor_y >= pxl_y )&&( cursor_y < ( pxl_y + p->unit ) ) )
			)
			{
				if ( n_game_click_single( &p->click_r ) )
				{
					n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_CLICK ] );
					n_hunyapiyo3_answer_single( p, x,y );
				}
			}

			x++;
			if ( x >= N_HUNYAPIYO3_MAP_SX )
			{
				x = 0;
				y++;
				if ( y >= N_HUNYAPIYO3_MAP_SY ) { break; }
			}
		}

	}


	n_type_gfx sx = N_BMP_SX( &p->bmp_percent );
	n_type_gfx sy = N_BMP_SY( &p->bmp_percent );

	n_bmp_fastcopy( &p->bmp_result, &game.bmp, p->px,p->py,sx,sy, p->px,p->py );


	n_bool ret = n_hunyapiyo3_button( p, &p->ok_hover_onoff, &p->bmp_ok, N_HUNYAPIYO3_OK );
	if ( ret )
	{

		hunyapiyo3.phase = N_HUNYAPIYO3_PHASE_CLCK;

		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_CLICK ] );

		//n_bmp_flush( &game.bmp, p->color_bg );
		n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

		n_game_refresh_on();
		return;

	}


	n_type_gfx  x = n_game_centering( game.sx, sx );
	n_type_gfx  y = n_game_centering( game.sy, sy );
//n_bmp_save_literal( &p->bmp_message, "ret.bmp" );

	if (
		( ( cursor_x >= x )&&( cursor_x < ( x + sx ) ) )
		&&
		( ( cursor_y >= y )&&( cursor_y < ( y + sy ) ) )
	)
	{

		//

	} else {

		y = n_hunyapiyo3_text_jump( p, y, sy / 2, 25, 0.01 );

		n_bmp_transcopy( &p->bmp_percent, &game.bmp, 0,0,sx,sy, x,y );

	}

	p->px = x;
	p->py = y;


	n_game_refresh_on();
	return;
}




#define n_hunyapiyo3_zero( p ) n_memory_zero( p, sizeof( n_hunyapiyo3 ) )

void
n_hunyapiyo3_init( n_hunyapiyo3 *p )
{

	// Global

	n_bmp_safemode = n_false;


	n_project_darkmode();
	n_win_darkmode_hwnd( game.hwnd, n_win_darkmode_onoff );


	// Metrics

	n_hunyapiyo3_metrics( p );


	// System

	n_game_title( N_HUNYAPIYO3_APPNAME );

	game.sx       = p->sx;
	game.sy       = p->sy + p->bar;
	game.fps      = 30;
	game.color    = p->color_bg;
	game.on_event = n_hunyapiyo3_on_event;


	n_game_window_fixed();


	//n_hmidiout_init();


	n_game_dwm_onoff();


	// Resources

	n_game_rc_load_bmp_literal( &p->bmp[ 0 ], "HUNYAPIYO3_BMP_0" );
	n_game_rc_load_bmp_literal( &p->bmp[ 1 ], "HUNYAPIYO3_BMP_1" );
	n_game_rc_load_bmp_literal( &p->bmp[ 2 ], "HUNYAPIYO3_BMP_2" );
	n_game_rc_load_bmp_literal( &p->bmp[ 3 ], "HUNYAPIYO3_BMP_3" );
	n_game_rc_load_bmp_literal( &p->bmp[ 4 ], "HUNYAPIYO3_BMP_4" );

	p->zoom = (n_type_gfx) ( (n_type_real) p->unit * 0.66 ) / N_BMP_SX( &p->bmp[ 0 ] );

	n_bmp_scaler_big( &p->bmp[ 0 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 1 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 2 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 3 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 4 ], p->zoom );

	p->question_size = N_BMP_SX( &p->bmp[ 0 ] );

	{

		int i = 0;
		n_posix_loop
		{

			n_bmp_resizer( &p->bmp[ i ], p->unit,p->unit, n_bmp_black, N_BMP_RESIZER_CENTER );

			i++;
			if ( i >= N_HUNYAPIYO3_BMP_ALL ) { break; }
		}

		n_hunyapiyo3_gdi_question( p, &p->bmp_question, p->unit, p->question_size, p->contour_size );

	}


	n_game_sound_bulk_zero( p->snd, N_HUNYAPIYO3_WAV_ALL );

	n_game_sound_init_literal( &p->snd[ 0 ], game.hwnd,  HUNYAPIYO3_WAV_0  );
	n_game_sound_init_literal( &p->snd[ 1 ], game.hwnd,  HUNYAPIYO3_WAV_1  );
	n_game_sound_init_literal( &p->snd[ 2 ], game.hwnd, "HUNYAPIYO3_WAV_2" );
	n_game_sound_init_literal( &p->snd[ 3 ], game.hwnd, "HUNYAPIYO3_WAV_3" );
	n_game_sound_init_literal( &p->snd[ 4 ], game.hwnd, "HUNYAPIYO3_WAV_4" );
	n_game_sound_init_literal( &p->snd[ 5 ], game.hwnd, "HUNYAPIYO3_WAV_5" );
	n_game_sound_init_literal( &p->snd[ 6 ], game.hwnd, "HUNYAPIYO3_WAV_6" );

	{

		int i = 0;
		n_posix_loop
		{

			n_wav_smoother( &p->snd[ i ].wav );

			i++;
			if ( i >= N_HUNYAPIYO3_WAV_ALL ) { break; }
		}

	}


	// Init

//n_game_title_literal( "Click!" );

	n_game_click_init( &p->click_l, VK_LBUTTON );
	n_game_click_init( &p->click_r, VK_RBUTTON );


	n_hunyapiyo3_gdi_background( p, &p->bmp_bg );
	n_hunyapiyo3_gdi_clickhere( p, &p->bmp_clickhere, p->message_font_size, p->contour_size );


	n_bmp_new( &p->bmp_result, game.sx, game.sy );


	p->is_first = n_true;


	return;
}

void
n_hunyapiyo3_exit( n_hunyapiyo3 *p )
{

	{

		int i = 0;
		n_posix_loop
		{

			n_bmp_free( &p->bmp[ i ] );

			i++;
			if ( i >= N_HUNYAPIYO3_BMP_ALL ) { break; }
		}

	}

	{

		int i = 0;
		n_posix_loop
		{

			n_game_sound_exit( &p->snd[ i ] );

			i++;
			if ( i >= N_HUNYAPIYO3_WAV_ALL ) { break; }
		}

	}


	n_bmp_free( &p->bmp_bg        );
	n_bmp_free( &p->bmp_clickhere );
	n_bmp_free( &p->bmp_message   );
	n_bmp_free( &p->bmp_question  );
	n_bmp_free( &p->bmp_percent   );
	n_bmp_free( &p->bmp_go        );
	n_bmp_free( &p->bmp_ok        );
	n_bmp_free( &p->bmp_result    );


	//n_hmidiout_exit();


	//n_memory_debug_refcount();


	return;
}

void
n_hunyapiyo3_loop( n_hunyapiyo3 *p )
{

	if ( n_game_refresh_is_on() ) { return; }


	if ( p->phase == N_HUNYAPIYO3_PHASE_CLCK )
	{

		n_hunyapiyo3_clickhere( p );

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_STRT )
	{
//n_game_hwndprintf_literal( "3" );

		p->phase       = N_HUNYAPIYO3_PHASE_CD_3;
		p->phase_timer = n_posix_tickcount();

		//n_hmidiout_all( 0, 55, N_HMIDIOUT_PANPOT_LEFT , 72, 80 );
		//n_hmidiout_all( 1, 55, N_HMIDIOUT_PANPOT_RIGHT, 72, 80 );
		n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_COUNTDOWN_3 ] );

		//n_bmp_flush( &game.bmp, p->color_bg );
		n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_CD_3 )
	{

		if ( n_game_timer( &p->phase_timer, 1000 ) )
		{
//n_game_hwndprintf_literal( "2" );

			p->phase       = N_HUNYAPIYO3_PHASE_CD_2;
			p->phase_timer = n_posix_tickcount();

			p->countdown_font_size = 0;

			//n_hmidiout_all( 0, 55, N_HMIDIOUT_PANPOT_LEFT , 74, 100 );
			//n_hmidiout_all( 1, 55, N_HMIDIOUT_PANPOT_RIGHT, 74, 100 );
			n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_COUNTDOWN_2 ] );

			//n_bmp_flush( &game.bmp, p->color_bg );
			n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

		} else {

			p->countdown_font_size += p->countdown_font_size_unit;
			n_hunyapiyo3_countdown( p, 3 );

		}

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_CD_2 )
	{

		if ( n_game_timer( &p->phase_timer, 1000 ) )
		{
//n_game_hwndprintf_literal( "1" );

			p->phase       = N_HUNYAPIYO3_PHASE_CD_1;
			p->phase_timer = n_posix_tickcount();

			p->countdown_font_size = 0;

			//n_hmidiout_all( 0, 55, N_HMIDIOUT_PANPOT_LEFT , 76, 120 );
			//n_hmidiout_all( 1, 55, N_HMIDIOUT_PANPOT_RIGHT, 76, 120 );
			n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_COUNTDOWN_1 ] );

			//n_bmp_flush( &game.bmp, p->color_bg );
			n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

		} else {

			p->countdown_font_size += p->countdown_font_size_unit;
			n_hunyapiyo3_countdown( p, 2 );

		}

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_CD_1 )
	{

		if ( n_game_timer( &p->phase_timer, 1000 ) )
		{
//n_game_hwndprintf( N_HUNYAPIYO3_APPNAME );

			p->phase       = N_HUNYAPIYO3_PHASE_CD_0;
			p->phase_timer = n_posix_tickcount();

			p->countdown_font_size = 0;

			//n_hmidiout_all( 0, 55, N_HMIDIOUT_PANPOT_LEFT , 0, 0 );
			//n_hmidiout_all( 1, 55, N_HMIDIOUT_PANPOT_RIGHT, 0, 0 );

			//n_bmp_flush( &game.bmp, p->color_bg );
			n_bmp_flush_fastcopy( &p->bmp_bg, &game.bmp );

		} else {

			p->countdown_font_size += p->countdown_font_size_unit;
			n_hunyapiyo3_countdown( p, 1 );

		}

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_CD_0 )
	{

		n_hunyapiyo3_short_term_memory( p );

		p->phase       = N_HUNYAPIYO3_PHASE_INIT;
		p->phase_timer = n_posix_tickcount();
		p->progress    = p->phase_timer;

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_INIT )
	{

		if ( n_game_timer( &p->phase_timer, N_HUNYAPIYO3_SHORTTERM_MSEC ) )
		{
			p->phase = N_HUNYAPIYO3_PHASE_MAIN;
		}

//n_game_hwndprintf_literal( " %f ", (n_type_real) ( n_posix_tickcount() - p->progress ) / N_HUNYAPIYO3_SHORTTERM_MSEC );
		n_hunyapiyo3_progressbar( p, (n_type_real) ( n_posix_tickcount() - p->progress ) / N_HUNYAPIYO3_SHORTTERM_MSEC );

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_MAIN )
	{

		n_hunyapiyo3_main( p );

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_RSLT )
	{

		if ( n_game_timer( &p->result_timer, N_HUNYAPIYO3_RESULT_MSEC ) )
		{
			n_hunyapiyo3_result( p );
		}

	} else
	if ( p->phase == N_HUNYAPIYO3_PHASE_PERC )
	{

		if ( p->is_fanfare )
		{
			p->is_fanfare = n_false;
			n_game_sound_loop( &p->snd[ N_HUNYAPIYO3_SOUND_FANFARE ] );
		}

		n_hunyapiyo3_percent( p );

	} // else


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_hunyapiyo3_zero( &hunyapiyo3 );
	n_hunyapiyo3_init( &hunyapiyo3 );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_hunyapiyo3_exit( &hunyapiyo3 );
		n_hunyapiyo3_init( &hunyapiyo3 );
		n_game_reset();
	}

	n_hunyapiyo3_loop( &hunyapiyo3 );


	return;
}

void
n_game_exit( void )
{

	n_hunyapiyo3_exit( &hunyapiyo3 );


	return;
}

#endif // #ifndef N_GAMECONSOLE

