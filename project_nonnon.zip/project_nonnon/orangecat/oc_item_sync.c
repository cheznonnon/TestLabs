// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_oc_item_sync_exit( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	n_memory_free( p->sync_item );
	n_memory_free( p->sync_type );

	p->sync_item   = NULL;
	p->sync_type   = NULL;
	p->sync_index  = 0;
	p->sync_timer  = 0;


	n_memory_free( p->load_item );

	p->load_item   = NULL;
	p->load_index  = 0;
	p->load_count  = 0;
	p->load_timer  = 0;


	return;
}

u32
n_oc_item_sync_count( n_oc_item *p )
{

	u32 ret = 0;

	if ( oc.view_is_computer )
	{

		n_posix_char name[ 100 ]; n_string_copy_literal( "A:\\", name );

		int i = 0;
		while( 1 )
		{

			u32 info_cur = n_sysinfo_drive_info( name );
			u32 type_cur = n_sysinfo_drive_type( name );

			if ( ( info_cur != 0 )&&( type_cur != 0 ) ) { ret++; }

			name[ 0 ]++;

			i++;
			if ( i >= 26 ) { break; }
		}

		ret += p->count_fake;

	} else {

		ret = n_posix_folder_count( oc.main );

	}


	return ret;
}

void
n_oc_sync_load_count_check( n_oc_item *p )
{

	p->load_count = 0;

	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->load_item[ i ] == N_ORANGECAT_LOAD_DONE )
		{
			p->load_count++;
		}

		i++;
	}


	return;
}

n_bool
n_oc_item_sync_is_name_changed( n_oc_item *p, const n_posix_char *path, int index )
{

	WIN32_FIND_DATA f; ZeroMemory( &f, sizeof( WIN32_FIND_DATA ) );
	FindClose( FindFirstFile( path, &f ) );


	n_posix_char *str = n_string_path_name_new( path );


	n_bool ret = ( n_false == n_string_is_same_strict( f.cFileName, str ) );


	if ( ret ) { n_vector_mod( &p->dir.name, index, f.cFileName ); }

//if ( ret ) { n_posix_debug_literal( "%s\n%s", f.cFileName, str ); }
//ret = n_false;

	n_string_path_free( str );


	return ret;
}

void
n_oc_item_sync_forcesync( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	n_memory_zero( p->sync_item, p->count * sizeof( int ) );

	p->sync_index = p->sync_timer = 0;


	if ( p->count == 0 ) { n_oc_item_init( p ); }


	return;
}

void
n_oc_item_sync_init( n_oc_item *p )
{

	// [!] : use n_oc_item_sync_reset() to initialaize members


	if ( n_oc_item_error( p ) ) { return; }


	n_oc_item_sync_exit( p );


	p->sync_item = n_memory_new( p->count * sizeof( int ) );
	p->sync_type = n_memory_new( p->count * sizeof( int ) );
	p->load_item = n_memory_new( p->count * sizeof( int ) );


	return;
}

void
n_oc_item_sync_reset( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->sync_item == NULL ) { return; }


	if ( oc.view_is_computer )
	{

		int i = 0;
		while( 1 )
		{

			n_posix_char *name = n_oc_item_index2path_new( p, i );

			if ( ( i >= 0 )&&( i < 26 ) )
			{
				p->sync_item[ i ] = n_sysinfo_drive_info( name );
				p->sync_type[ i ] = n_sysinfo_drive_type( name );
			} else {
				p->sync_item[ i ] = n_posix_stat_mtime  ( name );
			}
			p->load_item[ i ] = N_ORANGECAT_LOAD_NONE;

			n_string_path_free( name );

			i++;
			if ( i >= p->count ) { break; }
		}

	} else {

		int i = 0;
		while( 1 )
		{

			if ( i >= p->count ) { break; }


			n_posix_char *name = n_oc_item_index2path_new( p, i );

			p->sync_item[ i ] = n_posix_stat_mtime( name );
			p->load_item[ i ] = N_ORANGECAT_LOAD_NONE;

			n_string_path_free( name );


			i++;

		}

	}


	p->sync_index  = 0;
	p->sync_timer  = n_posix_tickcount();

	p->load_index  = 0;
	p->load_count  = 0;
	p->load_timer  = n_posix_tickcount();


	return;
}

void
n_oc_item_sync_resync( n_oc_item *p, int index )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->sync_item == NULL ) { return; }


	n_posix_char *name = n_oc_item_index2path_new( p, index );

	if ( oc.view_is_computer )
	{
		if ( ( index >= 0 )&&( index < 26 ) )
		{
			p->sync_item[ index ] = n_sysinfo_drive_info( name );
			p->sync_type[ index ] = n_sysinfo_drive_type( name );
		} else {
			p->sync_item[ index ] = n_posix_stat_mtime  ( name );
		}
	} else {
		p->sync_item[ index ] = n_posix_stat_mtime( name );
	}

	n_string_path_free( name );


	return;
}

void
n_oc_item_sync_image( n_oc_item *p, int index, u32 interval, n_bool is_replace, n_bool redraw )
{
//return;

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->load_item == NULL ) { return; }


	if ( ( index < 0 )||( index >= p->count ) ) { return; }


	if ( p->load_item[ index ] == N_ORANGECAT_LOAD_DONE )
	{

		if ( is_replace )
		{
			p->load_count--;
			p->load_item[ index ] = N_ORANGECAT_LOAD_NONE;
		}

	}


	// [x] : thread : items aren't loaded

	p->load_index = index;
	n_oc_item_preload_silent( p, index, redraw );


	// [!] : don't use : for speeding up
	//n_oc_event_redraw();


	return;
}

#define n_oc_item_sync_add( p, d, focus ) n_oc_item_sync_adddel( p, d, n_true , focus   )
#define n_oc_item_sync_del( p, d        ) n_oc_item_sync_adddel( p, d, n_false, n_false )

n_bool
n_oc_item_sync_adddel( n_oc_item *p, n_dir *newdir, n_bool is_add, n_bool focus )
{

	if ( n_oc_item_error( p ) ) { return n_false; }


	n_dir *f_dir;
	n_dir *t_dir;

	if ( is_add )
	{
		f_dir =  newdir;
		t_dir = &p->dir;
	} else {
		f_dir = &p->dir;
		t_dir =  newdir;
	}

	if ( 0 == n_dir_all( f_dir ) ) { return n_false; }

	if ( 0 == n_dir_all( t_dir ) )
	{
		n_oc_event_init();
		return n_false;
	}


	s64     focus_cb  =    0;
	n_bool *focus_ptr = NULL;

	if ( focus )
	{
		focus_cb  = n_dir_all( f_dir ) * sizeof( n_bool );
		focus_ptr = n_memory_new_closed( focus_cb );
		n_memory_zero( focus_ptr, focus_cb );
	}


	n_bool is_found = n_false;
	n_bool refresh  = n_false;

	s64 f = 0;
	s64 t = 0;
	while( 1 )
	{

		n_posix_char *f_str = n_dir_name( f_dir, f );
		n_posix_char *t_str = n_dir_name( t_dir, t );

		if ( n_string_is_same( f_str, t_str ) )
		{
			is_found = n_true;
			t = n_dir_all( t_dir ) - 1;
		}

		t++;
		if ( t >= n_dir_all( t_dir ) )
		{

			t = 0;


			if ( is_found )
			{

				is_found = n_false;

			} else {

				refresh = n_true;

				if ( is_add )
				{
					n_oc_item_add( p, f_str );
					if ( focus ) { focus_ptr[ f ] = n_true; }
				} else {
					n_oc_item_del( p, f ); f--;
				}

			}


			f++;
			if ( f >= n_dir_all( f_dir ) ) { break; }
		}
	}

//n_game_hwndprintf_literal( " %d : %d ", oc.view_is_key_operation, n_oc_item_multifocus_count( p ) );
	if ( ( is_add == n_false )&&( refresh ) )
	{
		if ( oc.view_is_key_operation )
		{
			if ( ( p->count != 0 )&&( 0 == n_oc_item_multifocus_count( p ) ) )
			{
				p->multifocus[ 0 ] = n_true;
				n_oc_item_autoscroll( p, 0, N_OC_ITEM_AUTOSCROLL_CENTERING );
			}
		}
	}


	if ( ( is_add )&&( focus )&&( refresh ) )
	{

		n_oc_item_multifocus_off_all( p );
		n_oc_item_multifocus_forced_fade_off( p );

		int i = 0;
		while( 1 )
		{
			if ( i >= n_dir_all( f_dir ) ) { break; }

			if ( focus_ptr[ i ] )
			{
				n_oc_item_multifocus_path2focus_light( p, n_dir_name( f_dir, i ), n_true, n_true );
			}

			i++;
		}

	}

	n_memory_free_closed( focus_ptr );


	return refresh;
}

void
n_oc_item_sync_fast( n_oc_item *p, int index )
{

	// [!] : this modulue is called from oc_info.c rename only


	if ( n_oc_item_error( p ) ) { return; }

	if ( ( index < 0 )||( index >= p->count ) ) { return; }


	// [Needed] : n_oc_item_gdi2bitmap() adds load_count

	p->load_count--;


	n_bmp_free( &p->bmp[ index ] );

	p->load_item[ index ] = N_ORANGECAT_LOAD_MAIN;
	n_oc_item_gdi2bitmap( p, index );


	p->hover = N_ORANGECAT_NOTHING;


	n_oc_item_sort_go( p );


	n_oc_event_redraw_fast();
	return;
}

void
n_oc_item_sync_go_computer( n_oc_item *p )
{
//n_game_hwndprintf_literal( " %d ", p->sync_index );


	if ( oc.view_is_computer == n_false ) { return; }


	while( 1 )
	{

		n_posix_char *name = n_oc_item_index2path_new( p, p->sync_index );
//n_posix_debug_literal( " %s ", name );

		if ( ( p->sync_index >= 0 )&&( p->sync_index < 26 ) )
		{

			int info_cur = n_sysinfo_drive_info( name );
			int type_cur = n_sysinfo_drive_type( name );

			if (
				( p->sync_item[ p->sync_index ] != info_cur )
				||
				( p->sync_type[ p->sync_index ] != type_cur )
			)
			{
				p->sync_item[ p->sync_index ] = info_cur;
				p->sync_type[ p->sync_index ] = type_cur;
			}

			n_string_path_free( name );

			p->sync_index++;
			if ( p->sync_index >= p->count ) { p->sync_index = 0; }

			if ( ( info_cur == 0 )&&( type_cur == 0 ) )
			{
				//
			} else {
				break;
			}

		} else {

			int info_cur = n_posix_stat_mtime( name );

			if ( p->sync_item[ p->sync_index ] != info_cur )
			{
				p->sync_item[ p->sync_index ] = info_cur;
			}

			n_string_path_free( name );

			p->sync_index++;
			if ( p->sync_index >= p->count ) { p->sync_index = 0; }

			break;

		}

	}


	return;
}

void
n_oc_item_sync_go_item( n_oc_item *p )
{

	// [!] : comment-out for performance

	//if ( n_oc_item_error( p ) ) { return n_false; }


	if ( oc.view_is_computer ) { return; }


	n_posix_char *name = n_oc_item_index2path_new( p, p->sync_index );

	if ( n_posix_stat_is_exist( name ) )
	{
//n_game_hwndprintf_literal( " exist " );

		int mtime_prv = p->sync_item[ p->sync_index ];
		int mtime_cur = n_posix_stat_mtime( name );

		if ( ( mtime_prv != mtime_cur )||( n_oc_item_sync_is_name_changed( p, name, p->sync_index ) ) )
		{
			n_oc_item_sync_image( p, p->sync_index, 0, n_true, n_true );
		}

		p->sync_item[ p->sync_index ] = mtime_cur;

		p->sync_index++;
		if ( p->sync_index >= p->count ) { p->sync_index = 0; }

	} else {
//n_game_hwndprintf_literal( " not exist " );
	}

	n_string_path_free( name );


	return;
}

#define n_oc_item_sync_go_view(        p, b ) n_oc_item_sync_go_view_internal( p, n_false, b )
#define n_oc_item_sync_go_view_forced( p, b ) n_oc_item_sync_go_view_internal( p, n_true , b )

void
n_oc_item_sync_go_view_internal( n_oc_item *p, n_bool is_forced, n_bool add_focus )
{

	// [!] : ( p->count == 0 ) is acceptable here

	u32 new_count = n_oc_item_sync_count( p );

//n_game_hwndprintf_literal( " %d : %d ", p->count, new_count );

	if ( ( p->count != new_count )||( is_forced ) )
	{
//return n_false;
//n_game_hwndprintf_literal( " %d : %d ", p->count, new_count );

		n_dir dir; n_dir_zero( &dir ); n_oc_item_dir_load( p, &dir );

		n_bool refresh_del = n_oc_item_sync_del( p, &dir            );
		n_bool refresh_add = n_oc_item_sync_add( p, &dir, add_focus );

		n_dir_free( &dir );


		n_bool refresh = refresh_del | refresh_add;
		if ( refresh )
		{

			extern void n_oc_item_on_resize( n_oc_item* );
			n_oc_item_on_resize( p );

			n_oc_event_redraw_fast();

		}

	} else {
//n_game_hwndprintf_literal( " Sync : Modify " );

		if ( p->drag2select_onoff == n_false )
		{

			if ( oc.view_is_computer )
			{
				n_oc_item_sync_go_computer( p );
			} else {
				n_oc_item_sync_go_item    ( p );
			}

		}

	}


	return;
}

#define n_oc_item_sync_go(        p ) n_oc_item_sync_go_internal( p, n_false )
#define n_oc_item_sync_go_forced( p ) n_oc_item_sync_go_internal( p, n_true  )

n_bool
n_oc_item_sync_go_internal( n_oc_item *p, n_bool is_forced )
{

	if ( n_oc_item_error( p ) ) { return n_false; }

	if ( oc.view == N_ORANGECAT_VIEW_INFO ) { return n_false; }


	if ( p->find_onoff )
	{

		if ( p->sync_item == NULL ) { return n_false; }

		n_oc_item_sync_go_item( p );

	} else {

		if ( is_forced )
		{
//n_game_hwndprintf_literal( " Sync : Forced " );
			n_oc_item_sync_go_view_forced( p, n_true );
		} else {
//n_game_hwndprintf_literal( " Sync " );
			n_oc_item_sync_go_view( p, n_true );
		}

	}


	return n_oc_event_is_busy();
}

void
n_oc_item_sync_on_delete( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count == 0 ) { return; }

	if ( p->sync_item == NULL ) { return; }

	if ( oc.view == N_ORANGECAT_VIEW_INFO ) { return; }


	if ( p->find_onoff )
	{
//n_posix_debug_literal( " ! " );

		n_bool redraw = n_false;

		int i = p->count - 1;
		while( 1 )
		{

			if ( p->multifocus[ i ] )
			{
				n_oc_item_del( p, i );
				redraw = n_true;
			}

			i--;
			if ( i < 0 ) { break; }
		}

		p->sync_index = 0;

		if ( redraw ) { n_oc_event_redraw(); }

	} else {
//n_game_hwndprintf_literal( " Sync " );

		n_oc_item_sync_go_view( p, n_true );

	}


	return;
}

void
n_oc_item_sync_event( n_oc_item *p )
{
//return;

 	// [!] : an empty folder is acceptable here

	if ( n_oc_item_error( p ) ) { return; }
	if ( p->recyclebin        ) { return; }

	if ( oc.view != N_ORANGECAT_VIEW_FILE ) { return; }


//n_game_hwndprintf_literal( " %d / %d ", p->load_count, p->count );


	// [!] : when a memory drive is unplugged

	n_posix_char *name = n_string_path_slash_new( oc.main ); n_string_path_drivename_slash_add( name );

	if (
		( n_false == n_string_is_same( N_ORANGECAT_COMPUTER, name ) )
		&&
		( n_false == n_posix_stat_is_exist( name ) )
	)
	{
//n_posix_debug_literal( " %s ", name );
		n_string_path_free( name );

		n_oc_navigate( N_ORANGECAT_COMPUTER );

		return;
	}

	n_string_path_free( name );


	if ( n_oc_event_is_busy() ) { return; }


	if ( p->progress_sync.onoff ) { return; }
	if ( p->progress_copy.onoff ) { return; }


	if ( p->load_count != p->count )
	{
//n_game_hwndprintf_literal( " %d ", oc.view_hover );

		extern void n_oc_sync_thread_go( void );
		n_oc_sync_thread_go();


		// [!] : this function is very heavy

		n_oc_item_sync_go( p );


		if (
			( p->hover != N_ORANGECAT_NOTHING )
			&&
			( n_false == p->multifocus[ p->hover ] )
			&&
			( p->load_item[ p->hover ] != N_ORANGECAT_LOAD_DONE )
		)
		{
			n_oc_item_sync_image( p, p->hover, 0, n_false, n_true );
			n_bmp_fade_init( &p->fade[ p->hover ], oc_color.item_hover );
		}

	} else {

		if ( n_game_timer( &p->sync_timer, N_ORANGECAT_INTERVAL_SYNC ) )
		{

			s32 f,t; n_oc_item_scan_index( &item, &f, &t, n_false );


			// [!] : outer screen only

			if ( p->scroll_item_per_page < p->count )
			{
				if ( ( p->sync_index >= f )&&( p->sync_index <= t ) )
				{

					p->sync_index = t + 1;
					if ( p->sync_index >= p->count )
					{
						p->sync_index = 0;
					}

				} else {

					n_oc_item_sync_go( p );
//n_game_hwndprintf_literal( " %d : %d %d ", p->sync_index, f, t );

					if ( oc.debug_sync )
					{
						n_bmp_fade_go( &p->fade[ p->sync_index ], n_bmp_rgb( 0, 200, 255 ) );
						n_oc_item_draw_single( p, p->sync_index, n_false );
					}

				}
			}


			// [!] : inner screen only

			s32 prv_sync_index = p->sync_index;
			     p->sync_index = p->sync_index_inner;

			if ( p->sync_index < f ) { p->sync_index = f; }
			if ( p->sync_index > t ) { p->sync_index = f; }

			n_oc_item_sync_go( p );
//n_game_hwndprintf_literal( " %d : %d %d ", p->sync_index, f, t );

			if ( oc.debug_sync )
			{
				n_bmp_fade_go( &p->fade[ p->sync_index ], n_bmp_rgb( 255,  0, 128 ) );
				n_oc_item_draw_single( p, p->sync_index, n_false );
			}

			p->sync_index_inner = p->sync_index;
			p->sync_index       = prv_sync_index;

		}

		if ( ( oc.debug_benchmark_onoff )&&( oc.debug_benchmark_timer != 0 ) )
		{
n_game_hwndprintf_literal( " %d ", (int) n_posix_tickcount() - oc.debug_benchmark_timer );
//n_game_hwndprintf_literal( " %d ", oc.unit__bpp );
//n_game_hwndprintf_literal( " %d ", n_win_darkmode_onoff );
			oc.debug_benchmark_timer = 0;
		}

	}


//n_game_hwndprintf_literal( " Loaded : %d / %d ", p->load_count, p->count );


	return;
}

