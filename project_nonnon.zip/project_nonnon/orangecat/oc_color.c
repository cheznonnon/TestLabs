// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_ORANGECAT_COLOR_BLACK  n_bmp_rgb(  10, 10, 10 )




typedef struct {

	u32 bg;

	u32 path_text;
	u32 path_bg;
	u32 path_press;
	u32 path_hover;
	u32 path_drop;
	u32 path_frame1;
	u32 path_frame2;
	u32 path_luna;

	u32 item_text;
	u32 item_hover;
	u32 item_focus;
	u32 item_key_i;
	u32 item_key_o;
	u32 item_zebra;
	u32 item_shadow;
	u32 item_select;
	u32 item_gauge;
	u32 item_copy;

	u32 info_bg_1;
	u32 info_bg_2;

} n_oc_color;


static n_oc_color oc_color;




// internal
void
n_oc_color_debug( u32 color )
{

	n_posix_debug_literal
	(
		"%d %d %d %d",
		n_bmp_a( color ),
		n_bmp_r( color ),
		n_bmp_g( color ),
		n_bmp_b( color )
	);


	return;
}

n_bool
n_oc_color_is_same( u32 color1, u32 color2 )
{

	// [!] : alpha will be skipped

	int r1 = n_bmp_r( color1 );
	int g1 = n_bmp_g( color1 );
	int b1 = n_bmp_b( color1 );

	int r2 = n_bmp_r( color2 );
	int g2 = n_bmp_g( color2 );
	int b2 = n_bmp_b( color2 );


	return ( ( r1 == r2 )&&( g1 == g2 )&&( b1 == b2 ) );
}




u32
n_oc_color_system( int color_name )
{

	u32 color = n_gdi_systemcolor( color_name );


	if ( color_name == COLOR_ACTIVECAPTION )
	{
		color = n_win_dwm_windowcolor_arranged();

/*
		// [!] : this will be a color of wallpaper

		HWND hwnd = GetActiveWindow();

		HDC hdc = GetWindowDC( hwnd );
		int m   = GetSystemMetrics( SM_CXSIZEFRAME );

		color = n_bmp_colorref2argb( GetPixel( hdc, m,m ) );

		ReleaseDC( hwnd, hdc );
*/
	}


	if ( n_oc_color_is_same( color, n_bmp_black ) )
	{
		color = N_ORANGECAT_COLOR_BLACK;
	}


	return n_bmp_alpha_visible_pixel( color );
}




u32
n_oc_color_highlight( void )
{
	return n_oc_color_system( COLOR_ACTIVECAPTION );
}

u32
n_oc_color_background( u32 bg, u32 fg )
{

	bg = n_bmp_alpha_invisible_pixel( bg );
	fg = n_bmp_alpha_invisible_pixel( fg );

	return n_bmp_blend_pixel( bg, fg, 0.5 );
}




u32
n_oc_color_dwm_textshadow( void )
{

	u32 bg = n_oc_color_system( COLOR_ACTIVECAPTION );
	u32 fg = N_ORANGECAT_COLOR_BLACK;


	n_type_real coeff = 0.0;

	{

		u32 color = n_bmp_argb2ahsl( bg );

		int l = n_bmp_lightness( color );

		coeff = (n_type_real) l / 255;

//n_posix_debug_literal( "%d : %f", l, coeff );
	}


	return n_bmp_blend_pixel( bg, fg, coeff * 1.75 );
}




u32
n_oc_color_path_hover( void )
{
	return n_oc_color_highlight();
}

u32
n_oc_color_path_drop( n_type_real ratio )
{

	// [!] : old orange color

	//return n_bmp_blend_pixel( n_oc_color_highlight(), n_bmp_rgb( 255,128,0 ), ratio );


	u32 color = n_bmp_argb2ahsl( n_oc_color_system( COLOR_ACTIVECAPTION ) );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	h -= 115;

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_path_luna( void )
{

	u32 bg = n_oc_color_system( COLOR_3DDKSHADOW );
	u32 fg = n_oc_color_highlight();

	return n_bmp_blend_pixel( bg, fg, 0.5 );
}




u32
n_oc_color_item_hover( void )
{

	u32 color;

	if ( oc.dwm_onoff )
	{

		// [!] : I don't know the better way

		u32 fg = n_oc_color_system( COLOR_CAPTIONTEXT   );
		u32 bg = n_oc_color_system( COLOR_ACTIVECAPTION );

		color = n_bmp_blend_pixel( bg, fg, 0.5 );

	} else {

		color = n_oc_color_highlight();

	}


	return color;
}




u32
n_oc_color_aero_path_bg( void )
{

	u32 fg = n_oc_color_system( COLOR_ACTIVECAPTION );
	u32 bg = N_ORANGECAT_COLOR_BLACK;
//n_oc_color_debug( fg );
//n_oc_color_debug( bg );
	return n_bmp_blend_pixel( bg, fg, 0.50 );
}

u32
n_oc_color_aero_path_press( void )
{

	u32 fg = n_oc_color_system( COLOR_ACTIVECAPTION );
	u32 bg = N_ORANGECAT_COLOR_BLACK;

	return n_bmp_blend_pixel( bg, fg, 0.33 );
}

u32
n_oc_color_aero_hover( void )
{

	u32 color = n_bmp_argb2ahsl( n_oc_color_system( COLOR_ACTIVECAPTION ) );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	l = 100;//n_posix_max( 128, l );

	if ( n_false == n_sysinfo_version_8_or_later() )
	{
		s = 200;
		l = 150;
	}

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_aero_alpha_pixel( u32 color )
{

	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	a = n_bmp_blend_channel( a, N_BMP_ALPHA_CHANNEL_INVISIBLE, 0.05 );

	// [!] : Debug
	//r = 255;


	return n_bmp_argb( a, r, g, b );
}

void
n_oc_color_aero_alpha( n_bmp *bmp )
{

	// [!] : no error check here

	//if ( n_sysinfo_version_8_or_later() ) { return; }

	n_type_gfx  o = 1;
	n_type_gfx oo = 2;

	n_type_gfx  x = 0 + o;
	n_type_gfx  y = 0 + o;
	n_type_gfx sx = N_BMP_SX( bmp ) - oo;
	n_type_gfx sy = N_BMP_SY( bmp ) - oo;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE != n_bmp_a( color ) )
		{
			n_bmp_ptr_set_fast( bmp, x,y, n_oc_color_aero_alpha_pixel( color ) );
		}

		x++;
		if ( x >= sx )
		{

			x = 0 + o;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}




u32
n_oc_color_material_drop( u32 color, n_type_real ratio )
{

	// [!] : old orange color

	//return n_bmp_blend_pixel( n_oc_color_highlight(), n_bmp_rgb( 255,128,0 ), ratio );


	//u32 color = n_bmp_argb2ahsl( n_oc_color_system( COLOR_ACTIVECAPTION ) );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	h -= 115;

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}




u32
n_oc_color_aqua_path_text( void )
{

	u32 color = n_bmp_argb2ahsl( n_oc_color_highlight() );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	s = 255;
	l =   0;

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_aqua_path_bg( void )
{

	u32 color = n_bmp_argb2ahsl( n_oc_color_highlight() );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	s = n_posix_max( 128     , s );
	l = n_posix_max( 128 + 12, l );

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_aqua_path_hover( void )
{

	u32 color = n_bmp_argb2ahsl( n_oc_color_highlight() );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color );
	int s = n_bmp_s( color );
	int l = n_bmp_l( color );
//n_posix_debug_literal( " %d %d %d ", h, s, l );

	s = 255;

	color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );


	return color;
}

u32
n_oc_color_aqua_path_keycolor( u32 fg )
{

	u32 color = n_bmp_argb
	(
		                        n_bmp_a( fg ),
		n_bmp_simplify_channel( n_bmp_r( fg ), 64 ),
		n_bmp_simplify_channel( n_bmp_g( fg ), 64 ),
		n_bmp_simplify_channel( n_bmp_b( fg ), 64 )
	);

	return color;
}




void
n_oc_color_init( void )
{

	// [!] : Win9x : default color scheme
	//
	//	RGB( 255,255,255 ) for COLOR_SCROLLBAR
	//	RGB(   0,  0,  0 ) for COLOR_3DDKSHADOW


	// [!] : .oc_color.path_frame1, frame2
	//
	//	only used in CLASSIC and 8


	n_bool darkmode_onoff = n_win_darkmode_onoff;

	if ( oc.dwm_onoff )
	{
		//
	} else
	if ( n_win_color_is_highcontrast() )
	{
		u32 bg = n_oc_color_system( COLOR_WINDOW );
//n_posix_debug_literal( "%d %d %d %d", n_bmp_a( bg ), n_bmp_r( bg ), n_bmp_g( bg ), n_bmp_b( bg ) );
		if ( bg == N_ORANGECAT_COLOR_BLACK ) { darkmode_onoff = n_true; }
	}


	if ( darkmode_onoff )
	{

		oc_color.bg           = n_win_darkmode_bg_argb;

		oc_color.path_text    = n_win_darkmode_systemcolor_colorref2argb( COLOR_WINDOWTEXT );
		oc_color.path_bg      = oc_color.bg;
		oc_color.path_hover   = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.90 );
		oc_color.path_drop    = n_oc_color_path_drop( 1.0 );
		oc_color.path_press   = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.25 );
		oc_color.path_frame1  = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.25 );
		oc_color.path_frame2  = n_bmp_white_invisible;
		oc_color.path_luna    = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.75 );

		oc_color.item_text    = oc_color.path_text;
		oc_color.item_hover   = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.16 );
		oc_color.item_key_i   = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.16 );
		oc_color.item_key_o   = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.33 );
		oc_color.item_zebra   = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.05 );
		oc_color.item_shadow  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.75 );
		oc_color.item_gauge   = n_oc_color_highlight();
		oc_color.item_copy    = n_oc_color_highlight();

		oc_color.info_bg_1    = n_bmp_rgb( 150,150,150 );
		oc_color.info_bg_2    = oc_color.item_copy;

		oc_color.item_select  = n_oc_color_system( COLOR_ACTIVECAPTION );

	} else
	if ( oc.dwm_onoff )
	{

		oc_color.bg          = n_bmp_black_invisible;

		oc_color.path_text   = n_oc_color_system( COLOR_BTNTEXT );
		oc_color.path_bg     = n_oc_color_system( COLOR_BTNFACE );
		oc_color.path_hover  = n_oc_color_path_hover();
		oc_color.path_drop   = n_oc_color_path_drop( 1.0 );
		oc_color.path_press  = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.50 );
		oc_color.path_frame1 = n_oc_color_system( COLOR_3DSHADOW  );
		oc_color.path_frame2 = n_oc_color_system( COLOR_3DHILIGHT );
		oc_color.path_luna   = n_oc_color_path_luna();

		oc_color.item_text   = n_bmp_white;
		oc_color.item_hover  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 0.25 );
		oc_color.item_key_i  = n_bmp_blend_pixel( oc_color.bg,   oc_color.item_text   , 0.25 );
		oc_color.item_key_o  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 0.50 );
		oc_color.item_zebra  = n_bmp_blend_pixel( oc_color.bg,             n_bmp_white, 0.25 );
		oc_color.item_shadow = n_oc_color_dwm_textshadow();
		oc_color.item_gauge  = n_bmp_white;
		oc_color.item_copy   = n_oc_color_path_drop( 0.75 );

		oc_color.info_bg_1    = oc_color.path_hover;
		oc_color.info_bg_2    = n_oc_color_path_drop( 0.75 );

	} else
	if ( n_win_color_is_highcontrast() )
	{

		oc_color.bg          = n_bmp_alpha_invisible_pixel( n_oc_color_system( COLOR_WINDOW ) );

		oc_color.path_text   = n_oc_color_system( COLOR_BTNTEXT   );
		oc_color.path_bg     = n_oc_color_system( COLOR_BTNFACE   );
		oc_color.path_hover  = n_oc_color_system( COLOR_HIGHLIGHT );
		oc_color.path_drop   = oc_color.path_hover;
		oc_color.path_press  = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.50 );
		oc_color.path_frame1 = n_oc_color_system( COLOR_3DSHADOW  );
		oc_color.path_frame2 = n_oc_color_system( COLOR_3DHILIGHT );
		oc_color.path_luna   = n_oc_color_path_luna();

		u32 color_hover = n_oc_color_system( COLOR_HIGHLIGHT );

		oc_color.item_text   = n_oc_color_system( COLOR_WINDOWTEXT );
		oc_color.item_hover  = n_bmp_blend_pixel( oc_color.bg,        color_hover, 0.11 );
		oc_color.item_key_i  = n_bmp_blend_pixel( oc_color.bg,        color_hover, 0.50 );
		oc_color.item_key_o  = n_bmp_blend_pixel( oc_color.bg,        color_hover, 0.25 );
		oc_color.item_zebra  = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.05 );
		oc_color.item_shadow = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.75 );
		oc_color.item_gauge  = color_hover;
		oc_color.item_copy   = n_oc_color_path_drop( 0.75 );

		oc_color.info_bg_1   = n_bmp_blend_pixel( oc_color.bg,        color_hover, 0.33 );
		oc_color.info_bg_2   = n_bmp_blend_pixel( oc_color.bg,        color_hover, 0.22 );

	} else {

		oc_color.bg          = n_bmp_alpha_invisible_pixel( n_oc_color_system( COLOR_WINDOW ) );

		oc_color.path_text   = n_oc_color_system( COLOR_BTNTEXT );
		oc_color.path_bg     = n_oc_color_system( COLOR_BTNFACE );
		oc_color.path_hover  = n_oc_color_path_hover();
		oc_color.path_drop   = n_oc_color_path_drop( 1.0 );
		oc_color.path_press  = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.50 );
		oc_color.path_frame1 = n_oc_color_system( COLOR_3DSHADOW  );
		oc_color.path_frame2 = n_oc_color_system( COLOR_3DHILIGHT );
		oc_color.path_luna   = n_oc_color_path_luna();

		oc_color.item_text   = n_oc_color_system( COLOR_WINDOWTEXT );
		oc_color.item_hover  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 0.25 );
		oc_color.item_key_i  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 1.00 );
		oc_color.item_key_o  = n_bmp_blend_pixel( oc_color.bg, n_oc_color_item_hover(), 0.50 );
		oc_color.item_zebra  = n_bmp_blend_pixel( oc_color.bg,      oc_color.item_text, 0.05 );
		oc_color.item_shadow = n_bmp_blend_pixel( oc_color.bg,      oc_color.item_text, 0.75 );
		oc_color.item_gauge  = n_oc_color_highlight();
		oc_color.item_copy   = n_oc_color_path_drop( 0.75 );

		oc_color.info_bg_1    = oc_color.path_hover;
		oc_color.info_bg_2    = n_oc_color_path_drop( 0.75 );

	}


	// [!] : Style

	if (
		( darkmode_onoff == n_false )
		&&
		( n_win_color_is_highcontrast() )
	)
	{

		// [!] : High Contrast White only

		if ( oc.style == N_ORANGECAT_STYLE_AERO )
		{

			oc_color.path_bg      = n_oc_color_aero_path_bg();
			oc_color.path_hover   = n_oc_color_aero_hover();
			oc_color.path_press   = n_oc_color_aero_path_press();

			oc_color.item_hover   = n_bmp_blend_pixel( oc_color.bg, oc_color.path_hover, 0.25 );
			oc_color.item_key_i   = n_bmp_blend_pixel( oc_color.bg, oc_color.path_hover, 1.00 );
			oc_color.item_key_o   = n_bmp_blend_pixel( oc_color.bg, oc_color.path_hover, 0.50 );

		} else
		if ( oc.style == N_ORANGECAT_STYLE_AQUA )
		{

			oc_color.path_text    = n_oc_color_system( COLOR_WINDOWTEXT );
			oc_color.path_bg      = n_bmp_blend_pixel( n_oc_color_system( COLOR_HIGHLIGHT ), n_bmp_white, 0.4 );
			oc_color.path_hover   = n_bmp_blend_pixel( n_oc_color_system( COLOR_HIGHLIGHT ), n_bmp_white, 0.6 );
			oc_color.path_drop    = n_bmp_blend_pixel( n_oc_color_system( COLOR_HIGHLIGHT ), n_bmp_white, 0.8 );
			oc_color.path_press   = n_bmp_blend_pixel( n_oc_color_system( COLOR_HIGHLIGHT ), n_bmp_white, 0.2 );

		}

	} else
	if ( ( oc.style == N_ORANGECAT_STYLE_LUNA )||( oc.style == N_ORANGECAT_STYLE_AERO ) )
	{

		if ( oc.style == N_ORANGECAT_STYLE_LUNA )
		{

			// [!] : Win8 or later : always rgb( 240,240,240 )

			if ( 0 == n_bmp_saturation( n_bmp_argb2ahsl( oc_color.path_bg ) ) )
			{
				oc_color.path_bg     = n_bmp_rgb( 236,233,216 );
			}

			if ( darkmode_onoff )
			{
				oc_color.path_text   = n_oc_color_system( COLOR_BTNTEXT );
			}

		} else {

			if ( darkmode_onoff )
			{
				//
			} else {
				oc_color.path_bg = n_oc_color_aero_path_bg();
			}

		}


		if ( darkmode_onoff )
		{
			oc_color.path_hover   = n_oc_color_aero_hover();
			oc_color.path_press   = n_oc_color_aero_path_press();
		} else {
			oc_color.path_hover   = n_oc_color_aero_hover();
			oc_color.path_press   = n_oc_color_aero_path_press();
		}
//n_oc_color_debug( oc_color.bg         );
//n_oc_color_debug( oc_color.path_bg    );
//n_oc_color_debug( oc_color.path_hover );


		// [!] : "oc_color.path_hover" will be overwritten

		u32 hover = oc_color.path_hover;

		if ( darkmode_onoff )
		{
			//
		} else {
			oc_color.item_hover   = n_bmp_blend_pixel( oc_color.bg, hover, 0.25 );
			oc_color.item_key_i   = n_bmp_blend_pixel( oc_color.bg, hover, 1.00 );
			oc_color.item_key_o   = n_bmp_blend_pixel( oc_color.bg, hover, 0.50 );
		}


		if ( oc.style == N_ORANGECAT_STYLE_LUNA )
		{
			u32           swap  = oc_color.path_hover;
			oc_color.path_hover = oc_color.path_drop;
			oc_color.path_drop  = swap;

			if ( darkmode_onoff )
			{
				oc_color.path_drop  = n_bmp_rgb( 0,200,255 );
			} else {
				oc_color.path_drop  = n_bmp_blend_pixel( oc_color.path_drop, oc_color.path_press, 0.5 );
			}
		}

	} else
	if ( oc.style == N_ORANGECAT_STYLE_8 )
	{

		if ( darkmode_onoff )
		{

			oc_color.path_hover   = n_bmp_rgb( 150,150,150 );
			oc_color.path_press   = n_bmp_rgb(  50, 50, 50 );

			oc_color.path_frame1  = n_bmp_rgb( 111,111,111 );
			oc_color.path_frame2  = n_bmp_rgb( 111,111,111 );

		} else {

			u32 path_hover = n_oc_color_path_hover();

			oc_color.path_hover   = n_bmp_blend_pixel( path_hover, oc_color.path_text, 0.20 );
			oc_color.path_press   = path_hover;

			oc_color.path_frame2  = n_oc_color_system( COLOR_WINDOW );

		}

	} else
	if ( oc.style == N_ORANGECAT_STYLE_FLUENT )
	{

		if ( darkmode_onoff )
		{

			oc_color.path_bg      = n_bmp_rgb( 100,100,100 );
			oc_color.path_hover   = n_bmp_rgb( 150,150,150 );
			oc_color.path_press   = n_bmp_rgb(  77, 77, 77 );

		} else {

			oc_color.path_bg      = n_bmp_rgb( 222,222,222 );
			oc_color.path_hover   = n_bmp_blend_pixel( oc_color.path_hover, oc_color.path_bg, 0.50 );

		}

	} else
	if ( oc.style == N_ORANGECAT_STYLE_MATERIAL )
	{

		oc_color.path_text  = n_bmp_white;
		oc_color.path_bg    = n_bmp_rgb( 26, 115, 232 );
		oc_color.path_hover = n_bmp_blend_pixel( oc_color.path_bg, n_bmp_white, 0.25 );
		oc_color.path_press = n_bmp_blend_pixel( oc_color.path_bg, n_bmp_black, 0.50 );

		oc_color.info_bg_1  = oc_color.path_bg;
		oc_color.info_bg_2  = n_oc_color_material_drop( oc_color.info_bg_1, 1.0 );

	} else
	if ( oc.style == N_ORANGECAT_STYLE_AQUA )
	{

		if ( darkmode_onoff )
		{

			oc_color.path_text    = n_bmp_rgb(  10, 10, 10 );
			oc_color.path_hover   = n_bmp_rgb(  50, 50, 50 );
			oc_color.path_press   = n_bmp_rgb(  10, 10, 10 );
			oc_color.path_drop    = n_bmp_rgb( 150,100,  0 );

			oc_color.path_bg      = n_bmp_blend_pixel( oc_color.path_hover, oc_color.path_text, 0.25 );

		} else {

			oc_color.path_text    = n_oc_color_aqua_path_text();
			oc_color.path_bg      = n_oc_color_aqua_path_bg();
			oc_color.path_hover   = n_oc_color_aqua_path_hover();
			oc_color.path_press   = n_bmp_blend_pixel( oc_color.path_bg, N_ORANGECAT_COLOR_BLACK, 0.25 );

		}

		oc_color.item_zebra   = n_bmp_blend_pixel( oc_color.bg, oc_color.item_hover, 0.25 );

	}


	if ( darkmode_onoff )
	{
		oc_color.item_focus = oc_color.item_key_o;
	} else
	if ( n_win_color_is_highcontrast() )
	{
		oc_color.item_select = n_oc_color_aero_hover();
	} else {
		oc_color.item_select = n_oc_color_aero_hover();
		oc_color.item_focus  = oc_color.item_key_o;
	}
	//oc_color.item_select = n_bmp_rgb( 0,200,255 );


	game.color = oc_color.bg;


	return;
}
