// ArcDrop
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




//#define N_MEMORY_DEBUG




#include "../nonnon/win32/win/commandline.c"

#include "../nonnon/neutral/string_path.c"
#include "../nonnon/neutral/tar.c"
#include "../nonnon/neutral/zip.c"




// [!] : for Rich Dialog bloat problem : 105KB to 250KB

//#include "../nonnon/project/macro.c"

#define n_project_string_info       n_posix_literal( "INFO" )

#define n_bool  BOOL
#define n_false FALSE
#define n_true  TRUE

void
n_project_dialog_info( HWND hwnd, const n_posix_char *str )
{

	int mb = MB_TOPMOST | MB_ICONINFORMATION | MB_OK;

	MessageBox( hwnd, str, n_project_string_info, mb );


	return;
}




#include <shlobj.h>




#define N_ARCDROP_SHOWWINDOW SW_MINIMIZE




#define N_ARCDROP_EXT_7Z  n_posix_literal( ".7z\0\0"  )
#define N_ARCDROP_EXT_ZIP n_posix_literal( ".zip\0\0" )
#define N_ARCDROP_EXT_GZ  n_posix_literal( ".gz\0\0"  )
#define N_ARCDROP_EXT_TGZ n_posix_literal( ".tgz\0\0" )
#define N_ARCDROP_EXT_TAR n_posix_literal( ".tar\0\0" )
#define N_ARCDROP_EXT_BZ2 n_posix_literal( ".bz2\0\0" )
#define N_ARCDROP_EXT_Z   n_posix_literal( ".z\0\0"   )




#define N_ARCDROP_ERROR_NONE               ( 0 )
#define N_ARCDROP_ERROR_NOT_SUPPORTED      ( 1 )
#define N_ARCDROP_ERROR_ALREADY_COMPRESSED ( 2 )


int n_arcdrop_errorcode = N_ARCDROP_ERROR_NONE;




void
n_arcdrop_explorer_refresh( void )
{

	// [!] : this is based on n_explorer_refresh() @ win32/explorer.c
	//
	//	for reducing EXE file size


	LONG shcne;
	UINT shcnf;
	void *p1, *p2;


	if ( n_sysinfo_version_95() )
	{

		shcne = SHCNE_ALLEVENTS;
		shcnf = SHCNF_PATH | SHCNF_FLUSHNOWAIT;
		p1    = ".\\";
		p2    = NULL;

	} else {

		shcne = SHCNE_ALLEVENTS;
		shcnf = SHCNF_FLUSHNOWAIT;
		p1    = NULL;
		p2    = NULL;

	}


	SHChangeNotify( shcne, shcnf, p1, p2 );


	return;
}

n_bool
n_arcdrop_decode_7zip( const n_posix_char *dir, const n_posix_char *arg )
{

	n_posix_char *dec = n_string_path_make_new( dir, n_posix_literal( "7ZA.EXE" ) );
	if ( n_false == n_posix_stat_is_exist( dec ) ) { n_string_path_free( dec ); return n_true; }


	n_bool ret = n_false;

	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_7Z , arg );
	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_ZIP, arg );
	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_GZ , arg );
	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_TGZ, arg );
	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_TAR, arg );
	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_BZ2, arg );
	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_Z  , arg );

	if ( ret == n_false ) { n_string_path_free( dec ); return n_true; }


	n_posix_char *exe = n_string_path_new( 100 + n_posix_strlen( dec ) + n_posix_strlen( arg ) );
	n_posix_sprintf_literal( exe, "%s x -y \"%s\"", dec, arg );

	n_win_execute( exe, N_ARCDROP_SHOWWINDOW, n_true );

//n_posix_debug( exe );


	// TAR chain unpacker

	n_posix_char *tar = n_string_path_carboncopy( arg );

	if ( n_string_path_ext_is_same( N_ARCDROP_EXT_GZ, tar ) )
	{
		n_string_path_ext_del( tar );
	} else
	if ( n_string_path_ext_is_same( N_ARCDROP_EXT_TGZ, tar ) )
	{
		n_string_path_ext_mod( N_ARCDROP_EXT_TAR, tar );
	}


	if ( n_string_path_ext_is_same( N_ARCDROP_EXT_TAR, tar ) )
	{

		n_posix_char *exe = n_string_path_new( 100 + n_posix_strlen( dec ) + n_posix_strlen( tar ) );
		n_posix_sprintf_literal( exe, "%s x -y \"%s\"", dec, tar );

		n_win_execute( exe, N_ARCDROP_SHOWWINDOW, n_true );

		n_posix_unlink( tar );

		n_string_path_free( exe );

	}

	n_string_path_free( tar );


	n_string_path_free( dec );
	n_string_path_free( exe );


	return n_false;
}

n_bool
n_arcdrop_decode_gzip( const n_posix_char *dir, const n_posix_char *arg )
{

	n_posix_char *dec = n_string_path_make_new( dir, n_posix_literal( "GZIP.EXE" ) );
//n_posix_debug( dec );


	if ( n_false == n_posix_stat_is_exist( dec ) ) { n_string_path_free( dec ); return n_true; }


	n_bool ret = n_false;

	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_GZ , arg );
	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_TGZ, arg );

	if ( ret == n_false ) { n_string_path_free( dec ); return n_true; }


	n_posix_char *exe = n_string_path_new( 100 + n_posix_strlen( dec ) + n_posix_strlen( arg ) );
	n_posix_sprintf_literal( exe, "%s -d \"%s\"", dec, arg );


	n_win_execute( exe, N_ARCDROP_SHOWWINDOW, n_true );

//n_posix_debug( exe );


	// [!] : TAR chain unpacker

	n_posix_char *tar = n_string_path_carboncopy( arg );

	if ( n_string_path_ext_is_same( N_ARCDROP_EXT_GZ, tar ) )
	{
		n_string_path_ext_del( tar );
	} else
	if ( n_string_path_ext_is_same( N_ARCDROP_EXT_TGZ, tar ) )
	{
		n_string_path_ext_mod( N_ARCDROP_EXT_TAR, tar );
	}


	if ( n_string_path_ext_is_same( N_ARCDROP_EXT_TAR, tar ) )
	{

		n_posix_char *exe = n_string_path_new( 100 + n_posix_strlen( dec ) + n_posix_strlen( tar ) );
		n_posix_sprintf_literal( exe, "%s -d \"%s\"", dec, tar );

		n_win_execute( exe, N_ARCDROP_SHOWWINDOW, n_true );

		n_posix_unlink( tar );

		n_string_path_free( exe );

	}

	n_string_path_free( tar );


	n_string_path_free( dec );
	n_string_path_free( exe );


	return n_false;
}

n_bool
n_arcdrop_decode_infozip( const n_posix_char *dir, const n_posix_char *arg )
{

	n_posix_char *dec = n_string_path_make_new( dir, n_posix_literal( "UNZIP.EXE" ) );

//n_posix_debug( dec );


	if ( n_false == n_posix_stat_is_exist( dec ) ) { n_string_path_free( dec ); return n_true; }


	n_bool ret = n_false;

	ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_ZIP, arg );

	if ( ret == n_false ) { n_string_path_free( dec ); return n_true; }


	n_posix_char *exe = n_string_path_new( 100 + n_posix_strlen( dec ) + n_posix_strlen( arg ) );
	n_posix_sprintf_literal( exe, "%s \"%s\"", dec, arg );


	n_win_execute( exe, N_ARCDROP_SHOWWINDOW, n_true );
//n_posix_debug( exe );


	n_string_path_free( dec );
	n_string_path_free( exe );


	return n_false;
}

n_bool
n_arcdrop_decode_nzip( const n_posix_char *dir, const n_posix_char *arg )
{

	n_bool ret = n_true;


#ifdef _H_NONNON_NEUTRAL_ZIP

	n_posix_char *newname = n_string_path_carboncopy( arg );

	if ( n_string_path_ext_is_same( N_ARCDROP_EXT_ZIP, newname ) )
	{
		ret = n_zip_main( newname );
	}

	n_string_path_free( newname );

#endif // #ifdef _H_NONNON_NEUTRAL_ZIP


	return ret;
}

n_bool
n_arcdrop_decode_ntar( const n_posix_char *dir, const n_posix_char *arg )
{

	n_bool ret = n_true;


#ifdef _H_NONNON_NEUTRAL_TAR

	n_posix_char *newname = n_string_path_carboncopy( arg );

	if ( n_string_path_ext_is_same( N_ARCDROP_EXT_TAR, newname ) )
	{
		ret = n_tar_main( newname );
	}

	n_string_path_free( newname );

#endif // #ifdef _H_NONNON_NEUTRAL_TAR


	return ret;
}

n_bool
n_arcdrop_encode( const n_posix_char *dir, const n_posix_char *arg )
{

	n_posix_char *zip = n_string_path_ext_mod_new( arg, N_ARCDROP_EXT_ZIP );


	n_posix_char *enc = n_string_path_make_new( dir, n_posix_literal( "ZIP.EXE" ) );
//n_posix_debug( zip );
//n_posix_debug( enc );


	if ( n_posix_stat_is_exist( enc ) )
	{

		n_posix_char *prm = n_string_path_new( 100 + n_posix_strlen( zip ) + n_posix_strlen( arg ) );
		n_posix_sprintf_literal( prm, "-r -S \"%s\" \"%s\"", zip, arg );

		n_posix_char *exe = n_string_path_new( n_posix_strlen( enc ) + 1 + n_posix_strlen( prm ) );
		n_posix_sprintf_literal( exe, "%s %s", enc, prm );


		// [!] : overwrite if already exist

		n_posix_unlink( zip );


		n_win_execute( exe, N_ARCDROP_SHOWWINDOW, n_true );


		n_string_path_free( zip );
		n_string_path_free( enc );
		n_string_path_free( prm );
		n_string_path_free( exe );


		return n_false;
	}


	n_string_path_free( enc );
	enc = n_string_path_make_new( dir, n_posix_literal( "7ZA.EXE" ) );

//n_posix_debug( enc );


	if ( n_posix_stat_is_exist( enc ) )
	{

		n_posix_char *prm = n_string_path_new( 100 + n_posix_strlen( zip ) + n_posix_strlen( arg ) );
		n_posix_sprintf_literal( prm, "a -tzip \"%s\" \"%s\"", zip, arg );

		n_posix_char *exe = n_string_path_new( n_posix_strlen( enc ) + 1 + n_posix_strlen( prm ) );
		n_posix_sprintf_literal( exe, "%s %s", enc, prm );


		// [!] : overwrite if already exist

		n_posix_unlink( zip );


		n_win_execute( exe, N_ARCDROP_SHOWWINDOW, n_true );


		n_string_path_free( zip );
		n_string_path_free( enc );
		n_string_path_free( prm );
		n_string_path_free( exe );


		return n_false;
	}


	// Fallback

	n_string_path_free( zip );
	zip = n_string_path_carboncopy( arg );

	if ( n_false == n_posix_stat_is_exist( zip ) )
	{

		n_string_path_free( zip );
		n_string_path_free( enc );

		return n_true;
	}


	{

		n_bool ret = n_false;

		ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_7Z , zip );
		ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_ZIP, zip );
		ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_GZ , zip );
		ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_TGZ, zip );
		ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_TAR, zip );
		ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_BZ2, zip );
		ret |= n_string_path_ext_is_same( N_ARCDROP_EXT_Z  , zip );

		if ( ret ) { n_arcdrop_errorcode = N_ARCDROP_ERROR_ALREADY_COMPRESSED; return ret; }


#ifdef _H_NONNON_NEUTRAL_ZIP


		ret = n_zip_main( zip );


#ifdef _H_NONNON_NEUTRAL_TAR

		if ( ret ) { ret = n_tar_main( zip ); }

#endif // #ifdef _H_NONNON_NEUTRAL_TAR


#else  // #ifdef _H_NONNON_NEUTRAL_ZIP


		ret = n_true;

#ifdef _H_NONNON_NEUTRAL_TAR

		ret = n_tar_main( zip );

#endif // #ifdef _H_NONNON_NEUTRAL_TAR


#endif // #ifdef _H_NONNON_NEUTRAL_ZIP

		if ( ret ) { n_arcdrop_errorcode = N_ARCDROP_ERROR_NOT_SUPPORTED; }

		n_string_path_free( zip );
		n_string_path_free( enc );

		return ret;

	}


	return n_true;
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	n_posix_char *arg = n_win_commandline_new();
//n_posix_debug( arg ); 

	if ( n_false == n_posix_stat_is_exist( arg ) ) { n_string_path_free( arg ); return n_true; }


	n_win_exedir2curdir();


	n_posix_char *dir = n_string_path_folder_current_new();


	n_string_path_folder_change( arg );
	if ( n_posix_stat_is_dir( arg ) ) { n_posix_chdir( N_STRING_DOTDOT ); }


	n_arcdrop_errorcode = N_ARCDROP_ERROR_NONE;

	if (
		( n_arcdrop_decode_nzip   ( dir, arg ) )
		&&
		( n_arcdrop_decode_7zip   ( dir, arg ) )
		&&
		( n_arcdrop_decode_infozip( dir, arg ) )
		&&
		( n_arcdrop_decode_gzip   ( dir, arg ) )
		&&
		( n_arcdrop_decode_ntar   ( dir, arg ) )
		&&
		( n_arcdrop_encode        ( dir, arg ) )
	)
	{

		// [!] : all error

		if ( n_arcdrop_errorcode == N_ARCDROP_ERROR_NOT_SUPPORTED )
		{
			n_project_dialog_info( NULL, n_posix_literal( "Not Supported" ) );
		} else
		if ( n_arcdrop_errorcode == N_ARCDROP_ERROR_ALREADY_COMPRESSED )
		{
			n_project_dialog_info( NULL, n_posix_literal( "Already Compressed" ) );
		}

	} else {

		n_arcdrop_explorer_refresh();

	}


	n_string_path_folder_change( dir );


	n_string_path_free( arg );
	n_string_path_free( dir );


	return n_false;
}

