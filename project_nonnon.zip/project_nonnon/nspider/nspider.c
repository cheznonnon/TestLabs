// Nonnon Spider
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
#include "../nonnon/game/click.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"
#include "../nonnon/game/transition.c"


#include "../nonnon/neutral/ini.c"

#include "../nonnon/win32/gdi.c"
#include "../nonnon/win32/win_titlemenu.c"

#include "../nonnon/project/macro.c"

#include "../nonnon/project/cardgenerator/cardgenerator.c"




// Constants

#ifndef N_GAMECONSOLE

#define N_GAMECONSOLE_ICON_OFFSET_SPIDER ( 0 )

#endif // #ifndef N_GAMECONSOLE


#define NSPIDER_WAV_MUTE         "N_PROJECT_SOUND_MUTE"
#define NSPIDER_WAV_TAKE         "N_PROJECT_SOUND_CLICK"
#define NSPIDER_WAV_DEAL         "N_PROJECT_SOUND_SH"

#define N_SPIDER_NOTHING         ( -1 )

#define N_SPIDER_SUIT_HEARTS     N_CARDGENERATOR_SUIT_HEARTS
#define N_SPIDER_SUIT_DIAMONDS   N_CARDGENERATOR_SUIT_DIAMONDS
#define N_SPIDER_SUIT_SPADES     N_CARDGENERATOR_SUIT_SPADES
#define N_SPIDER_SUIT_CLUBS      N_CARDGENERATOR_SUIT_CLUBS
#define N_SPIDER_SUIT_MAX        N_CARDGENERATOR_SUIT_MAX

#define N_SPIDER_CARD_UNIT       N_CARDGENERATOR_CARD_UNIT
#define N_SPIDER_CARD_ALL        N_CARDGENERATOR_CARD_ALL
#define N_SPIDER_PILE_SX         ( 10 )
#define N_SPIDER_PILE_SY         ( N_SPIDER_CARD_UNIT * 8 )
#define N_SPIDER_PILE_ALL        ( N_SPIDER_PILE_SX * N_SPIDER_PILE_SY )

#define N_SPIDER_SEQUENCE_NONE   0
#define N_SPIDER_SEQUENCE_DELAY  1
#define N_SPIDER_SEQUENCE_GO     2

#define N_SPIDER_EVENT_NONE      0
#define N_SPIDER_EVENT_DEAL      1
#define N_SPIDER_EVENT_SEQUENCE  2
#define N_SPIDER_EVENT_SOUNDSTOP 3

#define N_SPIDER_DEAL_MSEC       (  100 )
#define N_SPIDER_FADE_MSEC       ( 1000 )
#define N_SPIDER_RESZ_MSEC       (  200 )

#define N_SPIDER_DEAL_PHASE_0    0
#define N_SPIDER_DEAL_PHASE_1    1
#define N_SPIDER_DEAL_PHASE_2    2

#define N_SPIDER_RESZ_PHASE_NONE 0
#define N_SPIDER_RESZ_PHASE_STOP 1

#define N_SPIDER_TIMER_ID_STYLE  ( 1 )

#define N_SPIDER_SHADOW_COUNT    N_CARDGENERATOR_CARD_UNIT




typedef struct {

	n_bool          is_init;

	n_bool          is_first;

	n_cardgenerator cardgen;

	n_bool          resize_phase;
	u32             resize_timer;

	u32             color_init;
	u32             color_text;
	u32             color_gradient_upper;
	u32             color_gradient_lower;
	u32             color_halo_focus;
	u32             color_halo_current;

	n_bool          splash_onoff;

	int             event, event_next;
	int             deal_x, deal_y;
	u32             deal_timer;
	int             deal_phase;

	int             sequence;
	int             sequence_x, sequence_y;
	int             sequence_c;
	int             sequence_sy;
	u32             sequence_timer;

	n_game_sound    snd_mute;
	n_game_sound    snd_take;
	n_game_sound    snd_deal;

	n_bmp           bmp_bg;
	n_bmp           bmp_check;

	int             transition_type;
	n_bmp           transition_bmp_old;
	n_bmp           transition_bmp_new;
	n_type_real     transition_percent;

	n_bool          redraw [ N_SPIDER_PILE_SX  ];
	n_bool          loaded [ N_SPIDER_PILE_SX  ];
	n_bool          p_stock[ N_SPIDER_PILE_SX  ];
	n_game_chara    tableau[ N_SPIDER_PILE_ALL ];
	n_game_chara    bottom [ N_SPIDER_PILE_SX  ];
	n_game_chara    stock  [ N_SPIDER_PILE_SY  ];
	n_game_chara    restore[ N_SPIDER_PILE_SY  ];
	int             drag_index;
	int             stock_index;
	int             restore_count;
	int             dnd_pile_index;

	n_bool           menu_onoff;
	n_win_titlemenu  titlemenu;
	n_win_simplemenu simplemenu;
	int              option_suit;

	n_posix_char    *ini_section;
	n_posix_char    *ini_lval_suit;

	n_bool           shadow_global_onoff;
	n_bool           shadow_onoff;
	n_bmp           *shadow_bmp;
	n_bmp            shadow_bmp_cache[ N_SPIDER_SHADOW_COUNT ];
	n_type_gfx       shadow_x;
	n_type_gfx       shadow_y;
	n_type_gfx       shadow_sx;
	n_type_gfx       shadow_sy;
	n_type_gfx       shadow_px;
	n_type_gfx       shadow_py;
	n_type_gfx       shadow_psx;
	n_type_gfx       shadow_psy;

	n_bool           debug_onoff;
	n_bool           debug_seq_onoff;
	int              debug_pile_sx;
	u32              debug_deal_msec;

} n_spider;


static n_spider spider;




// Components

#include "./n_spider_midi.c"
#include "./n_spider_splashscreen.c"

#include "./subclass.c"





#define n_spider_pos2index( x, y ) ( ( x ) + ( N_SPIDER_PILE_SX * ( y ) ) )

#define n_spider_index_upper( i ) ( ( i ) * N_SPIDER_PILE_SX )

void
n_spider_chara_erase( n_spider *p, n_game_chara *c )
{

	const n_type_gfx m  = p->cardgen.halo;
	const n_type_gfx mm = ( p->cardgen.halo * 2 ) + ( p->cardgen.halo % 2 );


	c->px -= m;
	c->py -= m;
	c->sx += mm;
	c->sy += mm;

	n_game_chara_erase( c );

	c->px += m;
	c->py += m;
	c->sx -= mm;
	c->sy -= mm;


	return;
}

void
n_spider_chara_draw( n_spider *p, n_game_chara *c )
{

	{
		n_type_gfx x = c->x - p->cardgen.halo;
		n_type_gfx y = c->y - p->cardgen.halo;

		n_bmp_rasterizer( &p->cardgen.bmp_halo, &game.bmp, x,y, p->color_halo_current, n_false );
	}


	n_game_chara_draw( c );


	return;
}

void
n_spider_redraw_detect( n_spider *p )
{

	n_game_chara card = p->tableau[ p->drag_index ];
//n_game_hwndprintf_literal( " %d ", p->drag_index );

	card.x = card.px;
	card.y = card.py;


	int x = 0;
	int y = 0;
	n_posix_loop
	{

		if ( y == 0 )
		{

			n_game_chara *b = &p->bottom[ x ];
			if ( n_game_chara_is_hit_offset( &card, b, -p->cardgen.halo,-p->cardgen.halo, 0,0 ) )
			{
//n_game_hwndprintf_literal( " 1 " );
				p->redraw[ x ] = n_true;
			}

		} else {

			if ( ( x == p->drag_index )&&( p->restore_count != 0 ) )
			{
//n_game_hwndprintf_literal( " 2 " );

				// [!] : do nothing

			} else {

				int target = n_spider_pos2index( x, y );
				n_game_chara *c = &p->tableau[ target ];

				if (
					( c->data != N_SPIDER_NOTHING )
					&&
					( n_game_chara_is_hit_offset( &card, c, -p->cardgen.halo,-p->cardgen.halo, 0,0 ) )
				)
				{
//n_game_hwndprintf_literal( " 3 " );
					p->redraw[ x ] = n_true;
				}

			}

		}


		x++;
		if ( x >= N_SPIDER_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_SPIDER_PILE_SY ) { break; }
		}
	}


	return;
}

void
n_spider_reposition( n_spider *p )
{

	// Reset : when resized

	n_type_gfx tmp_sx = p->cardgen.csx / N_SPIDER_PILE_SX;
	if ( tmp_sx > p->cardgen.card_sx )
	{
		p->cardgen.osx = (n_type_gfx) ( fmod( tmp_sx, p->cardgen.card_sx ) / 2 );
	} else {
		p->cardgen.osx = 0;
	}

//n_game_hwndprintf_literal( "%d : %d %d", p->cardgen.osx, p->cardgen.csx, p->cardgen.card_sx );
//n_game_hwndprintf_literal( "%d %d", ( p->cardgen.csx / N_SPIDER_PILE_SX ), fmod( ( p->cardgen.csx / N_SPIDER_PILE_SX ), p->cardgen.card_sx ) );

	int x = 0;
	int y = 0;
	n_posix_loop
	{

		int target = n_spider_pos2index( x,y );

		n_game_chara *c = &p->tableau[ target ];


		n_type_gfx tx = ( ( p->cardgen.osx + p->cardgen.card_sx + p->cardgen.osx ) * x ) + p->cardgen.osx;
		n_type_gfx ty = ( p->cardgen.osy * y );

		n_game_chara_pos( c, tx,ty );
		n_game_chara_prv( c );


		x++;
		if ( x >= N_SPIDER_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_SPIDER_PILE_SY ) { break; }
		}
	}

	x = 0;
	n_posix_loop
	{

		n_game_chara *c = &p->bottom[ x ];


		n_type_gfx tx = ( ( p->cardgen.osx + p->cardgen.card_sx + p->cardgen.osx ) * x ) + p->cardgen.osx;

		n_game_chara_pos( c, tx,0 );
		n_game_chara_prv( c );


		x++;
		if ( x >= N_SPIDER_PILE_SX ) { break; }
	}


	return;
}

#define n_spider_rule_is_hearts(   p, i ) n_spider_rule_range( p, i, N_SPIDER_SUIT_HEARTS,   N_SPIDER_SUIT_DIAMONDS )
#define n_spider_rule_is_diamonds( p, i ) n_spider_rule_range( p, i, N_SPIDER_SUIT_DIAMONDS, N_SPIDER_SUIT_SPADES   )
#define n_spider_rule_is_spades(   p, i ) n_spider_rule_range( p, i, N_SPIDER_SUIT_SPADES,   N_SPIDER_SUIT_CLUBS    )
#define n_spider_rule_is_clubs(    p, i ) n_spider_rule_range( p, i, N_SPIDER_SUIT_CLUBS,    N_SPIDER_SUIT_MAX      )
#define n_spider_rule_is_reds(     p, i ) n_spider_rule_range( p, i, N_SPIDER_SUIT_HEARTS,   N_SPIDER_SUIT_SPADES   )
#define n_spider_rule_is_blacks(   p, i ) n_spider_rule_range( p, i, N_SPIDER_SUIT_SPADES,   N_SPIDER_SUIT_MAX      )

n_bool
n_spider_rule_range( n_spider *p, int index, int f, int t )
{

	int data = p->tableau[ index ].data;
	int unit = N_SPIDER_CARD_UNIT;

	if ( ( data >= ( unit * f ) )&&( data < ( unit * t ) ) ){ return n_true; }


	return n_false;
}

n_bool
n_spider_rule_suit_is_same( n_spider *p, int a, int b )
{

	if ( ( n_spider_rule_is_hearts  ( p, a ) ) && ( n_spider_rule_is_hearts  ( p, b ) ) ) { return n_true; }
	if ( ( n_spider_rule_is_diamonds( p, a ) ) && ( n_spider_rule_is_diamonds( p, b ) ) ) { return n_true; }
	if ( ( n_spider_rule_is_spades  ( p, a ) ) && ( n_spider_rule_is_spades  ( p, b ) ) ) { return n_true; }
	if ( ( n_spider_rule_is_clubs   ( p, a ) ) && ( n_spider_rule_is_clubs   ( p, b ) ) ) { return n_true; }


	return n_false;
}

n_bool
n_spider_rule_rank_is_same( n_spider *p, int a, int b )
{

	a = p->tableau[ a ].data;
	b = p->tableau[ b ].data;


	int rank;

	rank  = a % N_SPIDER_CARD_UNIT;
	rank -= b % N_SPIDER_CARD_UNIT;

	if ( rank == 1 ) { return n_true; }


	return n_false;
}

n_bool
n_spider_rule_is_movable( n_spider *p, int index )
{
//return n_true;


	// Empty cell

	if ( p->tableau[ index ].data == N_SPIDER_NOTHING ) { return n_false; }


	// Sequence Checker

	int i = 0;
	n_posix_loop
	{

		int f = index + n_spider_index_upper( i + 0 );
 		int t = index + n_spider_index_upper( i + 1 );


		// Single : top most of a pile

		if ( t >= N_SPIDER_PILE_ALL ) { return n_true; }


		// Single : top of a stock

		if ( p->tableau[ t ].data == N_SPIDER_NOTHING ) { return n_true; }


		// Multiple

		if (
			( n_false == n_spider_rule_rank_is_same( p, f, t ) )
			||
			( n_false == n_spider_rule_suit_is_same( p, f, t ) )
		)
		{
			break;
		}


		i++;
		if ( f >= N_SPIDER_PILE_ALL ) { break; }
	}


	return n_false;
}

n_bool
n_spider_rule_is_puttable( n_spider *p, int index )
{
//return n_true;

	// [Mechanism]
	//
	//	"index" : .data could have N_SPIDER_NOTHING

	n_posix_loop
	{

		// Cascading : Top to Bottom

		if ( p->tableau[ index ].data != N_SPIDER_NOTHING ) { break; }

		// Bottom-most

		index -= n_spider_index_upper( 1 );
		if ( index < 0 ) { return n_true; }
	}


	return n_spider_rule_rank_is_same( p, index, p->drag_index );
}

void
n_spider_rule_sequence_animation( n_spider *p )
{

	int target = n_spider_pos2index( p->sequence_x, p->sequence_y - p->sequence_c );

	p->tableau[ target ].data  = N_SPIDER_NOTHING;
	p->tableau[ target ].chara = NULL;

	n_game_chara_erase( &p->tableau[ target ] );


	if ( n_hmidiout_hmo == NULL )
	{
		n_game_sound_loop( &p->snd_take );
	} else {
		n_spider_midi_note_off( p );
		n_spider_midi_note_on ( p );
	}

	p->sequence_c++;
	if ( p->sequence_c >= N_SPIDER_CARD_UNIT )
	{
		p->event = N_SPIDER_EVENT_SOUNDSTOP;
	}


	p->redraw[ p->sequence_x ] = n_true;


	n_game_refresh_on();


	return;
}

void
n_spider_rule_sequence( n_spider *p, int x )
{

	int y = N_SPIDER_PILE_SY - 1;
	n_posix_loop
	{

		int target = n_spider_pos2index( x,y );

		if ( p->tableau[ target ].data != N_SPIDER_NOTHING ) { break; }

		y--;
		if ( y < 0 ) { return; }
	}


	int hearts, diamonds, spades, clubs;

	int start = N_SPIDER_NOTHING;
	int suit  = hearts = diamonds = spades = clubs = 0;
	n_posix_loop
	{

		int target = n_spider_pos2index( x,y );

		if ( suit != ( p->tableau[ target ].data % N_SPIDER_CARD_UNIT ) )
		{
			break;
		}

		if ( start == N_SPIDER_NOTHING ) { start = y; }

		suit++;
		hearts   += n_spider_rule_is_hearts  ( p, target );
		diamonds += n_spider_rule_is_diamonds( p, target );
		spades   += n_spider_rule_is_spades  ( p, target );
		clubs    += n_spider_rule_is_clubs   ( p, target );


		y--;
		if ( y < 0 ) { break; }
	}

//n_game_hwndprintf_literal( "%d : %d : %d", suit, hearts, spades );


	if ( start == N_SPIDER_NOTHING ) { return; }

	if ( suit != N_SPIDER_CARD_UNIT ) { return; }
	if (
		( hearts   != N_SPIDER_CARD_UNIT )
		&&
		( diamonds != N_SPIDER_CARD_UNIT )
		&&
		( spades   != N_SPIDER_CARD_UNIT )
		&&
		( clubs    != N_SPIDER_CARD_UNIT )
	)
	{
		return;
	}


	p->event       = N_SPIDER_EVENT_SEQUENCE;
	p->sequence_x  = x;
	p->sequence_y  = start;
	p->sequence_c  = 0;
	p->sequence_sy = suit;


	return;
}

void
n_spider_redraw( n_spider *p )
{

	int x = 0;
	n_posix_loop
	{

		p->redraw[ x ] = n_true;

		x++;
		if ( x >= N_SPIDER_PILE_SX ) { break; }
	}


	return;
}

void
n_spider_shadow( n_spider *p )
{

	if ( p->shadow_global_onoff == n_false ) { return; }

	//if ( p->animation_onoff ) { return; }


//n_game_hwndprintf_literal( " %d ", p->restore_count );


	int index = 0;
	if ( p->restore_count >= 1 ) { index = p->restore_count - 1; }


	p->shadow_bmp = &p->shadow_bmp_cache[ index ];

	if ( NULL != N_BMP_PTR( &p->shadow_bmp_cache[ index ] ) )
	{
		return;
	}


	n_game_chara *c = &p->tableau[ p->drag_index ];

	n_type_gfx osy = 0; if ( p->restore_count >= 2 ) { osy = p->cardgen.osy * ( p->restore_count - 1 ); }

//n_game_hwndprintf_literal( " %d ", p->cardgen.halo );

	p->shadow_x  = c->x + ( p->cardgen.halo * 2 );
	p->shadow_y  = c->y + ( p->cardgen.halo * 2 );
	p->shadow_sx = c->sx;
	p->shadow_sy = c->sy + osy;

	n_bmp bmp_tmp; n_bmp_zero( &bmp_tmp );
	n_cardgenerator_dropshadow( &bmp_tmp, p->shadow_sx, p->shadow_sy, p->cardgen.halo, p->cardgen.halo / 2 );

	n_bmp_new_fast( p->shadow_bmp, N_BMP_SX( &bmp_tmp ),N_BMP_SY( &bmp_tmp ) );
	n_bmp_flush( p->shadow_bmp, n_bmp_black_invisible );

	u32 shadow_color = n_bmp_blend_pixel( p->color_gradient_upper, n_bmp_black_invisible, 0.5 );
	n_bmp_rasterizer( &bmp_tmp, p->shadow_bmp, 0,0, shadow_color, n_false );
//n_bmp_save_literal( p->shadow_bmp, "ret.bmp" );

	n_bmp_free_fast( &bmp_tmp );


	return;
}

void
n_spider_shadow_erase( n_spider *p )
{

	if ( p->shadow_global_onoff == n_false ) { return; }

	//if ( p->animation_onoff ) { return; }

	if ( p->shadow_onoff == n_false ) { return; }


	p->shadow_onoff = n_false;


	n_type_gfx  x = p->shadow_px;
	n_type_gfx  y = p->shadow_py;
	n_type_gfx sx = p->shadow_psx;
	n_type_gfx sy = p->shadow_psy;

//n_bmp_box( &game.bmp, x,y,sx,sy, n_bmp_rgb(0,200,255) );
	n_bmp_fastcopy( &p->bmp_bg, &game.bmp, x,y,sx,sy, x,y );


	n_game_chara a; n_game_chara_zero( &a );
	n_game_chara_pos( &a, x,y );
	n_game_chara_src( &a, 0,0, sx,sy, 0,0 );

	n_type_gfx ix = 0;
	n_type_gfx iy = 0;
	n_posix_loop
	{//break;

		int target = n_spider_pos2index( ix, iy );
		n_game_chara *b = &p->tableau[ target ];

		if ( n_game_chara_is_hit( &a, b ) )
		{
			p->redraw[ ix ] = n_true;
		}

		ix++;
		if ( ix >= N_SPIDER_PILE_SX )
		{

			ix = 0;

			iy++;
			if ( iy >= N_SPIDER_PILE_SY ) { break; }
		}
	}


	return;
}

void
n_spider_shadow_draw( n_spider *p )
{

	if ( p->shadow_global_onoff == n_false ) { return; }

	//if ( p->animation_onoff ) { return; }


	p->shadow_onoff = n_true;

	n_game_chara *c = &p->tableau[ p->drag_index ];

	n_type_gfx ox = ( p->cardgen.halo * 1 );
	n_type_gfx oy = ( p->cardgen.halo * 1 );
	n_type_gfx  x = c->x + ox;
	n_type_gfx  y = c->y + oy;
	n_type_gfx sx = N_BMP_SX( p->shadow_bmp );
	n_type_gfx sy = N_BMP_SY( p->shadow_bmp );

	//n_bmp_rasterizer( p->shadow_bmp, &game.bmp, x,y, n_bmp_rgb( 50,50,50 ), n_false );
	//n_bmp_transcopy( p->shadow_bmp, &game.bmp, 0,0,sx,sy, x,y );

	n_bmp_clipcopy( p->shadow_bmp, &game.bmp, 0,0,sx,sy, x,y, c->chara,ox,oy, 0.0 );
//n_bmp_save_literal( c->chara, "ret.bmp" );


	p->shadow_px  = x;
	p->shadow_py  = y;
	p->shadow_psx = N_BMP_SX( p->shadow_bmp );
	p->shadow_psy = N_BMP_SY( p->shadow_bmp );


	return;
}

n_bool
n_spider_restore( n_spider *p, int index )
{

	if ( index != N_SPIDER_NOTHING )
	{

		if ( n_false == n_spider_rule_is_movable( p, index ) ) { return n_false; }


		n_game_chara_dnd( &p->tableau[ index ], game.hwnd, VK_LBUTTON );
		if ( n_false == p->tableau[ index ].dnd_onoff ) { return n_false; }


		if ( p->drag_index == N_SPIDER_NOTHING )
		{
//n_game_title_literal( "Restore : ON" );


			n_game_sound_loop( &p->snd_take );


			p->drag_index = index;

			int y = 0;
			n_posix_loop
			{

				int upper = p->drag_index + n_spider_index_upper( y );
				if ( upper >= N_SPIDER_PILE_ALL ) { break; }
				if ( p->tableau[ upper ].data == N_SPIDER_NOTHING ) { break; }

				p->restore[ y ] = p->tableau[ upper ];

				y++;
				if ( y >= N_SPIDER_PILE_SY ) { break; }
			}

			p->restore_count = y;

			n_spider_shadow( p );

			p->dnd_pile_index = p->drag_index % N_SPIDER_PILE_SX;
//n_game_hwndprintf_literal( " %d ", p->dnd_pile_index );

		} else {
//n_game_title_literal( "Dragging" );

			// Multiple Dragging

			if ( p->restore_count >= 2 )
			{
				int i = 1;
				n_posix_loop
				{

					int upper = p->drag_index + n_spider_index_upper( i );

					p->tableau[ upper ].x = p->tableau[ p->drag_index ].x;
					p->tableau[ upper ].y = p->tableau[ p->drag_index ].y + ( p->cardgen.osy * i );


					i++;
					if ( i >= p->restore_count ) { break; }
				}
			}


			// [!] : change halo color when puttable

//n_win_debug_count( game.hwnd );

			p->color_halo_current = p->cardgen.color_halo;


			n_type_gfx ox = p->cardgen.card_sx / 2;
			n_type_gfx oy = p->cardgen.card_sy / 2;

			int x = 0;
			int y = 0;
			n_posix_loop
			{

				int target = n_spider_pos2index( x,y );

				if (
					( p->tableau[ target ].data == N_SPIDER_NOTHING )
					&&
					( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->tableau[ target ], ox,oy, 0,0 ) )
					&&
					(
						( x == p->dnd_pile_index )
						||
						( n_spider_rule_is_puttable( p, target ) )
					)
				)
				{
					p->color_halo_current = p->color_halo_focus;
					break;
				}


				x++;
				if ( x >= N_SPIDER_PILE_SX )
				{

					x = 0;

					y++;
					if ( y >= N_SPIDER_PILE_SY ) { break; }
				}
			}

		}


		// [!] : off for halo effect

		//if ( n_game_chara_is_moved( &p->tableau[ p->drag_index ] ) )
		{
			n_game_refresh_on();
		}

	} else {

		if ( p->drag_index == N_SPIDER_NOTHING ) { return n_false; }

//n_game_title_literal( "Restore : OFF" );


		p->color_halo_current = p->cardgen.color_halo;


		n_bool moved = n_false;


		n_type_gfx ox = p->cardgen.card_sx / 2;
		n_type_gfx oy = p->cardgen.card_sy / 2;

		int x = 0;
		int y = 0;
		n_posix_loop
		{

			int target = n_spider_pos2index( x,y );

			if (
				( p->tableau[ target ].data == N_SPIDER_NOTHING )
				&&
				( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->tableau[ target ], ox,oy, 0,0 ) )
				&&
				( n_spider_rule_is_puttable( p, target ) )
			)
			{
//n_game_title_literal( "Collision" );
//break;
				moved = n_true;

				break;
			}


			x++;
			if ( x >= N_SPIDER_PILE_SX )
			{

				x = 0;

				y++;
				if ( y >= N_SPIDER_PILE_SY ) { break; }
			}
		}


		if ( moved == n_false )
		{

			int i = 0;
			n_posix_loop
			{

				int upper = p->drag_index + n_spider_index_upper( i );

				n_spider_chara_erase( p, &p->tableau[ upper ] );

				p->tableau[ upper ] = p->restore[ i ];


				i++;
				if ( i >= p->restore_count ) { break; }
			}

		} else {

			// [!] : cascade to the bottom most

			n_posix_loop
			{

				int target = n_spider_pos2index( x,y );

				if ( p->tableau[ target ].data != N_SPIDER_NOTHING ) { break; }

				y--;
				if ( y < 0 ) { break; }
			}
			y++;


			int i = 0;
			n_posix_loop
			{

				int f = n_spider_index_upper( i ) + p->drag_index;
				int t = n_spider_index_upper( i ) + n_spider_pos2index( x,y );


				// [!] : erase the last dragged position

				n_spider_chara_erase( p, &p->tableau[ f ] );


				// [!] : restore x,y,px,py

				p->tableau[ f ] = p->restore[ i ];


				// Move

				p->tableau[ t ].data  = p->tableau[ f ].data;
				p->tableau[ f ].data  = N_SPIDER_NOTHING;

				p->tableau[ t ].chara = p->tableau[ f ].chara;
				p->tableau[ f ].chara = NULL;


				i++;
				if ( i >= p->restore_count ) { break; }
			}


			p->sequence = N_SPIDER_SEQUENCE_DELAY;

		}


		p->tableau[ p->drag_index ].dnd_onoff = n_false;
		p->drag_index = N_SPIDER_NOTHING;


		n_game_sound_loop( &p->snd_take );

		n_spider_redraw( p );

		n_game_refresh_on();

	}


	return n_true;
}

void
n_spider_shuffle( n_spider *p )
{

	if ( p->debug_onoff )
	{

		int i = 0;
		int j = 0;
		int k = 0;
		n_posix_loop
		{

			if ( ( p->debug_seq_onoff )&&( k == 0 ) )
			{
				p->stock[ i ].data = 0;
			} else {
				p->stock[ i ].data = ( N_SPIDER_CARD_UNIT - 1 ) - ( j % N_SPIDER_CARD_UNIT );
			}

			k++;
			if ( k >= p->debug_pile_sx ) { k = 0; j++; }

			i++;
			if ( i >= N_SPIDER_PILE_SY ) { break; }

		}

		return;
	}


	int i = 0;
	n_posix_loop
	{

		int r = n_random_range_hq( N_SPIDER_PILE_SY );
//if ( r >= N_SPIDER_PILE_SY ) { n_game_title_literal( "n_random_range_hq()" ); }

		int swap           = p->stock[ i ].data;
		p->stock[ i ].data = p->stock[ r ].data;
		p->stock[ r ].data = swap;


		i++;
		if ( i >= N_SPIDER_PILE_SY ) { break; }
	}


	return;
}

void
n_spider_shuffle_all( n_spider *p )
{

	// Stock

	p->stock_index = 0;

	{

		int unit = N_SPIDER_CARD_UNIT * p->option_suit;

		int i = 0;
		n_posix_loop
		{

			p->stock[ i ].data = i % unit;


			// [!] : make spades

			if ( ( p->option_suit == 2 )&&( p->stock[ i ].data >= N_SPIDER_CARD_UNIT ) )
			{
				p->stock[ i ].data += N_SPIDER_CARD_UNIT;
			}


			i++;
			if ( i >= N_SPIDER_PILE_SY ) { break; }
		}

	}


	// Shuffle

	int i = 0;
	n_posix_loop
	{

		n_spider_shuffle( p );


		i++;
		if ( i >= 10 ) { break; }
	}


	return;
}

void
n_spider_deal( n_spider *p )
{

	int x = p->deal_x;
	int y = 0;
	n_posix_loop
	{

		int target = n_spider_pos2index( x,y );

		if ( p->tableau[ target ].data == N_SPIDER_NOTHING ) { break; }

		y++;
		if ( y >= N_SPIDER_PILE_SY ) { break; }
	}

	if ( p->loaded[ x ] )
	{

		int target = n_spider_pos2index( x,y );
		int number = p->stock[ p->p_stock[ x ] ].data;

		p->tableau[ target ].data  = number;
		p->tableau[ target ].chara = &p->cardgen.cards[ number ];


		n_game_sound_loop( &p->snd_deal );


		p->redraw[ x ] = n_true;

	}


	return;
}

void
n_spider_deal_preload( n_spider *p )
{

	int x = 0;
	n_posix_loop
	{

		p->loaded[ x ] = n_false;

		int y = 0;
		n_posix_loop
		{

			int target = n_spider_pos2index( x,y );

			if ( p->tableau[ target ].data == N_SPIDER_NOTHING ) { break; }

			y++;
			if ( y >= N_SPIDER_PILE_SY ) { break; }
		}

		if ( p->stock_index < N_SPIDER_PILE_SY )
		{

			p->p_stock[ x ] = p->stock_index; p->stock_index++;
			p->loaded [ x ] = n_true;


			p->redraw [ x ] = n_false;


			p->sequence = N_SPIDER_SEQUENCE_DELAY;

		}

		x++;
		if ( x >= p->debug_pile_sx ) { break; }
	}

//n_game_hwndprintf_literal( "%d/%d", p->stock_index, N_SPIDER_PILE_SY );


	return;
}

void
n_spider_reset( n_spider *p, n_bool is_init )
{

	// Reset : once per session

	p->drag_index = N_SPIDER_NOTHING;


	if ( is_init )
	{
		n_game_chara_bulk_zero( p->bottom,  N_SPIDER_PILE_SX  );
		n_game_chara_bulk_zero( p->stock,   N_SPIDER_PILE_SY  );
		n_game_chara_bulk_zero( p->tableau, N_SPIDER_PILE_ALL );
	}


	int x,y;

	x = y = 0;
	n_posix_loop
	{

		int    target = n_spider_pos2index( x,y );
		n_bmp *bmp_bg = &p->bmp_bg; if ( game.dwm_onoff ) { bmp_bg = NULL; }


		if ( is_init )
		{
			n_game_chara_bmp( &p->tableau[ target ], &game.bmp, NULL, bmp_bg, game.color );
			n_game_chara_src( &p->tableau[ target ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

			p->tableau[ target ].data = N_SPIDER_NOTHING;
		} else {
			n_game_chara_src( &p->tableau[ target ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );
		}


		x++;
		if ( x >= N_SPIDER_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_SPIDER_PILE_SY ) { break; }
		}
	}

	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg; if ( game.dwm_onoff ) { bmp_bg = NULL; }

		n_game_chara_bmp( &p->bottom[ x ], &game.bmp, &p->cardgen.bmp_foundation, bmp_bg, game.color );
		n_game_chara_src( &p->bottom[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );


		x++;
		if ( x >= N_SPIDER_PILE_SX ) { break; }
	}


	if ( is_init ) { p->event = N_SPIDER_EVENT_DEAL; }


	return;
}

n_bool
n_spider_is_deal( n_spider *p )
{

	static n_game_click click;


	static n_bool is_first = n_true;
	if ( is_first )
	{
		is_first = n_false;
		n_game_click_init( &click, VK_RBUTTON );
	}


	if (
		( n_game_click_single( &click ) )
		&&
		( n_win_is_hovered( game.hwnd ) )
		&&
		( n_win_simplemenu_target == NULL )
	)
	{
		return n_true;
	}


	return n_false;
}

void
n_spider_flush_background( n_spider *p )
{

	if ( game.dwm_onoff )
	{
		n_bmp_flush( &game.bmp, game.color );
	} else {
		n_bmp_flush( &game.bmp, p->color_gradient_upper );

		n_type_gfx sx = game.sx;
		n_type_gfx sy = game.sy / 3;
		n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );
		u32 color = n_bmp_alpha_replace_pixel( p->color_gradient_upper, 0 );
		n_bmp_flush_gradient( &b, color, p->color_gradient_lower, N_BMP_GRADIENT_VERTICAL );
		n_bmp_transcopy( &b, &game.bmp, 0,0,sx,sy, 0, ( sy * 2 ) + ( sy % 2 ) );
		n_bmp_free_fast( &b );
	}

	n_bmp_free( &p->bmp_bg );
	n_bmp_carboncopy( &game.bmp, &p->bmp_bg );


	return;
}

void
n_spider_newgame( n_spider *p )
{

	n_spider_flush_background( p );

	n_spider_reset( p, n_true );
	n_spider_shuffle_all( p );
	n_spider_reposition( p );
	n_spider_redraw( p );

	return;
}

void
n_spider_replay( n_spider *p )
{

	p->drag_index  = N_SPIDER_NOTHING;
	p->stock_index = 0;


	int i = 0;
	n_posix_loop
	{

		p->tableau[ i ].data = N_SPIDER_NOTHING;

		i++;
		if ( i >= N_SPIDER_PILE_ALL ) { break; }
	}


	p->event = N_SPIDER_EVENT_DEAL;


	return;
}

void
n_spider_input( n_spider *p )
{

	if ( n_false == n_game_refresh_is_off() ) { return; }


	// Deal

	if ( n_spider_is_deal( p ) )
	{

		if ( p->stock_index < N_SPIDER_PILE_SY )
		{
			if ( p->drag_index == N_SPIDER_NOTHING )
			{
				p->event = N_SPIDER_EVENT_DEAL;
			}
		} else {
			n_spider_newgame( p );
		}

		n_posix_sleep( 100 );

		n_game_refresh_on();

		return;

	}


	// DnD

	int i = N_SPIDER_PILE_ALL - 1;
	n_posix_loop
	{

		if ( n_spider_restore( p, i ) ) { break; }

		i--;
		if ( i < 0 )
		{
			n_spider_restore( p, N_SPIDER_NOTHING );
			break;
		}
	}


	// Sequence

	int x = 0;
	n_posix_loop
	{

		n_spider_rule_sequence( p, x );
		if ( p->event == N_SPIDER_EVENT_SEQUENCE )
		{
			p->redraw[ x ] = n_true;
			p->event_next  = N_SPIDER_EVENT_NONE;
			n_game_refresh_on();
		}

		x++;
		if ( x >= N_SPIDER_PILE_SX ) { break; }
	}


	return;
}

#define N_SPIDER_PILE_ERASE 0
#define N_SPIDER_PILE_DRAW  1

#define n_spider_pile_erase( p, x,y ) n_spider_pile( p, x,y, N_SPIDER_PILE_ERASE )
#define n_spider_pile_draw(  p, x,y ) n_spider_pile( p, x,y, N_SPIDER_PILE_DRAW  )

void
n_spider_pile( n_spider *p, int x, int y, int mode )
{

	// [!] : draw always for alpha blending

	if ( y == 0 )
	{

		if ( mode == N_SPIDER_PILE_ERASE )
		{
			n_game_chara_erase( &p->bottom[ x ] );
		} else {
			n_game_chara_draw ( &p->bottom[ x ] );
//n_bmp_box( &game.bmp, p->bottom[ x ].x,p->bottom[ x ].y, p->bottom[ x ].sx,10, n_game_randomcolor() );
		}

	}


	n_posix_loop
	{

		n_game_chara *c = &p->tableau[ n_spider_pos2index( x, y + 0 ) ];

		if ( c->data == N_SPIDER_NOTHING ) { break; }


		// [!] : dragged cards are handled as overlay

		if ( p->drag_index != N_SPIDER_NOTHING )
		{
			if ( p->drag_index == n_spider_pos2index( x,y ) ) { break; }
		}


		if ( mode == N_SPIDER_PILE_ERASE )
		{
			n_game_chara_erase( c );
		} else {
			n_game_chara_draw ( c );
//n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_game_randomcolor() );
		}


		y++;
		if ( y >= N_SPIDER_PILE_SY ) { break; }
	}


	return;
}

typedef struct {

	n_spider *spider;
	int       offset, cores;

} n_spider_pile_draw_all_thread_struct;

DWORD WINAPI
n_spider_pile_draw_all_thread( LPVOID lpParameter )
{

	n_spider_pile_draw_all_thread_struct *p = (void*) lpParameter;


	int x = p->offset;
	n_posix_loop
	{

		if ( p->spider->redraw[ x ] )
		{
			p->spider->redraw[ x ] = n_false;
			n_spider_pile_draw( p->spider, x, 0 );
/*
n_game_chara *c = &p->spider->tableau[ n_spider_pos2index( x, 0 ) ];
if ( 0 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 0,200,255 ) ); }
if ( 1 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 255,0,200 ) ); }
if ( 2 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 0,  0,255 ) ); }
if ( 3 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 255,0,  0 ) ); }
*/
		}

		x += p->cores;
		if ( x >= N_SPIDER_PILE_SX ) { break; }
	}


	return 0;
}

void
n_spider_pile_draw_all( n_spider *p )
{

	if ( n_thread_onoff() )
	{

		n_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_true;


		u32 cores = n_posix_min( n_thread_core_count, N_SPIDER_PILE_SX );


		n_thread                             *h = n_memory_new( cores * sizeof( n_thread                             ) );
		n_spider_pile_draw_all_thread_struct *f = n_memory_new( cores * sizeof( n_spider_pile_draw_all_thread_struct ) );


		u32 i = 0;
		n_posix_loop
		{

			n_spider_pile_draw_all_thread_struct tmp = { p, i, cores };
			n_memory_copy( &tmp, &f[ i ], sizeof( n_spider_pile_draw_all_thread_struct ) );

			h[ i ] = n_thread_init( n_spider_pile_draw_all_thread, &f[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( f );


		n_bmp_is_multithread = p_multithread;

		return;
	}


	int x = 0;
	n_posix_loop
	{

		if ( p->redraw[ x ] )
		{
			p->redraw[ x ] = n_false;
			n_spider_pile_draw( p, x, 0 );
		}


		x++;
		if ( x >= N_SPIDER_PILE_SX ) { break; }
	}


	return;
}

void
n_spider_style_change( n_spider *p )
{

	p->is_first    = n_true;


	n_project_darkmode();

	n_win_darkmode_hwnd( game.hwnd, n_win_darkmode_onoff );


	// [!] : DWM is off : because of not beautiful

	//n_game_dwm_onoff();

	game.dwm_onoff = n_posix_false;

//game.dwm_onoff = n_true;

	if ( game.dwm_onoff )
	{
		p->        color_init       = n_bmp_black_invisible;
		p->        color_text       = n_bmp_white;
		p->cardgen.color_margin     = n_bmp_black_invisible;
		p->cardgen.color_halo       = n_bmp_argb( 255,128,128,128 );
		p->        color_halo_focus = n_win_dwm_windowcolor_arranged();
	} else
	if ( n_win_darkmode_onoff )
	{
		p->        color_init       = n_bmp_rgb( 10,10,10 );
		p->        color_text       = n_bmp_white;
		p->cardgen.color_margin     = n_bmp_black_invisible;
		p->cardgen.color_halo       = n_bmp_rgb( 10,10,10 );
		p->        color_halo_focus = n_win_dwm_windowcolor_arranged();
	} else {
		p->        color_init       = n_gdi_systemcolor( COLOR_WINDOW     );
		p->        color_text       = n_gdi_systemcolor( COLOR_WINDOWTEXT );
		p->cardgen.color_margin     = n_bmp_white_invisible;
		p->cardgen.color_halo       = n_win_dwm_windowcolor_arranged();
		p->        color_halo_focus = n_bmp_rgb( 255,255,0 );
	}

	p->color_gradient_upper = n_bmp_lightness_replace_pixel( p->cardgen.color_halo,  50 );
	p->color_gradient_lower = n_bmp_lightness_replace_pixel( p->cardgen.color_halo, 100 );

	n_cardgenerator_exit( &p->cardgen );
	n_cardgenerator_init( &p->cardgen, 10 );


	return;
}




#define n_spider_zero( p ) n_memory_zero( p, sizeof( n_spider ) )

void
n_spider_init( n_spider *p )
{

	// Global #1

	n_direct2d_exit();

	n_bmp_safemode = n_bmp_safemode_base = n_false;

	n_win_tabletpc_disable( game.hwnd );


	// [!] : .option_* is set here

	p->ini_section   = n_posix_literal( "Nonnon Spider" );
	p->ini_lval_suit = n_posix_literal( "suit" );

	n_spider_ini_read( p );


	// Cards

	n_spider_style_change( p );


	// System

	n_game_title_literal( "+++Nonnon Spider+++" );

	game.sx       = p->cardgen.csx;
	game.sy       = p->cardgen.csy;
	game.fps      = 30;
	game.color    = p->color_init;
	game.on_event = n_spider_on_event;
	game.on_close = n_spider_on_close;

	n_game_window_resizable();

	n_spider_menu_init( p );


	n_hmidiout_init();


	// Resource

	n_game_sound_zero( &p->snd_mute );
	n_game_sound_init_literal( &p->snd_mute, game.hwnd, NSPIDER_WAV_MUTE );
	n_game_sound_loop( &p->snd_mute );

	n_game_sound_zero( &p->snd_take );
	n_game_sound_init_literal( &p->snd_take, game.hwnd, NSPIDER_WAV_TAKE );

	n_game_sound_zero( &p->snd_deal );
	n_game_sound_init_literal( &p->snd_deal, game.hwnd, NSPIDER_WAV_DEAL );


	// Debug Center

	p->debug_onoff     = n_false;
	p->debug_seq_onoff = n_false;
	p->debug_pile_sx   = N_SPIDER_PILE_SX;
	p->debug_deal_msec = N_SPIDER_DEAL_MSEC;

	p->shadow_global_onoff = n_true;

/*
	p->debug_onoff     = n_true;
	p->debug_seq_onoff = n_true;
	p->debug_pile_sx   = 3;
	p->debug_deal_msec = N_SPIDER_DEAL_MSEC;
*/


	return;
}

void
n_spider_loop( n_spider *p )
{
//return;

	if ( n_game_refresh_is_resize() )
	{
		if ( p->is_init == n_false )
		{
			return;
		}
	}


	if ( n_win_simplemenu_target != NULL ) { return; }


	n_cardgenerator_loop( &p->cardgen );


	// Splash Screen

	if ( p->splash_onoff == n_false )
	{

		if ( NULL == N_BMP_PTR( &p->transition_bmp_old ) )
		{

			p->transition_type = N_GAME_TRANSITION_NOTHING;
			if ( n_win_fade_is_on() ) { p->transition_type = N_GAME_TRANSITION_FADE; }

			n_spider_reset( p, n_true );
			n_spider_shuffle_all( p );
			n_spider_reposition( p );
			n_spider_redraw( p );

			n_bmp_new_fast( &p->transition_bmp_old, game.sx,game.sy );
			n_bmp_new_fast( &p->transition_bmp_new, game.sx,game.sy );

			n_spider_splashscreen( p, &p->transition_bmp_old );
//n_bmp_carboncopy( &p->transition_bmp_old, &p->transition_bmp_new );

			p->is_init = p->splash_onoff =  n_true;

			n_spider_flush_background( p );
			n_spider_loop( p );
			n_bmp_flush_fastcopy( &game.bmp, &p->transition_bmp_new );

			p->is_init = p->splash_onoff = n_false;
//n_win_exedir2curdir();
//n_bmp_save_literal( &p->transition_bmp_new, "ret.bmp" );
		}

		if ( game.dwm_onoff )
		{
			n_game_clear( game.color );
			n_bmp_flush_blendcopy( &p->transition_bmp_old, &game.bmp, (n_type_real) p->transition_percent * 0.01 );
		}

		n_bool ret = n_game_transition
		(
			&game.bmp,
			&p->transition_bmp_old,
			&p->transition_bmp_new,
			N_SPIDER_FADE_MSEC,
			&p->transition_percent,
			p->transition_type
		);

		if ( ret )
		{

			p->splash_onoff = n_true;

			n_bmp_free( &p->transition_bmp_old );
			n_bmp_free( &p->transition_bmp_new );

			p->is_init = n_true;

			if ( game.dwm_onoff )
			{
				n_spider_flush_background( p );
				n_spider_redraw( p );
				n_spider_pile_draw_all( p );
			}

			n_game_refresh_on();

		} else {

			n_game_refresh_on();

			return;
		}

	}


	// Control

	if ( p->sequence == N_SPIDER_SEQUENCE_DELAY )
	{

		// [!] : delay for smooth transition

		if ( n_game_refresh_is_off() )
		{
			p->sequence = N_SPIDER_SEQUENCE_GO;
		}

	}


	// Input

	if ( p->resize_phase == N_SPIDER_RESZ_PHASE_STOP )
	{
		if ( n_game_timer( &p->resize_timer, N_SPIDER_RESZ_MSEC ) )
		{
			p->resize_phase = N_SPIDER_RESZ_PHASE_NONE;
		}
	}

	if ( p->event == N_SPIDER_EVENT_NONE )
	{
		if ( p->resize_phase == N_SPIDER_RESZ_PHASE_NONE )
		{
			n_spider_input( p );
		}
	}


	// Resize

	if ( n_game_refresh_is_resize() )
	{
//n_game_title_literal( "Resize" );

		p->resize_timer = n_posix_tickcount();
		p->resize_phase = N_SPIDER_RESZ_PHASE_STOP;


		n_spider_flush_background( p );


		p->cardgen.csx = game.sx;
		p->cardgen.csy = game.sy;

		n_spider_reposition( p );
		n_spider_redraw( p );

		n_game_refresh_on();

	}


	// Draw

	if ( ( p->resize_phase == N_SPIDER_RESZ_PHASE_NONE )&&( p->event == N_SPIDER_EVENT_DEAL ) )
	{

		if ( p->deal_x >= p->debug_pile_sx )//N_SPIDER_PILE_SX )
		{
//n_game_hwndprintf_literal( "1" );

			p->event  = N_SPIDER_EVENT_NONE;
			p->deal_x = 0;

			n_game_timer( &p->deal_timer, p->debug_deal_msec );

		} else {

			if ( p->deal_phase == N_SPIDER_DEAL_PHASE_0 )
			{
//n_game_hwndprintf_literal( " N_SPIDER_DEAL_PHASE_0 " );

				// [!] : draw the bottom images

				p->deal_phase = N_SPIDER_DEAL_PHASE_1;

				int x = 0;
				n_posix_loop
				{
					p->redraw[ x ] = n_true;

					x++;
					if ( x >= N_SPIDER_PILE_SX ) { break; }
				}

				n_game_refresh_on();

			} else
			if ( p->deal_phase == N_SPIDER_DEAL_PHASE_1 )
			{
//n_game_hwndprintf_literal( " N_SPIDER_DEAL_PHASE_1 " );

				p->deal_phase = N_SPIDER_DEAL_PHASE_2;

				n_spider_deal_preload( p );

			} else
			if ( p->deal_phase == N_SPIDER_DEAL_PHASE_2 )
			{
//n_game_hwndprintf_literal( " N_SPIDER_DEAL_PHASE_2 " );

				if ( n_game_timer( &p->deal_timer, p->debug_deal_msec ) )
				{

					n_spider_deal( p );

					n_spider_rule_sequence( p, p->deal_x );
					if ( p->event == N_SPIDER_EVENT_SEQUENCE )
					{
						p->redraw[ p->deal_x ] = n_true;
						p->event_next          = N_SPIDER_EVENT_DEAL;
					}

					p->deal_x++;
					if ( p->deal_x >= p->debug_pile_sx )//N_SPIDER_PILE_SX )
					{
						p->deal_phase = N_SPIDER_DEAL_PHASE_0;
					}

					n_game_refresh_on();

				}

			}

		}

	} else
	if ( p->event == N_SPIDER_EVENT_SEQUENCE )
	{

		if ( n_game_timer( &p->sequence_timer, p->debug_deal_msec ) )
		{
			n_spider_rule_sequence_animation( p );
		}

	} else
	if ( p->event == N_SPIDER_EVENT_SOUNDSTOP )
	{

		if ( n_game_timer( &p->sequence_timer, p->debug_deal_msec ) )
		{

			p->event    = p->event_next;
			p->sequence = N_SPIDER_SEQUENCE_NONE;

			if ( n_hmidiout_hmo == NULL )
			{
				n_spider_midi_note_off( p );
			}

		}

	}


	if ( n_game_refresh_is_on() )
	{

//n_game_hwndprintf_literal( "%d", p->restore_count );
//n_game_hwndprintf_literal( "%d", p->event );


		// Erase

		if ( p->drag_index != N_SPIDER_NOTHING )
		{

			// [!] : Safe Mode

			//n_spider_redraw( p );
			//n_bmp_flush( &game.bmp, game.color );


			// [!] : Fast Mode

			n_spider_redraw_detect( p );


			int i = 0;
			n_posix_loop
			{

				int upper = p->drag_index + n_spider_index_upper( i );

				n_game_chara *c = &p->tableau[ upper ];

				n_spider_chara_erase( p, c );

				i++;
				if ( i >= p->restore_count ) { break; }
			}

		}

		n_spider_shadow_erase( p );

		{

			int x = 0;
			n_posix_loop
			{


				if ( p->redraw[ x ] ) { n_spider_pile_erase( p, x, 0 ); }


				x++;
				if ( x >= N_SPIDER_PILE_SX ) { break; }
			}

		}


		// Draw

		n_spider_pile_draw_all( p );

		if ( p->drag_index != N_SPIDER_NOTHING )
		{

			n_spider_shadow_draw( p );

			int i = 0;
			n_posix_loop
			{

				int upper = p->drag_index + n_spider_index_upper( i );

				n_game_chara *c = &p->tableau[ upper ];

				n_spider_chara_draw( p, c );


				i++;
				if ( i >= p->restore_count ) { break; }
			}

		}


		n_game_refresh_on();

	}


	return;
}

void
n_spider_exit( n_spider *p )
{

	n_cardgenerator_exit( &p->cardgen );


	n_bmp_free_fast( &p->bmp_bg    );
	n_bmp_free_fast( &p->bmp_check );

	int i = 0;
	n_posix_loop
	{

		n_bmp_free_fast( &p->shadow_bmp_cache[ i ] );

		i++;
		if ( i >= N_SPIDER_SHADOW_COUNT ) { break; }
	}


	n_game_sound_exit( &p->snd_mute );
	n_game_sound_exit( &p->snd_take );
	n_game_sound_exit( &p->snd_deal );

	n_hmidiout_exit();


	n_spider_zero( p );


	//n_memory_debug_refcount();


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_spider_zero( &spider );
	n_spider_init( &spider );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_spider_exit( &spider );
		n_spider_init( &spider );
		n_game_reset();
	}

	n_spider_loop( &spider );


	return;
}

void
n_game_exit( void )
{

	n_spider_exit( &spider );


	return;
}

#endif // #ifndef N_GAMECONSOLE

