// Neko no Te : New File Tweaker
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




//#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_inputpopup.c"
#include "../nonnon/win32/win_radiobutton.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_smallbutton_direct.c"

#include "../nonnon/win32/registry.c"
#include "../nonnon/win32/sysinfo.c"


#include "../nonnon/project/macro.c"




#define H_EXT_LINE     n_nekonote_new_hgui[ 0 ]
#define H_EXT_LABEL    n_nekonote_new_hgui[ 1 ]
#define H_EXT_TEMPLATE n_nekonote_new_hgui[ 2 ]
#define H_TYP_LINE     n_nekonote_new_hgui[ 3 ]
#define H_TYP_NAME     n_nekonote_new_hgui[ 4 ]
#define H_PAD_LINE     n_nekonote_new_hgui[ 5 ]
#define GUI_MAX                             6

#define H_EXT_BUTTON   n_nekonote_new_hbtn[ 0 ]
#define BTN_MAX                             1


#define N_NEKONOTE_NEW_HKLM     n_posix_literal( "System" )
#define N_NEKONOTE_NEW_HKCU     n_posix_literal( "User" )
#define N_NEKONOTE_NEW_TEMPLATE n_posix_literal( "Template" )
#define N_NEKONOTE_NEW_NAME     n_posix_literal( "Displayed Name" )




static HWND              n_nekonote_new_hgui[ GUI_MAX ];
static n_win_button      n_nekonote_new_hbtn[ BTN_MAX ];

static n_posix_char      n_nekonote_new_ext[ N_PATH_MAX ] = N_STRING_EMPTY;
static n_posix_char      n_nekonote_new_typ[ N_PATH_MAX ] = N_STRING_EMPTY;

static n_win_radio       n_nekonote_new_radio_hklm;
static n_win_radio       n_nekonote_new_radio_hkcu;

static n_win_txtbox      n_nekonote_new_input_ext;
static n_win_txtbox      n_nekonote_new_input_typ;

static n_win_smallbutton_direct n_nekonote_new_smallbutton_ext;
static n_win_smallbutton_direct n_nekonote_new_smallbutton_typ;

static n_bool            n_nekonote_new_is_system = n_true;//n_false;




void
n_nekonote_new_error( void )
{

	n_project_dialog_info
	(
		GetParent( H_EXT_LINE ),
		n_posix_literal( "Administrator rights are needed." )
	);


	return;
}

void
n_nekonote_new_nullfile_init( HKEY *hive, n_posix_char *path, n_posix_char *lval )
{

	if ( n_nekonote_new_is_system )
	{
		(*hive) = HKEY_LOCAL_MACHINE;
	} else {
		(*hive) = HKEY_CURRENT_USER;
	}

	n_posix_sprintf_literal( path, "Software\\Classes\\%s\\ShellNew", n_nekonote_new_ext );

	n_posix_sprintf_literal( lval, "%s", n_posix_literal( "NullFile" ) );


	return;
}

void
n_nekonote_new_nullfile_addremove( void )
{

	HKEY         hive;
	n_posix_char path[ N_PATH_MAX ];
	n_posix_char lval[ N_PATH_MAX ];

	n_nekonote_new_nullfile_init( &hive, path, lval );


	DWORD ret = 0;

	if ( n_registry_is_exist( hive, path, lval ) )
	{
		ret = n_registry_delete_value( hive, path, lval );
	} else {
		ret = n_registry_write( hive, path, lval, REG_SZ, N_STRING_EMPTY, 0 );
	}

	if ( ret ) { n_nekonote_new_error(); }


	return;
}

void
n_nekonote_new_filename_init( HKEY *hive, n_posix_char *path, n_posix_char *lval )
{

	if ( n_nekonote_new_is_system )
	{
		(*hive) = HKEY_LOCAL_MACHINE;
	} else {
		(*hive) = HKEY_CURRENT_USER;
	}

	n_posix_sprintf_literal( path, "Software\\Classes\\%s\\ShellNew", n_nekonote_new_ext );

	n_posix_sprintf_literal( lval, "%s", n_posix_literal( "FileName" ) );


	return;
}

void
n_nekonote_new_filename_template_add( void )
{

	HKEY         hive;
	n_posix_char path[ N_PATH_MAX ];
	n_posix_char lval[ N_PATH_MAX ];

	n_nekonote_new_filename_init( &hive, path, lval );


	n_posix_char str_template[ N_PATH_MAX ];
	n_win_txtbox_selection_get( &n_nekonote_new_input_ext, str_template );

	DWORD  cb = (DWORD) n_posix_strlen( str_template ) * sizeof( n_posix_char );
	DWORD ret = n_registry_write( hive, path, lval, REG_SZ, str_template, cb );

	if ( ret ) { n_nekonote_new_error(); }


	return;
}

void
n_nekonote_new_name_init( HKEY *hive, n_posix_char *path, n_posix_char *lval )
{

	if ( n_nekonote_new_is_system )
	{
		(*hive) = HKEY_LOCAL_MACHINE;
	} else {
		(*hive) = HKEY_CURRENT_USER;
	}

	n_posix_sprintf_literal( path, "Software\\Classes\\%s", n_nekonote_new_typ );

	n_posix_sprintf_literal( lval, "%s", n_posix_literal( "" ) );


	return;
}

void
n_nekonote_new_name_add( void )
{

	HKEY         hive;
	n_posix_char path[ N_PATH_MAX ];
	n_posix_char lval[ N_PATH_MAX ];

	n_nekonote_new_name_init( &hive, path, lval );


	n_posix_char name[ N_PATH_MAX ];
	n_win_txtbox_selection_get( &n_nekonote_new_input_typ, name );

	DWORD name_cb = (DWORD) n_posix_strlen( name ) * sizeof( n_posix_char );
	DWORD ret     = n_registry_write( hive, path, lval, REG_SZ, name, name_cb );

	if ( ret ) { n_nekonote_new_error(); }


	return;
}

void
n_nekonote_new_init( void )
{

	HKEY         hive;
	n_posix_char path[ N_PATH_MAX ];
	n_posix_char lval[ N_PATH_MAX ];


	// [!] : small buttons

	n_win_txtbox_smallbutton_direct_embed( &n_nekonote_new_input_ext, &n_nekonote_new_smallbutton_ext, 0 );
	n_win_txtbox_smallbutton_direct_embed( &n_nekonote_new_input_typ, &n_nekonote_new_smallbutton_typ, 0 );

	n_win_smallbutton_direct_bitmap_init( &n_nekonote_new_smallbutton_ext );
	n_win_smallbutton_direct_bitmap_init( &n_nekonote_new_smallbutton_typ );


	// [!] : Extension

	n_win_hwndprintf_literal( H_EXT_LINE, "Extension : %s", n_nekonote_new_ext );


	n_nekonote_new_nullfile_init( &hive, path, lval );

	if ( n_registry_is_exist( hive, path, lval ) )
	{
		n_win_hwndprintf_literal( H_EXT_LABEL      , "Register : (Registered)" );
		n_win_hwndprintf_literal( H_EXT_BUTTON.hwnd, "Unregister"              );
	} else {
		n_win_hwndprintf_literal( H_EXT_LABEL      , "Register : (Not registered)" );
		n_win_hwndprintf_literal( H_EXT_BUTTON.hwnd, "Register"                    );
	}


	if ( n_registry_is_exist( hive, path, lval ) )
	{
		EnableWindow( H_EXT_TEMPLATE, n_true );

		n_nekonote_new_smallbutton_ext.show_onoff = n_true;

		n_posix_sprintf_literal( lval, "%s", n_posix_literal( "FileName" ) );
		if ( n_registry_is_exist( hive, path, lval ) )
		{
			n_posix_char str_template[ N_PATH_MAX ] = N_STRING_EMPTY;
			n_registry_read( hive, path, lval, str_template, N_PATH_MAX * sizeof( n_posix_char ) );
			n_win_txtbox_line_set( &n_nekonote_new_input_ext, 0, str_template );
		}
	} else {
		EnableWindow( H_EXT_TEMPLATE, n_false );

		n_nekonote_new_smallbutton_ext.show_onoff = n_false;
	}


	// [!] : File Type

	n_win_hwndprintf_literal( H_TYP_LINE, "File Type : %s", n_nekonote_new_typ );


	// [!] : an empty path name will be opened as most top-level default key

	n_posix_sprintf_literal( path, "%s", n_nekonote_new_typ );

	n_bool typ_onoff = n_true;

	if ( n_string_is_empty( path ) )
	{
		typ_onoff = n_false;
	}

	n_nekonote_new_name_init( &hive, path, lval );

	if (
		( typ_onoff )
		//&&
		//( n_registry_is_exist( hive, path, lval ) )
	)
	{
		n_posix_char newfile[ N_PATH_MAX ] = N_STRING_EMPTY;
		n_string_truncate( lval );
		n_registry_read( hive, path, lval, newfile, N_PATH_MAX * sizeof( n_posix_char ) );
		n_win_txtbox_line_set( &n_nekonote_new_input_typ, 0, newfile );

		EnableWindow( H_TYP_NAME, n_true );

		n_nekonote_new_smallbutton_typ.show_onoff = n_true;
	} else {
		EnableWindow( H_TYP_NAME, n_false );

		n_nekonote_new_smallbutton_typ.show_onoff = n_false;
	}


	return;
}

void
n_nekonote_new_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_radio_on_settingchange( &n_nekonote_new_radio_hklm );
		n_win_radio_on_settingchange( &n_nekonote_new_radio_hkcu );

		n_win_smallbutton_direct_on_settingchange( &n_nekonote_new_smallbutton_ext, n_project_small_save );
		n_win_smallbutton_direct_on_settingchange( &n_nekonote_new_smallbutton_typ, n_project_small_save );

		n_win_stdfont_init( n_nekonote_new_hgui, GUI_MAX );

	break;


	} // switch


}

LRESULT CALLBACK
n_nekonote_new_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_nekonote_new_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global


		// Window

		n_win_init_literal( hwnd, "New File Tweaker", "", "" );

		n_win_radio_zero( &n_nekonote_new_radio_hklm );
		n_win_radio_zero( &n_nekonote_new_radio_hkcu );
		n_win_radio_init( &n_nekonote_new_radio_hklm, hwnd, N_NEKONOTE_NEW_HKLM, 0 );
		n_win_radio_init( &n_nekonote_new_radio_hkcu, hwnd, N_NEKONOTE_NEW_HKCU, 0 );

		n_win_smallbutton_direct_zero( &n_nekonote_new_smallbutton_ext );
		n_win_smallbutton_direct_zero( &n_nekonote_new_smallbutton_typ );

		{
			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET;

			n_win_txtbox_zero( &n_nekonote_new_input_ext );
			n_win_txtbox_zero( &n_nekonote_new_input_typ );

			n_win_txtbox_init( &n_nekonote_new_input_ext, hwnd, style, option );
			n_win_txtbox_init( &n_nekonote_new_input_typ, hwnd, style, option );
		}

		n_win_gui_literal( hwnd, CANVAS, "", &H_EXT_LINE     );
		n_win_gui_literal( hwnd, LABEL,  "", &H_EXT_LABEL    );
		n_win_button_init( &H_EXT_BUTTON, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_gui_literal( hwnd, LABEL,  "", &H_EXT_TEMPLATE );

		n_win_gui_literal( hwnd, CANVAS, "", &H_TYP_LINE     );
		n_win_gui_literal( hwnd, LABEL,  "", &H_TYP_NAME     );

		n_win_gui_literal( hwnd, CANVAS, "", &H_PAD_LINE     );


		n_win_hwndprintf( H_EXT_TEMPLATE, N_NEKONOTE_NEW_TEMPLATE );
		n_win_hwndprintf( H_TYP_NAME,     N_NEKONOTE_NEW_NAME     );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );

		n_win_style_add( n_nekonote_new_radio_hklm.hwnd, BS_CENTER );
		n_win_style_add( n_nekonote_new_radio_hkcu.hwnd, BS_CENTER );

		n_win_smallbutton_direct_init_by_data( &n_nekonote_new_smallbutton_ext, n_nekonote_new_input_ext.hwnd, hwnd, hwnd, 1, n_project_small_save );
		n_win_smallbutton_direct_init_by_data( &n_nekonote_new_smallbutton_typ, n_nekonote_new_input_typ.hwnd, hwnd, hwnd, 2, n_project_small_save );

		n_nekonote_new_smallbutton_ext.show_onoff = n_posix_true;
		n_nekonote_new_smallbutton_typ.show_onoff = n_posix_true;


		// Size

		n_win_stdfont_init( n_nekonote_new_hgui, GUI_MAX );


		{ // n_nekonote_new_resize()

		const n_bool redraw = n_false;


		n_type_gfx ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );

		n_type_gfx csx,csy; n_win_desktop_size( &csx, NULL );
		csx = n_posix_max_n_type_gfx( 333, (n_type_gfx) ( (n_type_real) csx * 0.25 ) );
		csy = ctl * 6;
		if ( n_sysinfo_version_xp_or_later() ) { csy = ctl * 7; }


		n_win_set( hwnd, NULL, csx + m, csy + m, N_WIN_SET_CENTERING );


		n_type_gfx u   = ( csx / 10 );
		n_type_gfx osx = ( csx % 10 ) + u;
		n_type_gfx isx = csx - osx;
		n_type_gfx x   = 0;
		n_type_gfx y   = 0;

		n_type_gfx label = 0;
		n_win_stdsize_text( H_TYP_NAME, N_NEKONOTE_NEW_NAME, &label, NULL );
		           label = label + m * 2;
		n_type_gfx input = isx - label;


		// [!] : Radio Buttons

		{

			n_type_gfx hlf = csx / 2;

			n_win_move( n_nekonote_new_radio_hklm.hwnd, x,y, hlf,ctl, redraw ); x += hlf; 
			n_win_move( n_nekonote_new_radio_hkcu.hwnd, x,y, hlf,ctl, redraw );

		}

		y += ctl;


		// [!] : Extension

		x = 0;

		n_win_move( H_EXT_LINE, x,y, csx,ctl, redraw ); y += ctl;


		{

			n_type_gfx lb1 = isx / 4 * 3;
			n_type_gfx bt1 = isx / 4 * 1;

			x = osx;
			n_win_move       (  H_EXT_LABEL , x,y, lb1,ctl, redraw );
			x = osx + lb1;
			n_win_button_move( &H_EXT_BUTTON, x,y, bt1,ctl, redraw );

		}


		if ( n_sysinfo_version_xp_or_later() )
		{

			y += ctl;

			x = osx;

			n_win_move( H_EXT_TEMPLATE               , x,y, label,ctl, redraw ); x += label;
			n_win_move( n_nekonote_new_input_ext.hwnd, x,y, input,ctl, redraw );

		}


		// [!] : File Type

		x  = 0;
		y += ctl;

		n_win_move( H_TYP_LINE, x,y, csx,ctl, redraw ); y += ctl;

		{
			x = osx;

			n_win_move( H_TYP_NAME                   , x,y, label,ctl, redraw ); x += label;
			n_win_move( n_nekonote_new_input_typ.hwnd, x,y, input,ctl, redraw );

		}

		// [!] Padding

		x  = 0;
		y += ctl;

		n_win_move( H_PAD_LINE, x,y, csx,ctl, redraw );


		} // n_nekonote_new_resize()


		// Init

		if ( n_nekonote_new_is_system )
		{
			n_win_radio_check( &n_nekonote_new_radio_hklm );
		} else {
			n_win_radio_check( &n_nekonote_new_radio_hkcu );
		}

		n_nekonote_new_init();


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( GetParent( hwnd ), n_false );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		SetFocus( hwnd );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == n_nekonote_new_radio_hklm.hwnd )
		{

			if ( wparam == RBS_CHECKEDHOT )
			{
				n_nekonote_new_is_system = n_true;
				n_win_radio_check  ( &n_nekonote_new_radio_hklm );
				n_win_radio_uncheck( &n_nekonote_new_radio_hkcu );
			} else {
				n_nekonote_new_is_system = n_false;
				n_win_radio_check  ( &n_nekonote_new_radio_hkcu );
				n_win_radio_uncheck( &n_nekonote_new_radio_hklm );
			}
//n_win_hwndprintf_literal( hwnd, " %d ", n_nekonote_new_is_system );

			n_nekonote_new_init();

		} else
		if ( (HWND) lparam == n_nekonote_new_radio_hkcu.hwnd )
		{

			if ( wparam == RBS_CHECKEDHOT )
			{
				n_nekonote_new_is_system = n_false;
				n_win_radio_check  ( &n_nekonote_new_radio_hkcu );
				n_win_radio_uncheck( &n_nekonote_new_radio_hklm );
			} else {
				n_nekonote_new_is_system = n_true;
				n_win_radio_check  ( &n_nekonote_new_radio_hklm );
				n_win_radio_uncheck( &n_nekonote_new_radio_hkcu );
			}
//n_win_hwndprintf_literal( hwnd, " %d ", n_nekonote_new_is_system );

			n_nekonote_new_init();

		} else
		if ( (HWND) lparam == n_nekonote_new_input_ext.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &n_nekonote_new_input_ext );
			}

		} else
		if ( (HWND) lparam == n_nekonote_new_input_typ.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &n_nekonote_new_input_typ );
			}

		} else
		if ( (HWND) lparam == H_EXT_BUTTON.hwnd )
		{
			n_nekonote_new_nullfile_addremove();
			n_nekonote_new_init();
		} else
		if ( ( (HWND) lparam == n_nekonote_new_smallbutton_ext.hwnd_msg )&&( wparam == 1 ) )
		{
			n_nekonote_new_filename_template_add();
			n_nekonote_new_init();
		} else
		if ( ( (HWND) lparam == n_nekonote_new_smallbutton_typ.hwnd_msg )&&( wparam == 2 ) )
		{
			n_nekonote_new_name_add();
			n_nekonote_new_init();
		}

	break;


	case WM_CLOSE :
	{

		n_win_inputpopup_silent_onoff = n_true;
		n_win_inputpopup_close();


		EnableWindow( GetParent( hwnd ), n_true );
		ShowWindow( hwnd, SW_HIDE );


		n_win_button_exit( &H_EXT_BUTTON );


		n_win_radio_exit( &n_nekonote_new_radio_hklm );
		n_win_radio_exit( &n_nekonote_new_radio_hkcu );


		n_win_txtbox_exit( &n_nekonote_new_input_ext );
		n_win_txtbox_exit( &n_nekonote_new_input_typ );


		n_win_smallbutton_direct_exit( &n_nekonote_new_smallbutton_ext );
		n_win_smallbutton_direct_exit( &n_nekonote_new_smallbutton_typ );


		n_win_stdfont_exit( n_nekonote_new_hgui, GUI_MAX );


		DestroyWindow( hwnd );

	}
	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	n_win_radio_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_radio_hklm );
	n_win_radio_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_radio_hkcu );


	{
		int ret = 0;

		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_input_ext );
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_input_typ );

		if ( ret ) { return ret; }
	}


	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &n_nekonote_new_input_ext );
	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &n_nekonote_new_input_typ );
	n_win_inputpopup_patch( hwnd, msg, &wparam, &lparam );


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_EXT_BUTTON );


	n_win_separator_proc( hwnd, msg, wparam, lparam, H_EXT_LINE, PS_SOLID );
	n_win_separator_proc( hwnd, msg, wparam, lparam, H_TYP_LINE, PS_SOLID );
	n_win_separator_proc( hwnd, msg, wparam, lparam, H_PAD_LINE, PS_SOLID );


	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_smallbutton_ext );
	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &n_nekonote_new_smallbutton_typ );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}
/*
int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_nekonote_new_wndproc );
}
*/


#undef H_EXT_LINE
#undef H_EXT_LABEL
#undef H_EXT_TEMPLATE
#undef H_TYP_LINE
#undef H_TYP_NAME
#undef H_PAD_LINE
#undef GUI_MAX

#undef H_EXT_BUTTON
#undef BTN_MAX


#undef N_NEKONOTE_NEW_HKLM
#undef N_NEKONOTE_NEW_HKCU
#undef N_NEKONOTE_NEW_TEMPLATE
#undef N_NEKONOTE_NEW_NAME


