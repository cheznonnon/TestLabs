// Nonnon Typing
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "../nonnon/game/hmidiout.c"




#define N_TYPING_MIDI_CHANNEL_MAX ( 4 )


#define N_TYPING_MIDI_SOUND       ( 118 )// "Synth Drum"




#define n_typing_midi_note_on(  p, n ) n_typing_midi_note( p, n, n_true  )
#define n_typing_midi_note_off( p, n ) n_typing_midi_note( p, n, n_false )

void
n_typing_midi_note( n_typing *p, int note, n_bool is_on )
{

	int ch = 0;
	n_posix_loop
	{

		int vol = 0;
		if ( is_on ) { vol = N_HMIDIOUT_VOLUME_MAX; }

		int panpot = 32 * ch; if ( panpot != 0 ) { panpot--; }
		//int panpot = N_HMIDIOUT_PANPOT_CENTER

		n_hmidiout_all( 0, N_TYPING_MIDI_SOUND, panpot, note, vol );

		ch++;
		if ( ch >= N_TYPING_MIDI_CHANNEL_MAX ) { break; }
	}


	return;
}


