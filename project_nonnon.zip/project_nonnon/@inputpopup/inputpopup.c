// Input Popup
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"

#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_popup.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/win32/win_inputpopup.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_txtbox txtbox_1;
	static n_win_txtbox txtbox_2;


	switch( msg ) {


	case WM_CREATE :

		n_win_fluent_ui_onoff = n_posix_true;


		n_win_init_literal( hwnd, "Tutorial", "MAIN_ICON", "" );


		n_win_txtbox_zero( &txtbox_1 );
		n_win_txtbox_init( &txtbox_1, hwnd, N_WIN_TXTBOX_STYLE_ONELINE, 0 );

		n_win_txtbox_zero( &txtbox_2 );
		n_win_txtbox_init( &txtbox_2, hwnd, N_WIN_TXTBOX_STYLE_ONELINE, 0 );


		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

		n_type_gfx ctl; n_win_stdsize( hwnd, NULL, &ctl, NULL );

		n_type_gfx sx = 100;
		n_type_gfx sy = ctl;

		n_type_gfx xx = ( w.csx - sx ) / 2;

		n_win_move( txtbox_1.hwnd, xx - ( sx / 2 ), ( w.csy - sy ) / 2, sx,sy, n_posix_true );
		n_win_move( txtbox_2.hwnd, xx + ( sx / 2 ), ( w.csy - sy ) / 2, sx,sy, n_posix_true );

	}
	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;

		if ( h == txtbox_1.hwnd )
		{
			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &txtbox_1 );
			}
		} else
		if ( h == txtbox_2.hwnd )
		{
			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &txtbox_2 );
			}
		}

	}
	break;


	case WM_CLOSE :

		n_win_inputpopup_silent_onoff = n_true;
		n_win_inputpopup_close();

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &txtbox_1 );
		if ( ret ) { return ret; }
	}

	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &txtbox_2 );
		if ( ret ) { return ret; }
	}


	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &txtbox_1 );
	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &txtbox_2 );
	n_win_inputpopup_patch( hwnd, msg, &wparam, &lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


