// nmixer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




HRESULT __stdcall
n_IAudioEndpointVolumeCallback_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
	return S_OK;
}

ULONG __stdcall
n_IAudioEndpointVolumeCallback_AddRef( void *_this )
{
	return S_OK;
}

ULONG __stdcall
n_IAudioEndpointVolumeCallback_Release( void *_this )
{
	return S_OK;
}

HRESULT __stdcall
n_IAudioEndpointVolumeCallback_OnNotify( void *_this, n_PAUDIO_VOLUME_NOTIFICATION_DATA pNotify )
{

	int vol = (int) ( (n_type_real) pNotify->fMasterVolume * 100 );

	n_nmixer_systray_icon_change_percent = vol;
	n_win_systray_icon_change( &nmixer.nid, nmixer.icon_name, nmixer.icon_index, n_nmixer_icon_supported );


	return S_OK;
}




const void *n_IAudioEndpointVolumeCallback_Vtbl[] = {

	n_IAudioEndpointVolumeCallback_QueryInterface,
	n_IAudioEndpointVolumeCallback_AddRef,
	n_IAudioEndpointVolumeCallback_Release,

	n_IAudioEndpointVolumeCallback_OnNotify,

};


static IAudioEndpointVolumeCallback n_IAudioEndpointVolumeCallback_instance = { (void*) n_IAudioEndpointVolumeCallback_Vtbl };




n_bool
n_IAudioEndpointVolumeCallback_onoff( n_bool is_init )
{

	HRESULT hr = 0;


	IMMDeviceEnumerator  *IMMDeviceEnumerator  = NULL;
	IMMDevice            *IMMDevice            = NULL;


	// [Needed] : keep to hold

	static IAudioEndpointVolume *IAudioEndpointVolume = NULL;


	CoInitialize( NULL );


	if ( is_init )
	{

		hr = CoCreateInstance
		(
			&n_mixer_CLSID_MMDeviceEnumerator,
			NULL,
			CLSCTX_ALL,
			&n_mixer_IID_IUnknown,
			(void*) &IMMDeviceEnumerator
		);

		if ( FAILED( hr )||( IMMDeviceEnumerator == NULL ) )
		{
//n_posix_debug_literal( " CoCreateInstance() " );
			goto cleanup;
		}


		hr = IMMDeviceEnumerator_GetDefaultAudioEndpoint
		(
			IMMDeviceEnumerator,
			eRender,
			eConsole,
			(void*) &IMMDevice
		);

		if ( FAILED( hr )||( IMMDevice == NULL ) )
		{
//n_posix_debug_literal( " IMMDeviceEnumerator_GetDefaultAudioEndpoint() " );
			goto cleanup;
		}


		hr = IMMDevice_Activate
		(
			IMMDevice,
			&n_mixer_IID_IAudioEndpointVolume,
			CLSCTX_ALL,
			NULL,
			(void*) &IAudioEndpointVolume
		);

		if ( FAILED( hr )||( IAudioEndpointVolume == NULL ) )
		{
//n_posix_debug_literal( "Activate" );
			goto cleanup;
		}
	}


	if ( is_init )
	{
		IAudioEndpointVolume_RegisterControlChangeNotify  ( IAudioEndpointVolume, &n_IAudioEndpointVolumeCallback_instance );
	} else {
		IAudioEndpointVolume_UnregisterControlChangeNotify( IAudioEndpointVolume, &n_IAudioEndpointVolumeCallback_instance );
	}


	cleanup:

	if ( is_init == n_false )
	{
		if ( IAudioEndpointVolume ) { IAudioEndpointVolume_Release( IAudioEndpointVolume ); }
	}

	if ( IMMDevice            ) { IMMDevice_Release           ( IMMDevice            ); }
	if ( IMMDeviceEnumerator  ) { IMMDeviceEnumerator_Release ( IMMDeviceEnumerator  ); }

	CoUninitialize();


	return FAILED( hr );
}


