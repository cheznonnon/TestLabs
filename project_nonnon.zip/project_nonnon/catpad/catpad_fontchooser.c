// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




//#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_scroller.c"

//#include "../nonnon/project/macro.c"




#define H_PREVIEW    n_catpad_fontchooser_hgui[ 0 ]
#define H_LIST       n_catpad_fontchooser_hgui[ 1 ]
#define GUI_MAX                                 2

#define H_SCROLL     n_catpad_fontchooser_hscr[ 0 ]
#define SCR_MAX                                 1




// [!] : internal

static n_win_scroller n_catpad_fontchooser_hscr[ SCR_MAX ];
static HWND           n_catpad_fontchooser_hgui[ GUI_MAX ];
static n_win_button   n_catpad_button;
static n_win_txtbox   n_catpad_fontchooser_htxt;
static WNDPROC        n_catpad_flickerfree_func;




HFONT
n_catpad_fontchooser_hfont( int size )
{

	// [Needed] : n_win_font_exit( n_catpad_hfont );

	n_posix_char str[ LF_FACESIZE ]; n_win_txtbox_selection_get( &n_catpad_fontchooser_htxt, str );

	return n_win_font_name2hfont( str, size );
}

void
n_catpad_fontchooser_preview_refresh( void )
{

	n_win_font_exit( n_win_font_get( H_PREVIEW ) );
	n_win_font_set( H_PREVIEW, n_catpad_fontchooser_hfont( n_win_scroller_value_get( &H_SCROLL ) * -1 ), n_true );

	n_win_refresh( H_PREVIEW, n_false );


	return;
}

void
n_catpad_fontchooser_scroll_init( HWND hwnd, int size )
{

	s32 dsx,dsy; n_win_desktop_size( &dsx, &dsy );

	int size_min  = 0;
	int size_max  = n_posix_max( dsx, dsy ) / 10;
	int size_page = size_max / 10;
	int size_pos  = n_posix_minmax( size_min, size_max, size );

	if ( size_pos == 0 )
	{
		int   sz = n_font_size_default( hwnd );
		HFONT hf = n_win_font_name2hfont( n_font_name( n_catpad_hfont ), sz );

		n_win_font_exit( hf );

		size_pos = abs( sz );
	}

	n_win_hwndprintf_literal( H_SCROLL.value, "%d", size_pos );

	n_win_scroller_scroll_parameter( &H_SCROLL, 1.0, size_page, size_max, size_pos, n_true );


	n_catpad_fontchooser_preview_refresh();


	return;
}

// internal
int CALLBACK
n_catpad_fontchooser_enumfontsproc( const LOGFONT *lf, const TEXTMETRIC *tm, u32 type, LPARAM lparam )
{

	const int mask = 15;


	if (
		( type != DEVICE_FONTTYPE )
		&&
		( ( lf->lfPitchAndFamily & mask ) == FIXED_PITCH )
		&&
		( lf->lfFaceName[ 0 ] != n_posix_literal( '@' ) )
	)
	{

		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, "%s", lf->lfFaceName );
		//n_posix_sprintf_literal( str, "%d : %s", (int) tm->tmOverhang, lf->lfFaceName );

		n_win_txtbox_line_add( &n_catpad_fontchooser_htxt, 0, str );

	}


	return n_true;
}

void
n_catpad_fontchooser_init( HWND hwnd )
{

	HDC hdc = GetDC( hwnd );

	EnumFonts( hdc, NULL, n_catpad_fontchooser_enumfontsproc, (LPARAM) 0 );

	ReleaseDC( hwnd, hdc );


	n_txt_sort_up( &n_catpad_fontchooser_htxt.txt );
	n_txt_del    ( &n_catpad_fontchooser_htxt.txt, 0 );

	if ( n_catpad_hfont == NULL )
	{
		n_win_txtbox_str2index_literal( &n_catpad_fontchooser_htxt, "FixedSys", n_true );
		n_catpad_fontchooser_scroll_init( hwnd, abs( n_font_size_default( hwnd ) ) );
	} else {
		n_win_txtbox_str2index( &n_catpad_fontchooser_htxt, n_font_name( n_catpad_hfont ), n_true );
		n_catpad_fontchooser_scroll_init( hwnd, abs( n_font_size( n_catpad_hfont ) ) );
//n_posix_debug_literal( " %d ", n_font_size( n_catpad_hfont ) );
	}

	n_catpad_fontchooser_preview_refresh();


	return;
}

void
n_catpad_fontchooser_exit( void )
{

	n_catpad_hfont = n_catpad_fontchooser_hfont( n_win_scroller_value_get( &H_SCROLL ) * -1 );

	n_catpad_font_init();


	return;
}

void
n_catpad_fontchooser_resize( HWND hwnd, n_bool is_first )
{

	int nwset;
	s32 csx,csy;

	if ( is_first )
	{

		nwset = N_WIN_SET_CENTERING;

		n_win_desktop_size( &csx, &csy );

		csx = csy = (s32) n_posix_max_double( 256, (double) n_posix_min( csx, csy ) * 0.4 );

	} else {

		nwset = n_project_n_win_set();

		csx   = -1;
		csy   = -1;

	}
 

	s32 ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );

	n_win w; n_win_set( hwnd, &w, csx,csy, nwset );

	csx = w.csx - m;
	csy = w.csy - m;


	const n_bool redraw = n_true;


	s32 x = 0;
	s32 y = 0;

	s32 psy = ( ctl * 2 );
	s32 lsy = csy - ( ctl + psy + ctl );
	s32 b_x = x; x++;
	s32 bsx = csx; csx -= 2;

	n_catpad_fontchooser_preview_refresh();

	HWND hbutton = n_catpad_button.hwnd;

	n_win_scroller_move( &H_SCROLL ,   x,y, csx,ctl, redraw ); y += ctl;
	n_win_move         (  H_PREVIEW,   x,y, csx,psy, redraw ); y += psy;
	n_win_move         (  H_LIST   ,   x,y, csx,lsy, redraw ); y += lsy;
	n_win_move         (  hbutton  , b_x,y, bsx,ctl, redraw );


	return;
}

LRESULT CALLBACK
n_catpad_fontchooser_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id       = 0;
	static UINT timer_id_flash = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == timer_id_flash )
		{
			n_win_timer_exit( hwnd, timer_id_flash );

			n_catpad_flashwindow_init();

			break;
		}


		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );


		n_win_scroller_on_settingchange( &H_SCROLL );

		n_win_txtbox_on_settingchange( &n_catpad_fontchooser_htxt );

		n_win_button_on_settingchange( &n_catpad_button );


		n_win_refresh( H_PREVIEW, n_true );


		if ( timer_id_flash == 0 ) { timer_id_flash = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id_flash, 500 );
		n_catpad_flashwindow_exit();

		n_win_txtbox_metrics( &n_catpad_txtbox_editor );

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );


		// Window

		n_win_init_literal( hwnd, "Font Chooser", "", "" );

		n_win_scroller_zero( &H_SCROLL );
		n_win_scroller_init_literal( &H_SCROLL, hwnd, "Size" );

		n_win_gui_literal( hwnd, CANVAS , "", &H_PREVIEW );

		n_win_button_zero( &n_catpad_button );
		n_win_button_init( &n_catpad_button, hwnd, n_project_string_go, PBS_NORMAL );

		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int style_option = 0;

			style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL;
			style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;

			n_win_txtbox_zero( &n_catpad_fontchooser_htxt );
			n_win_txtbox_init( &n_catpad_fontchooser_htxt, hwnd, style, style_option );

			H_LIST = n_catpad_fontchooser_htxt.hwnd;
		}


		n_win_text_set( H_PREVIEW, n_posix_literal( "Jumped Over A Sleepy Cat." ) );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME           );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW | WS_SIZEBOX );

		n_win_sysmenu_disable( hwnd, 1,0,0, 1,1, 0, 0 );


		n_win_flickerfree_init( hwnd, &n_catpad_flickerfree_func );
		n_win_flickerfree_win_iconbutton_init( n_catpad_button.hwnd );


		n_win_stdfont_init( n_catpad_fontchooser_hgui, GUI_MAX );


		SetFocus( H_LIST );


		// Init

		n_catpad_fontchooser_init( hwnd );
		n_catpad_fontchooser_resize( hwnd, n_true );

		n_win_txtbox_autofocus( &n_catpad_fontchooser_htxt );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		n_catpad_flashwindow_init();

		EnableWindow( GetParent( hwnd ), n_false );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }
		if ( H_PREVIEW != di->hwndItem ) { break; }

//n_win_scrollbar_debug_count( &n_pentrainer_config_htxt.vscr );


		HWND hgui = H_PREVIEW;
		RECT rect = di->rcItem;

		n_posix_char fontname[ LF_FACESIZE ];
		n_win_txtbox_selection_get( &n_catpad_fontchooser_htxt, fontname );

		n_win_fluent_ui_label( hgui, &rect, fontname, H_SCROLL.scrollbar.unit_pos * -1 );

	}
	break;


	case WM_SIZE :

		n_catpad_fontchooser_resize( hwnd, n_false );

		n_catpad_flashwindow_refresh();

	break;


	case WM_SETFOCUS :

		SetFocus( H_LIST );

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_LIST )
		{

			n_catpad_fontchooser_preview_refresh();

		} else
		if ( h == H_SCROLL.scrollbar.hwnd )
		{
//n_win_hwndprintf_literal( hwnd, " %d %d ", wparam, (int) H_SCROLL.scrollbar.unit_pos );

			if ( H_SCROLL.scrollbar.unit_pos == 0 )
			{
				H_SCROLL.scrollbar.unit_pos = abs( n_font_size_default( hwnd ) );
			}

			n_win_hwndprintf_literal( H_SCROLL.value, "%d", (int) H_SCROLL.scrollbar.unit_pos );
			n_win_scrollbar_draw_always( &H_SCROLL.scrollbar, n_true );

			n_catpad_fontchooser_preview_refresh();

		} else
		if ( h == n_catpad_button.hwnd )
		{

			n_catpad_fontchooser_exit();

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	}
	break;


	case WM_CLOSE :

		EnableWindow( GetParent( hwnd ), n_true );
		ShowWindow( hwnd, SW_HIDE );


		n_catpad_ini_write();


		n_catpad_flashwindow_exit();


		n_win_button_exit( &n_catpad_button );


		n_win_flickerfree_exit( hwnd, &n_catpad_flickerfree_func );
		n_win_flickerfree_win_iconbutton_exit( n_catpad_button.hwnd );


		n_win_stdfont_exit( n_catpad_fontchooser_hgui, GUI_MAX );


		n_win_scroller_exit( &H_SCROLL );


		n_win_txtbox_exit( &n_catpad_fontchooser_htxt );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	{
		LRESULT ret = n_win_scroller_proc( hwnd, msg, wparam, lparam, &H_SCROLL );
		if ( ret != 0 ) { return ret; }
	}


	n_catpad_flashwindow_proc( hwnd, msg, wparam, lparam );


	n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_catpad_fontchooser_htxt );


	n_win_button_proc( hwnd, msg, wparam, lparam, &n_catpad_button );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_PREVIEW
#undef H_LIST
#undef GUI_MAX

#undef H_SCROLL
#undef SCR_MAX


