// Nonnon IE
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/registry.c"
#include "../nonnon/win32/sysinfo/fileversion.c"
#include "../nonnon/win32/win.c"




// [!] : OldNewThing : this key is available
//
//	HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\App Paths\IEXPLORE.EXE
//	Win95b(IE3.x) has this key too

#define N_IE_PATH_SECTION n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\IEXPLORE.EXE" )




// internal
DWORD
n_ie_path_cch( void )
{

	DWORD cb = n_registry_read_valuebyte( HKEY_LOCAL_MACHINE, N_IE_PATH_SECTION, N_STRING_EMPTY );

	return cb / sizeof( n_posix_char );
}

// internal
void
n_ie_path( n_posix_char *str, DWORD len )
{

	n_registry_read( HKEY_LOCAL_MACHINE, N_IE_PATH_SECTION, N_STRING_EMPTY, str, len * sizeof( n_posix_char ) );

	return;
}

// internal
n_posix_char*
n_ie_path_new( void )
{

	DWORD         cch = n_ie_path_cch();
	n_posix_char *str = n_string_path_new( cch );

	n_ie_path( str, cch + 1 );


	return str;
}

// internal
HICON
n_ie_icon( void )
{

	n_posix_char *str = n_ie_path_new();

	HICON hico = n_win_icon_init( str, 0, N_WIN_ICON_INIT_OPTION_DEFAULT );

	n_string_path_free( str );


	return hico;
}

// internal
HICON
n_ie_icon_controlpanel( void )
{

	n_posix_char *inetcpl = n_posix_literal( "inetcpl.cpl" );


	n_posix_char fileversion[ 100 ];
	n_type_int   index = 27;


	n_sysinfo_fileversion_literal( inetcpl, "FileVersion", fileversion, 100 );
//n_posix_debug( fileversion );

	if ( fileversion[ 0 ] == n_posix_literal( '3' ) )
	{
		index = 12;
	} else
	if ( fileversion[ 0 ] == n_posix_literal( '4' ) )
	{
		index = 12;
	} else
	if ( fileversion[ 0 ] == n_posix_literal( '7' ) )
	{
		index = 38;
	}// else


	return n_win_icon_init( inetcpl, index, N_WIN_ICON_INIT_OPTION_DEFAULT );
}

// internal
void
n_ie_call( void )
{

	n_posix_char *str = n_ie_path_new();

	n_win_exec( str, SW_MAXIMIZE );

	n_string_path_free( str );


	// [!] : useless : SetActiveWindow( hwnd );

	HWND hwnd = n_win_hwnd_find_literal( NULL, "IEFrame" );

	SetWindowPos( hwnd, HWND_TOP, 0,0,0,0, SWP_NOSIZE | SWP_NOMOVE );


	return;
}

