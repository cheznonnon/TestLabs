// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "./_channel.c"




#define N_MIDI_OFFSET_HEADER (  1 )
#define N_MIDI_HOVER_NEUTRAL ( -1 )




typedef struct {

	n_posix_char *path;
	n_bmp         data;
	n_bool        logging_onoff;

	HWND          hwnd;
	int           line;
	int           unit;

	n_bmp         canvas;
	n_type_gfx    sx, sy;
	n_type_gfx    border;

	n_type_gfx    hover_x, hover_y;
	u32           clipboard;

	int           scroll_size;
	int           scroll_pos;
	int           scroll_step;
	int           scroll_page;
	int           scroll_max;

	RECT          scroll_thumb;
	RECT          scroll_shaft;

	n_gdi         gdi_template;
	n_type_gfx    header_sx, header_sy;
	int           note_sx, note_sy;

	n_channel     channel[ N_CHANNEL_MAX ];
	int           channel_number;

	n_type_gfx    stdsize_ctl;
	n_type_gfx    stdsize_ico;
	n_type_gfx    stdsize_m;

	n_type_gfx    last_bitmap_x;
	n_type_gfx    last_bitmap_y;

} n_nmidi_canvas;

static n_nmidi_canvas canvas;




#define n_nmidi_canvas_refresh( p ) n_win_refresh( ( p )->hwnd, n_false )

void
n_nmidi_canvas_gdi_template( n_nmidi_canvas *p )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                 = p->stdsize_ico;
	gdi.sy                 = p->stdsize_ico;
	gdi.style              = N_GDI_SMOOTH;
	gdi.layout             = 0;
	gdi.align              = 0;

	gdi.base_color_bg      = N_NMIDI_COLOR_TRANS;
	gdi.base_color_fg      = N_NMIDI_COLOR_TRANS;
	gdi.base_style         = N_GDI_BASE_DEFAULT;

	gdi.frame_style        = N_GDI_FRAME_TRANS;

	gdi.icon               = n_posix_literal( "" );
	gdi.icon_index         = 0;
	gdi.icon_style         = N_GDI_ICON_DEFAULT;
	gdi.icon_fxsize1       = 0;
	gdi.icon_fxsize2       = 0;

	gdi.text               = NULL;
	gdi.text_font          = n_project_stdfont();
	gdi.text_size          = 0;
	gdi.text_color_main    = N_NMIDI_COLOR_TRANS;
	gdi.text_color_contour = N_NMIDI_COLOR_CONTOUR;
	gdi.text_style         = N_GDI_TEXT_ITALIC | N_GDI_TEXT_CONTOUR;
	gdi.text_fxsize1       = 0;
	gdi.text_fxsize2       = 1;


	p->gdi_template = gdi;


	return;
}

// internal
void
n_nmidi_canvas_item_header( n_nmidi_canvas *p, int ch, int i )
{

	// Init

	i = 0;

	n_channel *channel = &p->channel[ ch ];


	n_posix_char str[ 100 ];


	n_bmp bmp_n; n_bmp_zero( &bmp_n );
	n_bmp bmp_l; n_bmp_zero( &bmp_l );


	// Number

	{

		n_posix_sprintf_literal( str, "%d", ch );


		n_gdi gdi = p->gdi_template;

		gdi.sx              = gdi.sx * 3 / 2;
		gdi.sy              = gdi.sy * 3 / 2;

		gdi.text            = str;
		gdi.text_size       = gdi.sy;
		gdi.text_color_main = N_NMIDI_COLOR_LINE;

		n_gdi_bmp( &gdi, &bmp_n );

	}


	// Label

	{


		n_gdi gdi = p->gdi_template;

		gdi.sx              = p->header_sx;
		gdi.sy              = gdi.sy;

		gdi.text            = str;
		gdi.text_size       = (n_type_gfx) ( (n_type_real) gdi.sy * 0.60 );
		gdi.text_color_main = N_NMIDI_COLOR_HEADER;
		gdi.text_style      = gdi.text_style | N_GDI_TEXT_BOLD;

		if ( n_win_darkmode_onoff )
		{
			gdi.text_style |= N_GDI_TEXT_CONTOUR_FOG;
		}


		if ( gdi.sx == 0 )
		{
			gdi.style |= N_GDI_CALCONLY;

			n_string_copy( n_midi_string_instruments[ 24 ], str );
			n_gdi_bmp( &gdi, &bmp_l );

			gdi.style &= ~N_GDI_CALCONLY;
		}


		if ( ch == N_MIDI_RHYTHMCHANNEL )
		{
			n_posix_sprintf_literal( str, "Rhythm Channel" );
		} else {
			n_posix_sprintf_literal( str, "%s", n_midi_string_instruments[ channel->sound ] );
		}

		n_gdi_bmp( &gdi, &bmp_l );

	}


	// Composition

	n_bmp *bmp = &channel->bmp[ i ];
	u32    bg  = p->gdi_template.base_color_bg;

	n_type_gfx nsx = N_BMP_SX( &bmp_n );
	n_type_gfx nsy = N_BMP_SY( &bmp_n );
	n_type_gfx lsx = N_BMP_SX( &bmp_l );
	n_type_gfx lsy = N_BMP_SY( &bmp_l );


	n_bmp_new_fast( bmp, lsx, lsy ); n_bmp_flush( bmp, bg );

	n_bmp_transcopy( &bmp_n, bmp, 0,0,nsx,nsy, 0, ( lsy - nsy ) / 2 );
	n_bmp_transcopy( &bmp_l, bmp, 0,0,lsx,lsy, 0, 0 );


	p->header_sx = N_BMP_SX( bmp );
	p->header_sy = N_BMP_SY( bmp );


	// Cleanup

	n_bmp_free( &bmp_n );
	n_bmp_free( &bmp_l );


	return;
}

// internal
void
n_nmidi_canvas_item_note( n_nmidi_canvas *p, int ch, int i )
{

	// Init

	n_channel *channel = &p->channel[ ch ];


	int note   = 0;
	int volume = 0;

	n_midi_bmp_note_get( &p->data, ch, i, &note, &volume );


	// Text

	n_posix_char str_note[ 100 ];
	n_posix_char str_text[ 100 ];

	if ( ch == N_MIDI_RHYTHMCHANNEL )
	{
		n_posix_sprintf_literal( str_text, "%3d", note );
	} else {
		n_midi_string_notes_get( note, str_note );
		n_posix_sprintf_literal( str_text, "%3s%s%3d", str_note, N_STRING_CRLF, note );
	}


	// Make

	n_gdi gdi = p->gdi_template;

	gdi.text            = str_text;
	gdi.text_size       = gdi.sy / 2;
	gdi.text_color_main = N_NMIDI_COLOR_NOTE;

	if ( volume != 0 )
	{
		gdi.text_color_main    = N_NMIDI_COLOR_SELECT;
		gdi.text_color_contour = n_bmp_blend_pixel( N_NMIDI_COLOR_CONTOUR, N_NMIDI_COLOR_FG, (n_type_real) volume / N_MIDI_PARAM_MAX );
	}


	n_bmp *bmp = &channel->bmp[ i ];

	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );

	p->note_sx = N_BMP_SX( bmp );
	p->note_sy = N_BMP_SY( bmp );


	return;
}

void
n_nmidi_canvas_scroll_calculate( n_nmidi_canvas *p )
{

	p->scroll_step = N_NMIDI_UNIT_QUARTER;
	p->scroll_page = N_NMIDI_UNIT_BAR;
	p->scroll_max  = N_BMP_SX( &p->data ) - N_MIDI_OFFSET_HEADER;


	return;
}

void
n_nmidi_canvas_scroll_set( n_nmidi_canvas *p, int delta )
{

	p->scroll_pos += p->scroll_step * delta;


	int minim = 0;
	int maxim = p->scroll_max - p->scroll_step;

	p->scroll_pos = n_posix_minmax( minim, maxim, p->scroll_pos );


	n_nmidi_canvas_refresh( p );


	return;
}

// internal
n_posix_char*
n_nmidi_canvas_autoname_new( void )
{

	n_posix_char *dir = n_string_path_folder_current_new();
	n_posix_char *tmp = n_string_path_tmpname_new( N_NMIDI_EXT_BMP );
	n_posix_char *ret = n_string_path_make_new( dir, tmp );

	n_string_path_free( dir );
	n_string_path_free( tmp );

	return ret;
}

#define n_nmidi_canvas_zero( p ) n_memory_zero( p, sizeof( n_nmidi_canvas ) )

void
n_nmidi_canvas_exit( n_nmidi_canvas *p )
{

	n_channel_bulk_free( p->channel );

	n_string_path_free( p->path );

	n_midi_bmp_free( &p->data );
	n_bmp_free( &p->canvas );

	n_nmidi_canvas_zero( p );


	return;
}

void
n_nmidi_canvas_save( n_nmidi_canvas *p )
{

	if (
		( n_posix_stat_is_exist( p->path ) )
		&&
		( n_false == n_project_dialog_yesno( p->hwnd, n_project_string_overwrite ) )
	)
	{
		return;
	}


	n_bmp_save( &p->data, p->path );
//n_posix_debug_literal( " %s : %d ", p->path, p->logging_onoff );
	n_midi_encode( p->path, p->logging_onoff );

	n_explorer_refresh( n_false );


	return;
}

n_bool
n_nmidi_canvas_newfile( n_nmidi_canvas *p, const n_posix_char *fname )
{

	n_bool ret_error;


	n_bmp bmp; n_bmp_zero( &bmp );
	if ( n_bmp_load( &bmp, fname ) )
	{

		n_midi_bmp_new( &bmp, 4 );

		ret_error = n_true;

	} else {

		n_bmp_alpha_reverse( &bmp );

		int i = 0;
		n_posix_loop
		{

			int ch;
			n_midi_bmp_channel_get( &bmp, i, &ch, NULL, NULL );

			if ( i != ch ) { ret_error = n_true; break; }

			i++;
			if ( i >= N_CHANNEL_MAX ) { ret_error = n_false; break; }
		}

	}


	n_bmp_free_fast( &p->data );
	n_bmp_alias( &bmp, &p->data );

	n_string_path_free( p->path );

	if ( ret_error )
	{
		p->path = n_nmidi_canvas_autoname_new();
		n_channel_bulk_new ( p->channel, &p->data );
	} else {
		p->path = n_string_path_carboncopy( fname );
		n_channel_bulk_load( p->channel, &p->data );
	}


	return ret_error;
}

void
n_nmidi_canvas_init( n_nmidi_canvas *p, HWND hwnd_target, const n_posix_char *fname )
{

	n_nmidi_canvas_exit( p );


	n_nmidi_canvas_newfile( p, fname );


	int line = n_midi_bmp_channel_detect( &p->data );
	int beat = n_midi_bmp_beat_detect( &p->data );
//n_posix_debug_literal( "%d : %d", line, beat );

	p->hwnd = hwnd_target;
	p->line = n_posix_minmax( 1, N_CHANNEL_MAX,        line );
	p->unit = n_posix_minmax( 0, N_NMIDI_UNIT_QUARTER, beat );
//n_posix_debug_literal( "%d : %d", p->line, p->unit );

	n_nmidi_canvas_scroll_calculate( p );


	p->hover_x = p->hover_y = N_MIDI_HOVER_NEUTRAL;


	// Template

	n_win_stdsize( p->hwnd, &p->stdsize_ctl, &p->stdsize_ico, &p->stdsize_m );

	n_nmidi_canvas_gdi_template( p );

	p->scroll_size = GetSystemMetrics( SM_CYHSCROLL );

	p->stdsize_m *= 4;


	// Preloader

	n_nmidi_canvas_item_header( p, 0, 0 );
	n_nmidi_canvas_item_note  ( p, 0, 1 );


	return;
}

void
n_nmidi_canvas_item( n_nmidi_canvas *p, n_bmp *bmp_item, n_type_gfx x, n_type_gfx y, n_bool is_hovered )
{

	const n_type_gfx sx = N_BMP_SX( bmp_item );
	const n_type_gfx sy = N_BMP_SY( bmp_item );

	x += p->stdsize_m / 2;
	y += p->stdsize_m / 2;

	if ( is_hovered )
	{

		const u32 fg = N_NMIDI_COLOR_FG;
		const u32 bg = N_NMIDI_COLOR_SELECT;


		n_type_gfx o1 = 1;
		n_type_gfx o2 = o1 * 2;
		n_type_gfx o4 = o1 * 4;
		n_type_gfx o8 = o1 * 8;

		n_bmp_roundrect_pixel( &p->canvas, x + o1, y + o1, sx - o2, sy - o2, fg, o4 );
		n_bmp_roundrect_pixel( &p->canvas, x + o4, y + o4, sx - o8, sy - o8, bg, o4 );

		n_bmp_antialias( &p->canvas, x, y, sx, sy, 1.0 );

	}

	n_bmp_transcopy( bmp_item, &p->canvas, 0,0,sx,sy, x,y );


	return;
}

void
n_nmidi_canvas_draw_header( n_nmidi_canvas *p )
{

	n_type_gfx bitmap_x = 0;
	n_type_gfx bitmap_y = 0;
	n_type_gfx canvas_x = p->border;
	n_type_gfx canvas_y = p->border;

	n_posix_loop
	{//break;

		n_channel *chl = &  p->channel[ bitmap_y ];
		n_bmp     *bmp = &chl->bmp    [ bitmap_x ];


		// Make

		if ( NULL == N_BMP_PTR( bmp ) ) { n_nmidi_canvas_item_header( p, bitmap_y, bitmap_x ); }


		// Draw

		//n_bmp_box( &p->canvas, canvas_x,canvas_y, p->header_sx,p->header_sy, N_NMIDI_COLOR_BG );

		n_bool is_hovered = ( ( p->hover_x == bitmap_x )&&( p->hover_y == bitmap_y ) );
		if ( n_false == IsWindowEnabled( H_STA_CANVAS ) )
		{
			if ( ( p->last_bitmap_x == bitmap_x )&&( p->last_bitmap_y == bitmap_y ) )
			{
				is_hovered = n_true;
			}
		} else
		if ( is_hovered )
		{
			p->last_bitmap_x = bitmap_x;
			p->last_bitmap_y = bitmap_y;
		}
		n_nmidi_canvas_item( p, bmp, canvas_x,canvas_y, is_hovered );


		bitmap_y += 1;
		canvas_y += p->header_sy + p->stdsize_m;
		if (
			( bitmap_y >= p->line )
			||
			( canvas_y >= p->sy   )
		)
		{
			break;
		}

	}


	return;
}

void
n_nmidi_canvas_indicator( n_nmidi_canvas *p, n_type_gfx x, n_type_gfx y, u32 color, n_bool dot )
{

	x += p->stdsize_m / 2;

	n_type_gfx sy = y + p->note_sy + p->stdsize_m;

	n_bmp_line_dot( &p->canvas, x,y,x,sy, color, dot );


	return;
}

void
n_nmidi_canvas_draw_note( n_nmidi_canvas *p )
{

	const u32 color_bar = N_NMIDI_COLOR_LINE;
	const u32 color_eol = N_NMIDI_COLOR_HEADER;


	n_type_gfx bitmap_x = N_MIDI_OFFSET_HEADER + p->scroll_pos;
	n_type_gfx bitmap_y = 0;
	n_type_gfx canvas_x = p->border + p->header_sx;
	n_type_gfx canvas_y = p->border;

	n_type_gfx start_bitmap_x = bitmap_x;
	n_type_gfx start_canvas_x = canvas_x;

	n_posix_loop
	{//break;

		n_channel *chl = &  p->channel[ bitmap_y ];
		n_bmp     *bmp = &chl->bmp    [ bitmap_x ];


		// Make

		if ( NULL == N_BMP_PTR( bmp ) ) { n_nmidi_canvas_item_note( p, bitmap_y, bitmap_x ); }


		// Draw

		//n_bmp_box( &p->canvas, canvas_x,canvas_y, p->note_sx,p->note_sy, N_NMIDI_COLOR_BG );

		n_bool is_hovered = ( ( p->hover_x == bitmap_x )&&( p->hover_y == bitmap_y ) );
		if ( n_false == IsWindowEnabled( H_STA_CANVAS ) )
		{
			if ( ( p->last_bitmap_x == bitmap_x )&&( p->last_bitmap_y == bitmap_y ) )
			{
				is_hovered = n_true;
			}
		} else
		if ( is_hovered )
		{
			p->last_bitmap_x = bitmap_x;
			p->last_bitmap_y = bitmap_y;
		}
		n_nmidi_canvas_item( p, bmp, canvas_x,canvas_y, is_hovered );


		// Bar Indicator

		if ( bitmap_x != 0 )
		{

			n_type_gfx note_number = bitmap_x - N_MIDI_OFFSET_HEADER;

			if ( 0 == ( note_number % N_NMIDI_UNIT_BAR ) )
			{
				n_nmidi_canvas_indicator( p, canvas_x,canvas_y, color_eol, n_false );
			} else
			if ( 0 == ( note_number % N_NMIDI_UNIT_QUARTER ) )
			{
				n_nmidi_canvas_indicator( p, canvas_x,canvas_y, color_bar, n_true  );
			}

		}


		bitmap_x += p->unit;
		canvas_x += p->note_sx;

		if (
			( bitmap_x >= chl->count )
			||
			( canvas_x >= p->sx )
		)
		{

			// End of Line Indicator

			n_nmidi_canvas_indicator( p, canvas_x+0,canvas_y, color_eol, n_false );
			n_nmidi_canvas_indicator( p, canvas_x+2,canvas_y, color_eol, n_false );


			bitmap_x = start_bitmap_x;
			canvas_x = start_canvas_x;


			bitmap_y += 1;
			canvas_y += p->note_sy + p->stdsize_m;
			if (
				( bitmap_y >= p->line )
				||
				( canvas_y >= p->sy   )
			)
			{
				break;
			}

		}

	}


	return;
}

void
n_nmidi_canvas_draw_scroll( n_nmidi_canvas *p )
{

	const u32 color_bg = N_NMIDI_COLOR_NOTE;
	const u32 color_fg = N_NMIDI_COLOR_FG;


	n_type_real n   = (n_type_real) p->scroll_max / p->scroll_step;
	n_type_real pos = (n_type_real) p->scroll_pos / p->scroll_step;
	n_type_real sx  = (n_type_real) p->sx / n;
	n_type_real sy  = (n_type_real) p->scroll_size;
	n_type_real x   = (n_type_real) sx * pos;
	n_type_real y   = (n_type_real) p->sy - sy;

	n_type_gfx tx  = (n_type_gfx) x;
	n_type_gfx ty  = (n_type_gfx) y;
	n_type_gfx tsx = (n_type_gfx) sx;
	n_type_gfx tsy = (n_type_gfx) sy;

	n_type_gfx u   = p->border;
	n_type_gfx uu  = p->border * 2;

	n_type_gfx m   = 0; if ( u == 0 ) { m = 1; }


	n_game_progressbar_horz( &p->canvas,  0+u+m,ty+u,  p->sx-uu, tsy-uu, color_bg, color_bg, 100, tsy );
	n_game_progressbar_horz( &p->canvas, tx+u+m,ty+u,    tsx-uu, tsy-uu, color_fg, color_fg, 100, tsy );


	// [!] : for collision

	n_win_rect_set_simple( &p->scroll_shaft,  0+u,ty+u, p->sx-uu,tsy-uu );
	n_win_rect_set_simple( &p->scroll_thumb, tx+u,ty+u,   tsx-uu,tsy-uu );


	return;
}

// internal
n_bool
n_nmidi_canvas_collision( n_nmidi_canvas *p )
{

	n_bool collision = n_false;


	n_type_gfx canvas_x = p->stdsize_m;
	n_type_gfx canvas_y = p->stdsize_m;
	n_type_gfx bitmap_x = 0;
	n_type_gfx bitmap_y = 0;

	n_posix_loop
	{

		n_channel *chl = &p->channel[ bitmap_y ];


		n_type_gfx sx,sy;
		if ( bitmap_x == 0 )
		{
			sx = p->header_sx;
			sy = p->header_sy;
		} else {
			sx = p->note_sx;
			sy = p->note_sy;
		}


		collision = n_win_is_hovered_offset( p->hwnd, canvas_x, canvas_y, sx, sy );


		canvas_x += sx;


		if ( collision )
		{
//n_win_hwndprintf_literal( hwnd, "ON : %d", bitmap_x );

			p->channel_number = bitmap_y;

			if ( ( p->hover_x != bitmap_x )||( p->hover_y != bitmap_y ) )
			{
				p->hover_x = bitmap_x;
				p->hover_y = bitmap_y;
				n_nmidi_canvas_refresh( p );
			}

			break;

		} else {
//n_win_hwndprintf_literal( hwnd, "OFF", 0 );

			//

		}


		if ( bitmap_x == 0 )
		{
			bitmap_x = N_MIDI_OFFSET_HEADER + p->scroll_pos;
		} else {
			bitmap_x += p->unit;
		}
		if ( ( bitmap_x >= chl->count )||( canvas_x >= p->sx ) )
		{

			bitmap_x  = 0;
			canvas_x  = p->stdsize_m;
			canvas_y += p->header_sy + p->stdsize_m;

			bitmap_y++;
			if ( ( bitmap_y >= p->line )||( canvas_y >= p->sy ) ) { break; }
		}
	}


	if (
		( collision == n_false )
		&&
		(
			( p->hover_x != N_MIDI_HOVER_NEUTRAL )
			||
			( p->hover_y != N_MIDI_HOVER_NEUTRAL )
		)
	)
	{
		p->hover_x = p->hover_y = N_MIDI_HOVER_NEUTRAL;
		n_nmidi_canvas_refresh( p );
	}


	return collision;
}

n_bool
n_nmidi_canvas_collision_scroll( n_nmidi_canvas *p )
{

	RECT r_thumb  = p->scroll_thumb;
	RECT r_shaft  = p->scroll_shaft;

	if ( n_win_is_hovered_offset( p->hwnd, r_thumb.left, r_thumb.top, r_thumb.right, r_thumb.bottom ) )
	{
//n_win_hwndprintf_literal( GetParent( p->hwnd ), "Thumb" );

		return n_true;

	}// else
	if ( n_win_is_hovered_offset( p->hwnd, r_shaft.left, r_shaft.top, r_shaft.right, r_shaft.bottom ) )
	{
//n_win_hwndprintf_literal( GetParent( p->hwnd ), "Shaft" );

		n_type_gfx cursor_x; n_win_cursor_position_relative( p->hwnd, &cursor_x, NULL );

		n_type_real n    = (n_type_real) r_thumb.right;
		n_type_real pos  = (n_type_real) cursor_x;
		int         page = (int) trunc( pos / n );

//n_win_hwndprintf_literal( GetParent( p->hwnd ), "%d", page );

		p->scroll_pos = 0;
		n_nmidi_canvas_scroll_set( p, page );

		return n_true;

	}


	return n_false;
}

void
n_nmidi_canvas_clipboard_get( n_nmidi_canvas *p )
{

	n_type_gfx ch = p->hover_y;
	n_type_gfx i  = p->hover_x;

	if ( i == 0 ) { return; }

	n_bmp_ptr_get( &p->data, i, ch, &p->clipboard );


	return;
}

void
n_nmidi_canvas_clipboard_set( n_nmidi_canvas *p )
{

	n_midi_bmp_note_set
	(
		&p->data,
		p->channel_number,
		p->hover_x, p->hover_x + p->unit,
		n_midi_bmp_color2note  ( p->clipboard ),
		n_midi_bmp_color2volume( p->clipboard )
	);


	n_type_gfx f = p->hover_x;
	n_type_gfx t = p->hover_x + p->unit;
	n_posix_loop
	{

		n_bmp_free( &p->channel[ p->channel_number ].bmp[ f ] );

		f++;
		if ( f >= t ) { break; }
	}


	n_nmidi_canvas_refresh( &canvas );


	return;
}

void
n_nmidi_canvas_channel_set( n_nmidi_canvas *p, int ch, int sound, int panpot )
{

	// [!] : don't use p->hover_*

	sound  = n_midi_bmp_param_clamp( sound  );
	panpot = n_midi_bmp_param_clamp( panpot );


	n_midi_bmp_channel_set( &p->data, ch, sound, panpot );

	p->channel[ ch ].sound  = sound;
	p->channel[ ch ].panpot = panpot;

	n_nmidi_canvas_item_header( p, ch, 0 );


	n_nmidi_canvas_refresh( &canvas );


	return;
}

void
n_nmidi_canvas_note_set( n_nmidi_canvas *p, int ch, int i, int note, int volume )
{

	// [!] : don't use p->hover_*


	note   = n_midi_bmp_param_clamp( note   );
	volume = n_midi_bmp_param_clamp( volume );


	n_midi_bmp_note_set
	(
		&p->data,
		ch,
		i, i + p->unit,
		note,
		volume
	);


	n_type_gfx f = i;
	n_type_gfx t = i + p->unit;
	n_posix_loop
	{

		n_bmp_free( &p->channel[ ch ].bmp[ f ] );

		f++;
		if ( f >= t ) { break; }
	}


	n_nmidi_canvas_refresh( &canvas );


	return;
}

