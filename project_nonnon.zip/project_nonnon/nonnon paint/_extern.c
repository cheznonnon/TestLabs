// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : gcc4 : don't use "extern" for global "static" variables




// Key Bindings

#define N_PAINT_KEY_A 'A'
#define N_PAINT_KEY_B 'B'
#define N_PAINT_KEY_C 'C'
#define N_PAINT_KEY_D 'D'
#define N_PAINT_KEY_E 'E'

#define N_PAINT_KEY_J 'J'

#define N_PAINT_KEY_1 '1'
#define N_PAINT_KEY_2 '2'
#define N_PAINT_KEY_3 '3'
#define N_PAINT_KEY_4 '4'
#define N_PAINT_KEY_5 '5'
#define N_PAINT_KEY_6 '6'
#define N_PAINT_KEY_7 '7'
#define N_PAINT_KEY_8 '8'
#define N_PAINT_KEY_9 '9'
#define N_PAINT_KEY_0 '0'


// Global Timeout : msec

#define N_PAINT_TIMEOUT ( 500 )


// [ nonnon_paint_grab_n_drag.c ]

static n_win_grab_n_drag n_paint_grab_n_drag;


// [ nonnon_paint.c ]

#define N_PAINT_APPNAME         "Nonnon Paint"
#define N_PAINT_APPNAME_LITERAL n_posix_literal( "Nonnon Paint" )

#define N_PAINT_MUTEX_REFRESH   n_posix_literal( "n_paint_refresh()" )


#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_NONNON_PAINT ( 0 )

#endif // #ifndef NONNON_APPS


#define N_PAINT_REFRESH_NONE     ( 0 << 0 )
#define N_PAINT_REFRESH_CLIENT   ( 1 << 0 )
#define N_PAINT_REFRESH_WINDOW   ( 1 << 1 )
#define N_PAINT_REFRESH_SCROLL   ( 1 << 2 )
#define N_PAINT_REFRESH_L_NAME   ( 1 << 3 )
#define N_PAINT_REFRESH_ALL      ( 0xffff )

static n_bool n_paint_refresh_lock    = n_false;
static int    n_paint_refresh_combine = N_PAINT_REFRESH_NONE;

#define n_paint_refresh_flush( mode ) n_paint_refresh( NULL, 0,0, N_BMP_SX( n_paint_bmp_data ),N_BMP_SY( n_paint_bmp_data ), mode, 0 )
#define n_paint_refresh_all()         n_paint_refresh_flush( N_PAINT_REFRESH_ALL    )
#define n_paint_refresh_client()      n_paint_refresh_flush( N_PAINT_REFRESH_CLIENT )
#define n_paint_refresh_window()      n_paint_refresh_flush( N_PAINT_REFRESH_CLIENT | N_PAINT_REFRESH_WINDOW )
#define n_paint_refresh_scroll()      n_paint_refresh_flush( N_PAINT_REFRESH_CLIENT | N_PAINT_REFRESH_SCROLL )
#define n_paint_refresh_layer_name()  n_paint_refresh_flush( N_PAINT_REFRESH_L_NAME )

#define N_PAINT_REFRESH_ID_NEWFILE  ( 1 )
#define N_PAINT_REFRESH_ID_WM_PAINT ( 2 )
#define N_PAINT_REFRESH_ID_SCROLL   ( 3 )
#define N_PAINT_REFRESH_ID_ZOOM     ( 4 )
#define N_PAINT_REFRESH_ID_PEN      ( 5 )
#define N_PAINT_REFRESH_ID_GRABBER  ( 6 )
#define N_PAINT_REFRESH_ID_LAYER    ( 7 )

#define n_paint_refresh_flush_id( mode, id ) n_paint_refresh( NULL, 0,0, N_BMP_SX( n_paint_bmp_data ),N_BMP_SY( n_paint_bmp_data ), mode, id )
#define n_paint_refresh_all_id( id )         n_paint_refresh_flush_id( N_PAINT_REFRESH_ALL   , id )
#define n_paint_refresh_client_id( id )      n_paint_refresh_flush_id( N_PAINT_REFRESH_CLIENT, id )
#define n_paint_refresh_window_id( id )      n_paint_refresh_flush_id( N_PAINT_REFRESH_CLIENT | N_PAINT_REFRESH_WINDOW, id )
#define n_paint_refresh_scroll_id( id )      n_paint_refresh_flush_id( N_PAINT_REFRESH_CLIENT | N_PAINT_REFRESH_SCROLL, id )


#define N_PAINT_FILTER_SCALE_LIL 0
#define N_PAINT_FILTER_SCALE_BIG 1
#define N_PAINT_FILTER_MIRROR    2
#define N_PAINT_FILTER_ROTATE_L  3
#define N_PAINT_FILTER_ROTATE_R  4
#define N_PAINT_FILTER_CLEAR     5
#define N_PAINT_FILTER_ALPHA_CLR 6
#define N_PAINT_FILTER_ALPHA_REV 7


#define N_PAINT_EXT_NUL n_posix_literal( ".___\0\0" )
#define N_PAINT_EXT_BMP n_posix_literal( ".bmp\0\0" )
#define N_PAINT_EXT_ICO n_posix_literal( ".ico\0\0" )
#define N_PAINT_EXT_CUR n_posix_literal( ".cur\0\0" )
#define N_PAINT_EXT_JPG n_posix_literal( ".jpg\0\0" )
#define N_PAINT_EXT_PNG n_posix_literal( ".png\0\0" )
#define N_PAINT_EXT_GIF n_posix_literal( ".gif\0\0" )
#define N_PAINT_EXT_LYR n_posix_literal( ".lyr\0\0" )

#define N_PAINT_FORMAT_NUL ( 0 )
#define N_PAINT_FORMAT_BMP ( 1 )
#define N_PAINT_FORMAT_ICO ( 2 )
#define N_PAINT_FORMAT_CUR ( 3 )
#define N_PAINT_FORMAT_JPG ( 4 )
#define N_PAINT_FORMAT_PNG ( 5 )
#define N_PAINT_FORMAT_LYR ( 6 )

#define n_paint_format_is_bmp( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_BMP, name ) )
#define n_paint_format_is_ico( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_ICO, name ) )
#define n_paint_format_is_cur( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_CUR, name ) )
#define n_paint_format_is_jpg( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_JPG, name ) )
#define n_paint_format_is_png( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_PNG, name ) )
#define n_paint_format_is_lyr( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_LYR, name ) )

#define n_paint_format_is_curico( name ) ( n_paint_format_is_ico( name ) || n_paint_format_is_cur( name ) )


// [!] : initialized by nonnon_paint_ini.c

static n_type_gfx        zoom;
static n_type_gfx        pensize, mix, boost, air;
static int               tooltype;
static n_bool            grid, pixelgrid, antishake, graycanvas, thumbnail;
static int               grabber;
static n_bool            n_paint_quick_eraser = n_false;
static n_bool            n_paint_quick_blur   = n_false;


// [!] : initialized by nonnon_paint.c

static HWND              hwnd_main;
static HWND              hwnd_tool;
static HWND              hwnd_layr;
static HWND              hwnd_thmb;
static n_win             nwin_main;
static n_win             nwin_tool;
static n_win             nwin_layr;
static n_win             nwin_thmb;
 
static HBITMAP           n_paint_dibsection;
static n_bmp            *n_paint_bmp_data;
static n_bmp            *n_paint_bmp_grab;
static n_bmp             n_paint_bmp_dbuf;
static n_bmp             n_paint_bmp_thmb;
static n_bmp             n_paint_bmp_name;
static n_bmp             n_paint_bmp_scrl;
static n_bmp             n_paint_bmp_wgrb;
static n_curico          n_paint_curico;
static int               n_paint_format = N_PAINT_FORMAT_NUL;
static n_type_int        n_paint_bmp_name_count;

static n_bmp             n_paint_bmp_zoom_i;
static n_bmp             n_paint_bmp_zoom_o;

static n_posix_char     *n_paint_bmpname;
static n_posix_char     *n_paint_grbname;
static n_posix_char     *n_paint_prvname = NULL;

static n_win_scrollbar   n_paint_hscr;
static n_win_scrollbar   n_paint_vscr;

static n_win_titlemenu   n_paint_titlemenu;
static n_win_simplemenu  n_paint_simplemenu;

#ifdef _H_NONNON_WIN32_WIN_WINTAB

static n_wintab          n_paint_wintab;
static n_bool            n_paint_wintab_onoff;

#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB

static n_bool            n_paint_thread_onoff;

static n_type_gfx        n_paint_prev_scrollx  = 0;
static n_type_gfx        n_paint_prev_scrolly  = 0;
static HANDLE            n_paint_hmutex        = NULL;

static n_type_gfx        n_paint_desktop_sx;
static n_type_gfx        n_paint_desktop_sy;

static n_type_gfx        n_paint_thumbnail_size;

static n_bool            n_paint_fastmode;


static n_bool n_paint_xmouse_onoff = n_true;

void
n_paint_xmouse( HWND hwnd, UINT msg )
{

	if ( n_paint_xmouse_onoff )
	{
		n_win_simplemenu_xmouse( &n_paint_simplemenu, hwnd, msg );
	}

	return;
}


extern void n_paint_refresh( HDC, n_type_gfx, n_type_gfx, n_type_gfx, n_type_gfx, int, int );

extern void n_paint_canvaspos( n_type_gfx*, n_type_gfx* );
extern void n_paint_colorpicker( void );

extern void n_paint_status( void );
extern void n_paint_title( void );

extern void n_paint_dialog_info( const n_posix_char* );
extern n_bool n_paint_dialog_yesno( const n_posix_char* );

extern n_bool n_paint_load( n_posix_char*, n_bmp*, n_curico* );

extern n_posix_char* n_paint_newname_new( void );

extern n_bool n_paint_is_innercanvas( void );


n_type_gfx
n_paint_pensize( void )
{

	n_type_gfx ret = pensize;

	if ( ret == 0 )
	{
		ret = 1;
	} else {
		ret = ( ret * 2 ) + 1;
	}

	return ret;
}

void
n_paint_cache_zero( n_bmp *bmp )
{

	//n_bmp_safemode_base = n_true;
	//n_bmp_flush( bmp, 0 );
	//n_bmp_safemode_base = n_false;

	n_memory_zero( N_BMP_PTR( bmp ), N_BMP_SIZE( bmp ) );

	return;
}


// [!] : canvas helper

#define N_PAINT_CANVAS_COLOR  n_bmp_argb( 0,128,128,128 )
#define N_PAINT_CANVAS_SIZE   128
#define N_PAINT_CANVAS_MARGIN  32

inline void
n_paint_margin_get( n_type_gfx *sx, n_type_gfx *sy )
{

	n_type_real scale  = n_win_scale( hwnd_main );
	n_type_real margin = (n_type_real) N_PAINT_CANVAS_MARGIN * scale;

	//if ( n_direct2d_is_on() ) { margin = 0; }

	if ( sx != NULL ) { (*sx) = (n_type_gfx) trunc( margin ); }
	if ( sy != NULL ) { (*sy) = (n_type_gfx) trunc( margin ); }


	return;
}

inline void
n_paint_hamburger_get( n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy )
{

	n_type_gfx ox,oy,osx,osy; ox = oy = osx = osy = 0;

	n_type_gfx m; m = 0;

	n_paint_margin_get( &osx,&osy );

	if ( n_win_is_lefthanded() ) { ox = N_BMP_SX( &n_paint_bmp_dbuf ) - osx; } 
//if ( 1 ) { ox = N_BMP_SX( &n_paint_bmp_dbuf ) - osx; } 

	n_win_stdsize( hwnd_main, NULL, NULL, &m );

	if (  x != NULL ) { (* x) = ox + m; }
	if (  y != NULL ) { (* y) = oy + m; }
	if ( sx != NULL ) { (*sx) = osx - ( m * 2 ); }
	if ( sy != NULL ) { (*sy) = osy - ( m * 2 ); }


	return;
}


// [!] : zoom in/out support helper

#define N_PAINT_ZOOM_MAX  ( 200 )
#define N_PAINT_ZOOM_ZERO ( N_PAINT_ZOOM_MAX / 2 )

#define n_paint_is_zoom_in(  zoom ) ( zoom > N_PAINT_ZOOM_ZERO )
#define n_paint_is_zoom_out( zoom ) ( zoom < N_PAINT_ZOOM_ZERO )

n_type_gfx
n_paint_zoom_get( n_type_gfx zoom )
{

	if ( n_paint_is_zoom_in( zoom ) )
	{
		return ( zoom - N_PAINT_ZOOM_ZERO );
	} else
	if ( n_paint_is_zoom_out( zoom ) )
	{
		return ( N_PAINT_ZOOM_ZERO - zoom );
	}


	return 0;
}

n_type_gfx
n_paint_zoom_clamp( n_type_gfx prev, n_type_gfx zoom )
{

	if ( prev > N_PAINT_ZOOM_ZERO )
	{
		if ( zoom < ( N_PAINT_ZOOM_ZERO + 1 ) ) { zoom = N_PAINT_ZOOM_ZERO - 2; }
	} else
	if ( prev < N_PAINT_ZOOM_ZERO )
	{
		if ( zoom > ( N_PAINT_ZOOM_ZERO - 2 ) ) { zoom = N_PAINT_ZOOM_ZERO + 1; }
	}


	return zoom;
}

// internal
void
n_paint_zoom_bitmap2canvas( n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy )
{

	n_type_gfx z = n_paint_zoom_get( zoom );


	if ( n_paint_is_zoom_in( zoom ) )
	{
		if ( x  != NULL ) { (*x ) *= z; }
		if ( y  != NULL ) { (*y ) *= z; }
		if ( sx != NULL ) { (*sx) *= z; }
		if ( sy != NULL ) { (*sy) *= z; }
	} else
	if ( n_paint_is_zoom_out( zoom ) )
	{
		if ( x  != NULL ) { (*x ) /= z; }
		if ( y  != NULL ) { (*y ) /= z; }
		if ( sx != NULL ) { (*sx) /= z; }
		if ( sy != NULL ) { (*sy) /= z; }
	}


	return;
}

// internal
void
n_paint_zoom_canvas2bitmap( n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy )
{

	n_type_gfx z = n_paint_zoom_get( zoom );


	if ( n_paint_is_zoom_out( zoom ) )
	{
		if ( x  != NULL ) { (*x ) *= z; }
		if ( y  != NULL ) { (*y ) *= z; }
		if ( sx != NULL ) { (*sx) *= z; }
		if ( sy != NULL ) { (*sy) *= z; }
	} else
	if ( n_paint_is_zoom_in( zoom ) )
	{
		if ( x  != NULL ) { (*x ) /= z; }
		if ( y  != NULL ) { (*y ) /= z; }
		if ( sx != NULL ) { (*sx) /= z; }
		if ( sy != NULL ) { (*sy) /= z; }
	}


	return;
}


// [ nonnon_paint_colorhistory.c ]

extern void n_paint_colorhistory_add( u32 );
extern LRESULT CALLBACK n_paint_colorhistory_wndproc( HWND, UINT, WPARAM, LPARAM );


// [ nonnon_paint_colorsync.c ]

static UINT n_paint_sync_wm_synccolor = WM_NULL;


extern void n_sync_go( UINT, WPARAM, LPARAM );


// [ nonnon_paint_formatter.c ]

#define N_PAINT_FORMATTER_MODE_NORMAL    ( 0 )
#define N_PAINT_FORMATTER_MODE_DROP2SAVE ( 1 )

static int           n_paint_formatter_mode;
static n_posix_char *n_paint_formatter_name;


// [ nonnon_paint_grabber.c ]

#define N_PAINT_GRABBER_NEUTRAL              0
#define N_PAINT_GRABBER_SELECTING            1
#define N_PAINT_GRABBER_DRAG_OK              2
#define N_PAINT_GRABBER_DRAGGING             3
#define N_PAINT_GRABBER_STRETCH_PROPORTIONAL 4
#define N_PAINT_GRABBER_STRETCH_TRANSFORM    5
#define N_PAINT_GRABBER_RESELECT             6

#define N_PAINT_GRABBER_IS_NEUTRAL()              ( grabber == N_PAINT_GRABBER_NEUTRAL              )
#define N_PAINT_GRABBER_IS_SELECTING()            ( grabber == N_PAINT_GRABBER_SELECTING            )
#define N_PAINT_GRABBER_IS_DRAG_OK()              ( grabber == N_PAINT_GRABBER_DRAG_OK              )
#define N_PAINT_GRABBER_IS_DRAGGING()             ( grabber == N_PAINT_GRABBER_DRAGGING             )
#define N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() ( grabber == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
#define N_PAINT_GRABBER_IS_STRETCH_TRANSFORM()    ( grabber == N_PAINT_GRABBER_STRETCH_TRANSFORM    )
#define N_PAINT_GRABBER_IS_RESELECT()             ( grabber == N_PAINT_GRABBER_RESELECT             )


extern void n_paint_grabber_system_get( n_type_gfx*, n_type_gfx*, n_type_gfx*, n_type_gfx*, n_type_gfx*, n_type_gfx* );
extern void n_paint_grabber_reset( void );
extern void n_paint_grabber_status( void );
extern void n_paint_grabber_position_reset( void );
extern void n_paint_grabber_resync_auto( void );


static n_bool     n_paint_grabber_finalize_onoff = n_true;
static n_bool     n_paint_grabber_wholegrb_onoff = n_false;
static n_bool     n_paint_grabber_is_rotated     = n_false;
static n_type_int n_paint_grabber_selected_index = 0;


// [ nonnon_paint_layer.c ]

#define N_PAINT_LAYER_MAX ( 16 )
#define N_PAINT_LAYER_CCH ( 32 )

typedef struct {

	n_posix_char name[ N_PAINT_LAYER_CCH ];
	n_bmp        bmp_data;
	n_bmp        bmp_grab;
	n_bool       visible;
	int          percent;
	int          blur;

	// Cache

	n_type_real  blend;

} n_paint_layer;

#define n_paint_layer_zero( p ) n_memory_zero( p, sizeof( n_paint_layer ) )


static n_bool            n_paint_layer_onoff = n_false;
static int               n_paint_layer_count = N_PAINT_LAYER_MAX;
static n_paint_layer    *n_paint_layer_data;
static n_posix_bool     *n_paint_layer_is_mod;
static n_bmp             n_paint_layer_as_one;
static n_win_txtbox      n_paint_layer_txtbox;
static n_win_txtbox      n_paint_layer_rename;
static n_bool            n_paint_layer_rename_onoff  = n_false;
static n_type_int        n_paint_layer_rename_target = 0;
static n_ini             n_paint_layer_ini;
static n_bool            n_paint_layer_shade_onoff   = n_false;
static n_bool            n_paint_layer_scroll_onoff  = n_false;
static n_type_int        n_paint_layer_menu_target   = -1;
static n_type_int        n_paint_layer_multiselect   = 0;

//static n_win_statusbar_ownerdraw n_paint_layer_statusbar;


#define n_bmp_layercopy( l,b, x,y,sx,sy, tx,ty, is_ui ) n_bmp_layercopy_main( l,b, x,y,sx,sy, tx,ty, n_bmp_white_invisible, is_ui )

extern void n_bmp_layercopy_main( n_paint_layer*, n_bmp*, n_type_gfx, n_type_gfx, n_type_gfx, n_type_gfx, n_type_gfx, n_type_gfx, u32, n_bool );
extern void n_paint_layer_grabber_check_enable( n_bool );
extern void n_paint_layercopy_grabber( n_bmp* );


n_bool
n_paint_layer_is_locked( n_type_int i )
{

	if ( n_paint_layer_onoff == n_false ) { return n_false; }


	return ( n_paint_layer_data[ i ].name[ 0 ] == n_posix_literal( '*' ) );
}

n_bool
n_paint_layer_is_locked_partially( void )
{

	if ( n_paint_layer_onoff            == n_false ) { return n_false; }
	if ( n_paint_grabber_wholegrb_onoff == n_false ) { return n_false; }


	n_type_int i = 0;
	n_posix_loop
	{
		if ( n_paint_layer_is_locked( i ) )
		{
			return n_true;
		}

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return n_false;
}


// [ nonnon_paint_refresh.c ]

extern inline u32 n_paint_canvas_grabber_pixel( n_bmp*, n_type_gfx, n_type_gfx, u32 );


// [ nonnon_paint_tool.c ]

#define N_PAINT_TOOL_TYPE_NONE  0
#define N_PAINT_TOOL_TYPE_PEN   1
#define N_PAINT_TOOL_TYPE_FILL  2
#define N_PAINT_TOOL_TYPE_GRAB  3


#define N_PAINT_TOOL_H_BTN_00_00  n_paint_tool_hbtn[ 0 ]
#define N_PAINT_TOOL_H_BTN_01_00  n_paint_tool_hbtn[ 1 ]
#define N_PAINT_TOOL_H_BTN_02_00  n_paint_tool_hbtn[ 2 ]
#define N_PAINT_TOOL_H_BTN_03_00  n_paint_tool_hbtn[ 3 ]
#define N_PAINT_TOOL_H_BTN_04_00  n_paint_tool_hbtn[ 4 ]

#define N_PAINT_TOOL_H_BTN_00_01  n_paint_tool_hbtn[ 0 + 5 ]
#define N_PAINT_TOOL_H_BTN_01_01  n_paint_tool_hbtn[ 1 + 5 ]
#define N_PAINT_TOOL_H_BTN_02_01  n_paint_tool_hbtn[ 2 + 5 ]
#define N_PAINT_TOOL_H_BTN_03_01  n_paint_tool_hbtn[ 3 + 5 ]
#define N_PAINT_TOOL_H_BTN_04_01  n_paint_tool_hbtn[ 4 + 5 ]

#define N_PAINT_TOOL_H_BTN_00_02  n_paint_tool_hbtn[ 0 + 10 ]
#define N_PAINT_TOOL_H_BTN_01_02  n_paint_tool_hbtn[ 1 + 10 ]
#define N_PAINT_TOOL_H_BTN_02_02  n_paint_tool_hbtn[ 2 + 10 ]
#define N_PAINT_TOOL_H_BTN_03_02  n_paint_tool_hbtn[ 3 + 10 ]
#define N_PAINT_TOOL_H_BTN_04_02  n_paint_tool_hbtn[ 4 + 10 ]

#define N_PAINT_TOOL_BTN_MAX                       ( 5 + 10 )


#define N_PAINT_TOOL_H_SCR_SIZE   ( &n_paint_tool_hscr[ 0 ] )
#define N_PAINT_TOOL_H_SCR_MIX    ( &n_paint_tool_hscr[ 1 ] )
#define N_PAINT_TOOL_H_SCR_BOOST  ( &n_paint_tool_hscr[ 2 ] )
#define N_PAINT_TOOL_H_SCR_AIR    ( &n_paint_tool_hscr[ 3 ] )
#define N_PAINT_TOOL_H_SCR_ZOOM   ( &n_paint_tool_hscr[ 4 ] )

#define N_PAINT_TOOL_SCR_MAX                            5




static n_win_colorpicker cp;
static HWND              n_paint_hpopup;

static n_win_button      n_paint_tool_hbtn[ N_PAINT_TOOL_BTN_MAX ];
static n_win_scroller    n_paint_tool_hscr[ N_PAINT_TOOL_SCR_MAX ];


extern void n_paint_tool_exit( void );
extern void n_paint_tool_saveicon_refresh( n_bool );
extern void n_paint_tool_scrollbar_updown( n_win_scroller*, int );


// [ nonnon_paint_tool_grabber.c ]

static n_win_statusbar_ownerdraw n_paint_tool_grabber_status;

static int         n_paint_tool_grabber_csy;
static n_bool      n_paint_tool_per_pixel_alpha_onoff;
static int         n_paint_tool_blend;
static n_type_real n_paint_tool_blend_ratio;

extern void n_paint_tool_grabber_exit( void );
extern void n_paint_tool_grabber_onoff( n_bool );
//extern void n_paint_tool_grabber_trans_onoff( n_bool );
extern void n_paint_tool_grabber_blend_zero( void );
extern void n_paint_tool_grabber_resize( void );
extern void n_paint_tool_grabber_proc( HWND, UINT, WPARAM, LPARAM );


inline u32
n_paint_tool_color_transparent_get( void )
{

	//return n_bmp_alpha_invisible_pixel( n_bmp_argb( cp.a, cp.r, cp.g, cp.b ) );

	if ( n_false == N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		return n_bmp_white_invisible;
	} else
	if ( n_paint_tool_per_pixel_alpha_onoff )
	{
		return n_bmp_white_invisible;
	} else
	if ( n_paint_layer_onoff )
	{
		return n_bmp_white_invisible;
	}


	return n_bmp_white;
}


// [ nonnon_paint_resizer.c ]

static n_type_gfx     n_paint_resizer_vanishing_point_x = -1;
static n_type_gfx     n_paint_resizer_vanishing_point_y = -1;

static n_bool         n_paint_resizer_backup_onoff = 0;
static n_type_int     n_paint_resizer_backup_index = 0;
static n_paint_layer *n_paint_resizer_backup_layer = NULL;
static n_posix_bool   n_paint_resizer_is_cancelled = n_posix_true;


// [ nonnon_paint_pen.c ]

#define N_PAINT_PEN_STRAIGHTLINE_VK VK_SPACE
#define N_PAINT_PEN_WHOLE_ERASER_VK VK_TAB

static n_type_gfx  n_paint_pen_radius   = 0;
static n_type_gfx  n_paint_pen_boost    = 0;
static u32         n_paint_pen_color    = 0;
static n_type_real n_paint_pen_blend    = 0;
static n_bool      n_paint_pen_start    = n_false;
static n_bool      n_paint_is_shiftzoom = n_false;

static n_type_gfx n_paint_pen_start_x;
static n_type_gfx n_paint_pen_start_y;
static n_bool     n_paint_pen_straight_line = n_false;

static n_bool     n_paint_pen_whole_eraser_onoff = n_false;

static n_bool     n_paint_hamburger_onoff      = n_false;
static n_bool     n_paint_hamburger_is_hovered = n_false;
static n_bool     n_paint_hamburger_is_started = n_false;

n_bool
n_paint_on_setcursor_condition( void )
{
//return n_false;

	n_type_gfx x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

	if ( n_win_is_hovered_offset( hwnd_main, x,y,sx,sy ) )
	{
		if (
			( n_paint_pen_start    == n_false )
			//&&
			//( n_paint_quick_eraser == n_false )
		)
		{
			n_win_cursor_add( NULL, IDC_ARROW );

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				return n_paint_hamburger_onoff;
			} else {
				return n_true;
			}
		}
	}

	if (
		( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
		||
		( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
	)
	{
		return n_true;
	}

	if (
		( n_paint_grabber_wholegrb_onoff )
		&&
		( tooltype == N_PAINT_TOOL_TYPE_GRAB )
	)
	{
		if ( n_paint_layer_is_locked( n_paint_layer_txtbox.select_cch_y ) )
		{
			return n_true;
		}
	} else
	if (
		( n_paint_grabber_wholegrb_onoff )
		&&
		( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		&&
		( grabber )
		&&
		( n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].visible )
	)
	{
		//
	} else
	if ( n_paint_layer_onoff )
	{
		n_type_int y1 = n_paint_layer_txtbox.select_cch_y;
		n_type_int y2 = n_paint_grabber_selected_index;

		if ( n_paint_layer_is_locked( y1 ) )
		{
			return n_true;
		} else
		if ( n_false == n_paint_layer_data[ y1 ].visible )
		{
			return n_true;
		} else
		if ( ( grabber )&&( n_false == n_paint_layer_data[ y2 ].visible ) )
		{
			return n_true;
		}
	}


	return n_false;
}

n_bool
n_paint_on_setcursor( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {

	case WM_SETCURSOR :

		if ( n_paint_is_shiftzoom ) { break; }

		if ( n_paint_pen_start ) { break; }


		if ( n_paint_resizer_backup_onoff )
		{
			n_win_cursor_add( NULL, IDC_ARROW );

			return n_true;
		}


		n_type_gfx x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

		if ( n_win_is_hovered_offset( hwnd, x,y,sx,sy ) )
		{
			n_win_cursor_add( NULL, IDC_ARROW );

			return n_true;
		}


		if (
			( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
			||
			( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
		)
		{
			n_win_cursor_add( NULL, IDC_ARROW );

			return n_true;
		}


		if ( n_paint_on_setcursor_condition() )
		{
			n_type_gfx sx = nwin_main.csx;
			n_type_gfx sy = nwin_main.csy;

			if ( n_win_is_hovered_offset( hwnd_main, 0,0,sx,sy ) )
			{
				n_win_cursor_add( NULL, IDC_NO );

				return n_true;
			}
		}

	break;

	} // switch


	return n_false;
}


// [ nonnon_paint_layer.c : #2 ]

static n_win_check n_paint_layer_chk_wholegrb;
static n_win_check n_paint_layer_chk_wholepvw;

static n_bool n_paint_whole_preview_onoff = n_false;

n_bool
n_paint_whole_preview( n_bool onoff )
{

	n_bool ret = n_false;
	if ( onoff != n_paint_whole_preview_onoff )
	{
		ret = n_true;
	}

	n_paint_whole_preview_onoff = onoff;


	return ret;
}


// [ nonnon_paint_layer.c : #3 ]

static n_posix_char *n_paint_layer_name_main = NULL;

void
n_paint_layer_name_exit( void )
{

	n_memory_free( n_paint_layer_name_main );

	n_paint_layer_name_main = NULL;


	return;
}

void
n_paint_layer_name_init( n_posix_char *target )
{

	n_paint_layer_name_exit();

	n_paint_layer_name_main = n_string_carboncopy( target );


	return;
}


// [ nonnon_paint_thumbnail.c ]

extern void n_paint_thumbnail_refresh( void );
extern void n_paint_thumbnail_show( void );
extern void n_paint_thumbnail_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam );


// [!] : cursor changer

void
n_paint_pen_cursor_default( HWND hwnd )
{

	if ( tooltype == N_PAINT_TOOL_TYPE_PEN  )
	{
		n_win_cursor_add_literal( hwnd, "NONNON_PAINT_PEN" );
	} else
	if ( tooltype == N_PAINT_TOOL_TYPE_FILL )
	{
		n_win_cursor_add_literal( hwnd, "NONNON_PAINT_FILL" );
	} else {
		n_win_cursor_add( hwnd, IDC_ARROW );
	}

	return;
}


