// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp.c"
#include "../nonnon/neutral/bmp/all.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_inputpopup.c"
#include "../nonnon/win32/win_scroller.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_txtbox.c"


#include "../nonnon/project/macro.c"




// rc.h

#define H_LBL_RESIZE    n_paint_resizer_hgui[  0 ]
#define H_LBL_SIZE      n_paint_resizer_hgui[  1 ]
#define H_LINE          n_paint_resizer_hgui[  2 ]
#define H_LBL_COLOR     n_paint_resizer_hgui[  3 ]
#define H_PREVIEW       n_paint_resizer_hgui[  4 ]
#define GUI_MAX                                5

#define H_BUTTON        n_paint_resizer_hbtn[  0 ]
#define H_BTN_REFRESH   n_paint_resizer_hbtn[  1 ]
#define BTN_MAX                                2

#define H_INPUT_SX      ( &n_paint_resizer_htxt[  0 ] )
#define H_INPUT_SY      ( &n_paint_resizer_htxt[  1 ] )
#define TXT_MAX                                   2

#define H_CMB_RESIZE    ( &n_paint_resizer_hcmb[  0 ] )
#define H_CMB_COLOR     ( &n_paint_resizer_hcmb[  1 ] )
#define CMB_MAX                                   2

#define H_SCR_ROUND     ( &n_paint_resizer_hscr[  0 ] )
#define H_SCR_GAMMA     ( &n_paint_resizer_hscr[  1 ] )
#define H_SCR_CLRWH     ( &n_paint_resizer_hscr[  2 ] )
#define H_SCR_VIVID     ( &n_paint_resizer_hscr[  3 ] )
#define H_SCR_SHARP     ( &n_paint_resizer_hscr[  4 ] )
#define H_SCR_CTRST     ( &n_paint_resizer_hscr[  5 ] )
#define SCR_MAX                                   6




#define MSG_SIZE                    "Size"
#define MSG_RESIZE                  "Resize Option"
#define MSG_RESIZE_TOPLEFT          "Top-Left"
#define MSG_RESIZE_TILE             "Tile"
#define MSG_RESIZE_CENTER           "Center"
#define MSG_RESIZE_TRANSFORM        "Transform"
#define MSG_RESIZE_FIT_X            "Fit : Lock X"
#define MSG_RESIZE_FIT_Y            "Fit : Lock Y"
#define MSG_RESIZE_PIXELART2        "Pixelart x2"
#define MSG_RESIZE_PIXELART3        "Pixelart x3"
#define MSG_RESIZE_CEL_ART_2        "Cel Art x2"
#define MSG_ROUND                   "Round"
#define MSG_COLOR                   "Color Option"
#define MSG_COLOR_NONE              "None"
#define MSG_COLOR_GRAY              "Grayscale"
#define MSG_COLOR_MONO              "Monochrome"
#define MSG_COLOR_REVS              "Reverse"
#define MSG_COLOR_MASK              "Noise Removal Mask"
#define MSG_COLOR_SIZE              "Color Reduction"
#define MSG_COLOR_V_PT              "Vanishing Point"
#define MSG_COLOR_CNTR              "Contour"
#define MSG_GAMMA                   "Gamma"
#define MSG_CLRWH                   "Color Wheel"
#define MSG_VIVID                   "Vividness"
#define MSG_BLACK                   "Blackness"
#define MSG_SHARP                   "Sharpness"
#define MSG_CTRST                   "Contrast"




// window

static HWND           n_paint_resizer_hgui[ GUI_MAX ];
static n_win_button   n_paint_resizer_hbtn[ BTN_MAX ];
static n_win_scroller n_paint_resizer_hscr[ SCR_MAX ];
static n_win_combo    n_paint_resizer_hcmb[ CMB_MAX ];
static n_win_txtbox   n_paint_resizer_htxt[ TXT_MAX ];


// app

static int n_paint_resizer_round;
static int n_paint_resizer_gamma;
static int n_paint_resizer_clrwh;
static int n_paint_resizer_vivid;
static int n_paint_resizer_sharp;
static int n_paint_resizer_ctrst;


static RECT n_paint_resizer_grabber_rect = { 0,0,0,0 };


static n_bool n_paint_resizer_scroll_init = n_false;




void
n_paint_resizer_backup_init( void )
{

	n_paint_resizer_grabber_rect = n_paint_grabber_rect;

	if ( n_paint_layer_onoff )
	{
		n_paint_resizer_backup_index = n_paint_layer_txtbox.select_cch_y;
	} else {
		n_paint_resizer_backup_index = 0;
	}

	n_paint_resizer_backup_layer = n_memory_new( sizeof( n_paint_layer ) * n_paint_layer_count );

	n_bmp_layer_copy( n_paint_layer_data, n_paint_resizer_backup_layer );


	n_win_hwndprintf_literal( hwnd_main, "Resizer Preview" );


	return;
}

void
n_paint_resizer_backup_exit( void )
{

	if ( n_paint_resizer_is_cancelled )
	{

		n_paint_layer *tmp = n_paint_layer_data;

		n_bmp_layer_free( n_paint_layer_data );
		n_paint_layer_data = n_paint_resizer_backup_layer;

		n_memory_free( tmp );

		if ( n_posix_false == N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_paint_grabber_rect = n_paint_resizer_grabber_rect;
			n_paint_grabber_resync_auto();
		}

	} else {

		n_bmp_layer_free( n_paint_resizer_backup_layer );
		n_memory_free( n_paint_resizer_backup_layer );


		if ( n_paint_grabber_wholegrb_onoff )
		{
			n_type_int i = 0;
			n_posix_loop
			{

				n_paint_layer_is_mod[ i ] = n_true;

				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}
		} else
		if ( n_paint_layer_onoff )
		{
			n_paint_layer_is_mod[ n_paint_layer_txtbox.select_cch_y ] = n_true;
		}

	}

	n_paint_bmp_data = &n_paint_layer_data[ n_paint_resizer_backup_index ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ n_paint_resizer_backup_index ].bmp_grab;

	n_paint_resizer_backup_index = 0;
	n_paint_resizer_backup_layer = NULL;

	n_paint_cache_zero( &n_paint_bmp_scrl );
	n_paint_cache_zero( &n_paint_bmp_wgrb );


	n_paint_title();


	n_paint_refresh_all();


	return;
}

void
n_paint_resizer_backup_go( void )
{

	n_paint_layer *tmp = n_paint_layer_data;

	n_paint_layer_data = n_memory_new( sizeof( n_paint_layer ) * n_paint_layer_count );

	n_bmp_layer_copy( n_paint_resizer_backup_layer, n_paint_layer_data );

	n_paint_bmp_data = &n_paint_layer_data[ n_paint_resizer_backup_index ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ n_paint_resizer_backup_index ].bmp_grab;

	n_bmp_layer_free( tmp );


	extern void n_paint_resizer_go( void );
	n_paint_resizer_go();


	return;
}




// internal
n_bool
n_paint_resizer_vanishing_point_usage( HWND hwnd )
{

	n_bool ret = n_false;


	n_posix_char *str_color = n_win_combo_selection_get( H_CMB_COLOR );

	if ( n_string_is_same_literal( MSG_COLOR_V_PT, str_color ) )
	{
		if ( n_paint_resizer_vanishing_point_x == -1 )
		{
			n_posix_char *msg =
				n_posix_literal
				(
					"[ Set ]\n"
					"double-click a canvas\n"
					"\n"
					"[ Unset ]\n"
					"double-menu-click a canvas"
				)
			;

			n_project_dialog_info( hwnd, msg );

			ret = n_true;
		}
	}


	return ret;
}

// internal
n_bool
n_paint_resizer_vanishing_point_combo_is_selected( void )
{

	n_bool ret = n_false;


	n_posix_char *str_color = n_win_combo_selection_get( H_CMB_COLOR );

	if ( n_string_is_same_literal( MSG_COLOR_V_PT, str_color ) )
	{
		ret = n_true;
	}


	return ret;
}

void
n_paint_vanishing_point( n_bmp *bmp )
{

	if ( n_paint_resizer_vanishing_point_x == -1 ) { return; }


	n_type_gfx bmpsx = N_BMP_SX( bmp );
	n_type_gfx bmpsy = N_BMP_SY( bmp );
	n_type_gfx maxim = n_posix_max_n_type_gfx( bmpsx, bmpsy );


	n_type_gfx x = n_paint_resizer_vanishing_point_x;
	n_type_gfx y = n_paint_resizer_vanishing_point_y;


	n_bmp bmp_onoff; n_bmp_zero( &bmp_onoff );
	n_bmp_new_fast( &bmp_onoff, bmpsx, bmpsy );
	n_bmp_flush( &bmp_onoff, 0 );


	n_type_gfx xx = -1;
	n_type_gfx yy = -1;
	n_posix_loop
	{
		n_bmp_line_reverse( bmp, &bmp_onoff, x+xx,0, x+xx,bmpsy );

		xx++;
		if ( xx >= 2 )
		{
			xx = 0;

			n_bmp_line_reverse( bmp, &bmp_onoff, 0,y+yy, bmpsx,y+yy );

			n_bmp_line_reverse( bmp, &bmp_onoff, x + xx - maxim, y + yy - maxim, x + xx + maxim, y + yy + maxim );
			n_bmp_line_reverse( bmp, &bmp_onoff, x + xx - maxim, y + yy + maxim, x + xx + maxim, y + yy - maxim );

			yy++;
			if ( yy >= 2 ) { break; }
		}
	}


	n_type_real seed = 1.5;

	n_type_gfx p = 4;
	n_type_gfx w = (n_type_gfx) pow( seed, p );
	n_type_gfx s = n_posix_max( bmpsx, bmpsy ) * 2;
	n_posix_loop
	{
		n_type_gfx r = -( w / 2 );

		if ( 10 < abs( r )  )
		{
			n_bmp_frame_reverse( bmp, &bmp_onoff, x+r,y+r,w,w );
		}

		p++;
		w = (n_type_gfx) pow( seed, p );
		if ( w > s ) { break; }
	}


	n_bmp_free_fast( &bmp_onoff );


	return;
}

void
n_paint_flush_reverse( n_bmp *bmp )
{

	n_type_gfx sx = N_BMP_SX( bmp );
	n_type_gfx sy = N_BMP_SY( bmp );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		int a =       n_bmp_a( color );
		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		n_bmp_ptr_set_fast( bmp, x,y, n_bmp_argb( a,r,g,b ) );

		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

// internal
n_bool
n_paint_resizer_all_same( n_bmp *bmp )
{

	n_bool ret = n_true;


	u32 color_main = 0;

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		if ( ( x == 0 )&&( y == 0 ) )
		{
			color_main = color;
		}

		if ( color_main != color )
		{
			ret = n_false;
			break;
		}

		x++;
		if ( x >= N_BMP_SX( bmp ) )
		{

			x = 0;

			y++;
			if ( y >= N_BMP_SY( bmp ) ) { break; }
		}
	}


	return ret;
}

// internal
void
n_paint_resizer_size_get( n_type_gfx *ret_sx, n_type_gfx *ret_sy )
{

	if ( ret_sx != NULL )
	{
		n_posix_char str_size[ 100 ];

		n_win_txtbox_selection_get( H_INPUT_SX, str_size );

		(*ret_sx) = n_posix_atoi( str_size );
	}

	if ( ret_sy != NULL )
	{
		n_posix_char str_size[ 100 ];

		n_win_txtbox_selection_get( H_INPUT_SY, str_size );

		(*ret_sy) = n_posix_atoi( str_size );
	}


	return;
}

// internal
void
n_paint_resizer_main_resize( n_bmp *bmp_ret, n_bmp *bmp_target )
{

	n_bmp b; n_bmp_carboncopy( bmp_target, &b );


	n_type_gfx sx,sy; n_paint_resizer_size_get( &sx, &sy );

	if ( sx == 0 ) { sx = N_BMP_SX( &b ); }
	if ( sy == 0 ) { sy = N_BMP_SY( &b ); }


	n_posix_char *str_resize = n_win_combo_selection_get( H_CMB_RESIZE );

	if ( n_string_is_same_literal( MSG_RESIZE_PIXELART2, str_resize ) )
	{

		n_bmp_scaler_big_pixelart( &b, 2 );

	} else

	if ( n_string_is_same_literal( MSG_RESIZE_PIXELART3, str_resize ) )
	{

		n_bmp_scaler_big_pixelart( &b, 3 );

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_CEL_ART_2, str_resize ) )
	{

		if ( n_paint_resizer_all_same( &b ) )
		{
			n_bmp_scaler_big( &b, 2 );
		} else {
			n_bmp_scaler_big( &b, 2 );
			n_bmp_scaler_big( &b, 2 );

			n_bmp_flush_antialias( &b, 1.0 );
			n_bmp_flush_antialias( &b, 1.0 );
			n_bmp_flush_antialias( &b, 1.0 );
			n_bmp_flush_antialias( &b, 1.0 );

			n_bmp_scaler_lil( &b, 2 );

			n_bmp_flush_sharpen( &b, 0.5 );
		}

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_TRANSFORM, str_resize ) )
	{

		n_bmp_resampler
		(
			&b,
			(n_type_real) sx / N_BMP_SX( &b ),
			(n_type_real) sy / N_BMP_SY( &b )
		);

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_FIT_X, str_resize ) )
	{

		n_type_real ratio = (n_type_real) sx / N_BMP_SX( &b );

		n_bmp_resampler( &b, ratio, ratio );

	} else
	if ( n_string_is_same_literal( MSG_RESIZE_FIT_Y, str_resize ) )
	{

		n_type_real ratio = (n_type_real) sy / N_BMP_SY( &b );

		n_bmp_resampler( &b, ratio, ratio );

	} else {

		int ret = 0;

		if ( n_string_is_same_literal( MSG_RESIZE_TOPLEFT, str_resize ) )
		{
			ret = N_BMP_RESIZER_NORMAL;
		}
		if ( n_string_is_same_literal( MSG_RESIZE_TILE,    str_resize ) )
		{
			ret = N_BMP_RESIZER_TILE;
		}
		if ( n_string_is_same_literal( MSG_RESIZE_CENTER,  str_resize ) )
		{
			ret = N_BMP_RESIZER_CENTER;
		}

		u32 margin = n_bmp_white;
		if ( n_paint_layer_onoff ) { margin = n_bmp_white_invisible; }

		n_bmp_resizer( &b, sx,sy, margin, ret );

	}


	{ // Rotate

		n_bmp_matrix_rotate( &b, n_paint_resizer_round, n_bmp_white_invisible, n_true );

		if ( n_paint_resizer_round != 360 ) { n_paint_grabber_is_rotated = n_true; }

	}


	if ( bmp_ret != NULL )
	{
		n_bmp_free_fast( bmp_ret );
		n_bmp_alias( &b, bmp_ret );
	}


	return;
}

// internal
void
n_paint_resizer_main_color( n_bmp *bmp_ret )
{

	{ // Color Option

		n_posix_char *str_color = n_win_combo_selection_get( H_CMB_COLOR );

		if ( n_string_is_same_literal( MSG_COLOR_GRAY, str_color ) )
		{
			n_bmp_flush_grayscale( bmp_ret );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_MONO, str_color ) )
		{
			n_bmp_flush_monochrome( bmp_ret );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_REVS, str_color ) )
		{
			n_paint_flush_reverse( bmp_ret );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_MASK, str_color ) )
		{
			n_bmp_flush_reducer( bmp_ret, 10 );
			n_bmp_flush_monochrome( bmp_ret );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_SIZE, str_color ) )
		{
			n_bmp_flush_reducer( bmp_ret, 4 );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_V_PT, str_color ) )
		{
			n_paint_vanishing_point( bmp_ret );
		} else
		if ( n_string_is_same_literal( MSG_COLOR_CNTR, str_color ) )
		{
			n_bmp_contour( bmp_ret );
		}// else

	}


	{ // Gamma

		// [!] : shortcut for performance

		n_type_real g = (n_type_real) n_paint_resizer_gamma / 10.0;
//u32 tick = n_posix_tickcount();
		if ( g == 0.0 ) { n_bmp_flush( bmp_ret, n_bmp_black ); } else
		if ( g == 2.0 ) { n_bmp_flush( bmp_ret, n_bmp_white ); } else
		if ( g != 1.0 ) { n_bmp_flush_gamma( bmp_ret, g );     }
//n_win_hwndprintf_literal( hwnd_main, "%d", n_posix_tickcount() - tick );
	}


	{ // Color Wheel & Vividness

		int h = n_paint_resizer_clrwh - 128;
		int s = n_paint_resizer_vivid - 100;
		int l = 0;

		n_bmp_flush_tweaker_hsl( bmp_ret, h, s, l );

	}


	{ // Sharpness

		int s = n_paint_resizer_sharp - 100;


		if ( s > 0 )
		{
			n_bmp_flush_sharpen  ( bmp_ret, (n_type_real) s * 0.01 );
		} else
		if ( s < 0 )
		{
			s *= -1;
			n_bmp_flush_antialias( bmp_ret, (n_type_real) s * 0.01 );
		}

	}


	{ // Contrast

		n_bmp_flush_contrast( bmp_ret, n_paint_resizer_ctrst );

	}


	return;
}

// internal
void
n_paint_resizer_main_rotate( n_bmp *bmp )
{

	// [!] : for rotation

	n_type_gfx sx = N_BMP_SX( bmp );
	n_type_gfx sy = N_BMP_SY( bmp );

	n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );


	return;
}

typedef struct {

	n_type_int oy, cores;

} n_paint_resizer_go_thread_struct;

// internal
void
n_paint_resizer_go_thread_main( n_paint_resizer_go_thread_struct *p )
{

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{//break;

			if ( n_paint_grabber_wholegrb_onoff )
			{
				n_bmp *bmp_target = &n_paint_layer_data[ i ].bmp_data;

				n_paint_resizer_main_resize( &n_paint_layer_data[ i ].bmp_data, bmp_target );
				n_paint_resizer_main_rotate( &n_paint_layer_data[ i ].bmp_data );

				if ( n_paint_layer_is_locked( i ) )
				{
					//
				} else
				if ( n_paint_layer_data[ i ].visible )
				{
					n_paint_resizer_main_color( &n_paint_layer_data[ i ].bmp_data );
				}
			} else {
				n_bmp *bmp_target = &n_paint_layer_data[ i ].bmp_data;

				n_paint_resizer_main_resize( &n_paint_layer_data[ i ].bmp_data, bmp_target );
				n_paint_resizer_main_rotate( &n_paint_layer_data[ i ].bmp_data );

				if ( n_paint_layer_is_locked( i ) )
				{
					//
				} else
				if (
					( n_paint_layer_data[ i ].visible )
					&&
					( i == n_paint_layer_txtbox.select_cch_y )
				)
				{
					n_paint_resizer_main_color( &n_paint_layer_data[ i ].bmp_data );
				}
			}


			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

		{
			n_type_gfx sx = N_BMP_SX( n_paint_bmp_data );
			n_type_gfx sy = N_BMP_SY( n_paint_bmp_data );

			n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );
		}

	} else {

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{//break;

			if ( n_paint_grabber_wholegrb_onoff )
			{
				n_bmp *bmp_target = &n_paint_layer_data[ i ].bmp_grab;

				n_paint_resizer_main_resize( &n_paint_layer_data[ i ].bmp_grab, bmp_target );
				n_paint_resizer_main_rotate( &n_paint_layer_data[ i ].bmp_grab );

				if ( n_paint_layer_is_locked( i ) )
				{
					//
				} else
				if ( n_paint_layer_data[ i ].visible )
				{
					n_paint_resizer_main_color ( &n_paint_layer_data[ i ].bmp_grab );
				}
			} else {

				if ( n_paint_layer_is_locked( i ) )
				{
					//
				} else
				if (
					( n_paint_layer_data[ i ].visible )
					&&
					( i == n_paint_layer_txtbox.select_cch_y )
				)
				{
					n_bmp *bmp_target = &n_paint_layer_data[ i ].bmp_grab;

					n_paint_resizer_main_resize( &n_paint_layer_data[ i ].bmp_grab, bmp_target );
					n_paint_resizer_main_rotate( &n_paint_layer_data[ i ].bmp_grab );
					n_paint_resizer_main_color ( &n_paint_layer_data[ i ].bmp_grab );
				}
			}


			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

		{
			n_type_gfx sx = N_BMP_SX( n_paint_bmp_grab );
			n_type_gfx sy = N_BMP_SY( n_paint_bmp_grab );

			n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );
		}

	}


	return;
}

// internal
n_thread_return
n_paint_resizer_go_thread( n_thread_argument p )
{

	n_paint_resizer_go_thread_main( (void*) p );

	return 0;
}

// internal
void
n_paint_resizer_go_main( void )
{

	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_paint_resizer() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		u32 cores = n_thread_core_count;

		n_thread                         *h = (void*) n_memory_new( cores * sizeof( n_thread                         ) );
		n_paint_resizer_go_thread_struct *p = (void*) n_memory_new( cores * sizeof( n_paint_resizer_go_thread_struct ) );


		u32 i = 0;
		n_posix_loop
		{

			n_paint_resizer_go_thread_struct tmp = { i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_resizer_go_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_resizer_go_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_paint_resizer_go_thread_struct tmp = { 0,1 };
		n_paint_resizer_go_thread_main( &tmp );

	}

//n_posix_debug_literal( " %d ", (int) n_posix_tickcount() - tick );


	return;
}

// internal
void
n_paint_resizer_go( void )
{

	if ( n_paint_layer_onoff )
	{

		n_paint_resizer_go_main();

		n_paint_grabber_resync_auto();

	} else {

		n_bmp *bmp_target;
		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			bmp_target = n_paint_bmp_data;
		} else {
			bmp_target = n_paint_bmp_grab;
		}

		if ( grabber )
		{

			n_bmp b; n_bmp_zero( &b );

			n_paint_resizer_main_resize( &b, bmp_target );
			n_paint_resizer_main_rotate( &b );
			n_paint_resizer_main_color ( &b );

			n_paint_grabber_select( &b, n_true );

			n_bmp_free_fast( &b );

		} else {

			n_paint_resizer_main_resize( n_paint_bmp_data, bmp_target );
			n_paint_resizer_main_rotate( n_paint_bmp_data );
			n_paint_resizer_main_color ( n_paint_bmp_data );

		}

	}


	n_paint_refresh_all();

	//n_paint_title();


	return;
}

// internal
void
n_paint_resizer_inputfield_set( void )
{

	n_type_gfx sx,sy;


	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		sx = N_BMP_SX( n_paint_bmp_data );
		sy = N_BMP_SY( n_paint_bmp_data );
	} else {
		sx = N_BMP_SX( n_paint_bmp_grab );
		sy = N_BMP_SY( n_paint_bmp_grab );
	}


	n_posix_char str_sx[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_sx, sx );
	n_posix_char str_sy[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_sy, sy );

	n_win_txtbox_line_set( H_INPUT_SX, 0, str_sx );
	n_win_txtbox_line_set( H_INPUT_SY, 0, str_sy );

	n_win_txtbox_select_tail_set( H_INPUT_SX );
	n_win_txtbox_select_tail_set( H_INPUT_SY );


	return;
}
void
n_paint_resizer_on_size( HWND hwnd, int nwin, n_bool redraw )
{

	n_type_gfx ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );


	n_type_gfx scale = (n_type_gfx) trunc( n_win_scale( hwnd ) );


	n_type_gfx csy = ( ctl * 11 );
	n_type_gfx csx = (n_type_gfx)( (n_type_real) csy * sqrt( 2 ) );

	n_win_set( hwnd, NULL, csx + m, csy + m, nwin );


	n_type_gfx btnsx = csx;
	n_type_gfx sx1_2 = ( csx / 2 );
	n_type_gfx cmbsx = csx - sx1_2;
	n_type_gfx inpsx = ( sx1_2 ) - ctl;
	n_type_gfx inpsz = inpsx / 2;
	n_type_gfx impx1 = sx1_2 + ctl;
	n_type_gfx impx2 = impx1 + inpsz;
	n_type_gfx ln_sx = csx - m;

	n_type_gfx x = scale;

	if ( scale != 1 ) { btnsx -= scale; }

	{
		csx--;
		cmbsx--;
		inpsx--;
	}


	n_win_move       (  H_LBL_RESIZE,      x,ctl* 0, sx1_2,ctl, redraw );
	n_win_combo_move (  H_CMB_RESIZE,  sx1_2,ctl* 0, cmbsx,csy, n_true );
	n_win_move       (  H_LBL_SIZE,        x,ctl* 1, sx1_2,ctl, redraw );
	n_win_button_move( &H_BTN_REFRESH, sx1_2,ctl* 1,   ctl,ctl, redraw );
	n_win_txtbox_move(  H_INPUT_SX,    impx1,ctl* 1, inpsz,ctl, redraw );
	n_win_txtbox_move(  H_INPUT_SY,    impx2,ctl* 1, inpsz,ctl, redraw );
	nwscr_move       (  H_SCR_ROUND,       x,ctl* 2,   csx,ctl, redraw );
	n_win_move       (  H_LINE,            x,ctl* 3, ln_sx,ctl, redraw );
	n_win_move       (  H_LBL_COLOR,       x,ctl* 4, sx1_2,ctl, redraw );
	n_win_combo_move (  H_CMB_COLOR,   sx1_2,ctl* 4, cmbsx,csy, n_true );
	nwscr_move       (  H_SCR_GAMMA,       x,ctl* 5,   csx,ctl, redraw );
	nwscr_move       (  H_SCR_CLRWH,       x,ctl* 6,   csx,ctl, redraw );
	nwscr_move       (  H_SCR_VIVID,       x,ctl* 7,   csx,ctl, redraw );
	nwscr_move       (  H_SCR_SHARP,       x,ctl* 8,   csx,ctl, redraw );
	nwscr_move       (  H_SCR_CTRST,       x,ctl* 9,   csx,ctl, redraw );
	n_win_button_move( &H_BUTTON   ,       x,ctl*10, btnsx,ctl, redraw );


	return;
}

void
n_paint_resizer_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );


		n_win_stdfont_init( n_paint_resizer_hgui, GUI_MAX );


		n_win_refresh( H_LBL_RESIZE, n_true );
		n_win_combo_on_settingchange( H_CMB_RESIZE );

		n_win_refresh( H_LBL_SIZE, n_true );

		n_win_txtbox_on_settingchange( H_INPUT_SX );
		n_win_txtbox_on_settingchange( H_INPUT_SY );

		n_win_scroller_on_settingchange( H_SCR_ROUND );

		n_win_refresh( H_LINE     , n_true );
		n_win_refresh( H_LBL_COLOR, n_true );

		n_win_combo_on_settingchange( H_CMB_COLOR );

		n_win_scroller_on_settingchange( H_SCR_GAMMA );
		n_win_scroller_on_settingchange( H_SCR_CLRWH );
		n_win_scroller_on_settingchange( H_SCR_VIVID );
		n_win_scroller_on_settingchange( H_SCR_SHARP );
		n_win_scroller_on_settingchange( H_SCR_CTRST );

		n_win_button_on_settingchange( &H_BUTTON );

		n_win_button_on_settingchange( &H_BTN_REFRESH );

	break;


	} // switch


}

LRESULT CALLBACK
n_paint_resizer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT preview_timer_id = 0;


	static n_posix_char str_resize_prv[ 1024 ] = N_STRING_EMPTY;
	static n_posix_char str_colour_prv[ 1024 ] = N_STRING_EMPTY;


	n_paint_xmouse( hwnd, msg );


	n_paint_resizer_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_combo_zero( H_CMB_RESIZE );
		n_win_combo_zero( H_CMB_COLOR  );

		n_win_scroller_zero( H_SCR_ROUND );
		n_win_scroller_zero( H_SCR_GAMMA );
		n_win_scroller_zero( H_SCR_CLRWH );
		n_win_scroller_zero( H_SCR_VIVID );
		n_win_scroller_zero( H_SCR_SHARP );
		n_win_scroller_zero( H_SCR_CTRST );

		n_win_txtbox_zero( H_INPUT_SX );
		n_win_txtbox_zero( H_INPUT_SY );

		n_win_button_zero( &H_BUTTON );
		n_win_button_zero( &H_BTN_REFRESH );


		n_paint_resizer_scroll_init = n_true;


		n_paint_resizer_backup_onoff = n_posix_true;
		n_paint_resizer_is_cancelled = n_posix_true;
		n_paint_resizer_backup_init();


		n_paint_resizer_vanishing_point_x = -1;
		n_paint_resizer_vanishing_point_y = -1;


		// Window

		n_win_init_literal( hwnd, "Resizer", "", "" );

		n_win_gui_literal( hwnd, LABEL,   MSG_RESIZE, &H_LBL_RESIZE );
		n_win_gui_literal( hwnd, LABEL,     MSG_SIZE, &H_LBL_SIZE   );
		n_win_gui_literal( hwnd, CANVAS,          "", &H_LINE       );
		n_win_gui_literal( hwnd, LABEL,    MSG_COLOR, &H_LBL_COLOR  );
		n_win_gui_literal( hwnd, CANVAS,          "", &H_PREVIEW    );

		n_win_button_init( &H_BUTTON, hwnd,n_project_string_go, PBS_NORMAL );

#ifdef UNICODE
		n_win_button_init( &H_BTN_REFRESH, hwnd, n_posix_literal( "\x21bb" ), PBS_NORMAL );
#else
		n_win_button_init( &H_BTN_REFRESH, hwnd, n_posix_literal( "r"      ), PBS_NORMAL );
#endif

		n_win_combo_init( H_CMB_RESIZE, hwnd );
		n_win_combo_init( H_CMB_COLOR , hwnd );

		{
			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_ONELINE_HCENTER;
			option |= N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL;
			option |= N_WIN_TXTBOX_OPTION_EDITBOX_KEYDOWN;
			option |= N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT;

			if ( n_win_fluent_ui_onoff )
			{
				option |= N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE;
			}

			n_win_txtbox_init( H_INPUT_SX, hwnd, style, option );
			n_win_txtbox_init( H_INPUT_SY, hwnd, style, option );

			n_win_property_init_literal( H_INPUT_SX->hwnd, "Number", n_true );
			n_win_property_init_literal( H_INPUT_SY->hwnd, "Number", n_true );
		}

		n_win_scroller_init_literal( H_SCR_ROUND, hwnd, MSG_ROUND );
		n_win_scroller_init_literal( H_SCR_GAMMA, hwnd, MSG_GAMMA );
		n_win_scroller_init_literal( H_SCR_CLRWH, hwnd, MSG_CLRWH );
		n_win_scroller_init_literal( H_SCR_VIVID, hwnd, MSG_VIVID );
		n_win_scroller_init_literal( H_SCR_SHARP, hwnd, MSG_SHARP );
		n_win_scroller_init_literal( H_SCR_CTRST, hwnd, MSG_CTRST );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		n_win_stdfont_init( n_paint_resizer_hgui, GUI_MAX );


		// Size

		n_paint_resizer_on_size( hwnd, N_WIN_SET_CENTERING, n_false );


		// Init

		n_paint_resizer_inputfield_set();


		n_txt_set_literal( &H_CMB_RESIZE->txt, 0, MSG_RESIZE_TOPLEFT   );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 1, MSG_RESIZE_TILE      );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 2, MSG_RESIZE_CENTER    );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 3, MSG_RESIZE_TRANSFORM );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 4, MSG_RESIZE_FIT_X     );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 5, MSG_RESIZE_FIT_Y     );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 6, MSG_RESIZE_PIXELART2 );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 7, MSG_RESIZE_PIXELART3 );
		n_txt_set_literal( &H_CMB_RESIZE->txt, 8, MSG_RESIZE_CEL_ART_2 );

		n_win_combo_selection_set_by_string_literal( H_CMB_RESIZE, MSG_RESIZE_CENTER );
		n_posix_sprintf_literal( str_resize_prv, "%s", n_win_combo_selection_get( H_CMB_RESIZE ) );


		n_txt_set_literal( &H_CMB_COLOR->txt, 0, MSG_COLOR_NONE );
		n_txt_set_literal( &H_CMB_COLOR->txt, 1, MSG_COLOR_GRAY );
		n_txt_set_literal( &H_CMB_COLOR->txt, 2, MSG_COLOR_MONO );
		n_txt_set_literal( &H_CMB_COLOR->txt, 3, MSG_COLOR_REVS );
		n_txt_set_literal( &H_CMB_COLOR->txt, 4, MSG_COLOR_MASK );
		n_txt_set_literal( &H_CMB_COLOR->txt, 5, MSG_COLOR_SIZE );
		n_txt_set_literal( &H_CMB_COLOR->txt, 6, MSG_COLOR_V_PT );
		n_txt_set_literal( &H_CMB_COLOR->txt, 7, MSG_COLOR_CNTR );

		n_win_combo_selection_set_by_string_literal( H_CMB_COLOR, MSG_COLOR_NONE );
		n_posix_sprintf_literal( str_colour_prv, "%s", n_win_combo_selection_get( H_CMB_COLOR ) );


		n_paint_resizer_round = 360;
		n_paint_resizer_gamma =  10;
		n_paint_resizer_clrwh = 128;
		n_paint_resizer_vivid = 100;
		n_paint_resizer_sharp = 100;
		n_paint_resizer_ctrst =   0;

		n_win_scroller_scroll_parameter( H_SCR_ROUND, 1, 10, 720, n_paint_resizer_round, n_true );
		n_win_scroller_scroll_parameter( H_SCR_GAMMA, 1, 10,  20, n_paint_resizer_gamma, n_true );
		n_win_scroller_scroll_parameter( H_SCR_CLRWH, 1, 10, 256, n_paint_resizer_clrwh, n_true );
		n_win_scroller_scroll_parameter( H_SCR_VIVID, 1, 10, 200, n_paint_resizer_vivid, n_true );
		n_win_scroller_scroll_parameter( H_SCR_SHARP, 1, 10, 200, n_paint_resizer_sharp, n_true );
		n_win_scroller_scroll_parameter( H_SCR_CTRST, 1, 10, 256, n_paint_resizer_ctrst, n_true );


		// Display

		n_paint_resizer_scroll_init = n_false;

		ShowWindowAsync( hwnd, SW_NORMAL );

		ShowWindowAsync( hwnd_tool, SW_HIDE );
		ShowWindowAsync( hwnd_layr, SW_HIDE );

		n_paint_refresh_client();

	break;


	case WM_SIZE :
//n_win_debug_count( hwnd );

		// [Needed] : non-DWM : scrollers disappear when combo is closed

		//n_paint_resizer_on_size( hwnd, N_WIN_SET_DEFAULT, n_true );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else
		if ( wparam == N_PAINT_KEY_D )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else
		if ( wparam == VK_TAB )
		{
//n_posix_debug_literal( " VK_TAB " );

			if ( H_INPUT_SX->hwnd == GetFocus() )
			{
				SetFocus( H_INPUT_SY->hwnd );

				n_win_txtbox_unselect( H_INPUT_SX );
				n_win_txtbox_select_tail_set( H_INPUT_SX );

				n_win_txtbox_menu_selectall( H_INPUT_SY );
			} else
			if ( H_INPUT_SY->hwnd == GetFocus() )
			{
				SetFocus( H_INPUT_SX->hwnd );

				n_win_txtbox_unselect( H_INPUT_SY );
				n_win_txtbox_select_tail_set( H_INPUT_SY );

				n_win_txtbox_menu_selectall( H_INPUT_SX );
			}
		} else
		if ( wparam == VK_RETURN )
		{
			if ( H_INPUT_SX->hwnd == GetFocus() )
			{
				n_paint_resizer_backup_go();
			} else
			if ( H_INPUT_SY->hwnd == GetFocus() )
			{
				n_paint_resizer_backup_go();
			}
		}

	break;


	case WM_COMMAND :
	{
//break;
		HWND h = (HWND) lparam;


		n_bool preview_refresh = n_false;


		if ( h == H_BTN_REFRESH.hwnd )
		{

			n_win_inputpopup_close();

			preview_refresh = n_posix_true;

		} else

		if ( h == H_INPUT_SX->hwnd )
		{
//n_win_hwndprintf_literal( hwnd, " %d ", wparam );

			if ( wparam == WM_SETFOCUS )
			{
//n_win_debug_count( hwnd );
				//n_win_inputpopup_open_txtbox( hwnd, H_INPUT_SX );
			}

		} else

		if ( h == H_INPUT_SY->hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				//n_win_inputpopup_open_txtbox( hwnd, H_INPUT_SY );
			}

		} else

		if ( h == n_win_combo_hwnd( H_CMB_RESIZE ) )
		{
//n_win_hwndprintf_literal( hwnd, " %d ", wparam );
//break;
			if ( ( wparam >= WM_MOUSEFIRST )&&( wparam <= WM_MOUSELAST ) ) { break; }


			EnableWindow( H_LBL_SIZE      , n_true );
			EnableWindow( H_INPUT_SX->hwnd, n_true );
			EnableWindow( H_INPUT_SY->hwnd, n_true );

			EnableWindow( H_LBL_COLOR, n_true );
			EnableWindow( n_win_combo_hwnd( H_CMB_COLOR ), n_true );
			nwscr_enable( H_SCR_ROUND, n_true );
			nwscr_enable( H_SCR_GAMMA, n_true );
			nwscr_enable( H_SCR_CLRWH, n_true );
			nwscr_enable( H_SCR_VIVID, n_true );
			nwscr_enable( H_SCR_SHARP, n_true );
			nwscr_enable( H_SCR_CTRST, n_true );


			n_posix_char *str = n_win_combo_selection_get( H_CMB_RESIZE );

			n_win_txtbox_grayed( H_INPUT_SX, n_false );
			n_win_txtbox_grayed( H_INPUT_SY, n_false );

			if ( n_string_is_same_literal( MSG_RESIZE_FIT_X,     str ) )
			{
				EnableWindow( H_INPUT_SY->hwnd, n_false );
				n_win_txtbox_grayed( H_INPUT_SY, n_true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_FIT_Y,     str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, n_false );
				n_win_txtbox_grayed( H_INPUT_SX, n_true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_PIXELART2, str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, n_false );
				EnableWindow( H_INPUT_SY->hwnd, n_false );

				n_win_txtbox_grayed( H_INPUT_SX, n_true );
				n_win_txtbox_grayed( H_INPUT_SY, n_true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_PIXELART3, str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, n_false );
				EnableWindow( H_INPUT_SY->hwnd, n_false );

				n_win_txtbox_grayed( H_INPUT_SX, n_true );
				n_win_txtbox_grayed( H_INPUT_SY, n_true );
			} else
			if ( n_string_is_same_literal( MSG_RESIZE_CEL_ART_2, str ) )
			{
				EnableWindow( H_INPUT_SX->hwnd, n_false );
				EnableWindow( H_INPUT_SY->hwnd, n_false );

				n_win_txtbox_grayed( H_INPUT_SX, n_true );
				n_win_txtbox_grayed( H_INPUT_SY, n_true );
			}// else


			if ( n_string_is_same( str, str_resize_prv ) )
			{
				//
			} else {
				n_string_copy( str, str_resize_prv );

				preview_refresh = n_true;
			}

		} else
		if ( h == n_win_combo_hwnd( H_CMB_COLOR ) )
		{

			if ( ( wparam >= WM_MOUSEFIRST )&&( wparam <= WM_MOUSELAST ) ) { break; }


			n_posix_char *str = n_win_combo_selection_get( H_CMB_COLOR );

			if ( n_string_is_same( str, str_colour_prv ) )
			{
				//
			} else {
				n_string_copy( str, str_colour_prv );

				preview_refresh = n_true;
			}

		} else

		if ( h == H_BUTTON.hwnd )
		{

			if ( n_paint_resizer_vanishing_point_usage( hwnd ) ) { break; }

			n_paint_resizer_is_cancelled = n_posix_false;
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_ROUND ) )
		{

			if (
				( n_paint_resizer_scroll_init == n_false )
				&&
				( n_paint_resizer_round == wparam )
			)
			{
				break;
			}
//n_posix_debug_literal( "%d %d", n_paint_resizer_round, wparam );

			if ( n_paint_resizer_scroll_init == n_false ) { preview_refresh = n_true; }


			n_paint_resizer_round = (int) wparam;


#ifdef UNICODE
			const n_posix_char *str_degree = L"\x00b0";
#else // #define UNICODE
			const n_posix_char *str_degree = "";
#endif // #define UNICODE

			n_win_hwndprintf_literal( H_SCR_ROUND->value, "%d%s", n_paint_resizer_round - 360, str_degree );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_GAMMA ) )
		{

			if (
				( n_paint_resizer_scroll_init == n_false )
				&&
				( n_paint_resizer_gamma == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == n_false ) { preview_refresh = n_true; }


			n_paint_resizer_gamma = (int) wparam;

			n_win_hwndprintf_literal( H_SCR_GAMMA->value, "%1.1f", (n_type_real) n_paint_resizer_gamma / 10.0 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_CLRWH ) )
		{

			if (
				( n_paint_resizer_scroll_init == n_false )
				&&
				( n_paint_resizer_clrwh == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == n_false ) { preview_refresh = n_true; }


			n_paint_resizer_clrwh = (int) wparam;

			n_win_hwndprintf_literal( H_SCR_CLRWH->value, "%d", n_paint_resizer_clrwh - 128 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_VIVID ) )
		{

			if (
				( n_paint_resizer_scroll_init == n_false )
				&&
				( n_paint_resizer_vivid == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == n_false ) { preview_refresh = n_true; }


			n_paint_resizer_vivid = (int) wparam;

			n_win_hwndprintf_literal( H_SCR_VIVID->value, "%d", n_paint_resizer_vivid - 100 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_SHARP ) )
		{

			if (
				( n_paint_resizer_scroll_init == n_false )
				&&
				( n_paint_resizer_sharp == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == n_false ) { preview_refresh = n_true; }


			n_paint_resizer_sharp = (int) wparam;

			n_win_hwndprintf_literal( H_SCR_SHARP->value, "%d", n_paint_resizer_sharp - 100 );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_CTRST ) )
		{

			if (
				( n_paint_resizer_scroll_init == n_false )
				&&
				( n_paint_resizer_ctrst == wparam )
			)
			{
				break;
			}

			if ( n_paint_resizer_scroll_init == n_false ) { preview_refresh = n_true; }


			n_paint_resizer_ctrst = (int) wparam;

			n_win_hwndprintf_literal( H_SCR_CTRST->value, "%d", n_paint_resizer_ctrst );

		}// else


		if ( preview_refresh )
		{
//static int i = 0; n_win_hwndprintf_literal( hwnd, " %d ", i ); i++;

			n_type_gfx sx,sy; n_paint_resizer_size_get( &sx, &sy );
			if ( n_bmp_is_overflow( sx, sy ) )
			{
				n_paint_resizer_inputfield_set();
				break;
			}


			if ( preview_timer_id == 0 ) { preview_timer_id = n_win_timer_id_get(); }

			n_win_timer_init( hwnd, preview_timer_id, N_PAINT_TIMEOUT );

		}

	}
	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != preview_timer_id ) { break; }


		n_win_timer_exit( hwnd, preview_timer_id );


		// [x] : why crash?
		//n_win_cursor_add( hwnd, IDC_APPSTARTING );

		SetCursor( LoadCursor( NULL, IDC_APPSTARTING ) );


		n_paint_resizer_backup_go();


		n_win_cursor_add( NULL, IDC_ARROW );

	break;


	case WM_CLOSE :

		n_paint_xmouse_onoff = n_false;

		if ( 1 )
		{
			ShowWindowAsync( hwnd_tool, SW_SHOWNA );
		}

		if ( n_paint_layer_onoff )
		{
			ShowWindowAsync( hwnd_layr, SW_SHOWNA );
		}

		n_paint_xmouse_onoff = n_true;

		n_paint_resizer_backup_onoff = n_posix_false;
		n_paint_resizer_backup_exit();


		n_win_inputpopup_silent_onoff = n_true;
		n_win_inputpopup_close();

		n_win_combo_silent = n_true;
		n_win_combo_exit( H_CMB_RESIZE );

		n_win_combo_silent = n_true;
		n_win_combo_exit( H_CMB_COLOR  );

		ShowWindow( hwnd, SW_HIDE );


		n_win_property_exit_literal( H_INPUT_SX->hwnd, "Number" );
		n_win_property_exit_literal( H_INPUT_SY->hwnd, "Number" );


		n_win_stdfont_exit( n_paint_resizer_hgui, GUI_MAX );

		n_win_scroller_exit( H_SCR_ROUND );
		n_win_scroller_exit( H_SCR_GAMMA );
		n_win_scroller_exit( H_SCR_CLRWH );
		n_win_scroller_exit( H_SCR_VIVID );
		n_win_scroller_exit( H_SCR_SHARP );
		n_win_scroller_exit( H_SCR_CTRST );

		n_win_button_exit( &H_BUTTON );
		n_win_button_exit( &H_BTN_REFRESH );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	case WM_MOUSEWHEEL :

		if ( n_win_inputpopup_hpopup != NULL ) { return 0; }

	break;


	case WM_NCLBUTTONDOWN :

		SetFocus( hwnd );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	n_win_separator_proc( hwnd, msg, wparam, lparam, H_LINE, PS_DOT );


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BUTTON );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_REFRESH );

/*
	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, H_INPUT_SX );
	n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, H_INPUT_SY );

	n_win_inputpopup_patch( hwnd, msg, &wparam, &lparam );
*/

	n_win_combo_proc( hwnd, msg, &wparam, &lparam, H_CMB_RESIZE );
	n_win_combo_proc( hwnd, msg, &wparam, &lparam, H_CMB_COLOR  );


	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_ROUND );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_GAMMA );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_CLRWH );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_VIVID );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_SHARP );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_CTRST );


	{
		int ret = 0;
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, H_INPUT_SX );
		ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, H_INPUT_SY );
		if ( ret ) { return ret; }
	}


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_LBL_RESIZE
#undef H_LBL_SIZE
#undef H_LINE
#undef H_LBL_COLOR
#undef H_PREVIEW
#undef GUI_MAX

#undef H_BUTTON
#undef H_BTN_REFRESH
#undef BTN_MAX

#undef H_INPUT_SX
#undef H_INPUT_SY
#undef TXT_MAX

#undef H_CMB_RESIZE
#undef H_CMB_COLOR
#undef CMB_MAX

#undef H_SCR_ROUND
#undef H_SCR_GAMMA
#undef H_SCR_CLRWH
#undef H_SCR_VIVID
#undef H_SCR_SHARP
#undef H_SCR_CTRST
#undef SCR_MAX


#undef MSG_SIZE
#undef MSG_RESIZE
#undef MSG_RESIZE_TOPLEFT
#undef MSG_RESIZE_TILE
#undef MSG_RESIZE_CENTER
#undef MSG_RESIZE_TRANSFORM
#undef MSG_RESIZE_FIT_X
#undef MSG_RESIZE_FIT_Y
#undef MSG_RESIZE_PIXELART2
#undef MSG_RESIZE_PIXELART3
#undef MSG_RESIZE_CEL_ART_2
#undef MSG_ROUND
#undef MSG_COLOR
#undef MSG_COLOR_NONE
#undef MSG_COLOR_GRAY
#undef MSG_COLOR_MONO
#undef MSG_COLOR_REVS
#undef MSG_COLOR_MASK
#undef MSG_COLOR_SIZE
#undef MSG_COLOR_V_PT
#undef MSG_COLOR_CNTR
#undef MSG_GAMMA
#undef MSG_CLRWH
#undef MSG_VIVID
#undef MSG_BLACK
#undef MSG_SHARP
#undef MSG_CTRST

