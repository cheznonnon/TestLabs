// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_CHECKBOX
#define _H_NONNON_WIN32_WIN_CHECKBOX




#include "../neutral/bmp/fade.c"


#include "./gdi/doublebuffer.c"

#include "./win.c"

#include "./gdi.c"

#include "./uxtheme.c"




typedef struct {

	HWND         hwnd;

	n_uxtheme    uxtheme;

	n_bmp_fade   fade;
	n_posix_bool fade_onoff;
	UINT         fade_timer_id;

	int          state;

	n_posix_bool press_onoff;
	n_posix_bool check_onoff;
	n_posix_bool p_chk_onoff;

	n_posix_bool is_classic;

} n_win_check;




#define n_win_check_zero( p ) n_memory_zero( p, sizeof( n_win_check ) )

n_posix_bool
n_win_check_is_enabled( n_win_check *p )
{

	n_posix_bool ret = n_posix_true;


	if (
		( p->state == CBS_UNCHECKEDDISABLED )
		||
		( p->state == CBS_CHECKEDDISABLED   )
		||
		( p->state == CBS_MIXEDDISABLED     )
		||
		( p->state == CBS_IMPLICITDISABLED  )
		||
		( p->state == CBS_EXCLUDEDDISABLED  )
	)
	{
		ret = n_posix_false;
	}


	return ret;
}

n_posix_bool
n_win_check_is_checked( n_win_check *p )
{

	n_posix_bool ret = n_posix_false;


	if (
		( p->state == CBS_CHECKEDNORMAL   )
		||
		( p->state == CBS_CHECKEDHOT      )
		||
		( p->state == CBS_CHECKEDPRESSED  )
		||
		( p->state == CBS_CHECKEDDISABLED )

	)
	{
		ret = n_posix_true;
	}


	return ret;
}

void
n_win_check_check( n_win_check *p )
{

	if ( p->state == 0 )
	{
		p->state = CBS_CHECKEDNORMAL;
	} else
	if ( p->state == CBS_UNCHECKEDNORMAL   )
	{
		p->state = CBS_CHECKEDNORMAL;
	} else
	if ( p->state == CBS_UNCHECKEDHOT      )
	{
		p->state = CBS_CHECKEDHOT;
	} else
	if ( p->state == CBS_UNCHECKEDPRESSED  )
	{
		p->state = CBS_CHECKEDPRESSED;
	} else
	if ( p->state == CBS_UNCHECKEDDISABLED )
	{
		p->state = CBS_CHECKEDDISABLED;
	}

	p->check_onoff = n_posix_true;

	n_bmp_fade_go( &p->fade, n_bmp_white );
	n_win_timer_init( p->hwnd, p->fade_timer_id, 1 );


	return;
}

void
n_win_check_uncheck( n_win_check *p )
{

	if ( p->state == 0 )
	{
		p->state = CBS_UNCHECKEDNORMAL;
	} else
	if ( p->state == CBS_CHECKEDNORMAL   )
	{
		p->state = CBS_UNCHECKEDNORMAL;
	} else
	if ( p->state == CBS_CHECKEDHOT      )
	{
		p->state = CBS_UNCHECKEDHOT;
	} else
	if ( p->state == CBS_CHECKEDPRESSED  )
	{
		p->state = CBS_UNCHECKEDPRESSED;
	} else
	if ( p->state == CBS_CHECKEDDISABLED )
	{
		p->state = CBS_UNCHECKEDDISABLED;
	}

	p->check_onoff = n_posix_false;

	n_bmp_fade_go( &p->fade, n_bmp_black );
	n_win_timer_init( p->hwnd, p->fade_timer_id, 1 );


	return;
}

// internal
void
n_win_check_draw( n_win_check *p, HDC hdc_override, RECT *rect )
{

	s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	HDC hdc;
hdc_override = NULL;
	if ( hdc_override == NULL )
	{
		hdc = n_gdi_doublebuffer_simple_init( p->hwnd, sx,sy );
	} else {
		hdc = hdc_override;
	}


	s32 dpi = n_win_dpi( p->hwnd );

	s32 ctl = n_win_stdsize_check( p->hwnd );
	s32   m = ctl / 3;


	// Background

	COLORREF bg = n_win_darkmode_systemcolor( COLOR_BTNFACE );

	n_win_box( p->hwnd, hdc, rect, bg );


	// Main

	// [x] : UxTheme : not beautiful in High-DPI

	if (
		( n_win_fluent_ui_onoff != N_WIN_FLUENT_UI_OVERRIDE )
		&&
		( p->is_classic == n_posix_false )
		&&
		( p->uxtheme.onoff )
		&&
		( n_posix_false == n_sysinfo_version_8_or_later() )
	)
	{

		RECT r = n_win_rect_set( NULL, m, abs( sy - ctl ) / 2, ctl, ctl );

		int part = BP_CHECKBOX;


		int state_f = n_win_property_get_literal( p->hwnd, "State" );

		p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, part, state_f, &r, NULL );

		n_bmp bmp_f; n_bmp_carboncopy( &n_gdi_doublebuffer_instance.bmp, &bmp_f );


		int state_t = p->state;

		p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, part, state_t, &r, NULL );

		n_bmp bmp_t; n_bmp_carboncopy( &n_gdi_doublebuffer_instance.bmp, &bmp_t );


		n_bmp_alpha_visible( &bmp_f );
		n_bmp_alpha_visible( &bmp_t );


		double ratio = (double) p->fade.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );


		n_bmp_flush_fastcopy( &bmp_t, &n_gdi_doublebuffer_instance.bmp );


		n_bmp_free_fast( &bmp_f );
		n_bmp_free_fast( &bmp_t );

	} else
	if (
		( p->is_classic == n_posix_false )
		||
		( n_win_fluent_ui_onoff )
	)
	{
//n_posix_debug_literal( "%d %d", sy, ctl );


		// [!] : shared

		int state_f = n_win_property_get_literal( p->hwnd, "State" );
		int state_t = p->state;

		n_gdi gdi; n_gdi_zero( &gdi );

		gdi.sx                  = ctl;
		gdi.sy                  = ctl;
		gdi.style               = N_GDI_NOMARGIN;

		gdi.frame_style         = N_GDI_FRAME_SIMPLE;
		gdi.frame_round         = 0;

		gdi.text_font           = n_posix_literal( "Marlett" );
		gdi.text_size           = ctl;
		gdi.text_style          = N_GDI_TEXT_SMOOTH;


		if ( n_win_fluent_ui_onoff )
		{
			gdi.frame_style = N_GDI_FRAME_FLUENT_UI;
		}


		n_posix_char *str           = NULL;
		n_posix_char *str_unchecked = NULL;
		n_posix_char *str_checked   = n_posix_literal( "a" );

		u32 color     = n_bmp_white_invisible;
		u32 color_nor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNTEXT   );
		u32 color_hot = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_HIGHLIGHT );
		u32 color_dis = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_GRAYTEXT  );

		u32 color_bg1 = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_WINDOW    );
		u32 color_bg2 = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_HIGHLIGHT );


		// [!] : from

		if ( state_f == CBS_UNCHECKEDNORMAL   ) { str = str_unchecked; color = color_nor; } else
		if ( state_f == CBS_UNCHECKEDHOT      ) { str = str_unchecked; color = color_hot; } else
		if ( state_f == CBS_UNCHECKEDPRESSED  ) { str = str_unchecked; color = color_hot; } else
		if ( state_f == CBS_UNCHECKEDDISABLED ) { str = str_unchecked; color = color_dis; } else
		if ( state_f == CBS_CHECKEDNORMAL     ) { str = str_checked  ; color = color_nor; } else
		if ( state_f == CBS_CHECKEDHOT        ) { str = str_checked  ; color = color_hot; } else
		if ( state_f == CBS_CHECKEDPRESSED    ) { str = str_checked  ; color = color_hot; } else
		if ( state_f == CBS_CHECKEDDISABLED   ) { str = str_checked  ; color = color_dis; }// else

		gdi.text                = str;
		gdi.text_color_main     = color_nor;

		if ( color == color_hot )
		{
			gdi.base_color_bg = n_bmp_blend_pixel( color_bg1, color_bg2, 0.125 );
		} else {
			gdi.base_color_bg = color_bg1;
		}

		n_bmp bmp_f; n_bmp_zero( &bmp_f ); n_gdi_bmp( &gdi, &bmp_f );

		if ( n_win_fluent_ui_onoff )
		{
			//
		} else {
			n_bmp_fill( &bmp_f, 0,0, color );
		}

//n_bmp_save_literal( &bmp_f, "ret.bmp" );


		// [!] : To

		if ( state_t == CBS_UNCHECKEDNORMAL   ) { str = str_unchecked; color = color_nor; } else
		if ( state_t == CBS_UNCHECKEDHOT      ) { str = str_unchecked; color = color_hot; } else
		if ( state_t == CBS_UNCHECKEDPRESSED  ) { str = str_unchecked; color = color_hot; } else
		if ( state_t == CBS_UNCHECKEDDISABLED ) { str = str_unchecked; color = color_dis; } else
		if ( state_t == CBS_CHECKEDNORMAL     ) { str = str_checked  ; color = color_nor; } else
		if ( state_t == CBS_CHECKEDHOT        ) { str = str_checked  ; color = color_hot; } else
		if ( state_t == CBS_CHECKEDPRESSED    ) { str = str_checked  ; color = color_hot; } else
		if ( state_t == CBS_CHECKEDDISABLED   ) { str = str_checked  ; color = color_dis; }// else

		gdi.text                = str;
		gdi.text_color_main     = color_nor;
	
		if ( color == color_hot )
		{
			gdi.base_color_bg = n_bmp_blend_pixel( color_bg1, color_bg2, 0.125 );
		} else {
			gdi.base_color_bg = color_bg1;
		}

		n_bmp bmp_t; n_bmp_zero( &bmp_t ); n_gdi_bmp( &gdi, &bmp_t );

		if ( n_win_fluent_ui_onoff )
		{
			//
		} else {
			n_bmp_fill( &bmp_t, 0,0, color );
		}

//n_bmp_save_literal( &bmp_t, "ret.bmp" );


		// [!] : draw engine

		double ratio = (double) p->fade.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );

		s32 tx = m;
		s32 ty = ( sy - ctl ) / 2; ty -= ( sy % 2 );

		n_bmp_fastcopy
		(
			&bmp_t, &n_gdi_doublebuffer_instance.bmp,
			0,0,ctl,ctl,
			tx,ty
		);


		// [!] : cleaup

		n_bmp_free_fast( &bmp_f );
		n_bmp_free_fast( &bmp_t );

	} else {

		RECT r = n_win_rect_set( NULL, m, abs( sy - ctl ) / 2, ctl, ctl );

		int dfcs = DFCS_BUTTONCHECK;

		if ( p->state == CBS_UNCHECKEDNORMAL   ) { } else
		if ( p->state == CBS_UNCHECKEDHOT      ) { } else
		if ( p->state == CBS_UNCHECKEDPRESSED  ) { dfcs |= DFCS_PUSHED  ; } else
		if ( p->state == CBS_UNCHECKEDDISABLED ) { dfcs |= DFCS_INACTIVE; } else
		if ( p->state == CBS_CHECKEDNORMAL     ) { dfcs |= DFCS_CHECKED ; } else
		if ( p->state == CBS_CHECKEDHOT        ) { dfcs |= DFCS_CHECKED ; } else
		if ( p->state == CBS_CHECKEDPRESSED    ) { dfcs |= DFCS_CHECKED | DFCS_PUSHED  ; } else
		if ( p->state == CBS_CHECKEDDISABLED   ) { dfcs |= DFCS_CHECKED | DFCS_INACTIVE; }// else

		DrawFrameControl( hdc, &r, DFC_BUTTON, dfcs );

	}


	// Text

	{

		s32 gap = m * 2; x += ctl + gap;

		if ( dpi > 96 ) { y -= dpi / 96; }


		n_posix_char str[ 1024 ]; n_win_text_get( p->hwnd, str, 1024 );


		RECT     r  = { x, y, x+sx, y+sy };
		COLORREF fg = n_win_darkmode_systemcolor_ui( COLOR_BTNTEXT   );
		HFONT    hf = SelectObject( hdc, n_win_font_get( p->hwnd ) );
		int      dt = ( DT_SINGLELINE | DT_VCENTER );


		SetBkMode( hdc, TRANSPARENT );

		if ( p->is_classic )
		{

			if ( n_posix_false == n_win_check_is_enabled( p ) )
			{

				COLORREF color_shadow;
				COLORREF color_text;

				if ( n_win_darkmode_onoff )
				{
					color_shadow = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );
					color_text   = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW     );
				} else {
					color_shadow = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );
					color_text   = n_win_darkmode_systemcolor_ui( COLOR_GRAYTEXT      );
				}

				RECT r_shadow  = { x+1, y+2, x+sx, y+sy };
				SetTextColor( hdc, color_shadow );
				DrawText( hdc, str,-1, &r_shadow, dt );

				SetTextColor( hdc, color_text );
				DrawText( hdc, str,-1, &r, dt );

			} else {

				SetTextColor( hdc, fg );
				DrawText( hdc, str,-1, &r, dt );

			}

		} else {

			SetTextColor( hdc, fg );
			DrawText( hdc, str,-1, &r, dt );

		}

/*
		UINT dst = DST_TEXT;
		if ( n_posix_false == n_win_check_is_enabled( p ) ) { dst |= DSS_DISABLED; }

		HBRUSH hbrush = n_win_darkmode_brush_bg( COLOR_BTNFACE );
		DrawState( hdc, hbrush, NULL, (LPARAM) str, 0, x+m,y,sx,sy, dst );
		DeleteObject( hbrush );
*/

		SelectObject( hdc, hf );

	}


	if ( ( p->is_classic == n_posix_false )&&( n_posix_false == n_win_check_is_enabled( p ) ) )
	{
		n_gdi_doublebuffer_mix( &n_gdi_doublebuffer_instance, bg, 0.5 );
	}


	if ( hdc_override == NULL ) { n_gdi_doublebuffer_simple_exit(); }


	return;
}

// internal
LRESULT CALLBACK
#ifdef _WIN64
n_win_check_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_check_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	n_win_check *p = (void*) dwRefData;
#else  // #ifdef _WIN64
	n_win_check *p = (void*) n_win_property_get_literal( hwnd, "n_win_check" );
#endif // #ifdef _WIN64

	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_TIMER :

		if ( wparam != p->fade_timer_id ) { break; }

		n_bmp_fade_engine( &p->fade, p->fade_onoff );
		n_win_refresh( p->hwnd, n_posix_false );

		if ( p->fade.percent == 100 )
		{
			n_win_timer_exit( hwnd, p->fade_timer_id );
			n_win_property_set_literal( p->hwnd, "State", p->state );
		}

//n_win_hwndprintf_literal( GetParent( p->hwnd ), "%d", (int) p->fade.percent );
	break;


	case WM_MOUSEMOVE :

		// [!] : this code depends SetCapture()/ReleaseCapture()

		n_win_on_mousemove( hwnd );

	break;

	case WM_MOUSEHOVER :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), "Check : WM_MOUSEHOVER" );

		if ( n_posix_false == n_win_check_is_enabled( p ) ) { break; }

//n_win_hwndprintf_literal( GetParent( p->hwnd ), " %d %d ", p->press_onoff, n_win_is_input( VK_LBUTTON ) );
		if ( n_win_is_input( VK_LBUTTON ) ) { break; }

		if ( p->state == CBS_CHECKEDNORMAL   )
		{
			p->state = CBS_CHECKEDHOT;

			n_bmp_fade_go( &p->fade, n_bmp_white );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		} else
		if ( p->state == CBS_UNCHECKEDNORMAL )
		{
			p->state = CBS_UNCHECKEDHOT;

			n_bmp_fade_go( &p->fade, n_bmp_white );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		}

	break;

	case WM_MOUSELEAVE :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), "Check : WM_MOUSELEAVE" );

		if ( n_posix_false == n_win_check_is_enabled( p ) ) { break; }

		if ( p->press_onoff )
		{
			p->check_onoff = p->p_chk_onoff;

			if ( p->check_onoff )
			{
				p->state = CBS_CHECKEDNORMAL;
			} else {
				p->state = CBS_UNCHECKEDNORMAL;
			}

			n_bmp_fade_go( &p->fade, n_bmp_black );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		} else
		if ( p->state == CBS_CHECKEDHOT   )
		{
			p->state = CBS_CHECKEDNORMAL;

			n_bmp_fade_go( &p->fade, n_bmp_black );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		} else
		if ( p->state == CBS_UNCHECKEDHOT )
		{
			p->state = CBS_UNCHECKEDNORMAL;

			n_bmp_fade_go( &p->fade, n_bmp_black );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		} else
		if ( p->state == CBS_CHECKEDPRESSED )
		{

			p->state = CBS_CHECKEDNORMAL;
			n_bmp_fade_go( &p->fade, n_bmp_black );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		}

	break;


	case WM_ERASEBKGND :

		return n_posix_true;

	break;


	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN   :

		p->press_onoff = n_posix_true;

		SetCapture( hwnd );

	case WM_LBUTTONDBLCLK :

		if ( n_posix_false == n_win_check_is_enabled( p ) ) { break; }

		p->p_chk_onoff = p->check_onoff;

		if ( p->check_onoff == n_posix_false )
		{
			p->state       = CBS_UNCHECKEDPRESSED;
			p->check_onoff = n_posix_true;

			n_bmp_fade_go( &p->fade, n_bmp_rgb( 0,200,255 ) );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		} else {
			p->state       = CBS_CHECKEDPRESSED;
			p->check_onoff = n_posix_false;

			n_bmp_fade_go( &p->fade, n_bmp_rgb( 0,200,255 ) );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		}

	break;

	case WM_LBUTTONUP :

		p->press_onoff = n_posix_false;

		ReleaseCapture();

		if ( p->check_onoff )
		{
			p->state       = CBS_CHECKEDHOT;
			p->check_onoff = n_posix_true;

			n_bmp_fade_go( &p->fade, n_bmp_rgb( 255,0,200 ) );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		} else {
			p->state       = CBS_UNCHECKEDHOT;
			p->check_onoff = n_posix_false;

			n_bmp_fade_go( &p->fade, n_bmp_rgb( 255,0,200 ) );
			n_win_timer_init( hwnd, p->fade_timer_id, 1 );
		}

		n_win_message_send( GetParent( hwnd ), WM_COMMAND, 0, hwnd );

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( (WNDPROC) n_win_property_get_literal( hwnd, "Subclass" ), hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_check_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_check *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		n_win_check_draw( p, di->hDC, &di->rcItem );

	}
	break;


	} // switch


	return;
}

void
n_win_check_onoff( n_win_check *p, n_posix_bool onoff )
{

	int p_state = p->state;

	if ( onoff )
	{

		EnableWindow( p->hwnd, onoff );

		if ( p->state == CBS_CHECKEDDISABLED   )
		{
			p->state = CBS_CHECKEDNORMAL;
		} else
		if ( p->state == CBS_UNCHECKEDDISABLED )
		{
			p->state = CBS_UNCHECKEDNORMAL;
		}// else

	} else {

		if ( ( p->state == CBS_UNCHECKEDNORMAL )||( p->state == CBS_UNCHECKEDHOT ) )
		{
			p->state = CBS_UNCHECKEDDISABLED;
		} else
		if ( ( p->state == CBS_CHECKEDNORMAL   )||( p->state == CBS_CHECKEDHOT   ) )
		{
			p->state = CBS_CHECKEDDISABLED;
		}// else

		EnableWindow( p->hwnd, onoff );

	}

	if ( p_state != p->state )
	{
		n_bmp_fade_go( &p->fade, n_bmp_rgb( 0,200,0 ) );
		n_win_timer_init( p->hwnd, p->fade_timer_id, 1 );
	}


	return;
}

void
n_win_check_on_settingchange( n_win_check *p )
{

	p->is_classic = n_win_style_is_classic();


	n_win_stdfont_exit( &p->hwnd, 1 );
	n_win_stdfont_init( &p->hwnd, 1 );


	n_uxtheme_exit( &p->uxtheme, p->hwnd );
	n_uxtheme_init( &p->uxtheme, p->hwnd, L"BUTTON" );


	p->fade_onoff = n_win_fade_is_on();
	n_bmp_fade_init( &p->fade, n_bmp_black );


	return;
}

#define n_win_check_init_literal( p, h, t, s ) n_win_check_init( p, h, n_posix_literal( t ), s )

void
n_win_check_init( n_win_check *p, HWND hwnd_parent, n_posix_char *text, int state )
{

	n_win_gui( hwnd_parent, N_WIN_GUI_CANVAS_BUTTON, text, &p->hwnd );
//n_win_style_add( p->hwnd, WS_BORDER );


	// [Mechanism]
	//
	//	CBS_MIXEDNORMAL    : rectangle check
	//	CBS_IMPLICITNORMAL : already checked
	//	CBS_EXCLUDEDNORMAL : "x" like check

	p->state = state;
	n_win_property_set_literal( p->hwnd, "State", p->state );


	p->fade_timer_id = n_win_timer_id_get();


#ifdef _WIN64

	SetWindowSubclass( p->hwnd, n_win_check_subclass, 0, (DWORD_PTR) p );

#else  // #ifdef _WIN64

	WNDPROC pfunc = n_win_gui_subclass_set( p->hwnd, n_win_check_subclass );

	n_win_property_init_literal( p->hwnd, "n_win_check", (int) p     );
	n_win_property_init_literal( p->hwnd, "Subclass"   , (int) pfunc );

#endif // #ifdef _WIN64


	n_win_property_init_literal( p->hwnd, "n_win_move_patch_button().check", n_posix_true );


	n_win_check_on_settingchange( p );


	return;
}

void
n_win_check_exit( n_win_check *p )
{

	n_win_property_exit_literal( p->hwnd, "State" );


#ifdef _WIN64

	RemoveWindowSubclass( p->hwnd, n_win_check_subclass, 0 );

#else  // #ifdef _WIN64

	n_win_property_exit_literal( p->hwnd, "n_win_check" );
	n_win_property_exit_literal( p->hwnd, "Subclass"    );

#endif // #ifdef _WIN64


	n_win_property_exit_literal( p->hwnd, "n_win_move_patch_button().check" );


	n_uxtheme_exit( &p->uxtheme, p->hwnd );


	n_win_stdfont_exit( &p->hwnd, 1 );


	DestroyWindow( p->hwnd );


	return;
}


#endif // _H_NONNON_WIN32_WIN_CHECKBOX


