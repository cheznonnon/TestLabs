// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Techniques : How to adjust padding ]
//
//	use a space or tab character
//
//
//	[ Techniques : How to make a separator ]
//
//	use N_GDI_TEXT_UNDERLINE or N_GDI_TEXT_STRIKEOUT for n_gdi.text_style


// [!] : gdi.icon, gdi.text : auto-free()
//
//	don't set these members by string literals
//	use n_string_carboncopy() for simple use




#ifndef _H_NONNON_WIN32_WIN_RICHDIALOG
#define _H_NONNON_WIN32_WIN_RICHDIALOG




#include "./gdi.c"
#include "./win.c"
#include "./win_button.c"




#define N_WIN_RICHDIALOG_MAX ( 32 )


typedef void (*n_win_richdialog_on_settingchange)( n_gdi* );


typedef struct {

	n_posix_char *title;
	n_posix_char *label;
	n_gdi        *gdi;
	n_bmp        *bmp;
	int           gdi_used;

	n_type_gfx    sx, sy;
	n_type_gfx    padding;
	n_type_gfx    header_sy;
	n_type_gfx    margin_sy;
	n_type_gfx    button_sy;

	HWND          hwnd;
	n_win_button  hbtn;

	n_posix_bool  is_ok;

	u32           tick;

	n_win_richdialog_on_settingchange on_settingchange;

} n_win_richdialog;


static n_win_richdialog n_win_richdialog_instance;




n_gdi
n_win_richdialog_template( void )
{

	static n_posix_char text_font[ LF_FACESIZE ]; n_string_zero( text_font, LF_FACESIZE );
	                int text_size = 16;

	{

		NONCLIENTMETRICS ncm; ZeroMemory( &ncm, sizeof( NONCLIENTMETRICS ) );
		UINT              cb = sizeof( NONCLIENTMETRICS );

		ncm.cbSize = cb;
		SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );

		n_string_copy( ncm.lfMessageFont.lfFaceName, text_font );
		text_size = ncm.lfMessageFont.lfHeight;

	}


	static n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx              = 0;
	gdi.sy              = 0;
	gdi.scale           = N_GDI_SCALE_AUTO;
	gdi.style           = 0;//N_GDI_AUTOMARGIN;
	gdi.layout          = 0;
	gdi.align           = 0;

	if ( n_win_darkmode_onoff )
	{
		gdi.base_color_bg = n_bmp_colorref2argb( n_win_darkmode_systemcolor_ui( COLOR_INFOBK ) );
	} else {
		gdi.base_color_bg = n_bmp_colorref2argb( n_win_darkmode_systemcolor_ui( COLOR_WINDOW ) );
	}

	gdi.base_color_fg   = n_bmp_trans;
	gdi.base_style      = N_GDI_BASE_DEFAULT;

	gdi.frame_style     = N_GDI_FRAME_NOFRAME;

	gdi.icon            = NULL;//n_posix_literal( "" );
	gdi.icon_index      = 0;
	gdi.icon_style      = N_GDI_ICON_DEFAULT;

	gdi.text            = NULL;//n_posix_literal( "" );
	gdi.text_font       = text_font;
	gdi.text_size       = text_size;
	gdi.text_color_main = n_bmp_colorref2argb( n_win_darkmode_systemcolor_ui( COLOR_WINDOWTEXT ) );
	gdi.text_style      = N_GDI_TEXT_DEFAULT;

	if ( n_sysinfo_version_vista_or_later() )
	{

		n_posix_bool onoff = n_posix_false;

		const UINT n_SPI_GETCLEARTYPE = 4168;
		SystemParametersInfo( n_SPI_GETCLEARTYPE, 0, &onoff, 0 );

		if ( n_win_darkmode_onoff )
		{
			if ( onoff ) { gdi.text_style = N_GDI_TEXT_SMOOTH; }
		} else {
			if ( onoff ) { gdi.text_style = N_GDI_TEXT_CLEAR ; }
		}

	}


	return gdi;
}

n_posix_bool
n_win_richdialog_exit( n_win_richdialog *p )
{

	if ( p == NULL ) { return n_posix_false; }


	n_posix_bool ret = p->is_ok;


	int i = 0;
	n_posix_loop
	{//break;

		if ( i >= p->gdi_used ) { break; }

		n_bmp_free( &p->bmp[ i ] );

		n_string_free( p->gdi[ i ].icon );
		n_string_free( p->gdi[ i ].text );

		i++;

	}

	n_memory_free( p->title );
	n_memory_free( p->gdi   );
	n_memory_free( p->bmp   );


	n_memory_zero( p, sizeof( n_win_richdialog ) );


	return ret;
}

void
n_win_richdialog_init( n_win_richdialog *p, int gdi_used, const n_posix_char *title )
{

	if ( p == NULL ) { return; }


	n_memory_zero( p, sizeof( n_win_richdialog ) );


	// [!] : prevent crash
	gdi_used = n_posix_max( 2, gdi_used );


	p->title    = n_string_carboncopy( title );
	p->gdi_used = n_posix_minmax( 1, N_WIN_RICHDIALOG_MAX, gdi_used );
	p->gdi      = n_memory_new( sizeof( n_gdi ) * p->gdi_used );
	p->bmp      = n_memory_new( sizeof( n_bmp ) * p->gdi_used );
	p->gdi[ 0 ] = n_win_richdialog_template();

	n_bmp_zero( &p->bmp[ 0 ] );

	int i = 1;
	n_posix_loop
	{

		n_gdi_alias( &p->gdi[ 0 ], &p->gdi[ i ] );
		n_bmp_alias( &p->bmp[ 0 ], &p->bmp[ i ] );

		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	return;
}

void
n_win_richdialog_autosize( n_win_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	n_win_stdsize( p->hwnd, &p->button_sy, NULL, NULL );

	p->margin_sy = p->button_sy * 2;
	p->padding   = p->button_sy / 4;


	n_type_gfx csx = ( p->padding * 2 );
	n_type_gfx csy = ( p->padding * 2 );

	n_type_gfx dsx; n_win_desktop_size( &dsx, NULL );
	csx = n_posix_max_n_type_gfx( csx, (n_type_gfx) ( (n_type_real) dsx * 0.1 ) );
	csx = n_posix_max_n_type_gfx( csx, 200 );

	int i = 0;
	n_posix_loop
	{//break;

		n_gdi *g = &p->gdi[ i ];

		g->style = g->style | N_GDI_CALCONLY;
		g->sx    = 0;
		g->sy    = 0;

		n_gdi_bmp( g, NULL );

		g->style = g->style & ~N_GDI_CALCONLY;


		csx = n_posix_max_n_type_gfx( csx, g->sx + ( p->padding * 2 ) );
		csy = csy + ( g->sy + p->padding );


		i++;
		if ( i >= p->gdi_used ) { break; }
	}

	p->header_sy = csy;


	p->sx = csx;
	p->sy = csy + p->margin_sy;


	return;
}

void
n_win_richdialog_bmp( n_win_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	int i = 0;
	n_posix_loop
	{//break;

		n_gdi *g = &p->gdi[ i ];
		n_bmp *b = &p->bmp[ i ];

		g->sx = 0;
		g->sy = 0;

		n_gdi_bmp( g, b );


		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	return;
}

void
n_win_richdialog_draw( n_win_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	// Init

	n_bmp canvas; n_bmp_zero( &canvas ); n_bmp_1st_fast( &canvas, p->sx,p->sy );


	// Background

	u32 color_margin = n_bmp_colorref2argb( n_win_darkmode_systemcolor_ui( COLOR_BTNFACE ) );

	n_bmp_box( &canvas, 0,0,p->sx,p->sy, color_margin );

	n_bmp_box( &canvas, 0,0,p->sx,p->header_sy, p->gdi[ 0 ].base_color_bg );


	// Draw

	n_type_gfx y = p->padding;

	int i = 0;
	n_posix_loop
	{//break;

		n_gdi *g = &p->gdi[ i ];
		n_bmp *b = &p->bmp[ i ];


		n_type_gfx sx = N_BMP_SX( b );
		n_type_gfx sy = N_BMP_SY( b );
		n_type_gfx  x = 0;

		if ( g->align == N_GDI_ALIGN_LEFT   ) { x = p->padding;                      } else
		if ( g->align == N_GDI_ALIGN_CENTER ) { x = ( p->sx - sx ) / 2;              } else
		if ( g->align == N_GDI_ALIGN_RIGHT  ) { x = p->sx - ( p->padding * 2 ) - sx; }

		n_bmp_fastcopy( b, &canvas, 0,0,sx,sy, x,y );

		y += sy + p->padding;


		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	// Exit

	n_gdi_bitmap_draw( p->hwnd, &canvas, 0,0,p->sx,p->sy, 0,0 );


	RECT rect; GetClientRect( p->hbtn.hwnd, &rect );
	n_win_button_draw( &p->hbtn, NULL, &rect );


	// Cleanup

	n_bmp_free( &canvas );


	return;
}

void
n_win_richdialog_resize( n_win_richdialog *p, n_posix_bool is_first )
{

	if ( p == NULL ) { return; }


	int nws = N_WIN_SET_DEFAULT;

	n_type_gfx csx = p->sx;
	n_type_gfx csy = p->sy;

	if ( is_first )
	{
		nws = N_WIN_SET_CENTERING;
	}

	n_win w; n_win_set( p->hwnd, &w, csx,csy, nws );// | N_WIN_SET_CALCONLY );

	p->sx = w.csx;
	p->sy = w.csy;


	n_win_richdialog_draw( p );


	//n_win_set( p->hwnd, &w, csx,csy, nws );


	n_type_gfx btn_sy = p->button_sy;
	n_type_gfx btn_sx = (n_type_gfx) ( (n_type_real) w.csx * 0.5 );
	n_type_gfx btn_x  = ( w.csx - btn_sx ) / 2;
	n_type_gfx btn_y  = p->header_sy + ( ( p->margin_sy - btn_sy ) / 2 );

	n_win_button_move( &p->hbtn, btn_x, btn_y, btn_sx, btn_sy, n_posix_false );


	return;
}

#define n_win_richdialog_is_locked( p ) ( ( n_posix_tickcount() - ( p )->tick ) < 333 )

LRESULT CALLBACK
n_win_richdialog_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_richdialog *p = &n_win_richdialog_instance;


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		n_win_timer_init( hwnd, timer_id, 500 );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_posix_true );

		n_win_button_on_settingchange( &p->hbtn );

		if ( p->on_settingchange != NULL )
		{

			p->gdi[ 0 ] = n_win_richdialog_template();

			int i = 1;
			n_posix_loop
			{

				n_gdi_alias( &p->gdi[ 0 ], &p->gdi[ i ] );

				i++;
				if ( i >= p->gdi_used ) { break; }
			}

			p->on_settingchange( p->gdi );

			n_win_richdialog_bmp ( p );
			n_win_richdialog_draw( p );

		}

	break;


	case WM_CREATE :
//return -1;

		// Global

		//n_bmp_safemode = n_posix_false;

		n_win_ime_disable( hwnd );

		p->hwnd = hwnd;

		n_win_button_zero( &p->hbtn );

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }


		// Window

		n_win_init_literal( hwnd, "", "", "" );

		{
			if ( n_string_is_empty( p->label ) )
			{
				p->label = n_posix_literal( "OK" );
			}

			n_win_button_init( &p->hbtn, hwnd, p->label, PBS_NORMAL );
		}

		n_win_text_set( p->hwnd, p->title );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, WS_POPUP | WS_CAPTION | WS_SYSMENU );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		// Size

		n_win_richdialog_autosize( p );
		n_win_richdialog_bmp( p );

		n_win_richdialog_resize( p, n_posix_true );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( n_win_hwnd_toplevel( hwnd ), n_posix_false );


		// [!] : prevent accidental clicking

		p->tick = n_posix_tickcount();


	break;


	case WM_ERASEBKGND :

		// [x] : UxTheme : margin will be black

		//return n_posix_true;

	break;

	case WM_PAINT :

		n_win_richdialog_draw( p );

	break;


	case WM_SIZE :

		n_win_richdialog_resize( p, n_posix_false );

	break;


	case WM_COMMAND :

		if ( n_win_richdialog_is_locked( p ) ) { break; }

		if ( (HWND) lparam == p->hbtn.hwnd )
		{
			p->hbtn.keep_on_pressing = n_posix_true;
			n_win_button_forced( &p->hbtn, PBS_PRESSED );

			p->is_ok = n_posix_true;
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;

	case WM_KEYDOWN :

		if ( n_win_richdialog_is_locked( p ) ) { break; }

		if ( ( wparam == VK_SPACE )||( wparam == VK_RETURN ) )
		{
			p->hbtn.keep_on_pressing = n_posix_true;
			p->hbtn.state            = PBS_PRESSED;
			p->hbtn.sink_onoff       = n_posix_true;

			n_win_property_set_literal( p->hbtn.hwnd, "State", p->hbtn.state );

			RECT rect; GetClientRect( p->hbtn.hwnd, &rect );
			n_win_button_draw( &p->hbtn, NULL, &rect );
		} else
		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}// else

	break;

	case WM_KEYUP :

		if ( n_win_richdialog_is_locked( p ) ) { break; }

		if ( ( wparam == VK_SPACE )||( wparam == VK_RETURN ) )
		{
			n_win_button_forced( &p->hbtn, PBS_PRESSED );

			p->is_ok = n_posix_true;
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}// else

	break;


	case WM_CLOSE :

		EnableWindow( n_win_hwnd_toplevel( hwnd ), n_posix_true );
		ShowWindow( hwnd, SW_HIDE );

		n_win_button_exit( &p->hbtn );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_win_button_proc( hwnd, msg, wparam, lparam, &p->hbtn );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

n_posix_bool
n_win_richdialog_go( n_win_richdialog *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return n_posix_false; }

	if ( hwnd_parent == NULL ) { return n_posix_false; }


	n_win_gui( hwnd_parent, N_WIN_GUI_WINDOW, n_win_richdialog_wndproc, &p->hwnd );


	// [!] : don't use GetMessage() : a closed process will remain in background

	MSG msg; ZeroMemory( &msg, sizeof( MSG ) );
	n_posix_loop
	{

		if ( n_win_message_peek( &msg ) )
		{

			if ( msg.message == WM_QUIT ) { break; }

			if ( n_posix_false == IsWindow( p->hwnd ) ) { break; }

			TranslateMessage( &msg );
			DispatchMessage ( &msg );

		} else {

			// [!] ; "else" is important with performance

			n_posix_sleep( 1 );

		}

	}


//n_win_hwndprintf_literal( hwnd_parent, "%d", p->is_ok );


	return n_win_richdialog_exit( p );
}




#endif // _H_NONNON_WIN32_WIN_RICHDIALOG

