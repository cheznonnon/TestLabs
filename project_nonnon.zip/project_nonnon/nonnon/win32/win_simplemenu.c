// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : All : drop shadow
//
//	CS_DROPSHADOW needs HWND_TOPMOST, see win32/win/style.c


// [!] : Win2000 : DragAcceptFiles() is needed else fade of AnimateWindow() will not work


// [x] : this layer is too simple : use your brain to handle accurately
//
//	[ when status is changed : a displayed status is changed too fastly ]
//
//		use static onoff variables to the next WPARAM_REARRANGE call


// [ Mechanism ]
//
//	[ WM_CREATE ]
//
//	n_win_simplemenu_zero()
//	n_win_simplemenu_init()
//	n_win_simplemenu_set()
//
//	[ WM_CLOSE ]
//
//	n_win_simplemenu_exit()
//
//	[ WM_COMMAND ]
//
//	WPARAM : notification code or zero-based index
//	LPARAM : HWND of popup menu
//
//	n_win_simplemenu_detect() to check
//	n_win_simplemenu_tweak() to change
//
//	[ WndProc ]
//
//	n_win_simplemenu_proc()
//	[!] : title bar focus patch
//	[!] : key bindings
//
//	[ show ]
//
//	n_win_simplemenu_show()
//
//	[ hide / close ]
//
//	n_win_simplemenu_hide()




#ifndef _H_NONNON_WIN32_SIMPLEMENU
#define _H_NONNON_WIN32_SIMPLEMENU




#include "./win.c"

#include "./uxtheme.c"

#include "./gdi/bitmap.c"
#include "./gdi/doublebuffer_32bpp.c"

#include "../game/rc.c"




#define n_win_simplemenu_debug_count( hwnd ) n_win_debug_count( n_win_hwnd_toplevel( hwnd ) )




static n_posix_bool n_win_simplemenu_clip_onoff = n_posix_false;

void
n_win_simplemenu_clip( HDC hdc, RECT *r )
{

	if ( n_win_simplemenu_clip_onoff )
	{
		ExcludeClipRect( hdc, r->left, r->top, r->right, r->bottom );
	}

	return;
}

void
n_win_simplemenu_frame( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, COLORREF color[ 4 ] )
{

	s32 fx,fy,tx,ty;


	HGDIOBJ hp[ 4 ] =
	{
		CreatePen( PS_SOLID, 1, color[ 0 ] ),
		CreatePen( PS_SOLID, 1, color[ 1 ] ),
		CreatePen( PS_SOLID, 1, color[ 2 ] ),
		CreatePen( PS_SOLID, 1, color[ 3 ] ),
	};


	// Top-Bottom

	fx = x; tx = fx + sx;

	fy = y; ty = fy;
	HGDIOBJ hp_old = SelectObject( hdc, hp[ 0 ] );
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	if ( n_win_simplemenu_clip_onoff ) { ExcludeClipRect( hdc, fx,fy,tx,ty+1 ); }

	fy = y + sy - 1; ty = fy;
	SelectObject( hdc, hp[ 1 ] );
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	if ( n_win_simplemenu_clip_onoff ) { ExcludeClipRect( hdc, fx,fy,tx,ty+1 ); }


	// Left-Right

	fy = y; ty = fy + sy;

	fx = x; tx = fx;
	SelectObject( hdc, hp[ 2 ] );
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	if ( n_win_simplemenu_clip_onoff ) { ExcludeClipRect( hdc, fx,fy,tx+1,ty ); }

	fx = x + sx - 1; tx = fx;
	SelectObject( hdc, hp[ 3 ] );
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	if ( n_win_simplemenu_clip_onoff ) { ExcludeClipRect( hdc, fx,fy,tx+1,ty ); }


	SelectObject( hdc, hp_old );


	DeleteObject( hp[ 0 ] );
	DeleteObject( hp[ 1 ] );
	DeleteObject( hp[ 2 ] );
	DeleteObject( hp[ 3 ] );


	return;
}

HFONT
n_win_simplemenu_font_bold( HFONT hfont )
{

	LOGFONT lf = n_win_font_hfont2logfont( hfont );


	lf.lfWeight = FW_BOLD;


	return n_win_font_logfont2hfont( &lf );
}

HFONT
n_win_simplemenu_font_underline( HFONT hfont )
{

	LOGFONT lf = n_win_font_hfont2logfont( hfont );


	lf.lfUnderline = n_posix_true;


	return n_win_font_logfont2hfont( &lf );
}




#define N_WIN_SIMPLEMENU_NOT_SELECTED     ( -12 ) // [!] : for debugging
#define N_WIN_SIMPLEMENU_WPARAM_REARRANGE ( -13 ) // [!] : for debugging




typedef void (*n_win_simplemenu_callback_type)( void *data );




typedef struct {

	HWND      hwnd;
	HWND      hwnd_fade;

	n_vector  bmp;
	n_vector  str;
	n_vector  key;

	int       focus, keyfocus, prvfocus;

	s32       dpi;
	s32       scale;
	s32       bmpsize;
	s32       border;
	s32       padding;
	s32       padding_text;

	n_posix_bool is_classic;
	n_posix_bool is_xp;
	n_posix_bool is_vista;
	n_posix_bool is_7;
	n_posix_bool is_8;
	n_posix_bool is_10;

	s32       x,y,sx,sy;
	s32       hx,hy,hsx,hsy;
	s32       px,py,psx,psy;

	n_posix_bool color_cache_onoff;
	COLORREF     color_bg;
	COLORREF     color_frame;
	COLORREF     color_shadow;
	COLORREF     color_line;
	COLORREF     color_light;
	COLORREF     color_offtxt;
	COLORREF     color_on_txt;
	COLORREF     color_focus;

	n_posix_bool font_cache_onoff;
	HFONT        hfont_marlett_big;
	HFONT        hfont_marlett_lil;
	HFONT        hfont_main;
	HFONT        hfont_main_bold;
	HFONT        hfont_main_bold_line;

	s64      * cch_cache;
	SIZE     *size_cache;

	n_posix_bool keybinding_cache_onoff;
	n_posix_bool keybinding_onoff;

	n_posix_bool uxtheme_cache_onoff;
	COLORREF     uxtheme_cache_bg;

	n_posix_bool silent_onoff;
	n_posix_bool superfast_onoff;

	// [Needed] : when a cursor is out of menu at exit
	n_posix_bool is_window;

	// [!] : use when rendering is delayed : see TxtBox 
	n_win_simplemenu_callback_type  callback;
	void                           *callback_data;

} n_win_simplemenu;




static n_posix_bool      n_win_simplemenu_printclient = n_posix_false;
static n_win_simplemenu *n_win_simplemenu_target      = NULL;
static n_posix_bool      n_win_simplemenu_is_escaped  = n_posix_false;




#define n_win_simplemenu_zero( p ) n_memory_zero( p, sizeof( n_win_simplemenu ) )

void
n_win_simplemenu_cleanup( n_win_simplemenu *p )
{

	DeleteObject( p->hfont_marlett_big    ); p->hfont_marlett_big    = NULL;
	DeleteObject( p->hfont_marlett_lil    ); p->hfont_marlett_lil    = NULL;
	DeleteObject( p->hfont_main           ); p->hfont_main           = NULL;
	DeleteObject( p->hfont_main_bold      ); p->hfont_main_bold      = NULL;
	DeleteObject( p->hfont_main_bold_line ); p->hfont_main_bold_line = NULL;

	p->   font_cache_onoff = n_posix_false;
	p->  color_cache_onoff = n_posix_false;
	p->uxtheme_cache_onoff = n_posix_false;


	return;
}

void
n_win_simplemenu_exit( n_win_simplemenu *p )
{

	if ( p == NULL ) { return; }


	n_vector_free( &p->bmp );
	n_vector_free( &p->str );
	n_vector_free( &p->key );


	n_memory_free( p-> cch_cache ); p-> cch_cache = NULL;
	n_memory_free( p->size_cache ); p->size_cache = NULL;


	n_win_property_exit_literal( GetParent( p->hwnd ), "Nonnon.Win32.SimpleMenu.Lock" );


	n_win_simplemenu_cleanup( p );


	p->silent_onoff = n_posix_true;


	return;
}

void
n_win_simplemenu_init( n_win_simplemenu *p )
{

	if ( p == NULL ) { return; }


	n_vector_new( &p->bmp );
	n_vector_new( &p->str );
	n_vector_new( &p->key );

	p->focus = p->keyfocus = p->prvfocus = N_WIN_SIMPLEMENU_NOT_SELECTED;

	p-> cch_cache = NULL;
	p->size_cache = NULL;


	p->superfast_onoff = n_posix_true;


	return;
}

void
n_win_simplemenu_metrics( n_win_simplemenu *p )
{

	if ( p == NULL ) { return; }


	p->dpi        = n_win_dpi( p->hwnd );
	p->scale      = p->dpi / 96;
	p->bmpsize    = GetSystemMetrics( SM_CXSMICON );
	p->is_classic = n_win_style_is_classic();
	p->is_xp      = n_sysinfo_version_xp();
	p->is_vista   = n_sysinfo_version_vista_or_later();
	p->is_7       = n_sysinfo_version_7_or_later();
	p->is_8       = n_sysinfo_version_8_or_later();
	p->is_10      = n_sysinfo_version_10_or_later();

	if ( p->is_classic )
	{
		p->border       = 2 * p->scale;
		p->padding      = 2 * p->scale;
		p->padding_text = 1 * p->border;
	} else {
		p->border       = 1 * p->scale;
		p->padding      = 2 * p->scale;
		p->padding_text = 2 * p->border;
	}


	return;
}

void
n_win_simplemenu_set( n_win_simplemenu *p, int index, n_posix_char *bmp, n_posix_char *str, n_posix_char *key )
{

	if ( p == NULL ) { return; }


	// Metrics

	n_win_simplemenu_metrics( p );


	if ( n_string_is_empty( bmp ) ) { bmp = N_STRING_SPACE; }
	if ( n_string_is_empty( str ) ) { str = N_STRING_SPACE; }
	if ( n_string_is_empty( key ) ) { key = N_STRING_SPACE; }

	n_vector_set( &p->bmp, index, bmp );
	n_vector_set( &p->str, index, str );
	n_vector_set( &p->key, index, key );


	n_memory_free( p-> cch_cache ); p-> cch_cache = NULL;
	n_memory_free( p->size_cache ); p->size_cache = NULL;

	p->keybinding_cache_onoff = n_posix_false;


	return;
}

void
n_win_simplemenu_xmouse( n_win_simplemenu *p, HWND hwnd, UINT msg )
{

	switch( msg ) {

	case WM_MOUSEMOVE   :
	case WM_NCMOUSEMOVE :

		if (    hwnd == GetActiveWindow() ) { break; }
		if ( p->hwnd == GetActiveWindow() ) { break; }

		SetActiveWindow( hwnd );

	break;

	} // switch


	return;
}

n_posix_bool
n_win_simplemenu_keybinding_is_used( n_win_simplemenu *p )
{

	n_posix_bool ret = n_posix_false;

	if ( p == NULL ) { return ret; }

	if ( p->keybinding_cache_onoff ) { return p->keybinding_onoff; }

	int i = 0;
	while( 1 )
	{
		if ( i >= p->key.sy ) { break; }

		n_posix_char *k = n_vector_get( &p->key, i );
		if ( k[ 0 ] != N_STRING_CHAR_SPACE ) { ret = n_posix_true; break; }

		i++;
	}

	p->keybinding_cache_onoff = n_posix_true;
	p->keybinding_onoff       = ret;


	return ret;
}

n_posix_bool
n_win_simplemenu_is_line( n_win_simplemenu *p, int index )
{

	if ( index < 0 ) { return n_posix_false; }

	n_posix_char *str = n_vector_get( &p->str, index );

	if ( str[ 1 ] == n_posix_literal( '-' ) ) { return n_posix_true; } else
	if ( str[ 1 ] == n_posix_literal( 'h' ) ) { return n_posix_true; } else
	if ( str[ 1 ] == n_posix_literal( 'H' ) ) { return n_posix_true; }// else


	return n_posix_false;
}

n_posix_bool
n_win_simplemenu_is_clickable( n_win_simplemenu *p, int index )
{

	if ( index < 0 ) { return n_posix_false; }

	n_posix_char *str = n_vector_get( &p->str, index );

	if ( str[ 1 ] == n_posix_literal( 'x' ) ) { return n_posix_false; } else
	if ( str[ 1 ] == n_posix_literal( 'X' ) ) { return n_posix_false; } else
	if ( str[ 1 ] == n_posix_literal( '-' ) ) { return n_posix_false; } else
	if ( str[ 1 ] == n_posix_literal( 'h' ) ) { return n_posix_false; } else
	if ( str[ 1 ] == n_posix_literal( 'H' ) ) { return n_posix_false; }// else


	return n_posix_true;
}

void
n_win_simplemenu_bold_onoff( n_win_simplemenu *p, int index, n_posix_bool onoff )
{

	if ( p == NULL ) { return; }


	if ( index < 0 ) { return; }


//n_posix_debug_literal( " %d ", p->focus );

	n_posix_char *str = n_vector_get( &p->str, index );

	if ( onoff )
	{

		if ( str[ 1 ] == n_posix_literal( ' ' ) )
		{
			str[ 1 ] = n_posix_literal( '_' );
		} else
		if ( str[ 1 ] == n_posix_literal( 'x' ) )
		{
			str[ 1 ] = n_posix_literal( 'X' );
		} else
		if ( str[ 1 ] == n_posix_literal( 'v' ) )
		{
			str[ 1 ] = n_posix_literal( 'V' );
		} else
		if ( str[ 1 ] == n_posix_literal( 'o' ) )
		{
			str[ 1 ] = n_posix_literal( 'O' );
		}// else

	} else {

		if ( str[ 1 ] == n_posix_literal( '_' ) )
		{
			str[ 1 ] = n_posix_literal( ' ' );
		} else
		if ( str[ 1 ] == n_posix_literal( 'X' ) )
		{
			str[ 1 ] = n_posix_literal( 'x' );
		} else
		if ( str[ 1 ] == n_posix_literal( 'V' ) )
		{
			str[ 1 ] = n_posix_literal( 'v' );
		} else
		if ( str[ 1 ] == n_posix_literal( 'O' ) )
		{
			str[ 1 ] = n_posix_literal( 'o' );
		}// else

	}


	return;
}

#define n_win_simplemenu_tweak_literal( p, i, c ) n_win_simplemenu_tweak( p, i, n_posix_literal( c ) )

void
n_win_simplemenu_tweak( n_win_simplemenu *p, int index, n_posix_char c )
{

	if ( p == NULL ) { return; }


	n_posix_char *str = n_vector_get( &p->str, index );
//n_posix_debug_literal( "%s", str );

	if ( 3 <= n_posix_strlen( str ) )
	{
		str[ 1 ] = c;
	}


	return;
}

#define n_win_simplemenu_detect_literal( p, i, c ) n_win_simplemenu_detect( p, i, n_posix_literal( c ) )

n_posix_bool
n_win_simplemenu_detect( n_win_simplemenu *p, int index, n_posix_char c )
{

	n_posix_bool ret = n_posix_false;

	if ( p == NULL ) { return ret; }


	n_posix_char *str = n_vector_get( &p->str, index );
//n_posix_debug_literal( "%s", str );

	if ( 3 <= n_posix_strlen( str ) )
	{
		if ( str[ 1 ] == c ) { ret = n_posix_true; }
	}


	return ret;
}

void
n_win_simplemenu_font_cache( n_win_simplemenu *p, HDC hdc )
{

	if ( p->font_cache_onoff == n_posix_false )
	{
		p->font_cache_onoff = n_posix_true;

		SIZE size;
		GetTextExtentPoint32( hdc, N_STRING_SPACE, 1, &size );
		size.cy += p->padding * 2;

		s32 size_small_cy = size.cy / 2;

		p->hfont_marlett_big    = n_win_font_name2hfont( n_posix_literal( "Marlett" ), size.cy );
		p->hfont_marlett_lil    = n_win_font_name2hfont( n_posix_literal( "Marlett" ), size_small_cy );
		p->hfont_main           = n_win_stdfont_hfont();
		p->hfont_main_bold      = n_win_simplemenu_font_bold( p->hfont_main );
		p->hfont_main_bold_line = n_win_simplemenu_font_underline( p->hfont_main_bold );
	}


	return;
}

int
n_win_simplemenu_hit_index( n_win_simplemenu *p, int fade_calc )
{

	if ( p == NULL ) { return N_WIN_SIMPLEMENU_NOT_SELECTED; }


	s32 m  = p->border + p->padding;
	s32 mm = m * 2;

	s32 csx = 0;
	s32 csy = 0;
	n_win_size_client( p->hwnd, &csx, &csy );


	s32 x,y,sx,sy;
	x = y = sx = sy = 0;

	s32 oy = m;


	HDC hdc = GetDC( p->hwnd );

	HFONT hfont_back = SelectObject( hdc, p->hfont_main );


	n_posix_bool visible = n_posix_true;


	int i = 0;
	while( 1 )
	{
		if ( i >= p->str.sy ) { i = N_WIN_SIMPLEMENU_NOT_SELECTED; break; }


		n_posix_char *str = n_vector_get( &p->str, i );

		if ( visible == n_posix_false )
		{
			if ( str[ 1 ] == n_posix_literal( 'H' ) )
			{
				visible = n_posix_true;
			} else
			if ( str[ 1 ] == n_posix_literal( 'h' ) )
			{
				visible = n_posix_true;
			} else {
				i++;
				continue;
			}
		}


		n_posix_bool bold_onoff = n_posix_false;

		if (
			( str[ 1 ] == n_posix_literal( 'h' ) )
			||
			( str[ 1 ] == n_posix_literal( 'H' ) )
			||
			( str[ 1 ] == n_posix_literal( '_' ) )
			||
			( str[ 1 ] == n_posix_literal( 'X' ) )
			||
			( str[ 1 ] == n_posix_literal( 'V' ) )
			||
			( str[ 1 ] == n_posix_literal( 'O' ) )
		)
		{
			bold_onoff = n_posix_true;
			SelectObject( hdc, p->hfont_main_bold );
		}


		SIZE size = { 0, 0 };
		if ( p->size_cache == NULL )
		{
			GetTextExtentPoint32( hdc, str, 1, &size );
			size.cy += p->padding * 2;

			size.cy = n_posix_max_s32( size.cy, p->bmpsize );
		} else {
			size = p->size_cache[ i ];
		}


		if ( bold_onoff )
		{
			SelectObject( hdc, p->hfont_main );
		}


		s32 xx;
		if (
			( str[ 1 ] == n_posix_literal( 'h' ) )
			||
			( str[ 1 ] == n_posix_literal( 'H' ) )
			||
			( str[ 1 ] == n_posix_literal( '-' ) )
		)
		{
			xx = 0;
		} else {
			xx = m;
		}

		 x = xx;
		 y = oy;
		sx = csx - mm;
		sy = size.cy;

		p->hx  =  x;
		p->hy  =  y;
		p->hsx = sx;
		p->hsy = sy;

		if (
			( fade_calc == i )
			||
			(
				( fade_calc == N_WIN_SIMPLEMENU_NOT_SELECTED )
				&&
				( n_win_is_hovered_offset( p->hwnd, x,y,sx,sy ) )
			)
		)
		{

			POINT pt = { x,y }; ClientToScreen( p->hwnd, &pt );

			p-> x = pt.x;
			p-> y = pt.y;
			p->sx = sx + m - ( p->padding * 2 );
			p->sy = sy;

			break;
		}


		if ( str[ 1 ] == n_posix_literal( 'h' ) ) { visible = n_posix_false; }


		oy = oy + size.cy;

		i++;
	}

	SelectObject( hdc, hfont_back );

	ReleaseDC( p->hwnd, hdc );


	return i;
}

void
n_win_simplemenu_draw_calc_all( n_win_simplemenu *p, HDC hdc, s32 *ret_sx, s32 *ret_sy )
{

	// [!] : Accordion UI : "ret_sy" : use n_win_simplemenu_draw_calc()


	if ( p == NULL ) { return; }


	if ( p-> cch_cache == NULL ) { p-> cch_cache = n_memory_new( p->str.sy * sizeof( s64  ) ); }
	if ( p->size_cache == NULL ) { p->size_cache = n_memory_new( p->str.sy * sizeof( SIZE ) ); }


	s32 sx,sy;


	// Metrics

	n_win_simplemenu_metrics( p );


	s32 m = p->border + p->padding;


	SIZE size_key = { 0,0 };


	n_win_simplemenu_font_cache( p, hdc );


	HFONT hfont_back = SelectObject( hdc, p->hfont_main );


	s32 ox = m;
	s32 oy = m;

	sx = sy = 0;


	n_posix_bool keybinding_enabled = n_win_simplemenu_keybinding_is_used( p );
	n_posix_bool keybinding_once    = n_posix_false;


	int i = 0;
	while( 1 )
	{

		if ( i >= p->str.sy ) { break; }


		s32 icon_sx = 0;
		s32 text_sx = 0;
		s32  key_sx = 0;


		n_posix_char *str = n_vector_get( &p->str, i );


		n_posix_bool is_header  = n_posix_false;
		n_posix_bool bold_onoff = n_posix_false;

		if (
			( str[ 1 ] == n_posix_literal( 'h' ) )
			||
			( str[ 1 ] == n_posix_literal( 'H' ) )
			||
			( str[ 1 ] == n_posix_literal( '_' ) )
			||
			( str[ 1 ] == n_posix_literal( 'X' ) )
			||
			( str[ 1 ] == n_posix_literal( 'V' ) )
			||
			( str[ 1 ] == n_posix_literal( 'O' ) )
		)
		{
			if ( str[ 1 ] == n_posix_literal( 'h' ) ) { is_header = n_posix_true; }
			if ( str[ 1 ] == n_posix_literal( 'H' ) ) { is_header = n_posix_true; }

			bold_onoff = n_posix_true;
			SelectObject( hdc, p->hfont_main_bold );
		}

		s64   cch = n_posix_strlen( &str[ 3 ] );
		SIZE size = { 0, 0 }; GetTextExtentPoint32( hdc, &str[ 3 ], cch, &size );
		size.cy += p->padding * 2;

		size.cy = n_posix_max_s32( size.cy, p->bmpsize );


		p-> cch_cache[ i ] =  cch;
		p->size_cache[ i ] = size;


		// Background

		n_posix_bool is_separator = ( str[ 1 ] == n_posix_literal( '-' ) );


		// Icon

		if (
			( str[ 1 ] == n_posix_literal( 'h' ) )
			||
			( str[ 1 ] == n_posix_literal( 'H' ) )
		)
		{

			//

		} else
		if (
			( str[ 1 ] == n_posix_literal( ' ' ) )
			||
			( str[ 1 ] == n_posix_literal( '_' ) )
		)
		{

			sx = size.cx;
			sy = size.cy;

		} else
		if (
			( str[ 1 ] == n_posix_literal( 'v' ) )
			||
			( str[ 1 ] == n_posix_literal( 'V' ) )
			||
			( str[ 1 ] == n_posix_literal( 'o' ) )
			||
			( str[ 1 ] == n_posix_literal( 'O' ) )
		)
		{

			sx = size.cx;
			sy = size.cy;

		} else {

			n_bmp bmp; n_bmp_zero( &bmp );

			n_game_rc_load_bmp( &bmp, n_vector_get( &p->bmp, i ) );
			n_bmp_resizer( &bmp, size.cy,size.cy, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );

			if ( n_posix_false == n_bmp_error( &bmp ) )
			{
				sx = N_BMP_SX( &bmp );
				sy = N_BMP_SY( &bmp );
			}

			n_bmp_free_fast( &bmp );

		}

		icon_sx = m + p->padding + ( p->bmpsize * 2 ) + p->padding + p->padding;


		// Text

		if ( is_separator == n_posix_false )
		{

			if ( is_header )
			{
				sx = size.cx;
				sy = size.cy;
			} else {
				sx = size.cx;
				sy = size.cy;

				if ( p->is_vista )
				{
					sx += p->padding * 2;
				}
			}

			text_sx = sx;


			// Key Binding

			if ( ( is_header == n_posix_false )&&( is_separator == n_posix_false )&&( keybinding_enabled ) )
			{ 

				n_posix_char *keybinding = n_vector_get( &p->key, i );

				if (
					( n_string_is_empty( keybinding ) )
					||
					( keybinding[ 0 ] == N_STRING_CHAR_SPACE )
				)
				{
					if ( keybinding_once == n_posix_false )
					{
						keybinding_once = n_posix_true;
						keybinding      = n_posix_literal( "Ctrl+Shift+W" );
						GetTextExtentPoint32( hdc, keybinding, n_posix_strlen( keybinding ), &size_key );
					}
				} else {
					GetTextExtentPoint32( hdc, keybinding, n_posix_strlen( keybinding ), &size_key );
				}

				key_sx = size_key.cx + ( sy * 2 );

			}

		}


		ox = n_posix_max_s32( ox, icon_sx + text_sx + key_sx );


		if ( bold_onoff )
		{
			SelectObject( hdc, p->hfont_main );
		}


		oy = oy + size.cy;


		i++;
	}


	oy += p->padding + p->padding;


	SelectObject( hdc, hfont_back );


	if ( ret_sx != NULL ) { (*ret_sx) = ox; }
	if ( ret_sy != NULL ) { (*ret_sy) = oy; }


	return;
}

void
n_win_simplemenu_draw_header
(
	n_win_simplemenu *p,
	HDC               hdc,
	n_posix_char     *str,
	s64               cch,
	RECT             *rect_line,
	RECT             *rect_text,
	n_posix_bool      is_focused,
	n_posix_bool      draw_onoff
)
{

	if ( draw_onoff == n_posix_false ) { return; }


	COLORREF bg = p->color_bg;
	COLORREF fg = p->color_line;
	COLORREF sh = p->color_shadow;


	n_win_box( p->hwnd, hdc, rect_line, fg );
	n_win_simplemenu_clip( hdc, rect_line );

	if ( p->is_classic )
	{
		RECT rect_line_shadow = (*rect_line);
		n_win_rect_move( &rect_line_shadow, 0, p->scale );

		n_win_box( p->hwnd, hdc, &rect_line_shadow, sh );
		n_win_simplemenu_clip( hdc, &rect_line_shadow );
	}

	SetBkColor( hdc, bg );


	n_win_box( p->hwnd, hdc, rect_text, bg );

	HFONT phf = NULL;

	if ( is_focused )
	{
		if ( n_win_darkmode_onoff )
		{
			SetTextColor( hdc, p->color_on_txt );
		} else {
			SetTextColor( hdc, p->color_focus  );
		}
		phf = SelectObject( hdc, p->hfont_main_bold_line );
	} else {
		SetTextColor( hdc, p->color_on_txt );
	}

	TextOut( hdc, rect_text->left, rect_text->top + p->border, &str[ 3 ], cch );
	//DrawText( hdc, &str[ 3 ], cch, rect_text, dt );
	n_win_simplemenu_clip( hdc, rect_text );

	if ( phf != NULL ) { SelectObject( hdc, phf ); }


	return;
}

void
n_win_simplemenu_draw_frame
(
	n_win_simplemenu *p,
	HDC               hdc,
	RECT             *rect,
	COLORREF          color_frame,
	COLORREF          color_inner,
	n_posix_bool      draw_onoff
)
{
//return;

	if ( draw_onoff == n_posix_false ) { return; }


	s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	COLORREF color[ 4 ];

	color[ 0 ] = color_frame;
	color[ 1 ] = color_frame;
	color[ 2 ] = color_frame;
	color[ 3 ] = color_frame;

	int i = 0;
	while( 1 )
	{

		n_win_simplemenu_frame( hdc, x+i,y+i,sx-(i*2),sy-(i*2), color );

		i++;
		if ( i >= p->scale ) { break; }
	}

	 x += p->scale * 1;
	 y += p->scale * 1;
	sx -= p->scale * 2;
	sy -= p->scale * 2;

	RECT r = n_win_rect_set( NULL, x,y,sx,sy );
	n_win_box( p->hwnd, hdc, &r, color_inner );


	return;
}

void
n_win_simplemenu_draw_separator
(
	n_win_simplemenu *p,
	HDC               hdc,
	RECT             *rect,
	n_posix_bool      draw_onoff
)
{

	if ( draw_onoff == n_posix_false ) { return; }


	COLORREF sh = p->color_shadow;
	COLORREF fg = p->color_line;


	n_win_box( p->hwnd, hdc, rect, fg );
	n_win_simplemenu_clip( hdc, rect );


	if ( p->is_classic )
	{
		RECT rect_shadow = (*rect);
		n_win_rect_move( &rect_shadow, 0, p->scale );

		n_win_box( p->hwnd, hdc, &rect_shadow, sh );
		n_win_simplemenu_clip( hdc, &rect_shadow );
	}


	return;
}

void
n_win_simplemenu_draw_checkradio
(
	n_win_simplemenu *p,
	HDC               hdc,
	n_posix_char     *str,
	RECT             *rect_icon,
	COLORREF          color_text,
	n_posix_bool      draw_onoff
)
{

	if ( draw_onoff == n_posix_false ) { return; }


	int bk = GetBkMode( hdc );
	SetBkMode( hdc, TRANSPARENT );

	HFONT phfont = SelectObject( hdc, p->hfont_marlett_big );


	SetTextColor( hdc, color_text );

	if (
		( str[ 1 ] == n_posix_literal( 'v' ) )
		||
		( str[ 1 ] == n_posix_literal( 'V' ) )
	)
	{
		n_posix_char str_check[ 2 ] = { 0x61, 0x00 };

		s32 x,y,sx,sy; n_win_rect_expand_size( rect_icon, &x, &y, &sx, &sy );

		if ( p->dpi == 96 )
		{

			SIZE size;
			GetTextExtentPoint32( hdc, str_check, 1, &size );

			x += ( sx - size.cx ) / 2;
			y += ( sy - size.cy ) / 2;

			if ( n_sysinfo_version_xp_or_later() )
			{
				x++;
				y--;
			} else {
				x++;
				y++;
			}

			TextOut( hdc, x, y, str_check, 1 );

		} else {

			int dt = DT_NOPREFIX | DT_NOCLIP | ( DT_SINGLELINE | DT_VCENTER ) | DT_CENTER;
			DrawText( hdc, str_check, 1, rect_icon, dt );

		}

	} else {

		n_posix_char str_radio[ 2 ] = { 0x68, 0x00 };

		int dt = DT_NOPREFIX | DT_NOCLIP | ( DT_SINGLELINE | DT_VCENTER ) | DT_CENTER;
		DrawText( hdc, str_radio, 1, rect_icon, dt );

	}

	SetBkMode( hdc, bk );

	SelectObject( hdc, phfont );


	return;
}

#define n_win_simplemenu_draw_calc( p, hdc, sx,sy ) n_win_simplemenu_draw_internal( p, hdc,   sx,   sy, -2, n_posix_true, n_posix_false )
#define n_win_simplemenu_draw_main( p, hdc        ) n_win_simplemenu_draw_internal( p, hdc, NULL, NULL, -2, n_posix_true, n_posix_false )
#define n_win_simplemenu_draw_fade( p, hdc, f     ) n_win_simplemenu_draw_internal( p, hdc, NULL, NULL,  f, n_posix_true, n_posix_false )
#define n_win_simplemenu_draw_line( p, hdc, f, h  ) n_win_simplemenu_draw_internal( p, hdc, NULL, NULL,  f,            h, n_posix_false )
#define n_win_simplemenu_draw_fast( p, hdc        ) n_win_simplemenu_draw_internal( p, hdc, NULL, NULL, -2, n_posix_true, n_posix_true  )

// internal
void
n_win_simplemenu_draw_internal
(
	n_win_simplemenu *p,
	HDC               hdc,
	s32              *ret_sx,
	s32              *ret_sy,
	s32               fade_line,
	n_posix_bool      fade_hover,
	n_posix_bool      fast_onoff
)
{
//n_win_simplemenu_debug_count( n_win_hwnd_toplevel( p->hwnd ) );

	// [!] : Accordion UI : "ret_sx" : use n_win_simplemenu_draw_calc_all()


	if ( p == NULL ) { return; }


	n_win_simplemenu_clip_onoff = fast_onoff;


	s32 x,y,sx,sy;


	// Color Scheme

	if ( p->color_cache_onoff == n_posix_false )
	{
		p->color_cache_onoff = n_posix_true;

		p->color_bg     = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE       );
		p->color_frame  = n_win_darkmode_systemcolor_ui( COLOR_3DDKSHADOW    );
		p->color_shadow = n_win_darkmode_systemcolor_ui( COLOR_WINDOW        );
		p->color_line   = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW     );
		p->color_light  = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );
		p->color_offtxt = n_win_darkmode_systemcolor_ui( COLOR_GRAYTEXT      );
		p->color_on_txt = n_win_darkmode_systemcolor_ui( COLOR_BTNTEXT       );
		p->color_focus  = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT     );

		//if ( p->is_10 )
		{
			if ( n_win_darkmode_onoff )
			{
				p->color_bg    = n_win_darkmode_bg;
				p->color_frame = RGB( 160,160,160 );
			}
		}
	}


	// Metrics

	//n_win_simplemenu_metrics( p );

	RECT rect;
	if ( fade_line < 0 )
	{
		GetClientRect( p->hwnd, &rect );
	} else
	if (
		(
			( fade_line != p->   focus )
			&&
			( fade_line != p->keyfocus )
		)
		||
		( n_win_simplemenu_is_line( p, fade_line ) )
	)
	{
		n_win_rect_set( &rect, 0,0,p->hsx,p->hsy+p->border+p->padding );
	}


	// [x] : DrawThemeBackground() : L"MENU" : not working on XP

	if ( ( p->is_classic == n_posix_false )&&( p->is_xp ) )
	{

		if ( p->uxtheme_cache_onoff == n_posix_false )
		{

			p->uxtheme_cache_onoff = n_posix_true;


			n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme ); n_uxtheme_init( &uxtheme, p->hwnd, L"WINDOW" );

			if ( uxtheme.onoff )
			{
				n_posix_char themename[ N_UXTHEME_THEMENAME_CCH_MAX ];
				n_uxtheme_themename( &uxtheme, themename );
//n_posix_debug_literal( "%s", themename );
				if ( n_string_is_same_literal( "Luna", themename ) )
				{
					p->uxtheme_cache_bg = p->color_bg = RGB( 255,255,255 );
				} else {
					p->is_classic = n_posix_true;
				}
			} else {
//n_posix_debug_literal( " uxtheme.onoff == n_posix_false " );
			}

			n_uxtheme_exit( &uxtheme, p->hwnd );

		} else {

			p->color_bg = p->uxtheme_cache_bg;

		}

	}


	// Erase Background : before

	if ( fast_onoff == n_posix_false )
	{
		SetBkMode( hdc, TRANSPARENT );
		n_win_box( p->hwnd, hdc, &rect, p->color_bg );
	} else {
		SetBkMode( hdc, OPAQUE );
		SetBkColor( hdc, p->color_bg );
	}


	// Border

	if ( ( fade_line < 0 )&&( p->is_classic ) )
	{
//DrawEdge( hdc, &rect, EDGE_RAISED, BF_RECT );

		COLORREF color[ 4 ];

		n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );


		color[ 0 ] = n_win_darkmode_systemcolor_ui( COLOR_3DLIGHT    );
		color[ 1 ] = n_win_darkmode_systemcolor_ui( COLOR_3DDKSHADOW );
		color[ 2 ] = n_win_darkmode_systemcolor_ui( COLOR_3DLIGHT    );
		color[ 3 ] = n_win_darkmode_systemcolor_ui( COLOR_3DDKSHADOW );

		int i = 0;
		while( 1 )
		{

			n_win_simplemenu_frame( hdc, x+i,y+i,sx-(i*2),sy-(i*2), color );

			i++;
			if ( i >= p->scale ) { break; }
		}


		color[ 0 ] = n_win_darkmode_systemcolor_ui( COLOR_3DHIGHLIGHT );
		color[ 1 ] = n_win_darkmode_systemcolor_ui( COLOR_3DSHADOW    );
		color[ 2 ] = n_win_darkmode_systemcolor_ui( COLOR_3DHIGHLIGHT );
		color[ 3 ] = n_win_darkmode_systemcolor_ui( COLOR_3DSHADOW    );

		 x += p->scale;
		 y += p->scale;
		sx -= p->scale * 2;
		sy -= p->scale * 2;

		i = 0;
		while( 1 )
		{

			n_win_simplemenu_frame( hdc, x+i,y+i,sx-(i*2),sy-(i*2), color );

			i++;
			if ( i >= p->scale ) { break; }
		}

	} else
	if ( fade_line < 0 )
	{

		COLORREF color[ 4 ];

		color[ 0 ] = p->color_frame;
		color[ 1 ] = p->color_frame;
		color[ 2 ] = p->color_frame;
		color[ 3 ] = p->color_frame;

		n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );

		int i = 0;
		while( 1 )
		{//break;

			n_win_simplemenu_frame( hdc, x+i,y+i,sx-(i*2),sy-(i*2), color );

			i++;
			if ( i >= p->scale ) { break; }
		}

	}


	s32 m  = p->border + p->padding;
	s32 mm = m * 2;

	s32 csx = 0;
	s32 csy = 0;
	n_win_size_client( p->hwnd, &csx, &csy );


	SIZE size_key = { 0,0 };


	n_win_simplemenu_font_cache( p, hdc );


	HFONT hfont_back = SelectObject( hdc, p->hfont_main );


	s32 ox = m;
	s32 oy = m;

	x = y = sx = sy = 0;


	//if ( fade_line < 0 ) { p->focus = N_WIN_SIMPLEMENU_NOT_SELECTED; }


	n_posix_bool keybinding_enabled = n_win_simplemenu_keybinding_is_used( p );
	n_posix_bool keybinding_once    = n_posix_false;


	n_posix_bool visible = n_posix_true;


	int dt = DT_NOPREFIX | DT_NOCLIP | ( DT_SINGLELINE | DT_VCENTER ) | DT_CENTER;

	int i = 0;
	while( 1 )
	{
//if ( fast_onoff ) { break; }
//ox = oy = 100; break;

		if ( i >= p->str.sy ) { break; }


		s32 xx = 0;
		if ( fade_line >= 0 )
		{
			if ( fade_line == i )
			{
				xx = m;
				oy = 0;
			} else {
				i++;
				continue;
			}
		}


		n_posix_char *str = n_vector_get( &p->str, i );

		if ( visible == n_posix_false )
		{
			if ( str[ 1 ] == n_posix_literal( 'H' ) )
			{
				visible = n_posix_true;
			} else
			if ( str[ 1 ] == n_posix_literal( 'h' ) )
			{
				visible = n_posix_true;
			} else {
				i++;
				continue;
			}
		}

//i++; ox = oy = 100; continue;


		n_posix_bool is_disabled =
		(
//(1)||
			( str[ 1 ] == n_posix_literal( 'x' ) )
			||
			( str[ 1 ] == n_posix_literal( 'X' ) )
		);


		n_posix_bool is_separator = ( str[ 1 ] == n_posix_literal( '-' ) );


		n_posix_bool is_header  = n_posix_false;
		n_posix_bool bold_onoff = n_posix_false;

		if (
			( str[ 1 ] == n_posix_literal( 'h' ) )
			||
			( str[ 1 ] == n_posix_literal( 'H' ) )
			||
			( str[ 1 ] == n_posix_literal( '_' ) )
			||
			( str[ 1 ] == n_posix_literal( 'X' ) )
			||
			( str[ 1 ] == n_posix_literal( 'V' ) )
			||
			( str[ 1 ] == n_posix_literal( 'O' ) )
		)
		{
			if ( str[ 1 ] == n_posix_literal( 'h' ) ) { is_header = n_posix_true; }
			if ( str[ 1 ] == n_posix_literal( 'H' ) ) { is_header = n_posix_true; }

			bold_onoff = n_posix_true;
			SelectObject( hdc, p->hfont_main_bold );
		}


		s64 cch;
		if ( p->cch_cache == NULL )
		{
			cch = n_posix_strlen( &str[ 3 ] );
		} else {
			cch = p->cch_cache[ i ];
		}

		SIZE size = { 0, 0 };
		if ( p->size_cache == NULL )
		{
			GetTextExtentPoint32( hdc, &str[ 3 ], cch, &size );
			size.cy += p->padding * 2;

			size.cy = n_posix_max_s32( size.cy, p->bmpsize );
		} else {
			size = p->size_cache[ i ];
		}
//i++; oy = oy + size.cy; continue;


		RECT local_rect_line = { 0,0,0,0 };
		RECT local_rect_icon = { 0,0,0,0 };
		RECT local_rect_rect = { 0,0,0,0 };

		 x = m - xx;
		 y = oy;
		sx = csx - mm;
		sy = size.cy;

		local_rect_rect = n_win_rect_set( NULL, x,y,sy,sy );


		n_posix_bool draw_onoff = ( ( fade_line < 0 )||( fade_line == i ) );


		n_posix_bool is_hovered = n_posix_false;
		if ( draw_onoff )
		{
			if ( p->keyfocus == N_WIN_SIMPLEMENU_NOT_SELECTED )
			{
				is_hovered = n_win_is_hovered_offset( p->hwnd, x,y,sx,sy );
			}
		}

		if ( is_hovered )
		{
			if ( fade_line < 0 ) { p->focus = i; }
		}

		if ( p->keyfocus == i )
		{
			is_hovered = n_posix_true;
		}

		if ( fade_line == i )
		{
			is_hovered = fade_hover;
		}


		// Background

		COLORREF fg = 0;
		COLORREF bg = 0;

		COLORREF hl = p->color_light;
		COLORREF sh = p->color_shadow;

		COLORREF local_color_frame  = 0;
		COLORREF local_color_inner  = 0;
		COLORREF local_color_text   = 0;
		COLORREF local_color_shadow = 0;

		n_posix_bool delayed_frame_onoff = n_posix_false;

		if ( is_header )
		{

			 x = m + ( p->padding + size.cx + p->padding );
			 y = oy + ( sy / 2 );
			sx = csx - mm - p->padding - size.cx - p->padding;
			sy = p->scale;

			RECT rect_line = n_win_rect_set( NULL, x,y,sx,sy );


			 x = m + p->padding;
			 y = oy;
			sx = n_posix_min( size.cx, csx - mm );
			sy = size.cy;

			RECT rect_text = n_win_rect_set( NULL, x,y,sx,sy );

			n_win_simplemenu_draw_header
			(
				p,
				hdc,
				str, cch,
				&rect_line,
				&rect_text,
				is_hovered,
				draw_onoff
			);

		} else
		if ( str[ 1 ] == n_posix_literal( '-' ) )
		{

			 x = m + p->bmpsize + p->padding;
			 y = oy + ( sy / 2 );
			sx = csx - mm - p->bmpsize - p->padding;
			sy = p->scale;

			local_rect_line = n_win_rect_set( NULL, x,y,sx,sy );


			n_win_simplemenu_draw_separator
			(
				p,
				hdc,
				&local_rect_line,
				draw_onoff
			);

		} else
		if ( is_hovered )
		{

			if ( ( p->is_classic )||( p->is_xp ) )
			{

				if ( is_disabled )
				{
					fg = p->color_offtxt;
					bg = p->color_focus;

					local_color_text   = p->color_offtxt;
					local_color_shadow = p->color_offtxt;
				} else {
					fg = hl;
					bg = p->color_focus;

					local_color_text   = fg;
					local_color_shadow = p->color_offtxt;
				}

			} else {

				if ( is_disabled )
				{
					fg = p->color_offtxt;
					bg = n_win_color_blend( fg, p->color_bg, 0.5 );
				} else {
					fg = p->color_on_txt;
					bg = p->color_focus;
				}

				local_color_text   = fg;
				local_color_shadow = p->color_offtxt;

			}


			RECT rect_line = n_win_rect_set( NULL, x,y,sx,sy );
			local_rect_line = rect_line;

			delayed_frame_onoff = n_posix_true;

		} else {

			if ( is_disabled )
			{
				fg = p->color_offtxt;
				bg = p->color_bg;
			} else {
				fg = p->color_on_txt;
				bg = p->color_bg;
			}

			local_color_frame = local_color_inner = bg;

			local_color_text   = fg;
			local_color_shadow = sh;

			local_rect_line = n_win_rect_set( NULL, x,y,sx,sy );

			SetBkColor( hdc, bg );

		}


		// Icon

		n_posix_char *str_bmp = n_vector_get( &p->bmp, i );
		n_bmp             bmp;
		n_posix_bool  drawbmp = n_posix_false;

		n_posix_bool delayed_light_onoff = n_posix_false;
		n_posix_bool delayed_check_onoff = n_posix_false;

		if ( str_bmp[ 0 ] != N_STRING_CHAR_SPACE )
		{
//n_win_simplemenu_debug_count( n_win_hwnd_toplevel( p->hwnd ) );

			n_bmp_zero( &bmp );

			n_game_rc_load_bmp( &bmp, n_vector_get( &p->bmp, i ) );
			n_bmp_resizer( &bmp, size.cy,size.cy, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );
//n_bmp_save_literal( &bmp, "ret.bmp" );

			if ( n_posix_false == n_bmp_error( &bmp ) )
			{
				drawbmp = n_posix_true;
			}

		}

		if ( is_header )
		{

			//

		} else
		if (
			( str_bmp[ 0 ] == N_STRING_CHAR_SPACE )
			&&
			(
				( str[ 1 ] == n_posix_literal( ' ' ) )
				||
				( str[ 1 ] == n_posix_literal( '_' ) )
			)
		)
		{

			sx = size.cy;
			sy = size.cy;

			local_rect_icon = n_win_rect_set( NULL, x,y,sx,sy );

			if ( draw_onoff )
			{
				n_win_box( p->hwnd, hdc, &local_rect_icon, local_color_inner );
			}

		} else
		if (
			( str[ 1 ] == n_posix_literal( 'v' ) )
			||
			( str[ 1 ] == n_posix_literal( 'V' ) )
			||
			( str[ 1 ] == n_posix_literal( 'o' ) )
			||
			( str[ 1 ] == n_posix_literal( 'O' ) )
		)
		{

//n_win_box( p->hwnd, hdc, &local_rect_rect, p->color_focus );

			local_rect_icon = local_rect_rect;
//n_win_box( p->hwnd, hdc, &rect_icon, RGB( 0,200,255 ) );

			if ( str_bmp[ 0 ] == N_STRING_CHAR_SPACE )
			{
				delayed_check_onoff = n_posix_true;
			}

			delayed_light_onoff = n_posix_true;

		}


		if ( delayed_frame_onoff )
		{

			if ( n_win_darkmode_onoff )
			{
				if ( p->is_10 )
				{
					local_color_frame = n_win_color_blend( hl, p->color_bg, 0.75 );
					local_color_inner = local_color_frame;
				} else {
					local_color_frame = n_win_color_blend( bg, p->color_bg, 0.00 );
					local_color_inner = n_win_color_blend( hl, p->color_bg, 0.90 );
				}
			} else {
				if ( p->is_10 )
				{
					local_color_frame = RGB( 255,255,255 );
					local_color_inner = RGB( 255,255,255 );
				} else
				if ( ( p->is_classic )||( p->is_xp ) )
				{
					local_color_frame = local_color_inner = bg;
				} else {
					local_color_frame = n_win_color_blend( bg, p->color_bg, 0.00 );
					local_color_inner = n_win_color_blend( bg, p->color_bg, 0.90 );
				}
			}


			n_win_simplemenu_draw_frame
			(
				 p,
				 hdc,
				&local_rect_line,
				 local_color_frame,
				 local_color_inner,
				 draw_onoff
			);


			SetBkColor( hdc, local_color_inner );

		}


		if ( delayed_light_onoff )
		{

			if (
				( ( p->is_classic == n_posix_false )&&( p->is_vista )&&( p->is_10 == n_posix_false ) )
				||
				( drawbmp )
			)
			{

				if ( p->is_10 )
				{
					if ( n_win_darkmode_onoff )
					{
						local_color_frame = local_color_inner = n_win_darkmode_bg;
					} else {
						local_color_frame = RGB( 200,200,200 );
						local_color_inner = RGB( 255,255,255 );
					}
				} else {
					u32 bg = p->color_focus;

					if ( n_win_darkmode_onoff )
					{
						local_color_frame = n_win_color_blend( bg, p->color_bg, 0.00 );
						local_color_inner = n_win_color_blend( hl, p->color_bg, 0.75 );
					} else {
						local_color_frame = n_win_color_blend( bg, p->color_bg, 0.00 );
						local_color_inner = n_win_color_blend( bg, p->color_bg, 0.75 );
					}
				}

				n_win_simplemenu_draw_frame
				(
					 p,
					 hdc,
					&local_rect_rect,
					 local_color_frame,
					 local_color_inner,
					 draw_onoff
				);

			} else {

				if ( p->is_10 )
				{
					n_win_box( p->hwnd, hdc, &local_rect_rect, local_color_inner );
				} else {
					n_win_box( p->hwnd, hdc, &local_rect_rect,                bg );
				}

			}

		}


		if ( delayed_check_onoff )
		{

			n_win_simplemenu_draw_checkradio
			(
				 p,
				 hdc,
				 str,
				&local_rect_icon,
				 local_color_text,
				draw_onoff
			);

			n_win_simplemenu_clip( hdc, &local_rect_icon );

		}


		if ( drawbmp )
		{
//n_win_box( p->hwnd, hdc, &local_rect_rect, RGB( 0,200,255 ) );

			 x = m - xx;
			 y = oy;
			sx = N_BMP_SX( &bmp );
			sy = N_BMP_SY( &bmp );

			local_rect_icon = n_win_rect_set( NULL, x,y,sx,sy );


			s32 b = p->border;

			 x += b;
			 y += b;
			sx -= b * 2;
			sy -= b * 2;

			{
				RECT rect = local_rect_rect;
				if ( n_win_simplemenu_clip_onoff == n_posix_false )
				{
					n_win_rect_resize( &rect, -p->border,-p->border );
				}

				n_win_box( p->hwnd, hdc, &rect, local_color_inner );
			}

			if ( is_disabled )
			{
				n_bmp gray; n_bmp_carboncopy( &bmp, &gray );

				n_bmp_flush_grayscale( &gray );
				n_bmp_flush_mixer( &gray, p->color_offtxt, 0.5 );

				n_bmp_fill( &gray, 0,0, n_bmp_colorref2argb( local_color_inner ) );
				n_gdi_bitmap_draw_main( p->hwnd, hdc, &gray, b,b,sx,sy, x,y );

				n_bmp_free_fast( &gray );
			} else {
				n_bmp_fill( &bmp, 0,0, n_bmp_colorref2argb( local_color_inner ) );
				n_gdi_bitmap_draw_main( p->hwnd, hdc, &bmp, b,b,sx,sy, x,y );
			}

			n_bmp_free_fast( &bmp );

		}


		// Text

		if ( ( is_separator == n_posix_false )&&( is_header == n_posix_false ) )
		{

//n_win_box( p->hwnd, hdc, &rect_text, RGB( 0,200,255 ) );

			RECT local_rect_text = { 0,0,0,0 };
			RECT local_rect_key  = { 0,0,0,0 };

			 x = m + p->padding + p->bmpsize + p->padding + p->padding - xx;
			 y = oy;
			sx = n_posix_min( size.cx, csx - mm );
			sy = size.cy;

			if ( p->is_vista )
			{
				x += p->padding * 2;
			}


			// [!] : TxtOut() is x2 faster than DrawText()

			RECT rect_text = n_win_rect_set( NULL, x,y,sx,sy );

			if ( draw_onoff )
			{
				if ( ( p->is_classic )&&( is_disabled )&&( is_hovered == n_posix_false ) )
				{
					SetTextColor( hdc, local_color_shadow );
					TextOut( hdc, x + p->scale, y + p->scale + p->border, &str[ 3 ], cch );
				}

				SetTextColor( hdc, local_color_text );
				TextOut( hdc, x, y + p->padding_text, &str[ 3 ], cch );
				//DrawText( hdc, &str[ 3 ], cch, &rect_text, dt );
			}

			local_rect_text = rect_text;
			local_rect_text.top    += p->padding;
			local_rect_text.bottom -= p->padding;


			// Key Binding

			if ( ( is_header == n_posix_false )&&( is_separator == n_posix_false )&&( keybinding_enabled ) )
			{ 
//n_win_simplemenu_debug_count( n_win_hwnd_toplevel( p->hwnd ) );

				n_posix_bool is_calconly = n_posix_false;
				n_posix_bool is_template = n_posix_false;

				n_posix_char *keybinding = n_vector_get( &p->key, i );

				if (
					( n_string_is_empty( keybinding ) )
					||
					( keybinding[ 0 ] == N_STRING_CHAR_SPACE )
				)
				{
					is_template = n_posix_true;

					if ( keybinding_once == n_posix_false )
					{
						keybinding_once = n_posix_true;
						is_calconly     = n_posix_true;
						keybinding      = n_posix_literal( "Ctrl+Shift+W" );
						GetTextExtentPoint32( hdc, keybinding, n_posix_strlen( keybinding ), &size_key );
					}

					 x = csx - m - p->padding - p->padding - size_key.cx - xx;
					sx = size_key.cx;

					if ( is_calconly == n_posix_false ) { local_rect_key = n_win_rect_set( NULL, x,y,sx,sy ); }
				} else {
					GetTextExtentPoint32( hdc, keybinding, n_posix_strlen( keybinding ), &size_key );
				}

				local_rect_key = n_win_rect_set( NULL, 0,0,0,0 );

				if ( is_calconly == n_posix_false )
				{
					 x = csx - m - p->padding - p->padding - size_key.cx - xx;
					sx = size_key.cx;

					RECT rect_key = n_win_rect_set( NULL, x,y+p->border,size_key.cx,sy-(p->border*2) );
					if ( is_template == n_posix_false )
					{
						local_rect_key = rect_key;
					}

					if ( ( p->is_classic )&&( is_disabled )&&( is_hovered == n_posix_false ) )
					{
						SetTextColor( hdc, local_color_shadow );
						RECT rect = rect_key; n_win_rect_move( &rect, p->scale, p->scale );
						DrawText( hdc, keybinding, n_posix_strlen( keybinding ), &rect, dt );
					}

					SetTextColor( hdc, local_color_text );
					DrawText( hdc, keybinding, n_posix_strlen( keybinding ), &rect_key, dt );
				}
//if ( i == 9 )
//{
//n_win_box( p->hwnd, hdc, &local_rect_key, RGB( 0,200,255 ) );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), "%d %d %d %d", x,y,sx,sy );
//}
			}

			if ( fast_onoff )
			{
				if ( is_hovered )
				{
					n_win_simplemenu_clip( hdc, &local_rect_line );
				} else {
					n_win_simplemenu_clip( hdc, &local_rect_icon );
					n_win_simplemenu_clip( hdc, &local_rect_text );
					n_win_simplemenu_clip( hdc, &local_rect_key  );
				}
			}

		}

		if ( bold_onoff )
		{
			SelectObject( hdc, p->hfont_main );
		}


		if ( str[ 1 ] == n_posix_literal( 'h' ) ) { visible = n_posix_false; }


		if ( fade_line == i ) { break; }


		oy = oy + size.cy;


		i++;
	}


	oy += p->padding + p->border;


	SelectObject( hdc, hfont_back );


	// Erase Background : after

	if ( fast_onoff )
	{
		n_win_box( p->hwnd, hdc, &rect, p->color_bg );
	}


	if ( ret_sx != NULL ) { (*ret_sx) = ox; }
	if ( ret_sy != NULL ) { (*ret_sy) = oy; }


	return;
}

void
n_win_simplemenu_close( n_win_simplemenu *p )
{

	if ( p == NULL ) { return; }


	if ( GetParent( p->hwnd ) != n_win_hwnd_toplevel( n_win_cursor2hwnd() ) )
	{
		p->silent_onoff = n_posix_true;
	}


	// [Needed] : stand-alone mode
//return;
	if ( n_win_simplemenu_detect_literal( p, p->focus, 'x' ) ) { return; }


	// [!] : send for title bar is clicked, post for fade_wndproc()

	if ( p->focus == N_WIN_SIMPLEMENU_NOT_SELECTED )
	{
		n_win_message_send( p->hwnd, WM_CLOSE, 0,0 );
	} else {
		n_win_message_post( p->hwnd, WM_CLOSE, 0,0 );
	}


	return;
}

void
n_win_simplemenu_resize( n_win_simplemenu *p )
{

	// [Needed] : drop shadow needs this : n_posix_true only

	n_win_topmost( p->hwnd, n_posix_true );


	HDC hdc = GetDC( p->hwnd );

	s32 sx,sy;
	n_win_simplemenu_draw_calc_all( p, hdc, &sx, NULL );
	n_win_simplemenu_draw_calc    ( p, hdc, NULL, &sy );

	ReleaseDC( p->hwnd, hdc );


	n_win_set( p->hwnd, NULL, sx,sy, N_WIN_SET_DEFAULT );


	n_win_refresh( p->hwnd, n_posix_false );


	return;
}

LRESULT CALLBACK
n_win_simplemenu_fade_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_win_simplemenu *p = n_win_simplemenu_target;


	switch( msg ) {


	case WM_CREATE :

		// Global

		n_win_ime_disable( hwnd );

		p->hwnd_fade = hwnd;


		// Window

		n_win_init_literal( hwnd, "", "", "" );


		// Style

		n_win_style_new( hwnd, WS_POPUP );

		n_win_topmost( p->hwnd, n_posix_true );


		// Size

		// [Needed] : WM_PRINTCLIENT : buggy : size will be insufficient

		MoveWindow( hwnd, p->x, p->y, p->sx+1, p->sy, n_posix_false );


		// Display

		ShowWindow( hwnd, SW_HIDE );

	break;


	case WM_ERASEBKGND :

		return n_posix_true;

	break;

	case WM_PAINT :
	{
		PAINTSTRUCT ps; BeginPaint( hwnd, &ps );


		s32 sx,sy; n_win_size_client( hwnd, &sx,&sy );

		n_gdi_doublebuffer db; n_gdi_doublebuffer_zero( &db );
		HDC hdc = n_gdi_doublebuffer_init( &db, hwnd, ps.hdc, sx,sy );

		n_win_simplemenu_draw_fade( p, hdc, p->focus );
//n_win_box( hwnd, hdc, NULL, RGB( 0,200,255 ) );

		n_gdi_doublebuffer_exit( &db );


		EndPaint( hwnd, &ps );
	}
	break;

	case WM_PRINTCLIENT :

		if ( n_win_simplemenu_printclient )
		{
			HDC hdc = (HDC) wparam;

//n_win_box( hwnd, hdc, NULL, RGB( 0,200,255 ) );
			n_win_box( hwnd, hdc, NULL, n_win_darkmode_systemcolor( COLOR_BTNFACE ) );

			n_win_simplemenu_draw_fade( p, hdc, p->focus );

			ValidateRect( hwnd, NULL );
		}

	break;


	case WM_KILLFOCUS :
	case WM_ACTIVATE  :
//n_win_simplemenu_debug_count( n_win_hwnd_toplevel( hwnd ) );

		// [!] : never come

	break;


	case WM_CLOSE :

		{

			int mode = n_win_simplemenu_animatewindow_mode();

			if ( mode == N_WIN_ANIMATEWINDOW_MODE_FADE )
			{
				n_win_simplemenu_printclient = n_posix_true;

				p->focus = n_win_simplemenu_hit_index( p, N_WIN_SIMPLEMENU_NOT_SELECTED );

				int aw = n_AW_BLEND | n_AW_HIDE;

				ShowWindow( hwnd, SW_SHOWNA );

				n_win_message_send( hwnd, WM_PAINT, 0, 0 );

				n_win_animatewindow( GetParent( hwnd ), 0, aw );
				n_win_animatewindow(            hwnd  , 0, aw );

				n_win_simplemenu_printclient = n_posix_false;
			}

		}

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
n_win_simplemenu_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_win_simplemenu *p = n_win_simplemenu_target;


	switch( msg ) {


	case WM_CREATE :

		// Global

		n_win_ime_disable( hwnd );

		p->hwnd = hwnd;

		p->is_window = n_posix_true;

		p->   focus = N_WIN_SIMPLEMENU_NOT_SELECTED;
		p->keyfocus = N_WIN_SIMPLEMENU_NOT_SELECTED;
		p->prvfocus = N_WIN_SIMPLEMENU_NOT_SELECTED;


		// Window

		n_win_init_literal( hwnd, "", "", "" );


		// Style

		n_win_style_new( hwnd, WS_POPUP );

		// [Needed] : drop shadow needs topmost window
		n_win_topmost( p->hwnd, n_posix_true );
		n_win_style_dropshadow_onoff( hwnd, n_posix_true );

		// [Needed] : Win2000 : fade needs this
		DragAcceptFiles( hwnd, n_posix_true );

		n_win_on_mousemove_fast_init( hwnd );


		// Size and Display

		n_win_message_send( GetParent( hwnd ), WM_COMMAND, N_WIN_SIMPLEMENU_WPARAM_REARRANGE, hwnd );

		{
			s32 cursor_x,cursor_y; n_win_cursor_position( &cursor_x, &cursor_y );

			n_win w; n_memory_zero( &w, sizeof( n_win ) );

			HDC hdc = GetDC( hwnd );
			s32 sx,sy;
			n_win_simplemenu_draw_calc_all( p, hdc, &sx, NULL );
			n_win_simplemenu_draw_calc    ( p, hdc, NULL, &sy );
			ReleaseDC( hwnd, hdc );

			n_posix_bool is_left_aligned = n_posix_false;
			SystemParametersInfo( SPI_GETMENUDROPALIGNMENT, 0, &is_left_aligned, 0 );
//is_left_aligned = n_posix_false;

			if ( is_left_aligned == n_posix_false )
			{
				w.posx = cursor_x + 1;
				w.posy = cursor_y + 1;
			} else {
				w.posx = cursor_x - sx;
				w.posy = cursor_y;
			}

			s32 desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );


			int mode = n_win_simplemenu_animatewindow_mode();

			if ( mode == N_WIN_ANIMATEWINDOW_MODE_SCRL )
			{

				int aw = n_AW_SLIDE;

				if ( 0 > w.posx )
				{
					w.posx = cursor_x + 1;
					aw = aw | n_AW_HOR_POSITIVE;
				} else
				if ( ( desktop_sx - sx ) < w.posx )
				{
					w.posx = cursor_x - sx;
					aw = aw | n_AW_HOR_NEGATIVE;
				} else {
					if ( is_left_aligned )
					{
						aw = aw | n_AW_HOR_NEGATIVE;
					} else {
						aw = aw | n_AW_HOR_POSITIVE;
					}
				}

				if ( 0 > w.posy )
				{
					w.posy = cursor_y + 1;
					aw = aw | n_AW_VER_POSITIVE;
				} else
				if ( ( desktop_sy - sy ) < w.posy )
				{
					w.posy = cursor_y - sy;
					aw = aw | n_AW_VER_NEGATIVE;
				} else {
					if ( is_left_aligned )
					{
						aw = aw | n_AW_VER_POSITIVE;
					} else {
						aw = aw | n_AW_VER_POSITIVE;
					}
				}

				n_win_set( hwnd, &w, sx,sy, N_WIN_SET_NEEDPOS );


				n_win_simplemenu_printclient = n_posix_true;

				n_posix_bool ret = n_win_animatewindow( hwnd, 0, aw );
				if ( ret ) { ShowWindow( hwnd, SW_SHOWNA ); }

				n_win_simplemenu_printclient = n_posix_false;

			} else
			if ( mode == N_WIN_ANIMATEWINDOW_MODE_FADE )
			{

				w.posx = n_posix_minmax( 0, desktop_sx - sx, w.posx );
				w.posy = n_posix_minmax( 0, desktop_sy - sy, w.posy );

				n_win_set( hwnd, &w, sx,sy, N_WIN_SET_NEEDPOS );


				n_win_simplemenu_printclient = n_posix_true;

				int aw = n_AW_BLEND;

				n_posix_bool ret = n_win_animatewindow( hwnd, 0, aw );
				if ( ret ) { ShowWindow( hwnd, SW_SHOWNA ); }

				n_win_simplemenu_printclient = n_posix_false;

			} else {

				w.posx = n_posix_minmax( 0, desktop_sx - sx, w.posx );
				w.posy = n_posix_minmax( 0, desktop_sy - sy, w.posy );

				n_win_set( hwnd, &w, sx,sy, N_WIN_SET_NEEDPOS );

				ShowWindow( hwnd, SW_SHOWNA );

			}

		}

	break;


	case WM_ERASEBKGND :

		return n_posix_true;

	break;

	case WM_PAINT :
	{
		PAINTSTRUCT ps; BeginPaint( hwnd, &ps );


		s32 sx,sy; n_win_size_client( hwnd, &sx,&sy );

		n_gdi_doublebuffer db; n_gdi_doublebuffer_zero( &db );
		HDC hdc = n_gdi_doublebuffer_init( &db, hwnd, ps.hdc, sx,sy );

		n_win_simplemenu_draw_main( p, hdc );

		n_gdi_doublebuffer_exit( &db );


		EndPaint( hwnd, &ps );
	}
	break;

	case WM_PRINTCLIENT :
//n_win_simplemenu_debug_count( hwnd );

		if ( n_win_simplemenu_printclient )
		{

			HDC hdc = (HDC) wparam;
			n_win_simplemenu_draw_main( p, hdc );
//n_win_box( hwnd, hdc, NULL, RGB( 255,255,255 ) );

/*
			HWND hwnd_desktop = 0;
			HDC   hdc_desktop = GetDC( hwnd_desktop );

			s32  x = 0;
			s32  y = 0;
			s32 sx = 0;
			s32 sy = 0;

			RECT rect_w; GetWindowRect( hwnd, &rect_w );

			x = rect_w.left;
			y = rect_w.top;

			n_win_size_client( hwnd, &sx,&sy );

			BitBlt( hdc, 0,0,sx,sy, hdc_desktop, x,y, SRCCOPY );


			HDC hdc_mem = n_gdi_doublebuffer_32bpp_simple_init( hwnd, sx,sy );

			BitBlt( hdc_mem, 0,0,sx,sy, hdc_desktop, x,y, SRCCOPY );
//n_bmp_save_literal( &n_gdi_doublebuffer_32bpp_instance.bmp, "ret.bmp" );

			n_gdi_doublebuffer_32bpp_simple_cleanup();


			ReleaseDC( hwnd_desktop, hdc_desktop );
*/
		}

	break;


	case WM_LBUTTONDOWN :
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %d ", p->focus );

		if ( n_win_simplemenu_is_clickable( p, p->focus ) )
		{
			n_posix_sleep( 100 );

			n_win_message_post( hwnd, WM_CLOSE, 0,0 );
		} else
		if (
			( n_win_simplemenu_detect_literal( p, p->focus, 'h' ) )
			||
			( n_win_simplemenu_detect_literal( p, p->focus, 'H' ) )
		)
		{
			if ( n_win_simplemenu_detect_literal( p, p->focus, 'h' ) )
			{
				n_win_simplemenu_tweak_literal( p, p->focus, 'H' );
			} else {
				n_win_simplemenu_tweak_literal( p, p->focus, 'h' );
			}

			n_win_simplemenu_resize( p );
		}

	break;

	case WM_KILLFOCUS :
//n_win_simplemenu_debug_count( n_win_hwnd_toplevel( hwnd ) );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %x %x %x ", hwnd, GetParent( hwnd ), n_win_cursor2hwnd() );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %x %x ", wparam, lparam );

		// [!] : this message will never come with SW_SHOWNA

	break;


	case WM_NCACTIVATE :
//n_win_simplemenu_debug_count( n_win_hwnd_toplevel( hwnd ) );

		// [x] : not perfect solution : see n_win_simplemenu_proc()
		//n_win_message_send( GetParent( hwnd ), WM_NCACTIVATE, wparam, lparam );

	break;


	case WM_MOUSEMOVE :
	{
//break;
//LARGE_INTEGER li_f; QueryPerformanceCounter( &li_f );

		if ( p->is_window == n_posix_false ) { break; }


		// [!] : this module is too much heavy
		//n_win_on_mousemove( hwnd );

		// [!] : this module is a little heavy
		n_win_on_mousemove_fast_loop( hwnd );


		int curfocus = n_win_simplemenu_hit_index( p, N_WIN_SIMPLEMENU_NOT_SELECTED );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " %d %d %d ", p->focus, curfocus, p->keyfocus );
		if ( p->focus == curfocus )
		{
//LARGE_INTEGER li_t; QueryPerformanceCounter( &li_t );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " same %d ", li_t.QuadPart - li_f.QuadPart );

			if ( p->keyfocus != N_WIN_SIMPLEMENU_NOT_SELECTED )
			{
				p->keyfocus = N_WIN_SIMPLEMENU_NOT_SELECTED;

				n_win_refresh( hwnd, n_posix_false );
			}

			break;
		}


		if ( p->superfast_onoff == n_posix_false )
		{

			s32 sx,sy; n_win_size_client( hwnd, &sx,&sy );

			HDC hdc = n_gdi_doublebuffer_simple_init( hwnd, sx,sy );


			// Slow Mode

			//n_win_simplemenu_draw_main( p, hdc );


			// Fast Mode : x6 faster

			n_win_simplemenu_draw_fast( p, hdc );


			n_gdi_doublebuffer_simple_exit();

		} else {

			// Super Fast Mode : x10 faster

			p->focus = curfocus;

			if ( p->focus != N_WIN_SIMPLEMENU_NOT_SELECTED )
			{
				HDC hdc = n_gdi_doublebuffer_simple_init( hwnd, p->hsx,p->hsy );

				s32 xx = 0;
				if (
					( n_win_simplemenu_detect_literal( p, p->focus, 'h' ) )
					||
					( n_win_simplemenu_detect_literal( p, p->focus, 'H' ) )
					||
					( n_win_simplemenu_detect_literal( p, p->focus, '-' ) )
				)
				{
					xx = p->border;
				}

				HDC hdc_main = n_gdi_doublebuffer_instance.hdc;

				n_win_simplemenu_draw_line( p, hdc, p->focus, n_posix_true );

				//n_bmp *bmp = &n_gdi_doublebuffer_instance.bmp;
				//n_gdi_bitmap_draw_main( hwnd, hdc_main, bmp, xx,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), p->hx + xx,p->hy );
//n_bmp_save_literal( bmp, "ret.bmp" );

				BitBlt( hdc_main, p->hx + xx,p->hy,p->hsx,p->hsy, hdc, xx,0, SRCCOPY );

				n_gdi_doublebuffer_simple_cleanup();
			}
//break;

			if ( p->prvfocus != N_WIN_SIMPLEMENU_NOT_SELECTED )
			{
				HDC hdc = n_gdi_doublebuffer_simple_init( hwnd, p->psx,p->psy );

				// [Needed] : High-DPI
				n_win_box( hwnd, hdc, NULL, p->color_bg );

				s32 xx = 0;
				if (
					( n_win_simplemenu_detect_literal( p, p->prvfocus, 'h' ) )
					||
					( n_win_simplemenu_detect_literal( p, p->prvfocus, 'H' ) )
					||
					( n_win_simplemenu_detect_literal( p, p->prvfocus, '-' ) )
				)
				{
					xx = p->border;
				}

				HDC hdc_main = n_gdi_doublebuffer_instance.hdc;

				n_win_simplemenu_draw_line( p, hdc, p->prvfocus, n_posix_false );

				//n_bmp *bmp = &n_gdi_doublebuffer_instance.bmp;
				//n_gdi_bitmap_draw_main( hwnd, hdc_main, bmp, xx,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), p->px + xx,p->py );
//n_bmp_save_literal( bmp, "ret.bmp" );

				BitBlt( hdc_main, p->px + xx,p->py,p->psx,p->psy, hdc, xx,0, SRCCOPY );

				n_gdi_doublebuffer_simple_cleanup();
			}


			p->prvfocus = curfocus;
			p->px       = p->hx;
			p->py       = p->hy;
			p->psx      = p->hsx;
			p->psy      = p->hsy;

		}


//LARGE_INTEGER li_t; QueryPerformanceCounter( &li_t );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " fast %d ", li_t.QuadPart - li_f.QuadPart );
	}
	break;

	case WM_MOUSEHOVER :

		// [!] : WM_MOUSELEAVE is needed but WM_MOUSEMOVE is faster than WM_MOUSEHOVER

	break;

	case WM_MOUSELEAVE :

		if ( p->is_window == n_posix_false ) { break; }

		p->focus = p->prvfocus = N_WIN_SIMPLEMENU_NOT_SELECTED;
		n_win_refresh( hwnd, n_posix_false );

	break;


	case WM_CLOSE :

		if ( p->is_window == n_posix_false ) { break; }

		p->is_window = n_posix_false;


		if ( n_win_simplemenu_is_escaped == n_posix_false )
		{
			n_posix_bool ret = n_win_message_send( GetParent( hwnd ), WM_COMMAND, p->focus, hwnd );
			if ( ret )
			{
				n_win_message_send( GetParent( hwnd ), WM_COMMAND, N_WIN_SIMPLEMENU_WPARAM_REARRANGE, hwnd );

				n_win_refresh( hwnd, n_posix_false );

				p->is_window = n_posix_true;

				return 0;
			}
		} else {
			n_win_simplemenu_is_escaped = n_posix_false;
		}


		n_win_on_mousemove_fast_exit( hwnd );


		if ( p->silent_onoff == n_posix_false )
		{

			if ( p->callback != NULL ) { p->callback( p->callback_data ); }


			int mode = n_win_simplemenu_animatewindow_mode();

			if ( mode == N_WIN_ANIMATEWINDOW_MODE_FADE )
			{
				n_win_simplemenu_printclient = n_posix_true;

				if ( p->focus != N_WIN_SIMPLEMENU_NOT_SELECTED )
				{
					n_win_gui( hwnd, N_WIN_GUI_WINDOW, n_win_simplemenu_fade_wndproc, &p->hwnd_fade );
					n_win_message_send( p->hwnd_fade, WM_CLOSE, 0, 0 );
				} else {
					int aw = n_AW_BLEND | n_AW_HIDE;
					n_win_animatewindow( hwnd, 0, aw );
				}

				n_win_simplemenu_printclient = n_posix_false;
			}

		} else {

			p->silent_onoff = n_posix_false;

		}


		n_win_simplemenu_cleanup( p );


		n_win_simplemenu_target = NULL;


		n_win_property_exit_literal( GetParent( hwnd ), "Nonnon.Win32.SimpleMenu.Lock" );
		n_win_property_init_literal( GetParent( hwnd ), "Nonnon.Win32.SimpleMenu.Lock", n_posix_true );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	case WM_MOUSEACTIVATE :

		return MA_NOACTIVATE;

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_win_simplemenu_keybinding_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_simplemenu *s )
{

	n_win_simplemenu *p = n_win_simplemenu_target;
	if ( p == NULL ) { return; }

	if ( p != s ) { return; }


	switch( msg ) {


	case WM_SYSKEYDOWN :
//n_win_simplemenu_debug_count( n_win_hwnd_toplevel( hwnd ) );

		if ( n_posix_false == IsWindow( p->hwnd ) ) { break; }

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %d ", wparam );

		if ( wparam == VK_MENU )
		{
			n_win_simplemenu_is_escaped = n_posix_true;
			n_win_message_post( p->hwnd, WM_CLOSE, 0, 0 );
		}

	break;


	case WM_KEYDOWN :
//n_win_simplemenu_debug_count( n_win_hwnd_toplevel( hwnd ) );

		if ( n_posix_false == IsWindow( p->hwnd ) ) { break; }

		// [!] : VK_MENU : never come : see above WM_SYSKEYDOWN
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %d ", wparam );

		if ( wparam == VK_UP )
		{

			if ( p->keyfocus == N_WIN_SIMPLEMENU_NOT_SELECTED )
			{
				if ( p->focus == N_WIN_SIMPLEMENU_NOT_SELECTED )
				{
					p->keyfocus = 0;
				} else {
					p->keyfocus = p->focus - 1;
					if ( p->focus < 0 ) { p->keyfocus = p->str.sy - 1; }
				}

				n_win_refresh( p->hwnd, n_posix_false );

				break;
			}

			if ( p->keyfocus == -2 ) { p->keyfocus = p->str.sy - 1; n_win_refresh( p->hwnd, n_posix_false ); break; }

			p->keyfocus--;
			if ( p->keyfocus < 0 )
			{
				p->keyfocus = -2;
			} else
			if ( n_win_simplemenu_detect_literal( p, p->keyfocus, '-' ) )
			{
				p->keyfocus--;
				if ( p->keyfocus < 0 )
				{
					p->keyfocus = -2;
				}
			} else {
				int i = p->keyfocus;
				while( 1 )
				{
					if ( i < 0 ) { break; }

					if ( n_win_simplemenu_detect_literal( p, i, 'h' ) )
					{
						p->keyfocus = i;
						break;
					} else
					if ( n_win_simplemenu_detect_literal( p, i, 'H' ) )
					{
						break;
					}

					i--;
				}
			}

			n_win_refresh( p->hwnd, n_posix_false );

		} else
		if ( wparam == VK_DOWN )
		{

			if ( p->keyfocus == N_WIN_SIMPLEMENU_NOT_SELECTED )
			{
				if ( p->focus == N_WIN_SIMPLEMENU_NOT_SELECTED )
				{
					p->keyfocus = 0;
				} else {
					p->keyfocus = p->focus + 1;
					if ( p->focus >= p->str.sy ) { p->keyfocus = 0; }
				}

				n_win_refresh( p->hwnd, n_posix_false );

				break;
			}

			if ( p->keyfocus == -2 ) { p->keyfocus = 0; n_win_refresh( p->hwnd, n_posix_false ); break; }

			p->keyfocus++;
			if ( p->keyfocus >= p->str.sy )
			{
				p->keyfocus = -2;
			} else {
				if ( n_win_simplemenu_detect_literal( p, p->keyfocus - 1, 'h' ) )
				{
					while( 1 )
					{
						if ( p->keyfocus >= p->str.sy ) { p->keyfocus = -2; break; }

						if (
							( n_win_simplemenu_detect_literal( p, p->keyfocus, 'h' ) )
							||
							( n_win_simplemenu_detect_literal( p, p->keyfocus, 'H' ) )
						)
						{
							//p->keyfocus++;
							break;
						}

						p->keyfocus++;
					}
				} else
				if ( n_win_simplemenu_detect_literal( p, p->keyfocus, '-' ) )
				{
					p->keyfocus++;
					if ( p->keyfocus >= p->str.sy )
					{
						p->keyfocus = -2;
					}
				}
			}

			n_win_refresh( p->hwnd, n_posix_false );

		} else
		if ( wparam == VK_RETURN )
		{

			p->focus = p->keyfocus;

			if (
				( n_win_simplemenu_detect_literal( p, p->focus, 'h' ) )
				||
				( n_win_simplemenu_detect_literal( p, p->focus, 'H' ) )
			)
			{
				if ( n_win_simplemenu_detect_literal( p, p->focus, 'h' ) )
				{
					n_win_simplemenu_tweak_literal( p, p->focus, 'H' );
				} else {
					n_win_simplemenu_tweak_literal( p, p->focus, 'h' );
				}
				n_win_simplemenu_resize( p );
			} else {
				// [Needed] : send only
				n_win_message_send( p->hwnd, WM_CLOSE, 0, 0 );
			}

		} else
		if ( wparam == VK_ESCAPE )
		{

			n_win_simplemenu_is_escaped = n_posix_true;
			n_win_message_post( p->hwnd, WM_CLOSE, 0, 0 );

		}

	break;


	} // switch


	return;
}

void
n_win_simplemenu_proc( HWND hwnd, UINT msg, WPARAM *wparam, LPARAM *lparam, n_win_simplemenu *p )
{

	if ( p == NULL ) { p = n_win_simplemenu_target; }
	if ( p == NULL ) { return; }


	switch( msg ) {


	case WM_NCLBUTTONDOWN :

		if ( (*wparam) != HTCLOSE )
		{
			n_win_simplemenu_close( n_win_simplemenu_target );
		}

	break;

	case WM_LBUTTONDOWN :

		n_win_simplemenu_close( n_win_simplemenu_target );

	break;

	case WM_ACTIVATE :

		if ( (*wparam) == WA_INACTIVE )
		{
			n_win_simplemenu_close( n_win_simplemenu_target );
			n_win_message_send( hwnd, WM_NCACTIVATE, n_posix_false, 0 );
		}

	break;

/*
	case WM_NCACTIVATE :

		if ( (*wparam) == n_posix_false )
		{
			(*wparam) = IsWindow( p->hwnd );
		}

	break;
*/
	} // switch


	n_win_simplemenu_keybinding_proc( hwnd, msg, *wparam, *lparam, p );


	// [!] : restoring is needed when menu is closed
/*
	static n_posix_bool onoff = n_posix_false;

	if ( IsWindow( p->hwnd ) )
	{

		onoff = n_posix_true;

	} else 
	if ( onoff )
	{

		onoff = n_posix_false;

		if ( hwnd != GetFocus() )
		{
			//n_win_message_send( hwnd, WM_NCACTIVATE, n_posix_false, 0 );
		}

	}
*/

	return;
}

void
n_win_simplemenu_show( n_win_simplemenu *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return; }


	if ( n_win_simplemenu_target != NULL )
	{
		if ( IsWindow( n_win_simplemenu_target->hwnd ) )
		{
			n_win_message_send( n_win_simplemenu_target->hwnd, WM_CLOSE, 0, 0 );
		}
	}


	if ( n_vector_is_empty( &p->str ) ) { return; }


	n_win_simplemenu_target = p;

	n_win_gui( hwnd_parent, N_WIN_GUI_WINDOW, n_win_simplemenu_wndproc, &p->hwnd );


	return;
}

void
n_win_simplemenu_hide( n_win_simplemenu *p )
{

	if ( p == NULL ) { return; }


	if ( IsWindow( p->hwnd ) )
	{
		n_win_message_send( p->hwnd, WM_CLOSE, 0, 0 );
	}


	return;
}


#endif // _H_NONNON_WIN32_SIMPLEMENU


