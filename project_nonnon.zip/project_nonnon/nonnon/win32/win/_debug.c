// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_DEBUG
#define _H_NONNON_WIN32_WIN_DEBUG




#include "../../neutral/posix.c"
#include "../../neutral/string.c"


#include "../registry.c"


#include "../sysinfo/version.c"


#include "./mutex.c"




n_posix_bool
n_win_is_lefthanded( void )
{

	n_posix_bool ret = n_posix_false;


	n_posix_bool align = n_posix_true;

	if ( GetSystemMetrics( SM_TABLETPC ) )
	{
		SystemParametersInfo( SPI_GETMENUDROPALIGNMENT, 0, &align, 0 );
	}

	if ( ( GetSystemMetrics( SM_SWAPBUTTON ) )||( align == n_posix_false ) )
	{
		ret = n_posix_true;
	}


	return ret;
}




// [Mechanism]
//
//	ANSI + ASCII : byte count == character count
//	ANSI + DBCS  : byte count != character count
//      UNICODE      : character count

// [!] : n_win_text_get() needs ( length + NUL('\0') )

#define n_win_text_len( h     )        GetWindowTextLength( h )
#define n_win_text_cch( h     )        GetWindowTextLength( h )
#define n_win_text_get( h,s,l )        GetWindowText( h, s, l )
#define n_win_text_set( h,s   )        SetWindowText( h, s )
#define n_win_text_set_literal( h, s ) SetWindowText( h, n_posix_literal( s ) )

n_posix_char*
n_win_text_new( HWND hgui )
{

	// [!] : n_string_free()/n_string_path_free() a returned string

	int           cch = n_win_text_cch( hgui );
	n_posix_char *str = n_string_new( cch );


	n_win_text_get( hgui, str, cch + 1 );


	return str;
}




// [Mechanism]
//
//	use n_posix_false first, if not function, then use n_posix_true

//#define n_win_refresh( h, b ) InvalidateRect( h, NULL, b )

void
n_win_refresh( HWND hwnd, n_posix_bool strong_mode )
{

	if ( hwnd == NULL ) { return; }
	if ( n_posix_false == IsWindow( hwnd ) ) { return; }


	InvalidateRect( hwnd, NULL, strong_mode );


	return;
}




#define n_win_hwndprintf_literal( h, f, ... ) n_win_hwndprintf( h, n_posix_literal( f ), ##__VA_ARGS__ )

void
n_win_hwndprintf( HWND hwnd, const n_posix_char *format, ... )
{

	n_posix_char str[ 1024 ];


	va_list vl;


	va_start( vl, format );

	n_posix_vsprintf( str, format, vl );

	va_end( vl );


	n_win_text_set( hwnd, str );


	return;
}

// internal
void
n_win_debug_count( HWND hwnd )
{

	static int i = 0;

	n_win_hwndprintf_literal( hwnd, "%d", i );

	i++;

	return;
}

#define n_win_hwnd_find(         h_parent, class_name ) FindWindowEx( h_parent, NULL,                  class_name  , NULL )
#define n_win_hwnd_find_literal( h_parent, class_name ) FindWindowEx( h_parent, NULL, n_posix_literal( class_name ), NULL )

HWND
n_win_hwnd_toplevel( HWND hwnd )
{

	// [!] : Win95 hasn't GetAncestor()

	while( 1 )
	{
		if ( NULL == GetParent( hwnd ) ) { break; }

		hwnd = GetParent( hwnd );
	}


	return hwnd;
}

HWND
n_win_hwnd_window( HWND hwnd )
{

	while( 1 )
	{//break;
		if ( hwnd == NULL ) { break; }

		if ( n_posix_false == ( WS_CHILD & GetWindowLong( hwnd, GWL_STYLE ) ) ) { break; }

		 hwnd = GetParent( hwnd );
	}

	return hwnd;
}

void
n_win_mouse_threshold( HWND hwnd, int *ret_x, int *ret_y )
{

	double dx = 1;
	double dy = 1;

	{
		// [Needed] : multi-thread

		HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_mouse_threshold()" );


		HDC hdc = GetDC( hwnd );

		int dpi_x = GetDeviceCaps( hdc, LOGPIXELSX );
		int dpi_y = GetDeviceCaps( hdc, LOGPIXELSY );
//n_win_hwndprintf_literal( hwnd, "%d %d", dpi_x, dpi_y );

		ReleaseDC( hwnd, hdc );

		dx = (double) dpi_x / 96;
		dy = (double) dpi_y / 96;


		hmutex = n_win_mutex_exit( hmutex );

	}


	// [!] : 4px will be returned
	//
	//	no change in a high-DPI setting

	const int threshold_sx = GetSystemMetrics( SM_CXDOUBLECLK );
	const int threshold_sy = GetSystemMetrics( SM_CYDOUBLECLK );
//n_win_hwndprintf_literal( hwnd, " %d %d ", threshold_sx, threshold_sy );


	int threshold_x = (int) ( (double) threshold_sx * dx );
	int threshold_y = (int) ( (double) threshold_sy * dy );
//n_win_hwndprintf_literal( hwnd, " %d %d ", threshold_x, threshold_y );


	if ( ret_x != NULL ) { (*ret_x) = threshold_x; }
	if ( ret_y != NULL ) { (*ret_y) = threshold_y; }


	return;
}

#define n_win_desktop_size(          sx, sy ) n_win_desktop_size_internal( sx, sy, n_posix_true  )
#define n_win_desktop_size_no_patch( sx, sy ) n_win_desktop_size_internal( sx, sy, n_posix_false )

void
n_win_desktop_size_internal( s32 *sx, s32 *sy, n_posix_bool patch_onoff )
{

	s32 desktop_sx = GetSystemMetrics( SM_CXMAXIMIZED );
	s32 desktop_sy = GetSystemMetrics( SM_CYMAXIMIZED );


	// [!] : magic!

	desktop_sx -= GetSystemMetrics( SM_CXSIZEFRAME ) * 2;
	desktop_sy -= GetSystemMetrics( SM_CYSIZEFRAME ) * 2;


#ifdef _MSC_VER

	// [x] : broken

	if ( patch_onoff )
	{
		desktop_sx -= GetSystemMetrics( SM_CXSIZEFRAME ) * 2;
		desktop_sy -= GetSystemMetrics( SM_CYSIZEFRAME ) * 2;
	}

#endif // #ifdef _MSC_VER


//n_txt_debug_printf_literal( "%d %d", desktop_sx, desktop_sy );

	if ( sx != NULL ) { *sx = desktop_sx; }
	if ( sy != NULL ) { *sy = desktop_sy; }


	return;
}

int
n_win_desktop_bpp( void )
{

	// [Needed] : multi-thread

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_desktop_bpp()" );


	HWND hwnd = GetDesktopWindow();
	HDC  hdc  = GetDC( hwnd );

	int bpp = GetDeviceCaps( hdc, BITSPIXEL );

	ReleaseDC( hwnd, hdc );


	hmutex = n_win_mutex_exit( hmutex );


	return bpp;
}

n_posix_bool
n_win_fade_is_on( void )
{

	n_posix_bool onoff = n_posix_false;


	if ( n_sysinfo_version_vista_or_later() )
	{
		int n_SPI_GETCLIENTAREAANIMATION = 0x1042;
		SystemParametersInfo( n_SPI_GETCLIENTAREAANIMATION, 0, &onoff, 0 );
	} else {
		// [!] : Win2000/XP : SPI_GETMENUFADE returns n_posix_false
		SystemParametersInfo(   SPI_GETSELECTIONFADE      , 0, &onoff, 0 );//SPI_GETMENUFADE
	}


	return onoff;
}

int
n_win_dpi( HWND hwnd )
{

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_dpi()" );


	HDC hdc = GetDC( hwnd );

	int dpi_x = GetDeviceCaps( hdc, LOGPIXELSX );

	ReleaseDC( hwnd, hdc );


	hmutex = n_win_mutex_exit( hmutex );


	return dpi_x;
}

double
n_win_scale( HWND hwnd )
{
	return (double) n_win_dpi( hwnd ) / 96;
}

void
n_win_clear( HWND hwnd, HDC hdc, const RECT *r, int color_id )
{

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_clear()" );


	// [MSDN] : don't do DeleteObject()

	n_posix_bool onoff = ( hdc == NULL );

	if ( onoff ) { hdc = GetDC( hwnd ); }

	FillRect( hdc, r, GetSysColorBrush( color_id ) );

	if ( onoff ) { ReleaseDC( hwnd, hdc ); }


	hmutex = n_win_mutex_exit( hmutex );


	return;
}

void
n_win_box( HWND hwnd, HDC hdc, const RECT *rect, COLORREF color )
{

	// [!] : Classic Theme : alpha value causes black-out

	color &= 0x00ffffff;


	// [Needed] : multi-thread

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_box()" );


	n_posix_bool onoff = ( hdc == NULL );

	if ( onoff ) { hdc = GetDC( hwnd ); }

	HBRUSH hb = CreateSolidBrush( color );

	RECT rc; if ( rect == NULL ) { GetClientRect( hwnd, &rc ); } else { rc = (*rect); }

	FillRect( hdc, &rc, hb );

	DeleteObject( hb );

	if ( onoff ) { ReleaseDC( hwnd, hdc ); }


	hmutex = n_win_mutex_exit( hmutex );


	return;
}

void
n_win_frame( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, COLORREF color )
{

	// [!] : Classic Theme : alpha value causes black-out

	color &= 0x00ffffff;


	s32 fx,fy,tx,ty;


	HGDIOBJ hp = SelectObject( hdc, CreatePen( PS_SOLID, 1, color ) );


	// Top-Bottom

	fx = x; tx = fx + sx;

	fy = y; ty = fy;
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	ExcludeClipRect( hdc, fx,fy,tx,ty+1 );

	fy = y + sy - 1; ty = fy;
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	ExcludeClipRect( hdc, fx,fy,tx,ty+1 );


	// Left-Right

	fy = y; ty = fy + sy;

	fx = x; tx = fx;
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	ExcludeClipRect( hdc, fx,fy,tx+1,ty );

	fx = x + sx - 1; tx = fx;
	MoveToEx( hdc, fx,fy, NULL ); LineTo( hdc, tx,ty );
	ExcludeClipRect( hdc, fx,fy,tx+1,ty );


	DeleteObject( SelectObject( hdc, hp ) );


	return;
}

#define n_win_location( h, x, y, sx, sy ) n_win_location_relative( GetParent( h ), h,    x,    y,   sx,   sy )
#define n_win_position( h, x, y         ) n_win_location_relative( GetParent( h ), h,    x,    y, NULL, NULL )
#define n_win_size(     h,       sx, sy ) n_win_location_relative( GetParent( h ), h, NULL, NULL,   sx,   sy )

#define n_win_position_relative( p, h, x, y ) n_win_location_relative( p, h, x, y, NULL, NULL )

void
n_win_location_relative( HWND hwnd_parent, HWND hwnd_child, s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	// [!] : frame border is included

	RECT r; GetWindowRect( hwnd_child, &r );

	POINT pt_tl = { r.left,  r.top    }; ScreenToClient( hwnd_parent, &pt_tl );
	POINT pt_br = { r.right, r.bottom }; ScreenToClient( hwnd_parent, &pt_br );

	if (  x != NULL ) { (* x) = pt_tl.x;           }
	if (  y != NULL ) { (* y) = pt_tl.y;           }
	if ( sx != NULL ) { (*sx) = pt_br.x - pt_tl.x; }
	if ( sy != NULL ) { (*sy) = pt_br.y - pt_tl.y; }


	return;
}




#define N_WIN_CLASS_CCH ( 256 + 1 )

void
n_win_class( HWND hwnd, n_posix_char *class_name )
{

	GetClassName( hwnd, class_name, N_WIN_CLASS_CCH );

	return;
}

#define n_win_class_is_same_literal( hwnd, class_name ) n_win_class_is_same( hwnd, n_posix_literal( class_name ) )

n_posix_bool
n_win_class_is_same( HWND hwnd, const n_posix_char *class_name )
{

	// [Needed] : n_string_truncate() : GetClassName() will not touch "str_class" when hwnd is NULL

	n_posix_char str_class[ N_WIN_CLASS_CCH ]; n_string_truncate( str_class );

	n_win_class( hwnd, str_class );

	if ( n_string_is_same( class_name, str_class ) )
	{
		return n_posix_true;
	}


	return n_posix_false;
}


#endif // _H_NONNON_WIN32_WIN_DEBUG

