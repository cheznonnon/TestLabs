// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : you can also use <windowsx.h> macro collection




#ifndef _H_NONNON_WIN32_WIN_CONTROL
#define _H_NONNON_WIN32_WIN_CONTROL




#include "./_debug.c"
#include "./message.c"




// All

#define n_win_param_hilo( hi, lo ) MAKEWPARAM( lo, hi )




// BUTTON

#define n_win_checkbox_get( h       ) n_win_message_send( h, BM_GETSTATE,   0, 0 )
#define n_win_checkbox_set( h,  bst ) n_win_message_send( h, BM_SETCHECK, bst, 0 )

#define n_win_checkbox_is_set( h ) ( BST_CHECKED == ( 3 & n_win_checkbox_get( h ) ) )

#define n_win_checkbox_add( h ) n_win_checkbox_set( h, BST_CHECKED   )
#define n_win_checkbox_del( h ) n_win_checkbox_set( h, BST_UNCHECKED )

#define n_win_radiobutton_get    n_win_checkbox_get
#define n_win_radiobutton_set    n_win_checkbox_set
#define n_win_radiobutton_is_set n_win_checkbox_is_set
#define n_win_radiobutton_add    n_win_checkbox_add
#define n_win_radiobutton_del    n_win_checkbox_del




// EDIT

#define n_win_edit_margin_set( h, l,r ) n_win_message_send( h, EM_SETMARGINS, EC_USEFONTINFO, n_win_param_hilo( r, l ) );

#define n_win_edit_caret_get(      h, f,t ) n_win_message_send( h, EM_GETSEL,      f, t )
#define n_win_edit_caret_set(      h, f,t ) n_win_message_send( h, EM_SETSEL,      f, t )
#define n_win_edit_caret_automove( h      ) n_win_message_send( h, EM_SCROLLCARET, 0, 0 )

void
n_win_edit_caret_eol( HWND hwnd )
{

	n_type_int len = n_win_text_len( hwnd );


	n_win_edit_caret_set( hwnd, len, len );


	return;
}

#define n_win_edit_line_cch( h, line ) n_win_message_send( h, EM_LINEINDEX,           line,   0 )
#define n_win_edit_line_top( h       ) n_win_message_send( h, EM_GETFIRSTVISIBLELINE,    0,   0 )
#define n_win_edit_line_cur( h       ) n_win_message_send( h, EM_LINEFROMCHAR,          -1,   0 )
#define n_win_edit_line_max( h       ) n_win_message_send( h, EM_GETLINECOUNT,           0,   0 )

#define n_win_edit_line_insert( h,  str ) n_win_message_send( h, EM_REPLACESEL, n_posix_true, str )

void
n_win_edit_line_get( HWND h, n_type_int line, n_posix_char *str, n_type_int size )
{

	if ( str == NULL ) { return; }


	WORD *w = (WORD*) str;


	// [!] : Tricky

	w[ 0 ] = (WORD) size;


	n_win_message_send( h, EM_GETLINE, line, str );


	return;
}




// COMBOBOX

#define n_win_combobox_index(  h      ) n_win_message_send( h, CB_GETCURSEL,       0,   0 )
#define n_win_combobox_find(   h, str ) n_win_message_send( h, CB_FINDSTRINGEXACT, 0, str )
#define n_win_combobox_get(    h, str ) n_win_message_send( h, CB_GETLBTEXT,       n_win_combobox_index( h      ), str )
#define n_win_combobox_set(    h, str ) n_win_message_send( h, CB_ADDSTRING,       0, str )
#define n_win_combobox_select( h, str ) n_win_message_send( h, CB_SETCURSEL,       n_win_combobox_find(  h, str ),   0 )
#define n_win_combobox_delete( h, str ) n_win_message_send( h, CB_DELETESTRING,    n_win_combobox_find(  h, str ),   0 )
#define n_win_combobox_reset(  h      ) n_win_message_send( h, CB_RESETCONTENT,    0,   0 )

#define n_win_combobox_find_literal(   h, str ) n_win_combobox_find(   h, n_posix_literal( str ) )
#define n_win_combobox_set_literal(    h, str ) n_win_combobox_set(    h, n_posix_literal( str ) )
#define n_win_combobox_select_literal( h, str ) n_win_combobox_select( h, n_posix_literal( str ) )
#define n_win_combobox_delete_literal( h, str ) n_win_combobox_delete( h, n_posix_literal( str ) )




// LISTBOX

#define n_win_listbox_index(  h      ) n_win_message_send( h, LB_GETCURSEL,       0,   0 )
#define n_win_listbox_find(   h, str ) n_win_message_send( h, LB_FINDSTRINGEXACT, 0, str )
#define n_win_listbox_cch(    h      ) n_win_message_send( h, LB_GETTEXTLEN,      n_win_listbox_index( h      ),   0 )
#define n_win_listbox_get(    h, str ) n_win_message_send( h, LB_GETTEXT,         n_win_listbox_index( h      ), str )
#define n_win_listbox_set(    h, str ) n_win_message_send( h, LB_ADDSTRING,       0, str )
#define n_win_listbox_select( h, str ) n_win_message_send( h, LB_SETCURSEL,       n_win_listbox_find(  h, str ),   0 )
#define n_win_listbox_delete( h, str ) n_win_message_send( h, LB_DELETESTRING,    n_win_listbox_find(  h, str ),   0 )
#define n_win_listbox_reset(  h      ) n_win_message_send( h, LB_RESETCONTENT,    0,   0 )

#define n_win_listbox_set_firstitem( h ) n_win_message_send( h, LB_SETCURSEL, 0, 0 )

#define n_win_listbox_find_literal(   h, str ) n_win_listbox_find(   h, n_posix_literal( str ) )
#define n_win_listbox_set_literal(    h, str ) n_win_listbox_set(    h, n_posix_literal( str ) )
#define n_win_listbox_select_literal( h, str ) n_win_listbox_select( h, n_posix_literal( str ) )
#define n_win_listbox_delete_literal( h, str ) n_win_listbox_delete( h, n_posix_literal( str ) )

n_posix_char*
n_win_listbox_item_new( HWND hgui )
{

	// [!] : n_string_free()/n_string_path_free() a returned string

	n_type_int    cch = n_win_listbox_cch( hgui );
	n_posix_char *str = n_string_new( cch );


	n_win_listbox_get( hgui, str );


	return str;
}




#endif // _H_NONNON_WIN32_WIN_CONTROL

