// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_FLUENT_UI
#define _H_NONNON_WIN32_WIN_FLUENT_UI




#include "./dwm.c"
#include "./style.c"




#define N_WIN_FLUENT_UI_OVERRIDE ( 2 )




static n_posix_bool n_win_fluent_ui_onoff = n_posix_false;




void
n_win_fluent_ui( void )
{

	if ( n_win_style_is_classic() )
	{
		n_win_fluent_ui_onoff = n_posix_false;
	} else {
		n_win_fluent_ui_onoff = n_posix_true;
	}


	return;
}

u32
n_win_fluent_ui_accent_color( void )
{

	u32 fg = n_win_dwm_windowcolor();
	u32 bg = n_bmp_lightness_replace_pixel( fg, 111 );


	return bg;
}

s32
n_win_fluent_ui_round_param( void )
{
	return (double) 4 * ( (double) n_win_dpi( NULL ) / 96 );
}




#endif // _H_NONNON_WIN32_WIN_FLUENT_UI

