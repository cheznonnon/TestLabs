// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_FLUENT_UI
#define _H_NONNON_WIN32_WIN_FLUENT_UI




#include "../../neutral/bmp/detect.c"


#include "./dwm.c"
#include "./style.c"




#define N_WIN_FLUENT_UI_OVERRIDE ( 2 )




static n_posix_bool n_win_fluent_ui_onoff = n_posix_false;




void
n_win_fluent_ui( void )
{

	if ( n_win_style_is_classic() )
	{
		n_win_fluent_ui_onoff = n_posix_false;
	} else {
		n_win_fluent_ui_onoff = n_posix_true;
	}


	return;
}

u32
n_win_fluent_ui_accent_color( void )
{

	u32 fg = n_win_dwm_windowcolor();
	u32 bg = n_bmp_lightness_replace_pixel( fg, 111 );


	return bg;
}

s32
n_win_fluent_ui_round_param( void )
{
	return (double) 4 * ( (double) n_win_dpi( NULL ) / 96 );
}

void
n_win_fluent_ui_draw_roundrect( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, int round, COLORREF color, double alpha )
{

	// [!] : this module is heavy

	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{//break;

		double coeff = 0;
		n_bmp_roundrect_detect_coeff( tx, ty, sx, sy, round, &coeff );

		COLORREF c = GetPixel ( hdc, x + tx, y + ty    );

		c = n_win_color_blend( c, color, coeff * alpha );

		             SetPixelV( hdc, x + tx, y + ty, c );


		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}

#define n_win_fluent_ui_bmp_roundframe(        bmp, x,y,sx,sy, r,f, fg,bg, msk, blend ) n_win_fluent_ui_bmp_roundframe_main( bmp, x,y,sx,sy, r,f, fg,bg, msk, NULL, blend )
#define n_win_fluent_ui_bmp_roundframe_bitmap( bmp, x,y,sx,sy, r,f, fg,bg, msk, blend ) n_win_fluent_ui_bmp_roundframe_main( bmp, x,y,sx,sy, r,f, fg,bg,   0,  msk, blend )

// internal
void
n_win_fluent_ui_bmp_roundframe_main
(
	n_bmp  *bmp,
	s32     x, s32 y, s32 sx, s32 sy,
	s32     round_size,
	s32     frame_size,
	u32     color_fg,
	u32     color_bg,
	u32     cornermask_color,
	n_bmp  *cornermask_bmp,
	double  blend
)
{

	if ( n_bmp_error( bmp ) ) { return; }

	if ( sx == -1 ) { sx = N_BMP_SX( bmp ); }
	if ( sy == -1 ) { sy = N_BMP_SY( bmp ); }


	if ( cornermask_bmp != NULL )
	{
		n_bmp_flush_fastcopy( cornermask_bmp, bmp );
	}


	s32 m = 0;

	n_bmp_roundrect_main( bmp, x + m, y + m, sx - ( m * 2 ), sy - ( m * 2 ), color_fg, round_size, 0, blend );

	if ( frame_size )
	{
		m += frame_size;

		double coeff = (double) 0.1 * round_size;
		n_bmp_roundrect_main( bmp, x + m, y + m, sx - ( m * 2 ), sy - ( m * 2 ), color_bg, round_size, coeff, blend );
	}


	if ( cornermask_bmp == NULL )
	{
		n_bmp_cornermask( bmp, round_size, 0, cornermask_color );
	}


	return;
}




#endif // _H_NONNON_WIN32_WIN_FLUENT_UI

