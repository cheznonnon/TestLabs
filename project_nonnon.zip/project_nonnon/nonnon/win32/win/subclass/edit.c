// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#ifndef _H_NONNON_WIN32_WIN_SUBCLASS_EDIT
#define _H_NONNON_WIN32_WIN_SUBCLASS_EDIT




#include "../../gdi/doublebuffer.c"


#include "../../sysinfo/version.c"


#include "../_debug.c"
#include "../dwm.c"
#include "../rect.c"
#include "../property.c"
#include "../style.c"




#include <imm.h>




LRESULT CALLBACK
#ifdef _WIN64
n_win_subclass_edit_doublebuffer( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_subclass_edit_doublebuffer( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	//
#else  // #ifdef _WIN64
	const WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "n_win_subclass_edit_doublebuffer()" );
	if ( pfunc == NULL ) { return 0; }
#endif // #ifdef _WIN64


	switch( msg ) {


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	{

		// [x] : DwmExtendFrameIntoClientArea() : misbehave while selection
		//
		//	[ Not Function Here ]
		//
		//	SetBkColor() SetTextColor()
		//	HPEN HBRUSH


		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );


		RECT       r;     GetClientRect( hwnd, &r );
		n_type_gfx sx,sy; n_win_rect_expand_size( &r, NULL, NULL, &sx, &sy );


		HDC hdc = n_gdi_doublebuffer_simple_init( hwnd, sx,sy );


		DWORD style = n_win_style_get( hwnd );

		if ( ( style & ES_READONLY )||( n_posix_false == IsWindowEnabled( hwnd ) ) )
		{
			n_win_message_send( GetParent( hwnd ), WM_CTLCOLORSTATIC, hdc, hwnd );
		} else {
			n_win_message_send( GetParent( hwnd ), WM_CTLCOLOREDIT,   hdc, hwnd );
		}

		n_gdi_doublebuffer_simple_fill( GetBkColor( hdc ) );


		n_win_message_send( hwnd, WM_PRINTCLIENT, hdc, 0 );


		n_gdi_doublebuffer_simple_visible();

		n_type_gfx tx,ty,tsx,tsy; n_win_rect_expand_size( &ps.rcPaint, &tx,&ty,&tsx,&tsy );
		n_gdi_doublebuffer_simple_exit_partial( tx,ty,tsx,tsy );


		EndPaint( hwnd, &ps );

		return 0;

	}
	break;


	case WM_CUT   :
	case WM_PASTE :
	case WM_UNDO  :
	case WM_KEYDOWN :
	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :
	case WM_LBUTTONDBLCLK :

		if ( n_posix_false == n_win_dwm_is_on() ) { break; }

		n_win_refresh( hwnd, n_posix_false );

	break;


	case WM_MOUSEMOVE :

		if ( n_posix_false == n_win_dwm_is_on() ) { break; }

		if ( wparam ) { n_win_refresh( hwnd, n_posix_false ); }

	break;


	} // switch


	//if ( ( msg != WM_PRINTCLIENT )&&( msg != WM_GETFONT )&&( msg != 642 ) )
	//{
	//	n_win_hwndprintf_literal( GetParent( hwnd ), "%d", msg );
	//}


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

LRESULT CALLBACK
#ifdef _WIN64
n_win_subclass_edit_tripleclick( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_subclass_edit_tripleclick( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	//
#else  // #ifdef _WIN64
	const WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "n_win_subclass_edit_tripleclick()" );
	if ( pfunc == NULL ) { return 0; }
#endif // #ifdef _WIN64


	static DWORD tmr  = 0;
	static UINT  pmsg = WM_NULL;
	static POINT pt   = { 0, 0 };


	switch( msg ) {


	case WM_LBUTTONDBLCLK :
	{
//n_win_text_set_literal( GetParent( hwnd ), "WM_LBUTTONDBLCLK" );

//tmr = GetTickCount(); break;


		// Triple-Click : Start

		if ( ( GetTickCount() - tmr ) > GetDoubleClickTime() )
		{
			tmr = 0;
			//break;
		} else {
			tmr = GetTickCount();
		}


		// [!] : for usability

		pmsg = WM_LBUTTONDBLCLK;

		GetCursorPos( &pt );


		// [Patch] : with illogical word selection

		         int  len = n_win_text_len( hwnd ) + 1;
		n_posix_char *str = n_string_new_fast( len );

		n_win_text_get( hwnd, str, len - 1 );


		int line  = (int) n_win_message_send( hwnd, EM_LINEFROMCHAR,   -1, 0 );
		int first = (int) n_win_message_send( hwnd, EM_LINEINDEX,    line, 0 );


		int f = 0;
		int t = 0;

		n_win_message_send( hwnd, EM_GETSEL, &f, &t );

#ifndef UNICODE
		if ( n_sysinfo_version_xp_or_later() )
		{
			f = n_string_cch2cb( str, f );
			t = n_string_cch2cb( str, t );
		}
#endif // #ifndef UNICODE


		// [!] : for the end of a text

		f = n_posix_min( len, f );
		t = n_posix_min( len, t );


		// [!] : outer area is clicked

		if ( str[ f ] == N_STRING_CHAR_CR ) { f = n_posix_max( first, f - 1 ); }
		if ( str[ t ] == N_STRING_CHAR_CR ) { t = n_posix_max( first, t - 1 ); }


		n_posix_char fch = str[ f ];
		n_posix_char tch = str[ t ];

//n_win_hwndprintf_literal( GetParent( hwnd ), "%d %d %d %d", f, t, fch, tch );


		n_posix_loop
		{

			// [Patch] : for an empty line

			if ( str[ f ] == N_STRING_CHAR_CR ) { break; }


			f--;
			if ( f < first ) { f = first; break; }

			if ( n_posix_false == n_string_char_is_blank( fch ) )
			{

				if ( str[ f ] == N_STRING_CHAR_SPACE ) { f++; break; }
				if ( str[ f ] == N_STRING_CHAR_TAB   ) { f++; break; }

			} else {

				if ( n_string_is_blank( str, f ) ) { f++; break; }

			}


			if ( str[ f ] == N_STRING_CHAR_CR ) { f++; break; }
			if ( str[ f ] == N_STRING_CHAR_LF ) { f++; break; }

		}

		n_posix_loop
		{

			// [Patch] : for an empty line

			if ( str[ t ] == N_STRING_CHAR_CR ) { t = f + 2; break; }


			t++;
			if ( t >= len ) { t = len; break; }

			if ( n_posix_false == n_string_char_is_blank( tch ) )
			{

				if ( str[ t ] == N_STRING_CHAR_SPACE ) { break; }
				if ( str[ t ] == N_STRING_CHAR_TAB   ) { break; }

			} else {

				if ( n_string_is_blank( str, t ) ) { break; }

			}


			if ( str[ t ] == N_STRING_CHAR_CR ) { break; }
			if ( str[ t ] == N_STRING_CHAR_LF ) { break; }

		}


#ifndef UNICODE
		if ( n_sysinfo_version_xp_or_later() )
		{
			f = n_string_cb2cch( str, f );
			t = n_string_cb2cch( str, t );
		}
#endif // #ifndef UNICODE


		n_win_message_send( hwnd, EM_SETSEL, f, t );


		n_memory_free( str );


		return FALSE;

	}
	break;

	case WM_LBUTTONDOWN :
	{
//n_win_text_set_literal( GetParent( hwnd ), "WM_LBUTTONDOWN" );


		// Triple-Click : End

		if ( ( GetTickCount() - tmr ) > GetDoubleClickTime() )
		{
			tmr = GetTickCount();
			break;
		} else {
			tmr = 0;
		}


		// [!] : for usability

		if ( pmsg != WM_LBUTTONDBLCLK ) { break; } else { pmsg = WM_LBUTTONDOWN; }

		{

			n_type_gfx threshold_sx = 0;
			n_type_gfx threshold_sy = 0;
			n_win_mouse_threshold( hwnd, &threshold_sx, &threshold_sy );

			POINT p;
			GetCursorPos( &p );

			if (
				( threshold_sx < abs( p.x - pt.x ) )
				||
				( threshold_sy < abs( p.y - pt.y ) )
			)
			{
				break;
			}

		}

//n_win_text_set_literal( GetParent( hwnd ), "Triple Clicked" );


		int fch = 0;
		int tch = 0;


		DWORD style = n_win_style_get( hwnd );
		if ( style & ES_MULTILINE )
		{

			// [!] : Buggy : EM_LINELENGTH does not function

			int fy = (int) n_win_message_send( hwnd, EM_LINEFROMCHAR, -1, 0 );
			int ty = fy + 1;


			fch = (int) n_win_message_send( hwnd, EM_LINEINDEX, fy, 0 );
			tch = (int) n_win_message_send( hwnd, EM_LINEINDEX, ty, 0 );


			// [!] : remove CRLF if exist

			int last = (int) n_win_message_send( hwnd, EM_GETLINECOUNT, 0, 0 );
			if ( ty != last )
			{

				if ( ( tch - fch ) > 2 )
				{
					tch = n_posix_max( fch, tch - 2 );
				} else {
					// [!] : empty line : select CRLF
				}

			}

//n_win_hwndprintf_literal( GetParent( hwnd ), "%d %d %d %d", fy, ty, fch, tch );

		} else {

			fch =  0;
			tch = -1;

		}


		n_win_message_send( hwnd, EM_SETSEL, fch, tch );


		return FALSE;

	}
	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

LRESULT CALLBACK
#ifdef _WIN64
n_win_subclass_edit_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_subclass_edit_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	//
#else  // #ifdef _WIN64
	const WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "n_win_subclass_edit_on_keydown()" );
	if ( pfunc == NULL ) { return 0; }
#endif // #ifdef _WIN64


	switch( msg ) {


	case WM_IME_STARTCOMPOSITION :

		n_win_property_init_literal( hwnd, "IME", n_posix_true );

	break;

	case WM_IME_ENDCOMPOSITION :

		n_win_property_exit_literal( hwnd, "IME" );

	break;


	case WM_KEYDOWN :
	{

		if ( n_win_property_get_literal( hwnd, "IME" ) ) { break; }

		if ( hwnd != GetFocus() ) { break; }

#ifdef _WIN64
		WNDPROC on_keydown = (WNDPROC) dwRefData;
#else  // #ifdef _WIN64
		WNDPROC on_keydown = (WNDPROC) n_win_property_get_literal( hwnd, "WM_KEYDOWN" );
#endif // #ifdef _WIN64

		if ( on_keydown != NULL )
		{

			n_posix_bool ret = (n_posix_bool) on_keydown( hwnd, msg, wparam, lparam );

			// [!] : avoid beep

			if ( ret )
			{
				n_win_message_remove();
				return 0;
			}

		}

	}
	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_subclass_edit_init( HWND hgui, const n_posix_char *classname )
{

	if ( n_posix_false == n_string_is_same_literal( "EDIT", classname ) ) { return; }

#ifdef _WIN64

	SetWindowSubclass( hgui, n_win_subclass_edit_tripleclick, 0, 0 );
	SetWindowSubclass( hgui, n_win_subclass_edit_on_keydown , 0, 0 );

	if ( n_sysinfo_version_xp_or_later() )
	{
		SetWindowSubclass( hgui, n_win_subclass_edit_doublebuffer, 0, 0 );
	}

#else  // #ifdef _WIN64

	n_win_property_init_literal
	(
		hgui,
		"n_win_subclass_edit_tripleclick()",
		(int) n_win_gui_subclass_set( hgui, n_win_subclass_edit_tripleclick )
	);


	n_win_property_init_literal
	(
		hgui,
		"n_win_subclass_edit_on_keydown()",
		(int) n_win_gui_subclass_set( hgui, n_win_subclass_edit_on_keydown )
	);


	if ( n_sysinfo_version_xp_or_later() )
	{
		n_win_property_init_literal
		(
			hgui,
			"n_win_subclass_edit_doublebuffer()",
			(int) n_win_gui_subclass_set( hgui, n_win_subclass_edit_doublebuffer )
		);
	}

#endif // #ifdef _WIN64


	return;
}


#endif // _H_NONNON_WIN32_WIN_SUBCLASS_EDIT

