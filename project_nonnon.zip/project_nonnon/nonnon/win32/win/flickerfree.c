// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_FLICKERFREE
#define _H_NONNON_WIN32_WIN_FLICKERFREE




#include "./_debug.c"
#include "./darkmode.c"
#include "./property.c"
#include "./rect.c"
#include "./subclass.c"




BOOL CALLBACK
n_win_flickerfree_EnumChildProc( HWND hwnd, LPARAM lparam )
{

	if ( n_posix_false == IsWindow       ( hwnd ) ) { return TRUE; }
	if ( n_posix_false == IsWindowVisible( hwnd ) ) { return TRUE; }


	RECT rect; GetWindowRect( hwnd, &rect );
	n_type_gfx fx,fy,tx,ty; n_win_rect_expand_range( &rect, &fx, &fy, &tx, &ty );

	HWND hwnd_window = n_win_hwnd_window( hwnd );

	POINT pt_tl = { fx, fy }; ScreenToClient( hwnd_window, &pt_tl );
	POINT pt_br = { tx, ty }; ScreenToClient( hwnd_window, &pt_br );

	fx = pt_tl.x;
	fy = pt_tl.y;
	tx = pt_br.x;
	ty = pt_br.y;

//rect = n_win_rect_set_simple( NULL, fx,fy,tx,ty );
//n_win_box( NULL, (HDC) lparam, &rect, RGB( 0,200,255 ) );
	ExcludeClipRect( (HDC) lparam, fx,fy,tx,ty );


	return TRUE;
}

LRESULT CALLBACK
#ifdef _WIN64
n_win_flickerfree_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_flickerfree_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	//
#else  // #ifdef _WIN64
	const WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "n_win_flickerfree_subclass()" );
	if ( pfunc == NULL ) { return 0; }
#endif // #ifdef _WIN64


	switch( msg ) {


	case WM_ERASEBKGND :
	{
		// [Needed] : prevent redraw error

		//HDC hdc = (HDC) wparam;

		return n_posix_true;
	}
	break;

	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		EnumChildWindows( hwnd, n_win_flickerfree_EnumChildProc, (LPARAM) ps.hdc );

		n_win_box( NULL, ps.hdc, &ps.rcPaint, n_win_darkmode_systemcolor_ui( COLOR_BTNFACE ) );

		EndPaint( hwnd, &ps );

		return 0;
	}
	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc(        hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return  CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_flickerfree_init( HWND hwnd, WNDPROC *func )
{

#ifdef _WIN64
	SetWindowSubclass( hwnd, n_win_flickerfree_subclass, 0, 0 );
#else  // #ifdef _WIN64
	n_win_property_init_literal
	(
		hwnd,
		"n_win_flickerfree_subclass()",
		(int) n_win_gui_subclass_set( hwnd, n_win_flickerfree_subclass )
	);
	(*func) = n_win_gui_subclass_set( hwnd, n_win_flickerfree_subclass );
#endif // #ifdef _WIN64


	return;
}

void
n_win_flickerfree_exit( HWND hwnd, const WNDPROC *func )
{

#ifdef _WIN64
	RemoveWindowSubclass( hwnd, n_win_flickerfree_subclass, 0 );
#else  // #ifdef _WIN64
	n_win_gui_subclass_set( hwnd, (*func) );
#endif // #ifdef _WIN64


	return;
}

void
n_win_flickerfree_win_iconbutton_init( HWND hgui )
{

	// [!] : if on DWM transparent window, don't use it

	n_win_property_init_literal( hgui, "Background.OnOff", n_posix_true );


	return;
}

void
n_win_flickerfree_win_iconbutton_exit( HWND hgui )
{

	// [!] : if on DWM transparent window, don't use it

	n_win_property_exit_literal( hgui, "Background.OnOff" );


	return;
}




#endif // _H_NONNON_WIN32_WIN_FLICKERFREE

