// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_BUTTON
#define _H_NONNON_WIN32_WIN_BUTTON




#include "../neutral/bmp/fade.c"


#include "./gdi/doublebuffer_32bpp.c"
#include "./uxtheme.c"
#include "./win.c"




typedef struct {

	// [!] : internal

	HWND         hwnd;

	n_uxtheme    uxtheme;
	n_posix_bool is_classic;

	n_bmp_fade   fade;
	n_posix_bool fade_onoff;
	UINT         fade_timer_id;

	int          state;

	n_posix_bool corner_is_first;
	n_posix_bool active_onoff;

	WPARAM       wm_activate;


	// [!] : option : you can set these directly

	HICON        hicon;

	n_posix_bool leave_onoff;
	n_posix_bool nomove_onoff;
	n_posix_bool select_onoff;

} n_win_button;




#define n_win_button_zero( p ) n_memory_zero( p, sizeof( n_win_button ) )

void
n_win_button_debug_state( n_win_button *p, int pbs )
{

	n_posix_char *str = N_STRING_EMPTY;

	if ( pbs == PBS_NORMAL   ) { str = n_posix_literal( "PBS_NORMAL"   ); }
	if ( pbs == PBS_HOT      ) { str = n_posix_literal( "PBS_HOT"      ); }
	if ( pbs == PBS_DISABLED ) { str = n_posix_literal( "PBS_DISABLED" ); }
	if ( pbs == PBS_PRESSED  ) { str = n_posix_literal( "PBS_PRESSED"  ); }

	n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " %s ", str );


	return;
}

n_posix_bool
n_win_button_is_enabled( n_win_button *p )
{
	return p->active_onoff;
}

void
n_win_button_grayed_onoff( n_win_button *p, n_posix_bool onoff )
{

	if ( onoff )
	{
		p->active_onoff = n_posix_false;

		n_win_property_set_literal( p->hwnd, "State", p->state );
		p->state = PBS_DISABLED;
	} else {
		p->active_onoff = n_posix_true;

		n_win_property_set_literal( p->hwnd, "State", PBS_DISABLED );
		p->state = PBS_NORMAL;
	}

	n_win_refresh( p->hwnd, n_posix_false );


	return;
}

void
n_win_button_fade_go( n_win_button *p, u32 color )
{

	n_bmp_fade_go( &p->fade, color );

	n_win_timer_init( p->hwnd, p->fade_timer_id, 1 );


	return;
}

void
n_win_button_draw( n_win_button *p, HDC hdc_override, RECT *rect )
{

	if ( n_posix_false == IsWindow       ( p->hwnd ) ) { return; }
	if ( n_posix_false == IsWindowVisible( p->hwnd ) ) { return; }


	s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	// [x] : flicker prevention : n_gdi_doublebuffer_simple_init() only

	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, sx,sy );


	// [!] : Metrics

	s32 o = ( n_win_dpi( p->hwnd ) / 96 );

	int  edge = EDGE_RAISED;
	int    bf = BF_RECT;
	int    bp = BP_PUSHBUTTON;
	int   pbs = p->state;

	DWORD style = n_win_style_get( p->hwnd );
	if ( style & BS_FLAT )
	{
		// [!] : BF_FLAT == WS_BORDER

		edge = EDGE_RAISED;
		bf   = bf | BF_MONO;
	}


	if ( p->state == PBS_PRESSED )
	{
		edge = EDGE_SUNKEN;
	}

	if ( p->select_onoff )
	{
		// [!] : Nonnon original behavior

		edge = EDGE_SUNKEN;
		bf   = bf & ~BF_MONO;

		if ( pbs != PBS_HOT ) { pbs = PBS_PRESSED; }

		o = 0;
	}


	if ( p->active_onoff == n_posix_false )
	{
		pbs = PBS_DISABLED;
	}


	// Main

	n_posix_bool is_drawedge = n_posix_false;

	if (
//(1)
//
//(0)&&
		(
			( n_win_fluent_ui_onoff == n_posix_false )
			&&
			( p->uxtheme.onoff )
		)
		||
		(
			( n_win_fluent_ui_onoff != N_WIN_FLUENT_UI_OVERRIDE )
			&&
			( p->uxtheme.onoff )
			&&
			( n_posix_false == n_sysinfo_version_8_or_later() )
		)
//
	)
	{

/*
		if (
			( p->uxtheme.longhorn )
			&&
			( p->uxtheme.IsThemeBackgroundPartiallyTransparent( p->uxtheme.htheme, bp, pbs ) )
		)
*/		{

			n_posix_bool bg_onoff = n_win_property_get_literal( p->hwnd, "Background.OnOff" );

			if ( bg_onoff == n_posix_false )
			{
				p->uxtheme.DrawThemeParentBackground( p->hwnd, hdc, rect );
			} else {
				n_win_box( p->hwnd, hdc, rect, n_win_darkmode_systemcolor_ui( COLOR_BTNFACE ) );
			}

		}


		int state_f = n_win_property_get_literal( p->hwnd, "State" );

		p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, bp, state_f, rect, NULL );

		n_bmp bmp_f; n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &bmp_f );


		int state_t = pbs;

		p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, bp, state_t, rect, NULL );

		n_bmp bmp_t; n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &bmp_t );


		//n_bmp_alpha_visible( &bmp_f );
		//n_bmp_alpha_visible( &bmp_t );


		double ratio = (double) p->fade.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );


		n_bmp_flush_fastcopy( &bmp_t, &n_gdi_doublebuffer_32bpp_instance.bmp );


		n_bmp_free_fast( &bmp_f );
		n_bmp_free_fast( &bmp_t );

	} else
	if (
//(0)&&
		( n_win_fluent_ui_onoff )
	)
	{

		// [!] : shared

		n_posix_bool is_toolband = n_win_property_get_literal( p->hwnd, "Toolband" );

		HWND hwnd_window = n_win_hwnd_window( p->hwnd );

		if ( p->wm_activate == WA_INACTIVE ) { p->corner_is_first = n_posix_false; }

		u32 corner = n_win_dwm_roundrect_corner_color( hwnd_window, p->wm_activate, is_toolband, p->corner_is_first );

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " %d %d %d ", is_toolband, p->wm_activate, p->corner_is_first );

//n_win_debug_count( n_win_hwnd_toplevel( p->hwnd ) );

		s32 round = n_win_fluent_ui_round_param() + 1;
		s32 frame = ( n_win_dpi( p->hwnd ) / 96 );


		int state_f = n_win_property_get_literal( p->hwnd, "State" );
		int state_t = pbs;

//n_win_button_debug_state( p, state_t );


		COLORREF color_f = 0;

		if ( state_f == PBS_NORMAL   ) { color_f = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE    ); }
		if ( state_f == PBS_HOT      ) { color_f = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT  ); }
		if ( state_f == PBS_DISABLED ) { color_f = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW  ); }
		if ( state_f == PBS_PRESSED  ) { color_f = n_win_darkmode_systemcolor_ui( COLOR_3DDKSHADOW ); }


		COLORREF color_t = 0;

		if ( state_t == PBS_NORMAL   ) { color_t = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE    ); }
		if ( state_t == PBS_HOT      ) { color_t = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT  ); }
		if ( state_t == PBS_DISABLED ) { color_t = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW  ); }
		if ( state_t == PBS_PRESSED  ) { color_t = n_win_darkmode_systemcolor_ui( COLOR_3DDKSHADOW ); }


		if ( n_win_dwm_aeroglass_is_on() )
		{
			corner = 0;
		} else {
			corner = n_bmp_alpha_visible_pixel( corner );
		}


		u32 color_border_base;

		if ( n_win_darkmode_onoff )
		{
			color_border_base = n_bmp_white;
		} else {
			color_border_base = n_bmp_rgb( 1,1,1 );
		}


		// [!] : test

		//u32 border = n_win_color_blend( color_t, RGB( 0,0,0 ), 0.25 );
		//s32 s = o / 2; 

		//n_win_fluent_ui_draw_roundrect( hdc_override, x  ,y  ,sx      ,sy      , round, border , 1.0 );
		//n_win_fluent_ui_draw_roundrect( hdc_override, x+s,y+s,sx-(s*2),sy-(s*2), round, color_t, 1.0 );


		// [!] : from

//if(round){}

		n_bmp bmp_f; n_bmp_zero( &bmp_f ); n_bmp_new_fast( &bmp_f, sx,sy );

//n_bmp_flush( &bmp_f, color_f );

		u32 clr_f;
		u32 bdr_f;

		clr_f = n_bmp_colorref2argb( color_f );
		bdr_f = n_bmp_blend_pixel( clr_f, color_border_base, 0.25 );

		clr_f = n_bmp_alpha_visible_pixel( clr_f );
		bdr_f = n_bmp_alpha_visible_pixel( bdr_f );

		n_win_fluent_ui_bmp_roundframe( &bmp_f, NULL, 0,0,sx,sy, 0,0, round, frame, bdr_f, clr_f, corner, 1.0 );


		// [!] : To

		n_bmp *bmp_t = &n_gdi_doublebuffer_32bpp_instance.bmp;

//n_bmp_flush( bmp_t, color_t );

		u32 clr_t;
		u32 bdr_t;

		clr_t = n_bmp_colorref2argb( color_t );
		bdr_t = n_bmp_blend_pixel( clr_t, color_border_base, 0.25 );

		clr_t = n_bmp_alpha_visible_pixel( clr_t );
		bdr_t = n_bmp_alpha_visible_pixel( bdr_t );

		n_win_fluent_ui_bmp_roundframe( bmp_t, NULL, 0,0,sx,sy, 0,0, round, frame, bdr_t, clr_t, corner, 1.0 );


		// [!] : draw engine

		double ratio = (double) p->fade.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, bmp_t, ratio );


		// [!] : cleaup

		n_bmp_free_fast( &bmp_f );

	} else {

		n_win_clear( p->hwnd, hdc, rect, COLOR_BTNFACE );

		DrawEdge( hdc, rect, edge, bf );

		is_drawedge = n_posix_true;

	}


	// Text or Icon
/*
	if ( 1 )
	{
		// [!] : for checking performance
	} else
*/
	if ( p->hicon == NULL )
	{

		RECT r = { x, y, x+sx, y+sy };

		if ( p->nomove_onoff )
		{
			// [!] : do nothing
		} else
		if ( pbs == PBS_PRESSED )
		{
			// [!] : Vista or later : Nonnon Original Behavior

			if (
				( is_drawedge )
				||
				( p->uxtheme.onoff == n_posix_false )
			)
			{
				n_win_rect_move( &r, o, o );
			} else
			if ( p->uxtheme.longhorn )
			{
				n_win_rect_move( &r, 0, o );
			}
		}


		int part, state;

		if ( p->uxtheme.onoff )
		{
			part  = bp;
			state = pbs;
		} else {
			part  = 0;
			state = p->state;
		}

		if ( state == PBS_DEFAULTED ) { state = 0; }

		int dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
		n_uxtheme_draw_text( &p->uxtheme, p->hwnd, hdc, &r, part,state, dt, TMT_MSGBOXFONT, n_posix_false );
/*
		SetBkMode( hdc, TRANSPARENT );
		n_posix_char str[ 1024 ]; n_win_text_get( p->hwnd, str, 1024 );
		DrawText( hdc, str, -1, &r, dt );
*/
	} else {

		s32 ico_sx, ico_sy; n_win_stdsize_icon_large( &ico_sx, &ico_sy );


		s32 tx = ( sx - ico_sx ) / 2;
		s32 ty = ( sy - ico_sy ) / 2;

		if ( p->nomove_onoff )
		{
			// [!] : do nothing
		} else
		if ( pbs == PBS_PRESSED )
		{
			// [!] : Vista or later : Nonnon Original Behavior

			if ( p->uxtheme.onoff == n_posix_false )
			{
				tx += o;
				ty += o;
			} else
			if ( p->uxtheme.longhorn )
			{
				ty += o;
			}
		}


		// [Needed] : DWM : alpha value support

		int drawstate_onoff = n_win_property_get_literal( p->hwnd, "DrawState" );

		if ( ( p->uxtheme.onoff )&&( drawstate_onoff == n_posix_false ) )
		{

			HMODULE hmod = LoadLibrary( n_posix_literal( "comctl32.dll" ) );

			FARPROC n_ImageList_Create      = (void*) GetProcAddress( hmod, "ImageList_Create"      );
			FARPROC n_ImageList_ReplaceIcon = (void*) GetProcAddress( hmod, "ImageList_ReplaceIcon" );
			FARPROC n_ImageList_Destroy     = (void*) GetProcAddress( hmod, "ImageList_Destroy"     );

			// [x] : Win10 : stretching is forced always
			int n_ILC_ORIGINALSIZE = 0x00010000;

			// [x] : WinXP : ILC_ORIGINALSIZE : handled as error
			if ( n_posix_false == n_sysinfo_version_vista_or_later() ) { n_ILC_ORIGINALSIZE = 0; }


			HIMAGELIST hil = (void*) n_ImageList_Create( ico_sx, ico_sy, ILC_COLOR32 | ILC_MASK | n_ILC_ORIGINALSIZE, 1, 0 );


			if ( pbs != PBS_DISABLED )
			{

				n_ImageList_ReplaceIcon( hil, -1, p->hicon );

			} else {

				HICON hicon_gray = n_win_icon_grayed( p->hicon, ico_sx, ico_sy );

				n_ImageList_ReplaceIcon( hil, -1, hicon_gray );

				n_win_icon_exit( hicon_gray );

			}


			RECT r = n_win_rect_set( NULL, tx, ty, ico_sx, ico_sy );
			p->uxtheme.DrawThemeIcon( p->uxtheme.htheme, hdc, bp,pbs, &r, hil, 0 );

			n_ImageList_Destroy( hil );


			FreeLibrary( hmod );

		} else {

			if ( ( pbs != PBS_DISABLED )||( n_win_fluent_ui_onoff == n_posix_false ) )
			{

				HBRUSH hb = GetSysColorBrush( COLOR_BTNFACE );
				DrawState( hdc, hb, NULL, (LPARAM) p->hicon,0, tx,ty,0,0, DSS_NORMAL | DST_ICON );

			} else {

				HICON hicon_gray = n_win_icon_grayed( p->hicon, ico_sx, ico_sy );

				DrawIcon( hdc, tx,ty, hicon_gray );

				n_win_icon_exit( hicon_gray );

			}

		}

	}


	if ( hdc_override != NULL )
	{
		BitBlt( hdc_override, 0,0,sx,sy, hdc, 0,0, SRCCOPY );
	}


	n_gdi_doublebuffer_32bpp_simple_exit();


	return;
}

// internal
LRESULT CALLBACK
#ifdef _WIN64
n_win_button_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_button_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	n_win_button *p = (void*) dwRefData;
#else  // #ifdef _WIN64
	n_win_button *p = (void*) n_win_property_get_literal( hwnd, "n_win_button" );
#endif // #ifdef _WIN64

	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_TIMER :

		if ( wparam != p->fade_timer_id ) { break; }

		n_bmp_fade_engine( &p->fade, p->fade_onoff );
		n_win_refresh( p->hwnd, n_posix_false );

		if ( p->fade.percent == 100 )
		{
			n_win_timer_exit( hwnd, p->fade_timer_id );
			n_win_property_set_literal( p->hwnd, "State", p->state );
		}

//n_win_hwndprintf_literal( GetParent( p->hwnd ), "%d", (int) p->fade.percent );
	break;


	case WM_MOUSEMOVE :

		if ( p->is_classic ) { break; }

		// [!] : this code depends SetCapture()/ReleaseCapture()

		n_win_on_mousemove( hwnd );

	break;

	case WM_MOUSEHOVER :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), " Button : WM_MOUSEHOVER " );

		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		if ( n_win_is_input( VK_LBUTTON ) ) { break; }

		if ( ( p->leave_onoff )&&( p->state != PBS_HOT ) )
		{
			p->state = PBS_HOT;

			n_win_button_fade_go( p, n_bmp_white );
		}

	break;

	case WM_MOUSELEAVE :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), " Button : WM_MOUSELEAVE " );

		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		if ( p->leave_onoff )
		{
			p->state = PBS_NORMAL;

			n_win_button_fade_go( p, n_bmp_black );
		}

	break;


	case WM_ERASEBKGND :

		return n_posix_true;

	break;


	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN   :

		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		SetCapture( hwnd );

	case WM_LBUTTONDBLCLK :

		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		p->state = PBS_PRESSED;

		if ( p->select_onoff ) { p->select_onoff = n_posix_false; }

		n_win_button_fade_go( p, n_bmp_rgb( 0,200,255 ) );

	break;

	case WM_LBUTTONUP :
	{

		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		ReleaseCapture();

		p->state = PBS_HOT;
		n_win_button_fade_go( p, n_bmp_rgb( 255,0,200 ) );

		n_win_message_send( GetParent( hwnd ), WM_COMMAND, 0, hwnd );

	}
	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( (WNDPROC) n_win_property_get_literal( hwnd, "Subclass" ), hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_button_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_button *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }

		n_win_button_draw( p, di->hDC, &di->rcItem );

	}
	break;


	} // switch


	return;
}

void
n_win_button_window_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_button *p )
{

	// [Needed]  fluent ui : put this on WndProc() of a window (not a control)


	switch( msg ) {


	case WM_ACTIVATE :
	{

		p->wm_activate = wparam;


//n_win_refresh( p->hwnd, n_posix_false );

		RECT rect; GetClientRect( p->hwnd, &rect );
		n_win_button_draw( p, NULL, &rect );

	}
	break;


	} // switch


	return;
}

void
n_win_button_on_settingchange( n_win_button *p )
{

	p->is_classic = n_win_style_is_classic();

	if ( p->is_classic ) { n_win_style_add( p->hwnd, BS_FLAT ); }


	n_win_stdfont_exit( &p->hwnd, 1 );
	n_win_stdfont_init( &p->hwnd, 1 );


	n_uxtheme_exit( &p->uxtheme, p->hwnd );
	n_uxtheme_init( &p->uxtheme, p->hwnd, L"BUTTON" );


	p->fade_onoff = n_win_fade_is_on();
	n_bmp_fade_init( &p->fade, n_bmp_black );


	return;
}

#define n_win_button_init_literal( p, h, t, s ) n_win_button_init( p, h, n_posix_literal( t ), s )

#define n_win_button_init(     p, h, t, s ) n_win_button_init_internal( p, h, t, s, n_posix_false )
#define n_win_button_init_dwm( p, h, t, s ) n_win_button_init_internal( p, h, t, s, n_posix_true  )

// internal
void
n_win_button_init_internal( n_win_button *p, HWND hwnd_parent, n_posix_char *text, int state, n_posix_bool is_toolband )
{

	n_win_gui( hwnd_parent, N_WIN_GUI_CANVAS_BUTTON, text, &p->hwnd );
//n_win_style_add( p->hwnd, WS_BORDER );


	p->state = state;
	n_win_property_set_literal( p->hwnd, "State", p->state );

	p->leave_onoff  = n_posix_true;
	p->active_onoff = ( p->state != PBS_DISABLED );


	p->fade_timer_id = n_win_timer_id_get();


	n_win_property_init_literal( p->hwnd, "Toolband", is_toolband );

	p->corner_is_first = n_posix_true;

	p->wm_activate = WA_ACTIVE;


	{

#ifdef _WIN64

		SetWindowSubclass( p->hwnd, n_win_button_subclass, 0, (DWORD_PTR) p );

#else  // #ifdef _WIN64

		WNDPROC pfunc = n_win_gui_subclass_set( p->hwnd, n_win_button_subclass );

		n_win_property_init_literal( p->hwnd, "n_win_button", (int) p     );
		n_win_property_init_literal( p->hwnd, "Subclass"    , (int) pfunc );

#endif // #ifdef _WIN64

	}


	n_win_button_on_settingchange( p );


	return;
}

void
n_win_button_exit( n_win_button *p )
{

	n_win_property_exit_literal( p->hwnd, "State" );
	n_win_property_exit_literal( p->hwnd, "Background.OnOff" );
	n_win_property_exit_literal( p->hwnd, "Toolband" );
	n_win_property_exit_literal( p->hwnd, "DrawState" );


#ifdef _WIN64

	RemoveWindowSubclass( p->hwnd, n_win_button_subclass, 0 );

#else  // #ifdef _WIN64

	n_win_property_exit_literal( p->hwnd, "n_win_button" );
	n_win_property_exit_literal( p->hwnd, "Subclass"     );

#endif // #ifdef _WIN64


	n_uxtheme_exit( &p->uxtheme, p->hwnd );


	n_win_icon_exit( p->hicon );

	n_win_stdfont_exit( &p->hwnd, 1 );


	DestroyWindow( p->hwnd );


	return;
}

n_posix_bool
n_win_button_checklike( n_win_button *p, int index_off, int index_on, n_posix_bool onoff )
{

	// [!] : BS_AUTOCHECKBOX-like behavior


	n_posix_char *exe = n_win_exepath_new();

	if ( onoff )
	{
		onoff = n_posix_false;

		p->hicon = n_win_icon_init( exe, index_off, N_WIN_ICON_INIT_OPTION_RESOURCE );
	} else {
		onoff = n_posix_true;

		p->hicon = n_win_icon_init( exe, index_on , N_WIN_ICON_INIT_OPTION_RESOURCE );
	}

	p->select_onoff = onoff;

	n_string_path_free( exe );


	return onoff;
}


#endif // _H_NONNON_WIN32_WIN_BUTTON


