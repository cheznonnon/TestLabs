// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_move( n_win_txtbox *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool redraw )
{

	//ShowWindow( p->hwnd, SW_HIDE );

	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE )
	{
		n_type_gfx o = p->maclike_offset + 1;

		 x -= o;
		 y -= o;
		sx += o * 2;
		sy += o * 2;
	}

	n_win_move( p->hwnd, x,y,sx,sy, redraw );

	//ShowWindow( p->hwnd, SW_NORMAL );


	return;
}

void
n_win_txtbox_move_simple( n_win_txtbox *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool redraw )
{

	//ShowWindow( p->hwnd, SW_HIDE );

	n_win_move_simple( p->hwnd, x,y,sx,sy, redraw );

	//ShowWindow( p->hwnd, SW_NORMAL );


	return;
}


