// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_drag_select2drag( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }

	p->drag_cch_x = p->select_cch_x;
	p->drag_cch_y = p->select_cch_y;

	return;
}

void
n_win_txtbox_drag_scroll( n_win_txtbox *p )
{
//return;

	if ( p == NULL ) { return; }


	s32 x,y; n_win_cursor_position_relative( p->hwnd, &x, &y );


	s32 usability = 1;


	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{

		usability = 1;

		SIZE size = { 0,0 };
		s32 sx; n_win_txtbox_tabbedmetrics( p, p->hover_cch_y, -1,-1,-1, &sx, NULL, NULL );
		size.cx = sx;

		//s32 cursor_x; n_win_cursor_position_relative( p->hwnd, &cursor_x, NULL );
//n_win_txtbox_hwndprintf_literal( p, " %d ", cursor_x );

		s32 client_sx = p->client_pxl_sx - ( ( p->border_pxl_sx + p->pad_pxl_sx ) * 2 );

		client_sx -= p->smallbutton_margin;

		//if ( size.cx > client_sx )
		{

			s32 usability_sx = usability * p->font_pxl_sx;

			if ( x > client_sx )
			{
				p->shift_dragging = VK_RIGHT;

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x + usability_sx, p->scroll_cch_tabbed_y );
			} else
			if ( x < ( p->border_pxl_sx + p->pad_pxl_sx ) )
			{
				p->shift_dragging = VK_LEFT;

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x - usability_sx, p->scroll_cch_tabbed_y );
			}

		}

	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{

		//SIZE size = n_win_txtbox_size_text( p, n_txt_get( &p->txt, p->hover_cch_y ) );

		SIZE size = { 0,0 };
		s32 sx; n_win_txtbox_tabbedmetrics( p, p->hover_cch_y, -1,-1,-1, &sx, NULL, NULL );
		size.cx = sx;

		n_posix_char *eol_str = n_win_txtbox_eol_string_get( p );
		if ( n_posix_false == n_string_is_empty( eol_str ) )
		{
			SIZE size_eol = n_win_txtbox_size_text( p, eol_str );
			size.cx += size_eol.cx;
		}

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", size.cx, p->client_pxl_sx );

		s32 client_sx = p->client_pxl_sx - ( p->border_pxl_sx + p->pad_pxl_sx + p->number_pxl_sx + p->number_pad_pxl_sx + p->scrollbar_pxl_sx );

		if ( size.cx > client_sx )
		{

			s32 usability_sx = usability * p->font_pxl_sx;

			if ( x > ( p->client_pxl_sx - p->border_pxl_sx - p->scrollbar_pxl_sx - p->pad_pxl_sx - usability_sx ) )
			{
				p->shift_dragging = VK_RIGHT;

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x + usability_sx, p->scroll_cch_tabbed_y );
			} else
			if ( x < ( p->border_pxl_sx + p->pad_pxl_sx + p->number_pxl_sx + p->number_pad_pxl_sx ) )
			{
				p->shift_dragging = VK_LEFT;

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x - usability_sx, p->scroll_cch_tabbed_y );
			}

		}

	}

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{

		if ( y > ( p->client_pxl_sy - p->border_pxl_sy - p->scrollbar_pxl_sy - p->pad_pxl_sy - usability ) )
		{
			p->shift_dragging = VK_DOWN;

			n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y + usability );
		} else
		if ( y < ( p->border_pxl_sy + p->pad_pxl_sy ) )
		{
			p->shift_dragging = VK_UP;

			n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y - usability );
		}

	}


	return;
}

void
n_win_txtbox_drag( n_win_txtbox *p )
{
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->hover_under );
//return;

	// [!] : mouse input only
	//
	//	keyboard input uses n_win_txtbox_edit_on_typing()


	if ( p == NULL ) { return; }


	//extern n_posix_bool n_win_txtbox_is_hovered( n_win_txtbox *p );
	//n_posix_bool is_hovered = n_win_txtbox_is_hovered( p );
//n_win_txtbox_hwndprintf_literal( p, " %d ", is_hovered );


	s32  x = n_posix_minmax_s32( 0, p->txt.sx, p->hover_cch_x );
	s32  y = n_posix_minmax_s32( 0, p->txt.sy, n_posix_min_s32( p->hover_cch_y, p->drag_cch_y ) );
	s32 sx = 0;
	s32 sy = n_posix_minmax_s32( 0, p->txt.sy - y, 1 + abs( n_posix_max_s32( 0, p->hover_cch_y ) - p->drag_cch_y ) );

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", y, sy );


	n_posix_char *line = n_txt_get( &p->txt, y );

	if ( p->drag_cch_x == x )
	{
//n_win_txtbox_hwndprintf_literal( p, " Stopped " );

		p->shift_dragging = 0;

	} else
	if ( p->drag_cch_x < x )
	{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %d %d ", p->drag_cch_x, x );

		p->shift_dragging = VK_RIGHT;

		n_win_txtbox_caret_m( line, x, &x );

		sx = abs( x - p->drag_cch_x );
		 x = n_posix_min_s32( x, p->drag_cch_x );

	} else
	if ( p->drag_cch_x > x )
	{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : %d %d ", p->drag_cch_x, x );

		p->shift_dragging = VK_LEFT;

		n_win_txtbox_caret_m( line, x, &x );

		sx = abs( x - p->drag_cch_x );
		 x = n_posix_min_s32( x, p->drag_cch_x );

	}

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", x, sx );
//return;


	if ( sy <= 1 )
	{

		// [Needed] : crash prevention
		sy = 1;

		extern void n_win_txtbox_reset_partial_selection( n_win_txtbox* );
		n_win_txtbox_reset_partial_selection( p );

	} else {

		 x = 0;
		sx = N_WIN_TXTBOX_ALL;

		if ( p->drag_cch_y < p->hover_cch_y )
		{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN " );

			p->shift_dragging = VK_DOWN;

			{

				if ( p->partial_selection_from_onoff == n_posix_false )
				{
					p->partial_selection_from_onoff = n_posix_true;
					p->partial_selection_from_cch_x = p->drag_cch_x;
				}

				p->partial_selection_to___cch_x = p->hover_cch_x;

//n_win_txtbox_hwndprintf_literal( p, " Min " );

				if ( y == p->select_cch_y )
				{
					 x = 0;
					sx = p->hover_cch_x;
				}

			}

		} else
		if ( p->drag_cch_y > p->hover_cch_y )
		{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP " );

			p->shift_dragging = VK_UP;

			if ( p->hover_under < 0 )
			{
//n_win_txtbox_hwndprintf_literal( p, " under : %d : %d %d %d %d ", p->hover_under, x,y,sx,sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_from_onoff, p->partial_selection_to___onoff );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

				if ( p->partial_selection_to___onoff )
				{
					p->partial_selection_from_cch_x = N_WIN_TXTBOX_ALL;
				}

			} else {

				p->partial_selection_from_cch_x = p->hover_cch_x;

				if ( p->partial_selection_to___onoff == n_posix_false )
				{
					p->partial_selection_to___onoff = n_posix_true;
					p->partial_selection_to___cch_x = p->drag_cch_x;
				}

//n_win_txtbox_hwndprintf_literal( p, " Max : %d %d ", y, ( p->select_cch_y + p->select_cch_sy - 1 ) );
//n_win_txtbox_hwndprintf_literal( p, " Max : %d %d ", p->hover_cch_y, p->drag_cch_y );

				if ( y == p->select_cch_y )
				{
					 x = p->hover_cch_x;
					sx = N_WIN_TXTBOX_ALL;
				}

			}

		}

		if ( sx == 0 )
		{
			 x = 0;
			sx = N_WIN_TXTBOX_ALL;
		}

	}


	n_win_txtbox_select( p, x, y, sx, sy );

	//n_win_txtbox_select_get( p, &x, &y, &sx, &sy );
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d %d %d ", p->shift_dragging, x, y, sx, sy );


	if ( p->shift_dragging == VK_LEFT  ) { p->is_caret_tail = n_posix_false; }
	if ( p->shift_dragging == VK_RIGHT ) { p->is_caret_tail = n_posix_true ; }
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->is_caret_tail );


	n_win_txtbox_drag_scroll( p );
	//n_win_txtbox_drag_select2drag( p );


//p->partial_selection_from_onoff = p->partial_selection_to___onoff = n_posix_false;


	return;
}


