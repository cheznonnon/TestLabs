// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




int
n_win_txtbox_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	// [Needed] : don't pass to DefWindowProc() when return value is non-zero


	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : you need to call this manually

		//n_win_txtbox_metrics( p );

	break;


	case WM_DRAWITEM :
	{
//break;

		DRAWITEMSTRUCT *di = (void*) lparam;

		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		n_win_txtbox_draw( p, N_WIN_TXTBOX_PROC_WM_DRAWITEM );


		// [x] : conflict with n_win_smallbutton.c
/*
		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_refresh( &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_refresh( &p->vscr );
		}
*/
	}
	break;


	case WM_PRINTCLIENT :
	{

		if ( n_win_txtbox_printclient == n_posix_false ) { break; }


		p->hdc_printclient = (HDC) wparam;

		HFONT pf = SelectObject( p->hdc_printclient, n_win_font_get( p->hwnd ) );

		n_win_txtbox_draw( p, N_WIN_TXTBOX_PROC_WM_PRINTCLIENT );

		SelectObject( p->hdc_printclient, pf );

		p->hdc_printclient = NULL;

	}
	break;


	case WM_SETCURSOR :

		if ( n_win_txtbox_smallbutton_direct_is_hovered( p ) )
		{
			n_win_txtbox_cursor_add( p, IDC_ARROW );

			return n_posix_true;
		} else
		if (
			( n_win_txtbox_is_hovered( p ) )
			&&
			( hwnd == n_win_cursor2hwnd() )
		)
		{
			n_win_txtbox_on_setcursor( p );

			return n_posix_true;
		}

	break;


	case WM_ACTIVATE :

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
		{
//n_win_txtbox_debug_count( p );

			n_posix_bool is_visible = ( p->style & N_WIN_TXTBOX_STYLE_VISIBLE );
			p->color_round_rect_bk = n_win_dwm_roundrect_corner_color( hwnd, wparam, is_visible, n_posix_false );

			n_win_txtbox_draw( p, 0 );
		}

	break;


	} // switch


	n_win_txtbox_proc_mouse( hwnd, msg, wparam, lparam, p );


	if ( p->mouse_input_stop_onoff == n_posix_false )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &p->vscr );
		}

	}


	return 0;
}


