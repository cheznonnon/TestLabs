// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Why is this needed ? ]
//
//		XP    : BS_ICON will be drawn as Classic Style
//		Vista : BS_ICON support is revivedbut not clipped
//
//
//	[ Supported Styles ]
//
//		BS_PUSHBUTTON
//		BS_DEFPUSHBUTTON
//		BS_ICON
//		BS_PUSHLIKE
//
//
//	[ Usage ]
//
//		1 : n_win_gui() : "Button", "Icon Button"
//		2 : set n_win_iconbutton_init() at WM_CREATE
//		3 : set n_win_iconbutton_proc() in WndProc()
//		4 : set n_win_iconbutton_exit() at WM_CLOSE
//		5 : Done!
//
//		you can control looking manually with n_win_iconbutton_status_change()
//
//
//	[ Behavior ]
//
//		[ Focusless ]
//
// 		WinXP or later : not smooth when doing SetFocus() to "Edit Control"
//
//
//	[ Compatibility Problems ]
//
//		Vista or later : GDI handle leak occurs
//		you need to call DestroyWindow( hgui ); at WM_CLOSE explicitly




#ifndef _H_NONNON_WIN32_WIN_ICONBUTTON
#define _H_NONNON_WIN32_WIN_ICONBUTTON




#include "./gdi/doublebuffer.c"
#include "./uxtheme.c"
#include "./win.c"


#include "../game/gdiplus.c"




static n_uxtheme    n_win_iconbutton_uxtheme;
static int          n_win_iconbutton_refcount          = 0;
static n_posix_bool n_win_iconbutton_ui_onoff          = n_posix_false;
static int          n_win_iconbutton_scaled_offset     = 0;
static n_posix_bool n_win_iconbutton_printclient_onoff = n_posix_false;
static HDC          n_win_iconbutton_hdc_override      = NULL;




// internal
void
n_win_iconbutton_status_change( HWND h, HDC hdc_override, UINT ods )
{

	if ( n_posix_false == IsWindowEnabled( h ) ) { return; }


	HDC   hdc = hdc_override; if ( hdc_override == NULL ) { hdc = GetDC( h ); }
	RECT  r; GetClientRect( h, &r );
	HFONT phf = SelectObject( hdc, n_win_font_get( h ) );


	SetBkColor  ( hdc, GetSysColor( COLOR_BTNFACE ) );
	SetTextColor( hdc, GetSysColor( COLOR_BTNTEXT ) );

	{

		DRAWITEMSTRUCT di = { ODT_BUTTON, 0,0, ODA_DRAWENTIRE, ods, h, hdc, r, 0 };

		n_win_message_send( GetParent( h ), WM_DRAWITEM, 0, &di );

	}


	SelectObject( hdc, phf );

	if ( hdc_override == NULL ) { ReleaseDC( h, hdc ); }


	return;
}

// internal
LRESULT CALLBACK
#ifdef _WIN64
n_win_iconbutton_globalsubclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_iconbutton_globalsubclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	static HWND hgui = NULL;


	switch( msg ) {


	case WM_PRINTCLIENT :

		if ( n_win_iconbutton_printclient_onoff )
		{
			n_win_iconbutton_hdc_override = (HDC) wparam;
			n_win_iconbutton_status_change( hwnd, (HDC) wparam, 0 );
		}

	break;


	case WM_MOUSEMOVE :

		// [!] : this code depends SetCapture()/ReleaseCapture()

		if ( n_posix_false == n_win_is_hovered( hwnd ) )
		{
			n_win_iconbutton_status_change( hwnd, NULL, 0 );
			hgui = NULL;
		}


		if ( n_win_iconbutton_uxtheme.onoff )
		{
			n_win_on_mousemove( hwnd );
		}

	break;

	case WM_MOUSEHOVER :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), "WM_MOUSEHOVER" );

		if ( n_win_iconbutton_uxtheme.onoff )
		{
			if ( n_win_iconbutton_ui_onoff == n_posix_false )
			{
				n_win_iconbutton_ui_onoff = n_posix_true;
				n_win_refresh( hwnd, n_posix_false );
			}
		}

	break;

	case WM_MOUSELEAVE :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), "WM_MOUSELEAVE" );

		n_win_iconbutton_status_change( hwnd, NULL, 0 );
		hgui = NULL;

		if ( n_win_iconbutton_uxtheme.onoff )
		{
			if ( n_win_iconbutton_ui_onoff )
			{
				n_win_iconbutton_ui_onoff = n_posix_false;
				n_win_refresh( hwnd, n_posix_false );
			}
		}

	break;


	case WM_ERASEBKGND :

		return n_posix_true;

	break;


	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN   :
	case WM_LBUTTONDBLCLK :

		SetCapture( hwnd );

		n_win_iconbutton_status_change( hwnd, NULL, ODS_SELECTED );
		hgui = hwnd;

		return 0;

	break;

	case WM_LBUTTONUP :

		ReleaseCapture();

		SetFocus( GetParent( hwnd ) );

		n_win_iconbutton_status_change( hwnd, NULL, 0 );
		if ( hwnd == hgui )
		{
			n_win_message_send( GetParent( hwnd ), WM_COMMAND, 0, hwnd );
		}
		hgui = NULL;

		return 0;

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( (WNDPROC) n_win_property_get_literal( hwnd, "Subclass" ), hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

#define n_win_iconbutton_init(     hwnd, hgui ) n_win_iconbutton_init_internal( hwnd, hgui, n_posix_false )
#define n_win_iconbutton_init_dwm( hwnd, hgui ) n_win_iconbutton_init_internal( hwnd, hgui, n_posix_true  )

void
n_win_iconbutton_init_internal( HWND hwnd, HWND hgui, n_posix_bool is_toolband )
{

	static n_posix_bool init = n_posix_false;


	if ( init == n_posix_false )
	{

		init = n_posix_true;

		n_uxtheme_zero( &n_win_iconbutton_uxtheme );

	}


	if ( n_win_iconbutton_refcount == 0 )
	{
		n_uxtheme_init( &n_win_iconbutton_uxtheme, hwnd, L"BUTTON" );

		if ( n_win_darkmode_onoff  ) { n_gdiplus_init(); }
		if ( n_win_fluent_ui_onoff ) { n_gdiplus_init(); }
	}

	n_win_iconbutton_refcount++;

//n_win_hwndprintf_literal( GetParent( hwnd ), "init : %d", n_win_iconbutton_refcount );


	n_win_iconbutton_scaled_offset = n_win_dpi( hgui ) / 96;


	if ( IsWindowEnabled( hgui ) )
	{
		n_win_property_init_literal( hgui, "PBS", PBS_NORMAL   );
	} else {
		n_win_property_init_literal( hgui, "PBS", PBS_DISABLED );
	}


	n_win_property_init_literal( hgui, "Toolband", is_toolband );


#ifdef _WIN64

	SetWindowSubclass( hgui, n_win_iconbutton_globalsubclass, 0, 0 );

#else  // #ifdef _WIN64

	{

		WNDPROC reg_func = (WNDPROC) n_win_property_get_literal( hgui, "Subclass" );
		WNDPROC prv_func = (WNDPROC) n_win_gui_subclass_get( hgui );
		WNDPROC new_func = n_win_iconbutton_globalsubclass;


		if (
			( reg_func == NULL )
			&&
			( prv_func != new_func )
		)
		{
			n_win_property_set_literal( hgui, "Subclass", (int) prv_func );
			n_win_gui_subclass_set( hgui, new_func );
		}

	}

#endif // #ifdef _WIN64


	if ( hgui == GetFocus() ) { SetFocus( GetParent( hgui ) ); }


	// [!] : emulate BS_DEFPUSHBUTTON

	if ( BS_DEFPUSHBUTTON == ( n_win_style_get( hgui ) & 0xf ) )
	{
		n_win_property_set_literal( hgui, "BS_DEFPUSHBUTTON", n_posix_true );
	}


	n_win_style_del( hgui, 0xf          );
	n_win_style_add( hgui, BS_OWNERDRAW );


	n_win_refresh( hgui, n_posix_false );


	return;
}

void
n_win_iconbutton_exit( HWND hwnd, HWND hgui )
{

#ifdef _WIN64
	RemoveWindowSubclass( hgui, n_win_iconbutton_globalsubclass, 0 );
#else  // #ifdef _WIN64
	WNDPROC reg_func = (WNDPROC) n_win_property_get_literal( hgui, "Subclass" );
	n_win_gui_subclass_set( hgui, reg_func );
	n_win_property_exit_literal( hgui, "Subclass" );
#endif // #ifdef _WIN64

	n_win_property_exit_literal( hgui, "PBS" );


	// [Needed] : when a child window uses win_iconbutton.c

	if ( n_win_iconbutton_refcount >= 1 ) { n_win_iconbutton_refcount--; }

	if ( n_win_iconbutton_refcount <= 0 )
	{

		n_uxtheme_exit( &n_win_iconbutton_uxtheme, hwnd );

		n_gdiplus_exit();

		n_win_iconbutton_refcount = 0;

	}

	n_win_iconbutton_ui_onoff = n_posix_false;

//n_win_hwndprintf_literal( GetParent( hwnd ), "free : %d", n_win_iconbutton_refcount );


	HICON hicon = (HICON) n_win_message_send( hgui, BM_GETIMAGE, IMAGE_ICON, 0 );
	if ( hicon != NULL ) { n_win_icon_exit( hicon ); }


	DestroyWindow( hgui );


	return;
}

// internal
void
n_win_iconbutton_draw_roundrect( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, int round, COLORREF color )
{

	s32 start_x = x;

	while( 1 )
	{//break;

		double coeff = 0;
		n_bmp_roundrect_detect_coeff( x,y, sx,sy, round, &coeff );

		COLORREF c = GetPixel( hdc, x, y );

		c = n_win_color_blend( c, color, coeff );

		SetPixelV( hdc, x, y, c );


		x++;
		if ( x >= sx )
		{

			x = start_x;

			y++;
			if ( y >= sy ) { break; }
		}
	}

	return;
}

// internal
void
n_win_iconbutton_draw
(
	n_uxtheme      *uxtheme,
	DRAWITEMSTRUCT *di,
	HDC             hdc_override,
	int             edge,
	int             bf,
	int             bp,
	int             pbs,
	int             dt,
	int             ds
)
{

	HWND hgui = di->hwndItem;

	s32 x,y,sx,sy; n_win_rect_expand_size( &di->rcItem, &x, &y, &sx, &sy );


	s32 o = n_win_iconbutton_scaled_offset;


	HDC hdc;

	if ( hdc_override == NULL )
	{
		hdc = n_gdi_doublebuffer_simple_init( hgui, sx,sy );
	} else {
		hdc = hdc_override;
	}


	n_posix_bool drawedge_onoff = n_posix_false;


	if (
		( n_win_fluent_ui_onoff == N_WIN_FLUENT_UI_OVERRIDE )
		||
		(
			( n_win_fluent_ui_onoff )
			&&
			( n_sysinfo_version_8_or_later() )
		)
	)
	{

		n_posix_bool is_toolband = n_win_property_get_literal( hgui, "Toolband" );

		if ( is_toolband )
		{
			if ( uxtheme->onoff )
			{
				uxtheme->DrawThemeParentBackground( hgui, hdc, &di->rcItem );
			} else {
				u32 c = n_win_dwm_roundrect_corner_color( n_win_hwnd_window( hgui ), WA_ACTIVE, is_toolband, n_posix_false );
				n_win_box( hgui, hdc, NULL, n_bmp_argb2colorref( c ) );
			}
		} else {
			u32 c = n_win_dwm_roundrect_corner_color( n_win_hwnd_window( hgui ), WA_ACTIVE, is_toolband, n_posix_false );
			n_win_box( hgui, hdc, NULL, n_bmp_argb2colorref( c ) );
		}


		COLORREF color1 = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE   );
		COLORREF color2 = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW );

		COLORREF base = n_win_color_blend( color1, color2, 0.25 );

		if ( pbs == PBS_HOT      ) { base  = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT  ); }
		if ( pbs == PBS_DISABLED ) { base  = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW  ); }
		if ( pbs == PBS_PRESSED  ) { base  = n_win_darkmode_systemcolor_ui( COLOR_3DDKSHADOW ); }


		if (
			( n_win_iconbutton_printclient_onoff == n_posix_false )
			&&
			( n_gdiplus_is_on() )
		)
		{
//n_posix_debug_literal( "" );

			n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_new_fast( &bmp, sx,sy );

			u32 c = n_win_dwm_roundrect_corner_color( n_win_hwnd_window( hgui ), WA_ACTIVE, is_toolband, n_posix_false );
			n_bmp_flush( &bmp, c );

			s32 r = n_win_fluent_ui_round_param();

			u32 clr_1  = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color1 ) );
			u32 clr_2  = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color2 ) );
			u32 border = n_bmp_blend_pixel( clr_1, clr_2, 0.75 );
			u32 color  = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( base ) );

			n_bmp_roundrect_pixel( &bmp, 0,0,sx      ,sy      , border, r );
			n_bmp_roundrect_pixel( &bmp, o,o,sx-(o*2),sy-(o*2), color , r );

			n_gdiplus_draw_fast( hdc, N_BMP_PTR( &bmp ), sx,sy );

			n_bmp_free_fast( &bmp );

		} else {

			s32 r = n_win_fluent_ui_round_param();
			s32 m = 1 * o;

			u32 border = n_win_color_blend( color1, color2, 0.75 );
			u32 color  = base;

			n_win_iconbutton_draw_roundrect( hdc, x  ,y  ,sx      ,sy      , r, border );
			n_win_iconbutton_draw_roundrect( hdc, x+m,y+m,sx-(m*1),sy-(m*1), r, color  );

		}

	} else
	if ( n_win_darkmode_onoff )
	{

		if (
			( n_win_iconbutton_printclient_onoff == n_posix_false )
			&&
			( n_gdiplus_is_on() )
		)
		{

			u32 frame = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT );
			u32 base  = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE   );
			if ( pbs == PBS_HOT      ) { base  = n_win_darkmode_systemcolor_ui( COLOR_BTNHIGHLIGHT ); }
			if ( pbs == PBS_DISABLED ) { base  = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW    ); }
			if ( pbs == PBS_PRESSED  ) { base  = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT    ); }

			frame = n_bmp_colorref2argb( frame );
			base  = n_bmp_colorref2argb( base  );

			frame = n_bmp_alpha_visible_pixel( frame );
			base  = n_bmp_alpha_visible_pixel( base  );

			n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_1st_fast( &bmp, sx,sy );

			n_bmp_flush( &bmp, frame );
			n_bmp_box( &bmp, 0+o,0+o,sx-(o*2),sy-(o*2), base );

			n_gdiplus_draw_fast( hdc, N_BMP_PTR( &bmp ), sx,sy );

			n_bmp_free_fast( &bmp );

		} else {

			u32 base  = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE   );
			if ( pbs == PBS_HOT      ) { base  = n_win_darkmode_systemcolor_ui( COLOR_BTNHIGHLIGHT ); }
			if ( pbs == PBS_DISABLED ) { base  = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW    ); }
			if ( pbs == PBS_PRESSED  ) { base  = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT    ); }

			n_win_box( hgui, hdc, &di->rcItem, base );
			drawedge_onoff = n_posix_true;

		}

	} else
	if ( uxtheme->onoff )
	{

		// [Needed]
		//
		//	XP    : when Compatible DC is used
		//	Vista : black margin when animation is enabled

/*
		if (
			( uxtheme->longhorn )
			&&
			( uxtheme->IsThemeBackgroundPartiallyTransparent( uxtheme->htheme, BP_PUSHBUTTON, pbs ) )
		)
*/		{

			n_posix_bool bg_onoff = n_win_property_get_literal( hgui, "Background.OnOff" );

			if ( bg_onoff == n_posix_false )
			{
				uxtheme->DrawThemeParentBackground( hgui, hdc, &di->rcItem );
			} else {
				n_win_box( hgui, hdc, &di->rcItem, n_win_darkmode_systemcolor_ui( COLOR_BTNFACE ) );
			}

		}

		uxtheme->DrawThemeBackground( uxtheme->htheme, hdc, bp,pbs, &di->rcItem, NULL );

		{

			s32 fb_sx = GetSystemMetrics( SM_CXFOCUSBORDER );
			s32 fb_sy = GetSystemMetrics( SM_CYFOCUSBORDER );

			RECT outer = di->rcItem;
			RECT inner;
			uxtheme->GetThemeBackgroundContentRect( uxtheme->htheme, hdc, bp,pbs, &outer, &inner );

			s32 u = abs( inner.top    - di->rcItem.top    ) + fb_sy;
			s32 d = abs( inner.bottom - di->rcItem.bottom ) + fb_sy;
			s32 l = abs( inner.left   - di->rcItem.left   ) + fb_sx;
			s32 r = abs( inner.right  - di->rcItem.right  ) + fb_sx;

			ExcludeClipRect( hdc,    0,   0,sx, u );
			ExcludeClipRect( hdc,    0,sy-d,sx,sy );
			ExcludeClipRect( hdc,    0,   0, l,sy );
			ExcludeClipRect( hdc, sx-r,   0,sx,sy );

		}

	} else {

		n_win_clear( hgui, hdc, &di->rcItem, COLOR_BTNFACE );

	}


	HICON  hicon = (HICON) n_win_message_send( hgui, BM_GETIMAGE, IMAGE_ICON, 0 );
	if ( hicon == NULL )
	{

		RECT r = di->rcItem;

		if ( di->itemState & ODS_SELECTED )
		{
			// [!] : Vista or later : Nonnon Original Behavior

			if ( uxtheme->onoff == n_posix_false )
			{
				n_win_rect_move( &r, o, o );
			} else
			if ( uxtheme->longhorn )
			{
				n_win_rect_move( &r, 0, o );
			}
		}


		int part, state;

		if ( uxtheme->onoff )
		{
			part  = bp;
			state = pbs;
		} else {
			part  = 0;
			state = di->itemState;
		}

		if ( state == PBS_DEFAULTED ) { state = 0; }

		n_uxtheme_draw_text( uxtheme, hgui, hdc, &r, part,state, dt, TMT_MSGBOXFONT, n_posix_true );

	} else {

		s32 ico_sx, ico_sy; n_win_stdsize_icon_large( &ico_sx, &ico_sy );
//n_posix_debug_literal( " %d %d ", ico_sx, ico_sy );
//ico_sx = ico_sy = 64;

		s32 tx = ( sx - ico_sx ) / 2;
		s32 ty = ( sy - ico_sy ) / 2;


		if ( di->itemState & ODS_SELECTED )
		{
			// [!] : Vista or later : Nonnon Original Behavior

			if ( uxtheme->onoff == n_posix_false )
			{
				tx += o;
				ty += o;
			} else
			if ( uxtheme->longhorn )
			{
				ty += o;
			}
		}


		// [Needed] : DWM : alpha value support

		int drawstate_onoff = n_win_property_get_literal( hgui, "DrawState" );

		if ( ( uxtheme->onoff )&&( drawstate_onoff == n_posix_false ) )//&&( n_win_dwm_is_on() ) )
		{

			HMODULE hmod = LoadLibrary( n_posix_literal( "comctl32.dll" ) );

			FARPROC n_ImageList_Create      = (void*) GetProcAddress( hmod, "ImageList_Create"      );
			FARPROC n_ImageList_ReplaceIcon = (void*) GetProcAddress( hmod, "ImageList_ReplaceIcon" );
			FARPROC n_ImageList_Destroy     = (void*) GetProcAddress( hmod, "ImageList_Destroy"     );

			// [x] : Win10 : stretching is forced always
			int n_ILC_ORIGINALSIZE = 0x00010000;

			// [x] : WinXP : ILC_ORIGINALSIZE : handled as error
			if ( n_posix_false == n_sysinfo_version_vista_or_later() ) { n_ILC_ORIGINALSIZE = 0; }


			HIMAGELIST hil = (void*) n_ImageList_Create( ico_sx, ico_sy, ILC_COLOR32 | ILC_MASK | n_ILC_ORIGINALSIZE, 1, 0 );


			if ( pbs != PBS_DISABLED )
			{

				n_ImageList_ReplaceIcon( hil, -1, hicon );

			} else {

				HICON hicon_gray = n_win_icon_grayed( hicon, ico_sx, ico_sy );

				n_ImageList_ReplaceIcon( hil, -1, hicon_gray );

				n_win_icon_exit( hicon_gray );

			}


			RECT r = n_win_rect_set( NULL, tx, ty, ico_sx, ico_sy );
			uxtheme->DrawThemeIcon( uxtheme->htheme, hdc, bp,pbs, &r, hil, 0 );

			n_ImageList_Destroy( hil );


			FreeLibrary( hmod );

		} else {

			if ( ( pbs != PBS_DISABLED )||( n_win_fluent_ui_onoff == n_posix_false ) )
			{

				HBRUSH hb = GetSysColorBrush( COLOR_BTNFACE );
				DrawState( hdc, hb, NULL, (LPARAM) hicon,0, tx,ty,0,0, ds | DST_ICON );

			} else {

				HICON hicon_gray = n_win_icon_grayed( hicon, ico_sx, ico_sy );

				DrawIcon( hdc, tx,ty, hicon_gray );

				n_win_icon_exit( hicon_gray );

			}

		}

	}

	if ( n_win_fluent_ui_onoff )
	{
		//
	} else
	if ( ( uxtheme->onoff == n_posix_false )||( drawedge_onoff ) )
	{

		DrawEdge( hdc, &di->rcItem, edge, bf );

		if ( di->itemState & ODS_FOCUS )
		{

			RECT r = { x, y, x + sx, y + sy };

			n_win_rect_resize( &r, 3, 3 );

			DrawFocusRect( hdc, &r );

		}

	}


	// Cleanup

	// [!] : don't do n_win_icon_exit( hicon );

	if ( hdc_override == NULL )
	{
		if ( hicon == NULL ) { n_gdi_doublebuffer_visible( &n_gdi_doublebuffer_instance ); }
		n_gdi_doublebuffer_simple_exit();
	}


	return;
}

void
n_win_iconbutton_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui )
{

	// [!] : XP or later : this message is sent many times

	// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

	n_uxtheme_exit( &n_win_iconbutton_uxtheme, hwnd );
	n_uxtheme_init( &n_win_iconbutton_uxtheme, hwnd, L"BUTTON" );

	if ( n_win_darkmode_onoff  ) { n_gdiplus_init(); }
	if ( n_win_fluent_ui_onoff ) { n_gdiplus_init(); }

	n_win_refresh( hgui, n_posix_true );


	return;
}

void
n_win_iconbutton_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui )
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [Needed] : you need to call this manually

		//n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, hgui );

	break;


	case WM_CREATE :

		// [Needed] : you need to call this manually

		//n_win_iconbutton_init( hwnd, hgui );

	break;


	case WM_CLOSE :

		// [Needed] : you need to call this manually

		//n_win_iconbutton_exit( hwnd, hgui );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;


		if ( di           == NULL ) { break; }
		if ( di->hwndItem != hgui ) { break; }


		int  edge = EDGE_RAISED;
		int    bf = BF_RECT;
		int    bp = BP_PUSHBUTTON;
		int   pbs = PBS_NORMAL;
		int    dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
		UINT   ds = DSS_NORMAL;


		if ( di->itemState & ODS_DISABLED )
		{
			pbs  = PBS_DISABLED;
			ds  |= DSS_DISABLED;
		} else
		if ( di->itemState & ODS_SELECTED )
		{
			edge = EDGE_SUNKEN;
			pbs  = PBS_PRESSED;
		} else
		if ( hgui == n_win_cursor2hwnd() )
		{
			if ( n_win_style_is_classic() )
			{
				//
			} else {
				pbs = PBS_HOT;
			}
		} else
		if ( ( di->itemState & ODS_FOCUS )||( n_win_property_get_literal( hgui, "BS_DEFPUSHBUTTON" ) ) )
		{
			// [!] : Nonnon original behavior
			pbs = PBS_DEFAULTED;
		}// else


		DWORD style = n_win_style_get( hgui );
		if ( style & BS_FLAT )
		{
			// [!] : BF_FLAT == WS_BORDER
			edge = EDGE_RAISED;
			bf   = bf | BF_MONO;
		}

		if ( style & BS_PUSHLIKE )
		{
			// [!] : Nonnon original behavior
			edge = EDGE_SUNKEN;
			pbs  = PBS_PRESSED;
			bf   = bf & ~BF_MONO;
		}


		// Classic & XP

		if (
			( n_win_iconbutton_uxtheme.onoff    == n_posix_false )
			||
			( n_win_iconbutton_uxtheme.longhorn == n_posix_false )
		)
		{

			n_win_iconbutton_draw( &n_win_iconbutton_uxtheme, di, n_win_iconbutton_hdc_override, edge, bf, bp, pbs, dt, ds );

			break;
		}


		// Vista : Animation : OFF

		BOOL onoff = n_win_fade_is_on();

		if ( onoff == n_posix_false )
		{

			n_win_iconbutton_draw( &n_win_iconbutton_uxtheme, di, n_win_iconbutton_hdc_override, edge, bf, bp, pbs, dt, ds );

			break;
		}


		// Vista : Animation : ON

		int ret = n_win_iconbutton_uxtheme.BufferedPaintRenderAnimation( hgui, di->hDC );
		if ( ret ) { break; }


		BP_ANIMATIONPARAMS bp_ap = { sizeof( BP_ANIMATIONPARAMS ), 0, BPAS_LINEAR, 0 };

		int p_pbs = n_win_property_get_literal( hgui, "PBS" );

		n_win_iconbutton_uxtheme.GetThemeTransitionDuration
		(
			n_win_iconbutton_uxtheme.htheme,
			BP_PUSHBUTTON,
			p_pbs, pbs,
			TMT_TRANSITIONDURATIONS,
			&bp_ap.dwDuration
		);

//n_win_hwndprintf_literal( hwnd, "%d", (int) bp_ap.dwDuration );


//n_win_iconbutton_draw( &n_win_iconbutton_uxtheme, di, NULL, edge, bf, bp, pbs, dt, ds );


		// [x] : GDI Handle Leak : fixed ???


		// [Needed] : on DWM : BPBF_TOPDOWNDIB

		HDC hdc_f = NULL;
		HDC hdc_t = NULL;

		HANIMATIONBUFFER hab = n_win_iconbutton_uxtheme.BeginBufferedAnimation
		(
			hgui, di->hDC, &di->rcItem,
			BPBF_TOPDOWNDIB,//BPBF_COMPATIBLEBITMAP,
			NULL, &bp_ap,
			&hdc_f, &hdc_t
		);


		if ( hdc_f != NULL )
		{
			n_win_iconbutton_draw( &n_win_iconbutton_uxtheme, di, hdc_f, edge, bf, bp, p_pbs, dt, ds );
		}

		if ( hdc_t != NULL )
		{
			n_win_iconbutton_draw( &n_win_iconbutton_uxtheme, di, hdc_t, edge, bf, bp,   pbs, dt, ds );
		}

		n_win_property_set_literal( hgui, "PBS", pbs );


		n_win_iconbutton_uxtheme.EndBufferedAnimation( hab, n_posix_true );

	}
	break;


	} // switch


	return;
}

n_posix_bool
n_win_iconbutton_checklike( HWND hgui, int index_off, int index_on, n_posix_bool onoff )
{

	// [!] : BS_AUTOCHECKBOX-like behavior


	n_posix_char *exe = n_win_exepath_new();

	if ( onoff )
	{

		onoff = n_posix_false;

		n_win_icon_set( hgui, n_win_icon_init( exe, index_off, N_WIN_ICON_INIT_OPTION_RESOURCE ) );

		n_win_style_del( hgui, BS_PUSHLIKE );

	} else {

		onoff = n_posix_true;

		n_win_icon_set( hgui, n_win_icon_init( exe, index_on,  N_WIN_ICON_INIT_OPTION_RESOURCE ) );

		n_win_style_add( hgui, BS_PUSHLIKE );

	}

	n_string_path_free( exe );


	return onoff;
}


#endif // _H_NONNON_WIN32_WIN_ICONBUTTON

