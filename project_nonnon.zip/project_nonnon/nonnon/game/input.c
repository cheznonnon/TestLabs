// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GAME_INPUT
#define _H_NONNON_WIN32_GAME_INPUT




#include "../neutral/posix.c"




#define N_GAME_INPUT_BUTTON_MAX 16




typedef struct {

	int number;
	int udlr   [                       4 ];
	int buttons[ N_GAME_INPUT_BUTTON_MAX ];

	// [!] : internal cache

	HMODULE hmod_winmm;
	FARPROC joyGetPos;

	HMODULE hmod_xinput;
	FARPROC XInputGetCapabilities;
	FARPROC XInputGetState;
	FARPROC XInputSetState;

} n_game_input;




#define n_game_input_zero( p ) n_memory_zero( p, sizeof( n_game_input ) )

void
n_game_input_exit( n_game_input *p )
{

	if ( p == NULL ) { return; }


	FreeLibrary( p->hmod_winmm  );
	FreeLibrary( p->hmod_xinput );

	n_game_input_zero( p );


	return;
}

void
n_game_input_init( n_game_input *p, int number )
{

	if ( p == NULL ) { return; }


	n_game_input_exit( p );


	p->number = number;


	p->hmod_winmm = LoadLibrary( n_posix_literal( "Winmm.dll" ) );
	if ( p->hmod_winmm == NULL )
	{
//n_posix_debug_literal( " LoadLibrary() : Winmm.dll " );
	}

	p->joyGetPos = GetProcAddress( p->hmod_winmm, "joyGetPos" );

	if ( p->joyGetPos == NULL )
	{

		FreeLibrary( p->hmod_winmm );

		p->hmod_winmm = NULL;
		p->joyGetPos  = NULL;

	}


	p->hmod_xinput = LoadLibrary( n_posix_literal( "Xinput9_1_0.dll" ) );
	if ( p->hmod_xinput == NULL )
	{
		p->hmod_xinput = LoadLibrary( n_posix_literal( "Xinput1_4.dll" ) );
	}
	if ( p->hmod_xinput == NULL )
	{
//n_posix_debug_literal( " LoadLibrary() : Xinput.dll " );
	}

	p->XInputGetCapabilities = GetProcAddress( p->hmod_xinput, "XInputGetCapabilities" );
	p->XInputGetState        = GetProcAddress( p->hmod_xinput, "XInputGetState"        );
	p->XInputSetState        = GetProcAddress( p->hmod_xinput, "XInputSetState"        );

	if (
		( p->XInputGetCapabilities == NULL )
		||
		( p->XInputGetState        == NULL )
		||
		( p->XInputSetState        == NULL )
	)
	{

		FreeLibrary( p->hmod_xinput );

		p->hmod_xinput           = NULL;
		p->XInputGetCapabilities = NULL;
		p->XInputGetState        = NULL;
		p->XInputSetState        = NULL;

	}


	return;
}

#define n_game_input_vk2udlr_default( p ) n_game_input_vk2udlr( p, VK_UP, VK_DOWN, VK_LEFT, VK_RIGHT )

void
n_game_input_vk2udlr( n_game_input *p, int vk_u, int vk_d, int vk_l, int vk_r )
{

	if ( p == NULL ) { return; }


	p->udlr[ 0 ] = vk_u;
	p->udlr[ 1 ] = vk_d;
	p->udlr[ 2 ] = vk_l;
	p->udlr[ 3 ] = vk_r;


	return;
}

void
n_game_input_vk2button( n_game_input *p, int vk, int button )
{

	if ( p == NULL ) { return; }


	if ( button <                        0 ) { return; }
	if ( button >= N_GAME_INPUT_BUTTON_MAX ) { return; }


	p->buttons[ button ] = vk;


	return;
}

n_posix_bool
n_game_input_joyGetPos( n_game_input *p, int vk )
{

	if ( p             == NULL ) { return n_posix_false; }
	if ( p->hmod_winmm == NULL ) { return n_posix_false; }


	// [Mechanism]
	//
	//	[ wButtons ]
	//
	//	1, 2, 4, 8...
	//	3 means that Button#1 and Button#2 are pressed together


	// [Problem] : joyGetPos() : before DirectX7
	//
	//	joyGetPos() returns zero-cleared JOYINFO
	//	this causes moving top-left
	//
	//	=> only at the first execute till the first input


	// [Problem] : joyGetPos()
	//
	//	process will be heavy after unplugging USB joystick 


	static n_posix_bool fallback = n_posix_false;

	if ( fallback ) { return n_posix_false; }


	typedef struct joyinfo_tag
	{

		UINT wXpos;
		UINT wYpos;
		UINT wZpos;
		UINT wButtons;

	} JOYINFO,*PJOYINFO,*LPJOYINFO;


	JOYINFO info;

	if ( p->joyGetPos( p->number, &info ) )
	{

		fallback = n_posix_true;

		return n_posix_false;
	}


	static n_posix_bool is_first = n_posix_true;

	if ( is_first )
	{

		if (
			( info.wYpos == 0 )&&( info.wXpos == 0 )&&( info.wZpos == 0 )
			&&
			( info.wButtons == 0 )
		)
		{
			return n_posix_false;
		}

		is_first = n_posix_false;

	}


	// Arrow

	info.wXpos &= 0xff00;
	info.wYpos &= 0xff00;

	if ( ( vk == p->udlr[ 0 ] )&&( info.wYpos == 0x0000 ) ) { return n_posix_true; }
	if ( ( vk == p->udlr[ 1 ] )&&( info.wYpos == 0xff00 ) ) { return n_posix_true; }
	if ( ( vk == p->udlr[ 2 ] )&&( info.wXpos == 0x0000 ) ) { return n_posix_true; }
	if ( ( vk == p->udlr[ 3 ] )&&( info.wXpos == 0xff00 ) ) { return n_posix_true; }


	// Buttons

	int i = 0;
	n_posix_loop
	{

		if ( info.wButtons & ( 1 << i ) )
		{
//n_game_hwndprintf_literal( "%d", info.wButtons );
			if ( vk == p->buttons[ i ] ) { return n_posix_true; }
		}

		i++;
		if ( i >= N_GAME_INPUT_BUTTON_MAX ) { break; }
	}


	return n_posix_false;
}

#define n_XINPUT_GAMEPAD_DPAD_UP        0x0001
#define n_XINPUT_GAMEPAD_DPAD_DOWN      0x0002
#define n_XINPUT_GAMEPAD_DPAD_LEFT      0x0004
#define n_XINPUT_GAMEPAD_DPAD_RIGHT     0x0008
#define n_XINPUT_GAMEPAD_START          0x0010
#define n_XINPUT_GAMEPAD_BACK           0x0020
#define n_XINPUT_GAMEPAD_LEFT_THUMB     0x0040
#define n_XINPUT_GAMEPAD_RIGHT_THUMB    0x0080
#define n_XINPUT_GAMEPAD_LEFT_SHOULDER  0x0100
#define n_XINPUT_GAMEPAD_RIGHT_SHOULDER 0x0200
#define n_XINPUT_GAMEPAD_A              0x1000
#define n_XINPUT_GAMEPAD_B              0x2000
#define n_XINPUT_GAMEPAD_X              0x4000
#define n_XINPUT_GAMEPAD_Y              0x8000

#define n_XINPUT_FLAG_GAMEPAD           0x00000001

#define N_GAME_INPUT_XINPUT_THUMB_MIN    -32768
#define N_GAME_INPUT_XINPUT_THUMB_MAX     32767

#define N_GAME_INPUT_XINPUT_TRIGGER_MAX   255

n_posix_bool
n_game_input_XInput( n_game_input *p, int vk )
{

	if ( p              == NULL ) { return n_game_input_joyGetPos( p, vk ); }
	if ( p->hmod_xinput == NULL ) { return n_game_input_joyGetPos( p, vk ); }


	typedef struct _XINPUT_GAMEPAD
	{

		WORD  wButtons;
		BYTE  bLeftTrigger;
		BYTE  bRightTrigger;
		SHORT sThumbLX;
		SHORT sThumbLY;
		SHORT sThumbRX;
		SHORT sThumbRY;

	} XINPUT_GAMEPAD, *PXINPUT_GAMEPAD;


	typedef struct _XINPUT_VIBRATION
	{

		WORD wLeftMotorSpeed;
		WORD wRightMotorSpeed;

	} XINPUT_VIBRATION, *PXINPUT_VIBRATION;


	typedef struct _XINPUT_CAPABILITIES
	{

		BYTE             Type;
		BYTE             SubType;
		WORD             Flags;
		XINPUT_GAMEPAD   Gamepad;
		XINPUT_VIBRATION Vibration;

	} XINPUT_CAPABILITIES, *PXINPUT_CAPABILITIES;


	typedef struct _XINPUT_STATE
	{

		DWORD          dwPacketNumber;
		XINPUT_GAMEPAD Gamepad;

	} XINPUT_STATE, *PXINPUT_STATE;


	XINPUT_CAPABILITIES caps; ZeroMemory( &caps, sizeof( XINPUT_CAPABILITIES ) );
	DWORD dw = (DWORD) p->XInputGetCapabilities( p->number, n_XINPUT_FLAG_GAMEPAD, &caps );
	if ( dw == ERROR_DEVICE_NOT_CONNECTED )
	{
		return n_game_input_joyGetPos( p, vk );
	}


	XINPUT_STATE state; ZeroMemory( &state, sizeof( XINPUT_STATE ) );
	p->XInputGetState( p->number, &state );

	WORD button = state.Gamepad.wButtons;
//if ( button ) { n_game_hwndprintf_literal( " %d : %d ", state.dwPacketNumber, button ); }

	if ( ( vk == p->udlr   [  0 ] )&&( button & n_XINPUT_GAMEPAD_DPAD_UP        ) ) { return n_posix_true; }
	if ( ( vk == p->udlr   [  1 ] )&&( button & n_XINPUT_GAMEPAD_DPAD_DOWN      ) ) { return n_posix_true; }
	if ( ( vk == p->udlr   [  2 ] )&&( button & n_XINPUT_GAMEPAD_DPAD_LEFT      ) ) { return n_posix_true; }
	if ( ( vk == p->udlr   [  3 ] )&&( button & n_XINPUT_GAMEPAD_DPAD_RIGHT     ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  0 ] )&&( button & n_XINPUT_GAMEPAD_Y              ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  1 ] )&&( button & n_XINPUT_GAMEPAD_B              ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  2 ] )&&( button & n_XINPUT_GAMEPAD_A              ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  3 ] )&&( button & n_XINPUT_GAMEPAD_X              ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  6 ] )&&( button & n_XINPUT_GAMEPAD_LEFT_SHOULDER  ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  7 ] )&&( button & n_XINPUT_GAMEPAD_RIGHT_SHOULDER ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  8 ] )&&( button & n_XINPUT_GAMEPAD_LEFT_THUMB     ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  9 ] )&&( button & n_XINPUT_GAMEPAD_RIGHT_THUMB    ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[ 10 ] )&&( button & n_XINPUT_GAMEPAD_BACK           ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[ 11 ] )&&( button & n_XINPUT_GAMEPAD_START          ) ) { return n_posix_true; }

	BYTE l2 = state.Gamepad.bLeftTrigger;
	BYTE r2 = state.Gamepad.bRightTrigger;

	if ( ( vk == p->buttons[  4 ] )&&( l2 == N_GAME_INPUT_XINPUT_TRIGGER_MAX    ) ) { return n_posix_true; }
	if ( ( vk == p->buttons[  5 ] )&&( r2 == N_GAME_INPUT_XINPUT_TRIGGER_MAX    ) ) { return n_posix_true; }

	SHORT updown = state.Gamepad.sThumbLY;
	SHORT lr     = state.Gamepad.sThumbLX;
//n_game_hwndprintf_literal( " %d : %d : %d : %d ", updown, lr, state.Gamepad.sThumbRX, state.Gamepad.sThumbRY );

	if ( ( vk == p->udlr   [  0 ] )&&( updown == N_GAME_INPUT_XINPUT_THUMB_MAX   ) ) { return n_posix_true; }
	if ( ( vk == p->udlr   [  1 ] )&&( updown == N_GAME_INPUT_XINPUT_THUMB_MIN   ) ) { return n_posix_true; }
	if ( ( vk == p->udlr   [  2 ] )&&( lr     == N_GAME_INPUT_XINPUT_THUMB_MIN   ) ) { return n_posix_true; }
	if ( ( vk == p->udlr   [  3 ] )&&( lr     == N_GAME_INPUT_XINPUT_THUMB_MAX   ) ) { return n_posix_true; }


	return n_posix_false;
}

#define N_GAME_INPUT_XINPUT_VIBRATE_MAX 65535

void
n_game_input_XInput_vibrate( n_game_input *p, int vibrate_l, int vibrate_r )
{

	if ( p              == NULL ) { return; }
	if ( p->hmod_xinput == NULL ) { return; }


	typedef struct _XINPUT_VIBRATION
	{

		WORD wLeftMotorSpeed;
		WORD wRightMotorSpeed;

	} XINPUT_VIBRATION, *PXINPUT_VIBRATION;


	XINPUT_VIBRATION v = { vibrate_l, vibrate_r };
	p->XInputSetState( p->number, &v );


	return;
}

n_posix_bool
n_game_input_loop( n_game_input *p, int vk )
{

	// [Mechanism]
	//
	//	[ GetAsyncKeyState() ]
	//
	//	first input            : 0xffff8001
	//	second input and later : 0xffff8000
	//
	//	single-fire            : AND 0x0001
	//	rapid-fire             : AND 0x8000


	// Key Input : rapid fire only

	if ( 0x8000 & GetAsyncKeyState( vk ) ) { return n_posix_true; }


	// Gamepad Input

	if ( n_game_input_XInput   ( p, vk ) ) { return n_posix_true; }
	//if ( n_game_input_joyGetPos( p, vk ) ) { return n_posix_true; }


	return n_posix_false;
}


#endif // _H_NONNON_WIN32_GAME_INPUT

