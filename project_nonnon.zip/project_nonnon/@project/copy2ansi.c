// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/path.c"




int
main( void )
{

	n_posix_char *f[] = {
		"@toybox\\directx\\Nonnon Direct2D1 DLL\\Nonnon Direct2D1 DLL.dll",
		//"@toybox\\gdiplus\\Nonnon GDIPlus DLL.dll",
		"arcdrop\\arcdrop.exe",
		"gameconsole\\gameconsole.exe",
		"nonnonapps\\nonnonapps.exe",
		NULL
	};

	n_posix_char *t = "Z:\\nonnon\\cheznonnon\\nonnon_win\\software\\nonnon_win_ansi";


	int i = 0;
	while( 1 )
	{

		n_posix_char name_f[ N_PATH_MAX ]; n_path_getcwd( name_f ); n_path_maker( name_f, f[ i ], name_f );
		n_posix_char name_t[ N_PATH_MAX ]; n_path_name( name_f, name_t ); n_path_maker( t, name_t, name_t );

		n_filer_merge( name_f, name_t );
//n_posix_debug_literal( "%s\n%s", name_f, name_t );

		i++;
		if ( f[ i ] == NULL ) { break; }
	}


	return 0;
}

