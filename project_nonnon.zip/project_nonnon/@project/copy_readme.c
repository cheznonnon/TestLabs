// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"




int
main( void )
{

	n_posix_char *f = "Z:\\c\\nonnon\\project\\readme";
	n_posix_char *a = "Z:\\nonnon\\cheznonnon\\nonnon_win\\software\\nonnon_win_ansi\\readme";
	n_posix_char *u = "Z:\\nonnon\\cheznonnon\\nonnon_win\\software\\nonnon_win_unicode\\readme";
	n_posix_char *x = "Z:\\nonnon\\cheznonnon\\nonnon_win\\software\\nonnon_win_x64\\readme";


	n_filer_remove( a );
	n_filer_remove( u );
	n_filer_remove( x );

	n_filer_copy( f, a );
	n_filer_copy( f, u );
	n_filer_copy( f, x );


	return 0;
}

