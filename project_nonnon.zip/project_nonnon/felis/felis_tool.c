// Felis
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_FELIS_EXT_URL n_posix_literal( ".url\0\0" )




n_bool
n_felis_bool_toggle( n_bool b )
{

	if ( b ) { b = n_false; } else { b = n_true; }


	return b;
}

n_bool
n_felis_not_supported( void )
{

	int v = n_WebBrowser_version();

	if ( v <= 3 )
	{

		return n_true;

	} else
	if ( v >= 8 )
	{

		const n_posix_char *keyname = n_posix_literal( "Software\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION" );

		n_posix_char *lval = n_string_path_name_new( n_felis_exepath );
//n_posix_debug_literal( "%s", n_felis_exepath );

		DWORD rval = v * 1000;
		n_registry_write( HKEY_CURRENT_USER, keyname, lval, REG_DWORD, &rval, sizeof( DWORD ) );

		n_string_path_free( lval );

	}


	return n_false;
}




void
n_felis_newwindow( BSTR bstr )
{

	n_posix_char *felis = n_win_exepath_new();
	n_posix_char *delim = n_posix_literal( " " );

#ifdef NONNON_APPS

	n_posix_char *option = N_APPS_OPTION_FELIS;

#else  // #ifdef NONNON_APPS

	n_posix_char *option = N_STRING_EMPTY;

#endif // #ifdef NONNON_APPS


	n_posix_char *str = n_com_bstr2string( bstr );
	n_posix_char *exe = n_string_path_cat( felis, delim, option, delim, str, NULL );

	n_win_exec( exe, SW_NORMAL );

	n_memory_free( exe );
	n_memory_free( str );

	n_memory_free( felis );


	return;
}




n_bool
n_felis_is_url( const wchar_t *protocol, const wchar_t *url )
{

	if ( protocol == NULL ) { return n_false; }
	if ( url      == NULL ) { return n_false; }


	n_type_int len_f = wcslen( protocol );
	n_type_int len_t = wcslen( url );

	if ( len_f > len_t ) { return n_false; }


	return ( 0 == memcmp( protocol, url, len_f * sizeof( wchar_t ) ) );
}

n_posix_char*
n_felis_urlfile_load_new( const n_posix_char *url_name )
{

	if ( n_false == n_string_path_ext_is_same( N_FELIS_EXT_URL, url_name ) ) { return NULL; }


	const n_posix_char *sect = n_posix_literal( "[InternetShortcut]" );
	const n_posix_char *lval = n_posix_literal( "URL" );


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, url_name );

	n_posix_char *ret = n_ini_value_str_new( &ini, sect, lval, N_STRING_EMPTY );

	n_ini_free( &ini );


	return ret;
}

void
n_felis_urlfile_save( const n_posix_char *title, const n_posix_char *url )
{

	const n_posix_char *sect = n_posix_literal( "[InternetShortcut]" );
	const n_posix_char *lval = n_posix_literal( "URL" );


	// [!] : make a .URL file on desktop

	n_posix_char *url_path = n_explorer_path_new( NULL );
	n_posix_char *url_name = n_string_path_carboncopy( title ); n_string_safename( url_name, url_name );
	n_posix_char *url_save = n_string_path_cat( url_path, N_POSIX_SLASH, url_name, N_FELIS_EXT_URL, NULL );
//n_posix_debug( url_save );


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, url_save );

	n_ini_section_add( &ini, sect );
	n_ini_key_add_str( &ini, sect, lval, url );

	n_ini_save( &ini, url_save );
	n_ini_free( &ini );


	n_string_path_free( url_path );
	n_string_path_free( url_name );
	n_string_path_free( url_save );


	n_explorer_refresh( n_false );


	return;
}




n_type_int
n_felis_frameset_count( IWebBrowser2 *wb )
{

	LONG l = 0;


	IHTMLDocument2 *hd = n_WebBrowser_MSHTML( (void*) wb );
	IHTMLWindow2   *hw = NULL; if ( hd != NULL ) { IHTMLDocument2_get_parentWindow( hd, &hw ); }

	if ( hw != NULL )
	{
		IHTMLWindow2_get_length( hw, &l );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( H_WB ), "%d", l );
	}

	n_com_release( hw );
	n_com_release( hd );


	return (n_type_int) l;
}

void
n_felis_history_clear( HWND hwnd )
{

	n_WebBrowser_historycleaner();


	{

		n_posix_char *s = n_com_bstr2string( n_felis_url_current );

#ifdef NONNON_APPS

		n_posix_char *str = n_string_path_cat( n_felis_exepath, N_STRING_SPACE, N_APPS_OPTION_FELIS, N_STRING_SPACE, s, NULL );

#else  // #ifdef NONNON_APPS

		n_posix_char *str = n_string_path_cat( n_felis_exepath, N_STRING_SPACE, s, NULL );

#endif // #ifdef NONNON_APPS

		n_win_exec( str, SW_NORMAL );

		n_string_path_free( str );

		n_memory_free( s );


		n_win_message_post( hwnd, WM_CLOSE, 0,0 );

	}


	return;
}




static n_posix_char *n_felis_url_home      = NULL;
static n_posix_char *n_felis_url_select2go = NULL;

void
n_felis_ini_read( void )
{
//return;

	const n_posix_char *section = n_posix_literal( "[Felis]" );


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_project_ini_name );


	const n_posix_char *lval_hp = n_posix_literal( "homepage " );
	const n_posix_char * def_hp = n_posix_literal( "about:blank" );

	const n_posix_char *lval_sg = n_posix_literal( "select2go" );
	const n_posix_char * def_sg = n_posix_literal( "https://en.wikipedia.org/w/index.php?search=%s" );


	n_felis_url_home      = n_ini_value_str_new( &ini, section, lval_hp, def_hp );
	n_felis_url_select2go = n_ini_value_str_new( &ini, section, lval_sg, def_sg );
//n_posix_debug_literal( "%s\n%s", n_felis_url_home, n_felis_url_select2go );


	// [!] : backward compatibility : for alignment using space, see "lval_hp"

	n_bool ie_exist_sg = n_ini_key_chk( &ini, section, lval_sg );

	if ( ie_exist_sg == n_false )
	{
		n_ini_section_del( &ini, section );
	}


	n_ini_section_add( &ini, section );

	n_ini_key_add_str( &ini, section, lval_hp, n_felis_url_home      );
	n_ini_key_add_str( &ini, section, lval_sg, n_felis_url_select2go );


	n_ini_save( &ini, n_project_ini_name );


	n_ini_free( &ini );


	return;
}




n_bool
n_felis_select2go( IWebBrowser2 *_this )
{

	n_bool is_done = n_false;


	BSTR bstr = n_WebBrowser_selection( _this );


	n_posix_char *s = n_com_bstr2string( bstr );
//n_posix_debug_literal( "%s", s );

	if ( n_false == n_string_is_empty( s ) )
	{

		n_posix_char *s2 = n_www_percentencoding_encode( s );
		n_string_copy( &s2[ n_posix_strlen_literal( "file:///" ) ], s2 );
//n_posix_debug_literal( "%s", s2 );

		{

			n_posix_char *go = n_string_new( n_posix_strlen( n_felis_url_select2go ) + n_posix_strlen( s2 ) );
			n_string_copy( n_felis_url_select2go, go );
			n_string_replace( go, go, n_posix_literal( "%s" ), s2 );
//n_posix_debug_literal( "%s", go );

			{
				BSTR bstr = n_com_bstr_init( go );


				const n_bool is_singlewindow = n_false;

				if ( is_singlewindow )
				{
					n_WebBrowser_go( n_felis_wb, bstr );
				} else {
					n_felis_newwindow( bstr );
				}


				is_done = n_true;


				n_com_bstr_exit( bstr );
			}

			n_memory_free( go );

		}

		n_memory_free( s2 );

	}

	n_memory_free( s );


	n_com_bstr_exit( bstr );


	return is_done;
}




void
n_felis_info_draw( n_gdi *gdi )
{

	n_posix_char *s = N_STRING_EMPTY;

	{

		BSTR bstr = n_WebBrowser_useragent( n_felis_wb );

		s = n_com_bstr2string( bstr );

		n_com_bstr_exit( bstr );

	}


	{ // [Patch] : wordwrapper

	n_type_int    l = n_posix_strlen( s );
	n_posix_char *t = n_string_new_fast( l * 2 );

	n_type_int i  = 0;
	n_type_int ii = 0;
	n_posix_loop
	{

		if ( s[ i ] == N_STRING_CHAR_NUL      )
		{

			break;

		} else
		if ( s[ i ] == n_posix_literal( '(' ) )
		{

			t[ ii ] = N_STRING_CHAR_LF; ii++;
			i++;

		} else
		if ( s[ i ] == n_posix_literal( ')' ) )
		{

			i++;
			if ( s[ i ] != N_STRING_CHAR_NUL )
			{
				t[ ii ] = N_STRING_CHAR_LF; ii++;
				if ( s[ i ] == N_STRING_CHAR_SPACE ) { i++; }
			}

		} else {

			if ( s[ i ] == N_STRING_CHAR_SEMICOLON )
			{
				t[ ii ] = N_STRING_CHAR_LF; ii++;
				i++;
				if ( s[ i ] == N_STRING_CHAR_SPACE ) { i++; }
			} else {
				t[ ii ] = s[ i ]; ii++;
				i++;
			}

		}

	}

	n_string_terminate( t, ii );

	n_memory_free( s );
	s = t;

	} // [Patch] : wordwrapper


	gdi[ 0 ].layout      = N_GDI_LAYOUT_VERTICAL;
	gdi[ 0 ].frame_style = N_GDI_FRAME_TRANS;
	gdi[ 0 ].icon        = n_string_carboncopy( n_felis_exepath );
	gdi[ 0 ].icon_index  = N_APPS_ICON_OFFSET_FELIS;
	gdi[ 0 ].text        = n_string_carboncopy( n_posix_literal( "Felis Local Web Browser" ) );
	gdi[ 0 ].text_font   = n_project_stdfont();
	gdi[ 0 ].text_size   = (n_type_gfx) ( (n_type_real) gdi[ 0 ].text_size * 1.5 );
	gdi[ 0 ].text_style |= N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD;

	//gdi[ 1 ].frame_style = N_GDI_FRAME_FLAT;
	gdi[ 1 ].text        = s;
	gdi[ 1 ].text_font   = n_project_stdfont();
	gdi[ 1 ].text_style |= N_GDI_TEXT_SMOOTH;


	return;
}

void
n_felis_info( HWND hwnd )
{

	n_win_richdialog_init( &n_win_richdialog_instance, 2, n_posix_literal( "Felis" ) );

	n_win_richdialog_instance.on_settingchange = &n_felis_info_draw;

	n_felis_info_draw( n_win_richdialog_instance.gdi );

	n_win_richdialog_go( &n_win_richdialog_instance, hwnd );


	return;
}




#define n_felis_register_filetype_literal( name ) n_felis_register_filetype( n_posix_literal( name ) )

void
n_felis_register_filetype( const n_posix_char *filetype )
{

#ifndef NONNON_APPS

	const n_posix_char *caption = n_posix_literal( "" );

	n_posix_char *pth = n_win_exepath_new();
	n_posix_char *ico = n_string_path_cat( pth, n_posix_literal( ",1"      ), NULL );
	n_posix_char *exe = n_string_path_cat( pth, n_posix_literal( " \"%1\"" ), NULL );

	n_registry_filetype_reg( filetype, caption, ico, exe );

#else // #ifndef NONNON_APPS

	const n_posix_char *caption = n_posix_literal( "" );
	const n_posix_char *option  = N_APPS_OPTION_FELIS;

	n_posix_char *felis = n_win_exepath_new();

	n_posix_char *pth = n_string_path_new( n_posix_strlen( felis ) + 1 + n_posix_strlen( option ) );
	n_posix_sprintf_literal( pth, "%s %s", felis, option );

	n_type_int    cch = n_posix_strlen( pth );
	n_posix_char *ico = n_string_path_new( cch + 100 );
	n_posix_char *exe = n_string_path_new( cch + 100 );

	n_posix_sprintf_literal( ico, "%s,%d", felis, N_APPS_ICON_OFFSET_FELIS + 1 );
	n_posix_sprintf_literal( exe, "%s %s",   pth, n_posix_literal( "\"%1\"" ) );
//n_posix_debug_literal( "%s\n%s\n%s", pth, ico, exe );

	n_registry_filetype_reg( filetype, caption, ico, exe );

	n_string_path_free( felis );

#endif // #ifndef NONNON_APPS

	n_string_path_free( pth );
	n_string_path_free( ico );
	n_string_path_free( exe );


	return;
}

void
n_felis_register( void )
{

	// [!] : file type

	n_felis_register_filetype_literal( "Felis" );
	n_felis_register_filetype_literal( "ftp"   );
	n_felis_register_filetype_literal( "http"  );
	n_felis_register_filetype_literal( "https" );


	// [!] : extension

	n_registry_association_add_literal( ".html", "Felis" );
	n_registry_association_add_literal( ".htm",  "Felis" );
	n_registry_association_add_literal( ".url",  "Felis" );


	// [!] : .URL property sheet support

	{
		HKEY          hive = HKEY_CURRENT_USER;
		n_posix_char *base = n_posix_literal( "Software\\Classes\\felis" );

		n_posix_char shellex[ 1024 ]; n_posix_sprintf_literal( shellex, "%s\\ShellEx\\PropertySheetHandlers\\{FBF23B40-E3F0-101B-8488-00AA003E56F8}", base );

		n_registry_write( hive, shellex, N_STRING_EMPTY, REG_SZ, N_STRING_EMPTY, 0 );
	}


	// [!] : default

	HKEY          hive = HKEY_CURRENT_USER;
	n_posix_char *base = n_posix_literal( "Software\\Microsoft\\Windows\\Shell\\Associations\\UrlAssociations" );

	n_posix_char   ftp[ 1024 ]; n_posix_sprintf_literal(   ftp, "%s\\ftp\\UserChoice",   base );
	n_posix_char  http[ 1024 ]; n_posix_sprintf_literal(  http, "%s\\http\\UserChoice",  base );
	n_posix_char https[ 1024 ]; n_posix_sprintf_literal( https, "%s\\https\\UserChoice", base );

	n_posix_char *progid   = n_posix_literal( "Progid" );
	n_posix_char *filetype = n_posix_literal( "Felis"  );

	n_registry_write( hive,   ftp, progid, REG_SZ, filetype, 0 );
	n_registry_write( hive,  http, progid, REG_SZ, filetype, 0 );
	n_registry_write( hive, https, progid, REG_SZ, filetype, 0 );


	// [!] : done!

	n_explorer_refresh( n_true );


	return;
}




