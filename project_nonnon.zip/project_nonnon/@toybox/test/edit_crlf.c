



#define UNICODE




#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Edit Control CRLF Test", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_gui_literal( hwnd, N_WIN_GUI_EDITOR, "", &hgui );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );
		n_win_move_simple( hgui, 0,0,256,256, n_true );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :
	{

		ShowWindow( hwnd, SW_HIDE );


		// [Mechanism] : behavior is different between A and W
		//
		//	  : empty : not empty
		//	A : CRLF  : CRLF
		//	W : empty : CRLF


		n_posix_char str[ 100 ];


		n_win_text_get( hgui, str, 100 - 1 );
		if ( n_string_match( N_STRING_CRLF, &str[ n_posix_strlen( str ) - 2 ] ) )
		{
			n_posix_debug_literal( "CRLF" );
		}


		DestroyWindow( hwnd );

	}
	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

