// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_SUBCLASS_TXTBOX
#define _H_NONNON_WIN32_WIN_SUBCLASS_TXTBOX




#include "../_debug.c"
#include "../ime.c"
#include "../message.c"
#include "../property.c"




LRESULT CALLBACK
#ifdef _WIN64
n_win_subclass_txtbox_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_subclass_txtbox_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	//
#else  // #ifdef _WIN64
	const WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "n_win_subclass_txtbox_on_keydown()" );
	if ( pfunc == NULL ) { return 0; }
#endif // #ifdef _WIN64


	switch( msg ) {


	case WM_IME_STARTCOMPOSITION :

		n_win_property_init_literal( hwnd, "IME", true );

	break;

	case WM_IME_ENDCOMPOSITION :

		n_win_property_exit_literal( hwnd, "IME" );

	break;


	case WM_KEYDOWN :
	{

		if ( n_win_property_get_literal( hwnd, "IME" ) ) { break; }

		if ( hwnd != GetFocus() ) { n_win_property_exit_literal( hwnd, "IME" ); break; }

#ifdef _WIN64
		WNDPROC on_keydown = (WNDPROC) dwRefData;
#else  // #ifdef _WIN64
		WNDPROC on_keydown = (WNDPROC) n_win_property_get_literal( hwnd, "WM_KEYDOWN" );
#endif // #ifdef _WIN64

		if ( on_keydown != NULL )
		{

			bool ret = on_keydown( hwnd, msg, wparam, lparam );

			// [!] : avoid beep

			if ( ret )
			{
				n_win_property_exit_literal( hwnd, "IME" );

				n_win_message_remove();
				return 0;
			}

		}

	}
	break;


	case WM_CLOSE   :
	case WM_DESTROY :
//n_posix_debug_literal( " ! " );

		// [x] : never come

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc(        hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return  CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_subclass_txtbox_on_keydown_exit()
{

}



#endif // _H_NONNON_WIN32_WIN_SUBCLASS_TXTBOX

