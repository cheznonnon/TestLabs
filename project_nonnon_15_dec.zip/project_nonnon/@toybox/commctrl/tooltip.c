



// link is needed : -lcomctl32




//#define UNICODE




#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"


#include <commctrl.h>




void
n_win_tooltip_set( HWND hgui, HWND hwnd_rect, RECT rect, n_posix_char *str, bool is_first )
{

	TOOLINFO toolInfo; ZeroMemory( &toolInfo, sizeof( TOOLINFO ) );

	toolInfo.cbSize   = sizeof( TOOLINFO );
	toolInfo.uFlags   = TTF_SUBCLASS;
	toolInfo.hwnd     = hwnd_rect;
	toolInfo.uId      = 0;
	toolInfo.rect     = rect;
	toolInfo.hinst    = GetModuleHandle( NULL );
	toolInfo.lpszText = str;
	toolInfo.lParam   = 0;

	if ( is_first )
	{
		n_win_message_send( hgui, TTM_ADDTOOL,     0, &toolInfo );
	} else {
		n_win_message_send( hgui, TTM_SETTOOLINFO, 0, &toolInfo );
	}


	return;
}

void
n_win_tooltip_gui( HWND hwnd_parent, HWND *hgui )
{

	if ( hgui == NULL ) { return; }


	InitCommonControls();


	(*hgui) = CreateWindowEx
	(
		0,
		TOOLTIPS_CLASS,
		NULL,
		TTS_ALWAYSTIP,
		0,0,0,0,
		hwnd_parent,
		(HMENU) NULL,
		GetModuleHandle( NULL ),
		NULL
	);


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;

	static n_posix_char str_tip[ N_PATH_MAX ];


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Nonnon", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		n_win_tooltip_gui( hwnd, &hgui );
		{
			n_posix_sprintf_literal( str_tip, "Nonnon Tooltip" );
			RECT r; GetClientRect( hwnd, &r );
			n_win_tooltip_set( hgui, hwnd, r, str_tip, true );
		}


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{
		n_posix_sprintf_literal( str_tip, "Nonnon Tooltip" );
		RECT r; GetClientRect( hwnd, &r );
		n_win_tooltip_set( hgui, hwnd, r, str_tip, false );
	}
	break;


	case WM_LBUTTONDOWN :
	{
		n_posix_sprintf_literal( str_tip, "New Text" );
		RECT r; GetClientRect( hwnd, &r );
		n_win_tooltip_set( hgui, hwnd, r, str_tip, false );
	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

