// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#define UNICODE


#include "../../nonnon/win32/win.c"
#include "../../nonnon/win32/gdi.c"


#include "../../nonnon/project/macro.c"




typedef struct {

	HWND  hgui;
	n_gdi gdi;
	n_bmp bmp;

	n_posix_char text[ N_PATH_MAX ];
	n_posix_char icon[ N_PATH_MAX ];
	n_posix_char font[ N_PATH_MAX ];

	s32 sx,sy;

	int status;
	int p_status;

} n_ownerdraw;




#define n_ownerdraw_zero( p ) n_memory_zero( p, sizeof( n_ownerdraw ) )

void
n_ownerdraw_free( n_ownerdraw *p )
{

	if ( p == NULL ) { return; }


	n_bmp_free( &p->bmp );

	n_memory_zero( p, sizeof( n_ownerdraw ) );


	return;
}

void
n_ownerdraw_init( n_ownerdraw *p, HWND hgui )
{

	if ( p == NULL ) { return; }


	n_ownerdraw_free( p );


	// Init

	p->hgui     = hgui;
 	p->status   =  0;
	p->p_status = -1;

	n_win_size( p->hgui, &p->sx, &p->sy );
//n_posix_debug_literal( "%d %d", p->sx, p->sy );

	n_win_text_get( p->hgui, p->text, N_PATH_MAX - 1 );
	n_posix_sprintf_literal( p->icon, "%s", n_posix_literal( "../../nonnon/project/neko.multi.ico" ) );
	n_posix_sprintf_literal( p->font, "%s", N_STRING_EMPTY );

//n_posix_debug_literal( "%s : %d", p->icon, n_posix_stat_is_exist( p->icon ) );


	// Template

	n_gdi gdi;
	n_gdi_zero( &gdi );

	gdi.sx                = p->sx;
	gdi.sy                = p->sy;
	gdi.style             = N_GDI_CLARITY;

	gdi.base_color_bg     = n_gdi_systemcolor( COLOR_ACTIVECAPTION );
	gdi.base_color_fg     = n_gdi_systemcolor( COLOR_BTNHILIGHT    );
	gdi.base_style        = N_GDI_BASE_VERTICAL;

	gdi.frame_style       = N_GDI_FRAME_RPG;//N_GDI_FRAME_ROUND;//
	gdi.frame_round       = 0;

	gdi.icon              = p->icon;
	gdi.icon_index        = 0;
	gdi.icon_style        = N_GDI_ICON_DEFAULT;

	gdi.text              = p->text;
	gdi.text_font         = p->font;
	gdi.text_size         = GetSystemMetrics( SM_CYICON ) / 2;
	gdi.text_color_main   = n_bmp_rgb( 255,255,255 );
	gdi.text_color_shadow = n_bmp_blend_pixel( gdi.base_color_bg, n_bmp_black + 1, 0.5 );
	gdi.text_style        = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD | N_GDI_TEXT_SHADOW;
	gdi.text_fxsize1      = 1;

	p->gdi = gdi;


	return;
}

void
n_ownerdraw_bitmap( n_ownerdraw *p )
{

	if ( p == NULL ) { return; }


	n_gdi gdi = p->gdi;


	if ( p->status & ODS_SELECTED )
	{

		gdi.base_color_bg = n_bmp_blend_pixel( p->gdi.base_color_bg, n_bmp_black + 1, 0.25 );
		gdi.base_color_fg = n_bmp_blend_pixel( p->gdi.base_color_fg, n_bmp_black + 1, 0.25 );

	} else
	if ( p->status & ODS_DISABLED )
	{

		gdi.style |= N_GDI_GRAY;

	} else
	if ( p->status & ODS_FOCUS )
	{

		gdi.base_color_bg = n_bmp_blend_pixel( p->gdi.base_color_bg, n_bmp_white, 0.25 );
		gdi.base_color_fg = n_bmp_blend_pixel( p->gdi.base_color_fg, n_bmp_white, 0.25 );

	}// else


	n_bmp_free( &p->bmp );
	n_gdi_bmp( &gdi, &p->bmp );


	// [!] : margin color

	{

		const u32 bg = n_gdi_systemcolor( COLOR_BTNFACE );

		n_bmp b;
		n_bmp_carboncopy( &p->bmp, &b );
		n_bmp_flush( &b, bg );

		n_bmp_flush_transcopy( &p->bmp, &b );

		n_bmp_free_fast( &p->bmp );
		n_bmp_alias( &b, &p->bmp );

//n_bmp_save_literal( &p->bmp, "result.bmp" );

	}


	return;
}

void
n_ownerdraw_draw( n_ownerdraw *p )
{

	if ( p ==NULL ) { return; }


	if ( p->p_status != p->status )
	{

		p->p_status = p->status;

		n_ownerdraw_bitmap( p );
		n_gdi_bitmap_draw( p->hgui, &p->bmp, 0,0,p->sx,p->sy, 0,0 );

	}


/*
	if ( p->status & ODS_FOCUS )
	{

		RECT r; GetClientRect( p->hgui, &r );

		InflateRect( &r, -4,-4 );

		HDC hdc = GetDC( p->hgui );
		DrawFocusRect( hdc, &r );
		ReleaseDC( p->hgui, hdc );

	}
*/


	return;
}

void
n_ownerdraw_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_ownerdraw *p )
{

	// ODT_MENU		1
	// ODT_LISTBOX		2
	// ODT_COMBOBOX		3
	// ODT_BUTTON		4
	// ODT_STATIC		5
	//
	// ODA_DRAWENTIRE	1
	// ODA_SELECT		2
	// ODA_FOCUS		4
	//
	// ODS_SELECTED		1
	// ODS_GRAYED		2
	// ODS_DISABLED		4
	// ODS_CHECKED		8
	// ODS_FOCUS		16
	// ODS_DEFAULT		32
	// ODS_COMBOBOXEDIT	4096


	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;


		if ( di == NULL ) { break; }

		if ( p->hgui != di->hwndItem ) { break; }


		if ( di->itemAction == ODA_DRAWENTIRE )
		{
			p->p_status = -1;
		}

		p->status = di->itemState;

		n_ownerdraw_draw( p );

	}
	break;


	case WM_SYSCOLORCHANGE :	
	{

		int status = p->status;

		n_ownerdraw_init( p, p->hgui );

		p->status = status;

	}
	break;


	} // switch


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND        hgui[ 3 ];
	static n_ownerdraw   od[ 3 ];


	switch( msg ) {


	case WM_CREATE :

		// Global

		n_win_exedir2curdir();


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_gui_literal( hwnd, BUTTON, "Nonnon",  &hgui[ 0 ] );
		n_win_gui_literal( hwnd, BUTTON, "Focus",   &hgui[ 1 ] );
		n_win_gui_literal( hwnd, BUTTON, "Disable", &hgui[ 2 ] );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_style_add( hgui[ 0 ], BS_OWNERDRAW );
		n_win_style_add( hgui[ 1 ], BS_OWNERDRAW );
		n_win_style_add( hgui[ 2 ], BS_OWNERDRAW );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		n_win_move( hgui[ 0 ], 0,50*0, 200,40, true );
		n_win_move( hgui[ 1 ], 0,50*1, 200,40, true );
		n_win_move( hgui[ 2 ], 0,50*2, 200,40, true );


		// Init

		SetFocus( hgui[ 1 ] );
		EnableWindow( hgui[ 2 ], false );

		n_ownerdraw_init( &od[ 0 ], hgui[ 0 ] );
		n_ownerdraw_init( &od[ 1 ], hgui[ 1 ] );
		n_ownerdraw_init( &od[ 2 ], hgui[ 2 ] );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;

	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_ownerdraw_free( &od[ 0 ] );
		n_ownerdraw_free( &od[ 1 ] );
		n_ownerdraw_free( &od[ 2 ] );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;

	} // switch


	n_ownerdraw_proc( hwnd, msg, wparam, lparam, &od[ 0 ] );
	n_ownerdraw_proc( hwnd, msg, wparam, lparam, &od[ 1 ] );
	n_ownerdraw_proc( hwnd, msg, wparam, lparam, &od[ 2 ] );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

