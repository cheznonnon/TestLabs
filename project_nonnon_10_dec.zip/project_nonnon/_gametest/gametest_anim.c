// Nonnon Game Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	n_bmp        b;
	n_game_chara c;

	bool         init;
	bool         input;

	int          frame;
	int          interval;
	u32          timer;

} n_gametest_anim;




void
n_gametest_anim_init( n_gametest_anim *a )
{

	a->init     = false;
	a->frame    =     1;
	a->interval =   300;
	a->timer    =     0;


	n_bmp_load( &a->b, n_posix_literal( "./gametest/anim.bmp" ) );

	n_game_chara_zero( &a->c );
	n_game_chara_bmp ( &a->c, &game.bmp, &a->b, NULL, n_bmp_black );


	n_game_timer( &a->timer, a->interval );


	return;
}

void
n_gametest_anim_loop( n_gametest_anim *a )
{

	const s32 bmpsx = N_BMP_SX( &a->b );
	const s32 bmpsy = N_BMP_SY( &a->b );


	static double alpha;
	static int    mirror;
	static int    rotate;
	static int    edge;


	a->input = true;


	if ( a->init == false )
	{
		a->init = true;
	} else
	if ( n_game_refresh_is_resize() )
	{
		a->input = false;
		n_game_refresh_on();
	} else
	if ( n_win_is_input( VK_UP ) )
	{
		a->frame++;
	} else
	if ( n_win_is_input( VK_DOWN ) )
	{
		if ( a->frame > 1 ) { a->frame--; }
	} else
	if ( n_win_is_input( VK_LEFT ) )
	{
		a->interval -= 10;
	} else
	if ( n_win_is_input( VK_RIGHT ) )
	{
		a->interval += 10;
	} else
	if ( n_win_is_input( 'A' ) )
	{
		alpha += 10; if ( alpha > 100 ) { alpha = 0; }
	} else
	if ( n_win_is_input( 'M' ) )
	{
		mirror++; if ( mirror > N_BMP_COPY_MIRROR_ROTATE180 ) { mirror = 0; }
	} else
	if ( n_win_is_input( 'R' ) )
	{
		rotate++; if ( rotate > N_BMP_ROTATE_RIGHT ) { rotate = 0; }
	} else
	if ( n_win_is_input( 'E' ) )
	{

		static int mode = 0;


		mode++;
		if ( mode >= 4 ) { mode = 0; }


		if ( mode == 0 )
		{
			edge = N_BMP_EDGE_NONE;
		} else
		if ( mode == 1 )
		{
			edge = N_BMP_EDGE_INNER | N_BMP_EDGE_CROSS;
		} else
		if ( mode == 2 )
		{
			edge = N_BMP_EDGE_OUTER | N_BMP_EDGE_CROSS;
		} else
		if ( mode == 3 )
		{
			edge = N_BMP_EDGE_INNER | N_BMP_EDGE_OUTER | N_BMP_EDGE_CROSS;
		}// else

	} else { a->input = false; }


	if ( a->input )
	{

		n_game_hwndprintf_literal
		(
			"frame %d : %d msec : a:%d : m:%d, r:%d : e:%d",
			a->frame, a->interval, (int) alpha, mirror, rotate,
			( edge & N_BMP_EDGE_MASK )
		);

		n_game_chara_src( &a->c, 0,0, bmpsx / a->frame, bmpsy, 0,0 );

		n_posix_sleep( 200 );

		n_game_refresh_on();

	}


	if ( n_game_timer( &a->timer, a->interval ) )
	{

		a->c.srcx += a->c.sx;
		if ( a->c.srcx >= bmpsx ) { a->c.srcx = 0; }

		n_game_refresh_on();

	}


	if ( n_game_refresh_is_on() )
	{

		s32 sx = a->c.sx;
		s32 sy = a->c.sy;
		n_game_chara_pos( &a->c, n_game_centering( game.sx, sx ), n_game_centering( game.sy, sy ) );

		n_bmp_flush( &game.bmp, n_bmp_white );
		n_game_chara_draw_full( &a->c, (double) alpha * 0.01, mirror, rotate, edge );

		n_game_refresh_on();

	}


	return;
}

void
n_gametest_anim_exit( n_gametest_anim *a )
{

	n_bmp_free( &a->b );


	return;
}

