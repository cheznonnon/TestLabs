// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_oc_subclass_on_keydown( int vk, bool forced_frame_onoff )
{

	if ( oc.view == N_ORANGECAT_VIEW_FILE )
	{

		if ( vk == VK_RETURN )
		{

			if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
			{
				if ( 1 == n_oc_item_multifocus_count( &item ) )
				{
					n_oc_item_go( &item, n_oc_item_multifocus_single( &item ) );
				}
			} else
			if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_PATH )
			{
				path.press = path.focus;
				n_bmp_fade_go( &path.fade[ path.focus ], oc_color.path_press );

				n_oc_event_btn_press();
			}

		} else
		if ( vk == VK_APPS )
		{

			n_win_simplemenu_hide( &oc.menu );


			extern void n_oc_on_viewchange( int, int, bool );

			if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
			{
				if ( item.count != 0 )
				{
					n_oc_on_viewchange( n_oc_item_multifocus_single( &item ), N_ORANGECAT_NOTHING, n_win_is_input( VK_CONTROL ) );
				}
			} else
			if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_PATH )
			{
				n_oc_on_viewchange( N_ORANGECAT_NOTHING, path.focus, n_win_is_input( VK_CONTROL ) );
			}

		} else
		if ( vk == VK_ESCAPE )
		{

			if ( item.drag2select_onoff )
			{
				n_oc_item_drag2select_exit( &item );
			}

		} else
		if ( vk == 'C' )
		{

			if ( n_win_is_input( VK_CONTROL ) )
			{
				n_posix_char *grab = n_oc_item_multifocus_focus2path_new( &item );

				n_clipboard_explorer_set( game.hwnd, grab );

				n_string_path_free( grab );
			}

		} else
		if ( vk == 'V' )
		{

			if ( n_win_is_input( VK_CONTROL ) )
			{

				n_posix_char *grab = n_clipboard_explorer_new( game.hwnd );
//n_oc_item_multifocus_debug( grab );

				bool is_canceled = false;
				bool ret = n_oc_item_multifocus_dnd( grab, oc.main, N_ORANGECAT_DRAG_VBUTTON, &is_canceled );
				if ( ret ) { n_project_dialog_info( game.hwnd, n_project_string_error ); }

				n_string_path_free( grab );

			}

		}

	} else
	if ( oc.view == N_ORANGECAT_VIEW_INFO )
	{

		// [x] : Edit Control uses this

		if ( vk == VK_APPS )
		{
			//n_oc_event_viewchange();
		}

	}


	n_oc_key_operation( vk, forced_frame_onoff );


	return;
}

LRESULT CALLBACK
n_oc_on_event( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	// [!] : be careful to set "oc.event" : race condition is possible


	static HWND          drop_hwnd   = NULL;
	static n_posix_char *drop_source = NULL;
	static n_posix_char *drop_target = NULL;


	static bool focus = true;
	//static bool wheel = false;


	if ( msg == oc.msg_is_oc )
	{
		return true;
	} else
	if ( msg == oc.msg_drag_internal )
	{
		return item.drag;
	} else
	if ( msg == oc.msg_drag_external )
	{
		oc.view_drag_external = wparam;
	} else
	if ( msg == oc.msg_drag_oc2oc )
	{
		oc.view_drag_oc2oc = wparam;
	} else
	if ( msg == oc.msg_path_sx )
	{
		if ( false == n_bmp_error( &path.bmp[ 0 ] ) ) { return N_BMP_SX( &path.bmp[ 0 ] ); }
	} else
	if ( msg == oc.msg_path_sy )
	{
		if ( false == n_bmp_error( &path.bmp[ 0 ] ) ) { return N_BMP_SY( &path.bmp[ 0 ] ); }
	} else
	if ( msg == oc.msg_is_computer )
	{
		return oc.view_is_computer;
	} else
	if ( msg == oc.msg_hwnd )
	{
		drop_hwnd = (HWND) lparam;
		return 0;
	} else
	if ( msg == oc.msg_is_droppable )
	{
		return n_oc_item_is_droppable( &item );
	} else
	if ( msg == oc.msg_find_onoff )
	{
		return item.find_onoff;
	} else
	if ( msg == oc.msg_dnd_onoff )
	{
		oc.view_dnd_onoff = wparam;
		return 0;
	}// else


	switch( msg ) {


	case WM_SETTINGCHANGE :
//n_game_hwndprintf_literal( " %d : %s ", wparam, lparam );

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		// [x] : n_win_dwm_windowcolor() needs some time

		if ( n_sysinfo_version_vista_or_later() )
		{
			if ( oc.timer_id_style == 0 ) { oc.timer_id_style = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, oc.timer_id_style, N_ORANGECAT_STYLE_MSEC );
		} else {
			n_oc_reset_style();
			if ( oc.view == N_ORANGECAT_VIEW_INFO )
			{
				n_oc_info_scaling( &info );
			}
		}

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == oc.timer_id_style )
		{

			n_win_timer_exit( hwnd, oc.timer_id_style );

			n_project_darkmode();

			n_oc_reset();
			n_oc_event_init();

			if ( oc.view == N_ORANGECAT_VIEW_INFO )
			{
				n_oc_info_scaling( &info );
			}

		} else
		if ( wparam == oc.timer_id_drop )
		{
//n_game_hwndprintf_literal( " Dropped " );

			n_win_timer_exit( hwnd, oc.timer_id_drop );
//break;

			n_win_cursor_add( NULL, IDC_ARROW );


			//EnableWindow(      hwnd, false );
			EnableWindow( drop_hwnd, false );

			bool is_cancelled = false;
			bool ret = n_oc_item_multifocus_dnd( drop_source, drop_target, oc.view_drag_external, &is_cancelled );
			if ( ret ) { n_project_dialog_info( game.hwnd, n_project_string_error ); }

			//EnableWindow(      hwnd, true );
			EnableWindow( drop_hwnd, true );
//break;

			oc.view_drag_external = N_ORANGECAT_DRAG_NEUTRAL;
			oc.is_external_dnd    = false;

			n_oc_item_scroll_restore( &item );

			if ( is_cancelled == false )
			{
//n_posix_debug_literal( "%s\n%s", drop_target, oc.main );

				if ( n_string_is_same( drop_target, oc.main ) )
				{
					// [!] : not yet registered
					n_oc_item_sync_go_forced( &item );

					n_oc_item_multifocus_off_all( &item );
					n_oc_item_multifocus_path2focus( &item, drop_source, true );

					n_oc_sync_load_count_check( &item );
				}

				n_oc_event_redraw();
			}

			n_string_path_free( drop_source );
			n_string_path_free( drop_target );

		} else
		if ( ( oc.view == N_ORANGECAT_VIEW_INFO )&&( wparam == info.fade_timer ) )
		{
//n_game_debug_count();

			n_oc_event_redraw_fast();

			if ( info.fade.percent == 100 )
			{
				n_win_timer_exit( game.hwnd, info.fade_timer );
			}

		}

	break;


	case WM_DROPFILES :
	{

		if ( oc.view == N_ORANGECAT_VIEW_INFO )
		{

			drop_source = n_win_dropfiles_multiple_new( hwnd, wparam );

			if ( oc.find_mode == N_ORANGECAT_FIND_MODE_NONE )
			{
				n_posix_char *nam = n_string_path_name_new( drop_source );
				n_posix_char *ext = n_string_path_ext_get_new( n_txt_get( &info.txtbox[ 0 ].txt, 0 ) );
				n_posix_char *str = NULL;

				if ( n_string_is_empty( ext ) )
				{
					str = n_string_path_carboncopy( nam );
					n_string_path_ext_del( str );
				} else {
					str = n_string_path_ext_mod_new( nam, ext );
				}
//n_posix_debug_literal( "%s\n%s\n%s", nam, ext, str );

				n_win_txtbox_line_set( &info.txtbox[ 0 ], 0, str );

				n_string_path_free( nam );
				n_string_path_free( ext );
				n_string_path_free( str );

				n_oc_info_input_focus( &info );
			} else {
				n_win_txtbox_unselect( &info.txtbox[ 0 ] );
				n_win_txtbox_line_set( &info.txtbox[ 0 ], 0, drop_source );
				n_win_txtbox_select( &info.txtbox[ 0 ], 0,0, -1,-1 );
			}

			n_win_txtbox_refresh( &info.txtbox[ 0 ] );

			SetFocus( info.txtbox[ 0 ].hwnd );

			n_string_path_free( drop_source );


			break;

		} else
		if ( oc.view != N_ORANGECAT_VIEW_FILE )
		{
			break;
		}
//break;

		if (
			( oc.view_is_computer )
			&&
			( false == n_oc_item_computer_is_droppable( &item ) )
		)
		{
//n_posix_debug_literal( " ! " );
			break;
		}

//n_posix_debug_literal( "%d", item.hover ); break;

		// [!] : order is important : path.hover first, item.hover second

		if ( path.hover != N_ORANGECAT_NOTHING )
		{

			bool find_onoff = n_win_message_send( oc.view_hwnd, oc.msg_find_onoff, 0,0 );
			if ( find_onoff ) { break; }

			drop_target = n_oc_path_index2path_new( &path, path.hover );

			n_oc_path_draw( &path );

		} else
		if ( item.hover != N_ORANGECAT_NOTHING )
		{
//n_posix_debug_literal( " 1 " );
			if ( n_oc_item_is_droppable_main( &item, true ) )
			{
				drop_target = n_oc_item_index2path_new( &item, item.hover );
			} else {
				if ( item.find_onoff ) { break; }
				drop_target = n_string_path_carboncopy( oc.main );
			}

		} else
		if ( item.hover == N_ORANGECAT_NOTHING )
		{
//n_posix_debug_literal( " 2 " );

			if ( item.find_onoff ) { break; }
			drop_target = n_string_path_carboncopy( oc.main );

		} else
		//
		{
//n_posix_debug_literal( " 3 " );
			if ( item.find_onoff ) { break; }

			if ( oc.view_hover != N_ORANGECAT_VIEW_HOVER_ITEM )
			{

				oc.view_drag_external = N_ORANGECAT_DRAG_NEUTRAL;
				oc.is_external_dnd    = false;

				n_oc_item_scroll_restore( &item );

				break;
			}

			drop_target = n_string_path_carboncopy( oc.main );

		}


		// [!] : Explorer => OrangeCat only

//n_posix_debug_literal( "%d", n_IDropTarget_keystate );

		if ( n_IDropTarget_keystate )
		{
			if ( n_IDropTarget_keystate & MK_LBUTTON ) { oc.view_drag_external = N_ORANGECAT_DRAG_LBUTTON; } else
			if ( n_IDropTarget_keystate & MK_MBUTTON ) { oc.view_drag_external = N_ORANGECAT_DRAG_MBUTTON; } else
			if ( n_IDropTarget_keystate & MK_RBUTTON ) { oc.view_drag_external = N_ORANGECAT_DRAG_RBUTTON; }
		}


		drop_source = n_win_dropfiles_multiple_new( hwnd, wparam );
//n_oc_item_multifocus_debug( drop_source );
//n_posix_debug_literal( "%d", cch );


		// [!] : OrangeCat to Application : DoDragDrop() changes a cursor until WM_DROPFILES is done
		//
		//	[ OrangeCat to OrangeCar : Dnd ]
		//
		//	 win_filer will appear, then click OK, a cursor will flicker

		if ( oc.timer_id_drop == 0 ) { oc.timer_id_drop = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, oc.timer_id_drop, N_ORANGECAT_DROP_MSEC );

	}
	break;


	case WM_MOUSEMOVE :

		if ( oc.view == N_ORANGECAT_VIEW_INFO )
		{
/*
			if ( n_win_is_hovered_offset( game.hwnd, info.edit_x,info.edit_y,info.edit_sx,info.edit_sy ) )
			{
				ShowWindow( info.txtbox[ 0 ].hwnd, SW_SHOWNA );
			}
*/
			break;
		}

		if ( oc.view != N_ORANGECAT_VIEW_FILE ) { break; }


		// [!] : conflict with SetCapture()

		//mk = wparam;
		//if ( wheel ) { wheel = false; }


		if ( n_oc_is_draggable() )
		{

			oc.focuskeeper_onoff = false;

			if ( oc.capture_phase == N_ORANGECAT_CAPTURE_CLICKED )
			{
//n_game_debug_count();
				oc.capture_phase = N_ORANGECAT_CAPTURE_CAPTURE;
				if ( hwnd != GetCapture() ) { SetCapture( hwnd ); }
			}

		}


		if ( item.drag == N_ORANGECAT_DRAG_UNKNOWN )
		{

			if ( oc.is_internal_dnd )
			{
				if ( item.drag2select_onoff == false )
				{
					oc.view_is_key_operation = oc.view_is_key_operation_fade_out = false;
					n_oc_item_drag2select_init( &item );
				} else {
					n_oc_item_drag2select_loop( &item );
				}
			}

		}

	break;


	case WM_MOUSEWHEEL :

		if ( oc.view == N_ORANGECAT_VIEW_FILE )
		{

			// [!] : this doesn't work accurately

			//wheel = true;

			int delta = n_win_scrollbar_wheeldelta( wparam, 1, false );
			if ( delta == 0 ) { break; }

			if ( n_win_is_input( VK_CONTROL ) )
			{
				n_oc_item_scroll_gallery( &item, delta );
			} else
			if ( n_win_is_input( VK_SHIFT ) )
			{
				n_oc_item_scroll_fontsize( &item, delta );
			} else {
				n_win_scrollbar_scroll_pixel( &oc.scrollbar, delta * oc.scrollbar.pixel_step, N_WIN_SCROLLBAR_SCROLL_AUTO );
			}

		}

	break;


	case WM_NCLBUTTONDBLCLK :
	case WM_NCMBUTTONDBLCLK :
	case WM_NCRBUTTONDBLCLK :

		if ( oc.view != N_ORANGECAT_VIEW_FILE ) { break; }


		// [!] : for Win7 vertical maximize feature

		oc.input_onoff = false;

	break;

	case WM_NCLBUTTONUP :
	case WM_NCMBUTTONUP :
	case WM_NCRBUTTONUP :

		if ( oc.view != N_ORANGECAT_VIEW_FILE ) { break; }


		// [!] : for Win7 vertical maximize feature

		oc.input_onoff = true;

	break;


	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :
//n_game_debug_count();

		if ( oc.view == N_ORANGECAT_VIEW_INFO )
		{
//n_game_hwndprintf_literal( " %x : %x : %x : %x : %x ", game.hwnd, GetFocus(), info.txtbox[ 0 ].hwnd, n_win_cursor2hwnd(), n_win_cursor2hwnd_relative( game.hwnd ) );

			if ( msg == WM_LBUTTONDOWN )
			{
				n_oc_info_input_focus_off( &info );

				if ( false == n_oc_info_input_is_hovered( &info ) )
				{
					SetFocus( info.txtbox[ 0 ].hwnd );
				}
			}

			break;
		}

		if ( oc.view != N_ORANGECAT_VIEW_FILE ) { break; }


		// [!] : for Win7 vertical maximize feature

		oc.input_onoff = true;


		oc.capture_phase = N_ORANGECAT_CAPTURE_CLICKED;


		n_oc_item_autoscroll( &item, item.hover, N_OC_ITEM_AUTOSCROLL_DEFAULT );


		if ( item.progress_sync.onoff )
		{
			extern void n_oc_on_input( bool );
			n_oc_on_input( true );
		}

	break;

	case WM_LBUTTONDBLCLK :

		if ( oc.view != N_ORANGECAT_VIEW_FILE ) { break; }


		if ( item.hover != N_ORANGECAT_NOTHING )
		{

			n_oc_item_dnd_off( &item );

			oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;
			n_oc_key_operation_onoff( false );

			n_oc_item_go( &item, item.hover );

		}


		//item.tooltip_phase = N_OC_HOVER2TOOLTIP_PHASE_FADEOUT;
		//n_oc_item_hover2tooltip_fade_on( &item );

	break;

	case WM_LBUTTONUP :
	case WM_MBUTTONUP :
	case WM_RBUTTONUP :
	{

		if ( oc.view != N_ORANGECAT_VIEW_FILE ) { break; }


		oc.focuskeeper_onoff = false;


		n_oc_item_drag2select_exit( &item );


		bool is_external_hwnd = ( game.hwnd != oc.view_hwnd );

//n_game_hwndprintf_literal( " WM_*BUTTONUP : External HWND %d : Drag %d ", is_external_hwnd, item.drag );

		if (
			( false == oc.view_is_computer )
			&&
			( is_external_hwnd )
			&&
			(
				( ( msg == WM_LBUTTONUP )&&( item.drag == N_ORANGECAT_DRAG_LBUTTON ) )
				||
				( ( msg == WM_MBUTTONUP )&&( item.drag == N_ORANGECAT_DRAG_MBUTTON ) )
				||
				( ( msg == WM_RBUTTONUP )&&( item.drag == N_ORANGECAT_DRAG_RBUTTON ) )
			)
		)
		{
//n_game_hwndprintf_literal( " DnD started " );

			n_posix_char *f = n_oc_item_multifocus_focus2path_new( &item );
			n_posix_char *t = n_explorer_cursor2path_new();
 
			if ( n_string_is_empty( t ) )
			{
//n_game_hwndprintf_literal( "OrangeCat to Application" );

				// [!] : OrangeCat to Application

				n_win_message_send( oc.view_hwnd, oc.msg_drag_external, item.drag,    0 );
				n_win_message_send( oc.view_hwnd, oc.msg_hwnd,                  0, hwnd );

				n_IDropSource_start( f );
//n_game_hwndprintf_literal( " %s ", f );

//n_oc_item_multifocus_debug( f );

				//n_win_cursor_add( NULL, IDC_ARROW );

			} else {
//n_game_hwndprintf_literal( "OrangeCat to Explorer" );

				// [!] : OrangeCat to Explorer

				bool ret = n_oc_item_multifocus_dnd( f, t, item.drag, NULL );
				if ( ret ) { n_project_dialog_info( game.hwnd, n_project_string_error ); }

				oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;

				n_oc_item_sync_go_forced( &item );

				n_oc_item_progressbar_reset( &item.progress_sync, N_ITASKBARLIST_MODE_GREEN );

				n_oc_event_redraw();
			}

			n_string_path_free( f );
			n_string_path_free( t );


			// [Needed] : stop internal DnD

			//item.hover = N_ORANGECAT_NOTHING;
			//n_oc_item_multifocus_off( &item );

			item.drag = N_ORANGECAT_DRAG_NEUTRAL;

			oc.activate_onoff = false;

		} else {

			if ( oc.activate_onoff )
			{
				oc.activate_onoff = false;
				SetActiveWindow( game.hwnd );
			}

		}


		// [Needed] : release after n_IDropSource_start() is done

		if ( hwnd == GetCapture() ) { ReleaseCapture(); }
		oc.capture_phase = N_ORANGECAT_CAPTURE_NEUTRAL;

	}
	break;


	case WM_MOUSEACTIVATE :

		// [x] : buggy : this message is not sent after another EXE is launched from OrangeCat
//n_game_hwndprintf_literal( " %d %d ", focus, item.hover );

		if ( oc.view == N_ORANGECAT_VIEW_FILE )
		{
//n_game_hwndprintf_literal( " %x %x ", game.hwnd, wparam );
//n_game_hwndprintf_literal( " %d ", LOWORD( lparam ) );

			// [!] : for DnD : delayed activation for usability

			if ( item.hover != N_ORANGECAT_NOTHING )
			{
				oc.activate_onoff = true;
				return MA_NOACTIVATE;
			} else {
				oc.focuskeeper_onoff = true;
			}

		} else
		if ( oc.view == N_ORANGECAT_VIEW_INFO )
		{

			//

		}

	break;


	case WM_SETFOCUS :

		if ( focus == false )
		{

			focus = true;

			if ( oc.view == N_ORANGECAT_VIEW_FILE )
			{

				//n_oc_event_redraw();

				//item.drag = N_ORANGECAT_DRAG_NEUTRAL;

			} else
			if ( oc.view == N_ORANGECAT_VIEW_INFO )
			{
				n_oc_event_redraw_fast();
			}

		}

	break;

	case WM_KILLFOCUS :
//n_game_hwndprintf_literal( " %x %x %x ", game.hwnd, wparam, info.txtbox[ 0 ].hwnd );

		if ( focus )
		{

			focus = false;

			if ( oc.view == N_ORANGECAT_VIEW_FILE )
			{
				//n_bmp_flush_tweaker( &game.bmp, 0,-50,-50,-50 );
				//n_game_refresh_on();
			} else
			if ( oc.view == N_ORANGECAT_VIEW_INFO )
			{
				//
			}

		}

	break;


	case WM_KEYDOWN :

		n_oc_subclass_on_keydown( wparam, true );
/*
		if ( wparam == VK_F1 )
		{
			oc.scrollbar.drag_onoff     = true;
			n_win_scrollbar_hwnd_global = oc.scrollbar.hwnd;

			n_win_scrollbar_position_cursor( &oc.scrollbar, & oc.scrollbar.prv_cursor_x, & oc.scrollbar.prv_cursor_y );
			n_win_scrollbar_offset( &oc.scrollbar );
		}
*/
/*
		if ( wparam == VK_F1 )
		{
			n_win_simplemenu_show( &oc.menu, game.hwnd );
		}
*/
	break;


	case WM_COMMAND :

		if ( oc.view == N_ORANGECAT_VIEW_FILE )
		{

			if ( (HWND) lparam == oc.scrollbar.hwnd )
			{
				if ( oc.scrollbar_prv_pos == wparam ) { break; }
				oc.scrollbar_prv_pos = wparam;
				if ( oc.event == N_ORANGECAT_EVENT_ZERO ) { n_oc_event_redraw_fast(); }
			} else {
				bool ret = n_oc_menu_proc( hwnd, msg, wparam, lparam );
				if ( ret ) { return ret; }
			}

		} else
		if ( oc.view == N_ORANGECAT_VIEW_INFO )
		{
//n_game_hwndprintf_literal( " %x ", lparam );

			if ( wparam == WM_LBUTTONDOWN )
			{
				n_oc_info_input_focus_off( &info );
			} else
			if ( wparam == WM_IME_NOTIFY )
			{
				n_oc_info_fade_go( &info, n_oc_info_fade_color( &info ) );
				//n_oc_event_redraw();
			}

		}

	break;


	case WM_SETCURSOR :

		if ( oc.view_dnd_onoff )
		{
			return true;
		}

	break;

/*
	// [!] : never come

	case WM_PRINTCLIENT :
	{
n_game_debug_count();

		HDC hdc = (HDC) wparam;

		HDC     hdc_compat = CreateCompatibleDC( hdc );
		HBITMAP hbmp_old   = SelectObject( hdc_compat, game.hbmp );

		BitBlt( hdc, 0,0,game.sx,game.sy, hdc_compat, game.ox,game.oy, SRCCOPY );

		SelectObject( hdc_compat, hbmp_old );
		DeleteDC( hdc_compat );

	}
	break;
*/

	} // switch


	if ( oc.view == N_ORANGECAT_VIEW_INFO )
	{
		int ret = 0;

		int i = 0;
		while( 1 )
		{
			ret |= n_win_txtbox_proc( hwnd, msg, wparam, lparam, &info.txtbox[ i ] );

			i++;
			if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
		}

		if ( ret ) { return ret; }
	}


	if ( oc.view == N_ORANGECAT_VIEW_FILE )
	{
		n_win_scrollbar_proc    ( hwnd, msg, wparam, lparam, &oc.scrollbar );
		n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &oc.scrollbar );
	}


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


/*
	{

		s32 min_csx = item.cell_sx + oc.unit_scrl;
		s32 min_csy = oc.unit_path + item.cell_sy + oc.unit_scrl;

		n_win_minsize_proc( hwnd,msg,wparam,lparam, min_csx, min_csy );

	}
*/

	return DefWindowProc( hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
n_oc_on_close( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	oc.exit_onoff = true;


	// [!] : before n_oc_menu_exit()

	n_oc_ini_write();


	n_win_scrollbar_exit( &oc.scrollbar );


	n_oc_menu_exit();


	n_uxtheme_exit( &oc.uxtheme, game.hwnd );


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
	n_IDropTarget_exit( game.hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


	n_ITaskbarList_exit( oc.ITaskbarList3, game.hwnd );


	return 0;
}

