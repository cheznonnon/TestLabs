// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_COLOR
#define _H_NONNON_WIN32_WIN_COLOR




COLORREF
n_win_color_blend( COLORREF f, COLORREF t, double blend )
{

	if ( f == t ) { return t; }

	if ( blend == 0.0 ) { return f; }
	if ( blend == 1.0 ) { return t; }


	double blend_1 = 1.0 - blend;
	double blend_2 =       blend;


	double r1 = (double) GetRValue( f ) * blend_1;
	double g1 = (double) GetGValue( f ) * blend_1;
	double b1 = (double) GetBValue( f ) * blend_1;
	double r2 = (double) GetRValue( t ) * blend_2;
	double g2 = (double) GetGValue( t ) * blend_2;
	double b2 = (double) GetBValue( t ) * blend_2;
	double r  = ( r1 + r2 );
	double g  = ( g1 + g2 );
	double b  = ( b1 + b2 );


	return RGB( r,g,b );
}

bool
n_win_color_is_highcontrast( void )
{

	bool ret = false;


	if ( n_sysinfo_version_vista_or_later() )
	{

		// [!] : XP or earlier : HCF_HIGHCONTRASTON is not supported

		HIGHCONTRAST hc; ZeroMemory( &hc, sizeof( HIGHCONTRAST ) );
		hc.cbSize = sizeof( HIGHCONTRAST );
		SystemParametersInfo( SPI_GETHIGHCONTRAST, 0, &hc, 0 );

//n_posix_debug_literal( "%d : %s", hc.dwFlags, hc.lpszDefaultScheme );


		ret = ( hc.dwFlags & HCF_HIGHCONTRASTON );

	} else {

		if ( GetSysColor( COLOR_BTNFACE ) == GetSysColor( COLOR_WINDOW ) )
		{
			ret = true;
		}

	}


	return ret;
}




#endif // _H_NONNON_WIN32_WIN_COLOR

