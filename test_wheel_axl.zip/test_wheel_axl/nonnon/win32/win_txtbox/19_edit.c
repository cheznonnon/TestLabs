// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_edit_undo( n_win_txtbox *p, bool reverse )
{

	if ( p == NULL ) { return; }


	if ( reverse )
	{

		if ( n_txt_error( &p->txt_undo ) ) { return; }

		if ( p->undo_onoff == false ) { return; }

		n_win_txtbox_unselect( p );

		n_win_txtbox_txt_copy( p, &p->txt_undo, &p->txt, true );

		n_win_txtbox_select( p, p->undo_cch_x,p->undo_cch_y,p->undo_cch_sx,p->undo_cch_sy );

		p->line_min_onoff = p->undo_line_min_onoff;
		p->line_max_onoff = p->undo_line_max_onoff;
		p->line_min_cch_x = p->undo_line_min_cch_x;
		p->line_max_cch_x = p->undo_line_max_cch_x;

		p->undo_onoff = false;

	} else {

		p->undo_cch_x  = p->select_cch_x;
		p->undo_cch_y  = p->select_cch_y;
		p->undo_cch_sx = p->select_cch_sx;
		p->undo_cch_sy = p->select_cch_sy;

		p->undo_line_min_onoff = p->line_min_onoff;
		p->undo_line_max_onoff = p->line_max_onoff;
		p->undo_line_min_cch_x = p->line_min_cch_x;
		p->undo_line_max_cch_x = p->line_max_cch_x;

		p->undo_onoff = true;

		n_win_txtbox_txt_copy( p, &p->txt, &p->txt_undo, false );

//n_txt_save_literal( &p->txt_undo, "undo.txt" );
	}


	return;
}

void
n_win_txtbox_edit_copy( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sy == 0 ) { return; }


	if ( p->select_cch_sy == 1 )
	{

		n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

		if ( n_string_is_empty( line ) )
		{

			n_clipboard_text_set( p->hwnd, N_STRING_CRLF );

		} else
		if ( p->select_cch_sx )
		{

			n_posix_char *text = n_string_carboncopy( line );

			s32 tail = n_win_txtbox_select_tail_get( p );

			n_string_terminate( text, tail );
			n_clipboard_text_set( p->hwnd, &text[ p->select_cch_x ] );

			n_memory_free( text );

//n_win_txtbox_hwndprintf_literal( p, "Copy : %d %d : %d", p->select_cch_x, p->select_cch_sx, tail );

		}

	} else {

		s32 sy = p->select_cch_sy;
		if ( sy == N_WIN_TXTBOX_ALL ) { sy = p->txt.sy; }


		s32 y   = 0;
		s32 cch = 0;
		while( 1 )
		{

			n_posix_char *text = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y + y ) );

			if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
			{
				if ( y == 0 )
				{
					n_posix_sprintf_literal( text, "%s", &text[ p->line_min_cch_x ] );
				} else
				if ( y == ( sy - 1 ) )
				{
					n_string_terminate( text, p->line_max_cch_x );
				}
			}

			cch += n_posix_strlen( text );

			n_memory_free( text );

			y++;
			if ( y >= sy ) { break; }

			cch += n_posix_strlen( N_STRING_CRLF );

		}

		n_posix_char *clipboard = n_string_new_fast( cch );

		y = cch = 0;
		while( 1 )
		{

			n_posix_char *text = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y + y ) );

			if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
			{
				if ( y == 0 )
				{
					n_posix_sprintf_literal( text, "%s", &text[ p->line_min_cch_x ] );
				} else
				if ( y == ( sy - 1 ) )
				{
					n_string_terminate( text, p->line_max_cch_x );
				}
			}

			cch += n_posix_sprintf_literal( &clipboard[ cch ], "%s", text );

			n_memory_free( text );

			y++;
			if ( y >= sy ) { break; }

			cch += n_posix_sprintf_literal( &clipboard[ cch ], "%s", N_STRING_CRLF );

		}

		n_clipboard_text_set( p->hwnd, clipboard );

		n_memory_free( clipboard );

	}


	return;
}

void
n_win_txtbox_edit_del( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sy == 0 ) { return; }


	if ( p->select_cch_sy == 1 )
	{

		n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
		s32           cch  = n_posix_strlen( line );


		if ( cch == 0 )
		{
//n_win_txtbox_hwndprintf_literal( p, "Single : Empty Line" );

			if ( p->select_cch_y == 0 ) { return; }

			n_win_txtbox_line_del( p, p->select_cch_y );

			s32 tail = n_posix_strlen( n_txt_get( &p->txt, p->select_cch_y - 1 ) );

			n_win_txtbox_select_set( p, tail, p->select_cch_y - 1, 0, 1, false );

		} else
		if ( p->select_cch_sx == 0 )
		{
//n_win_txtbox_hwndprintf_literal( p, "Single : Not Selected : %d %d", p->select_cch_x, p->select_cch_sx );

			if ( p->select_cch_x == 0 )
			{

				if ( p->select_cch_y == 0 ) { return; }

				n_posix_char *p_line = n_txt_get( &p->txt, p->select_cch_y - 1 );
				s32           p_cch  = n_posix_strlen( p_line );
				n_posix_char *text   = n_string_new_fast( cch + p_cch );

				n_posix_sprintf_literal( text, "%s%s", p_line, line );

				n_win_txtbox_line_mod( p, p->select_cch_y - 1, text );
				n_win_txtbox_line_del( p, p->select_cch_y );

				n_memory_free( text );

				n_win_txtbox_select_set( p, p_cch, p->select_cch_y - 1, 0, 1, false );

			} else {

				s32 unit = p->select_cch_x;
				n_win_txtbox_caret_l( line, p->select_cch_x, &unit );
				unit = p->select_cch_x - unit;

				n_string_copy( &line[ p->select_cch_x ], &line[ p->select_cch_x - unit ] );

				n_win_txtbox_select_set( p,  p->select_cch_x - unit, p->select_cch_y, 0, 1, false );

			}

		} else {
//n_win_txtbox_hwndprintf_literal( p, "Single : Selected : %d %d : %d", p->select_cch_x, p->select_cch_sx, cch );
//n_win_txtbox_hwndprintf_literal( p, "Single : Selected : %d %d", p->line_min_onoff, p->line_max_onoff );

			s32 tail = n_win_txtbox_select_tail_get( p );

			n_string_copy( &line[ tail ], &line[ p->select_cch_x ] );

			if ( false == n_win_txtbox_is_caret_tail( p ) )
			{
				n_win_txtbox_unselect( p );
			}

			n_win_txtbox_select_set( p,  p->select_cch_x, p->select_cch_y, 0, 1, false );

		}

	} else {
//n_win_txtbox_hwndprintf_literal( p, " Multiple : %d %d ", p->select_cch_y, p->drag_cch_y );

		bool line_add = true;

		s32 i = p->select_cch_y + p->select_cch_sy - 1;
		while( 1 )
		{

			if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
			{

				line_add = false;

				n_posix_char *text = n_string_carboncopy( n_txt_get( &p->txt, i ) );
//n_win_txtbox_hwndprintf_literal( p, " %s ", text );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->line_min_onoff, p->line_max_onoff );

				if ( i == p->select_cch_y )
				{

					int nextline = i + 1;

					n_posix_char *cat1 = n_string_carboncopy( n_txt_get( &p->txt, nextline ) );

					size_t cch1 = n_posix_strlen( text );
					size_t cch2 = n_posix_strlen( cat1 );

					n_posix_char *cat2 = n_string_alloccopy( cch1 + cch2, text );

					size_t line_min_cch_x = p->line_min_cch_x;
					if ( line_min_cch_x <= n_posix_strlen( cat2 ) )
					{
						n_string_terminate( cat2, line_min_cch_x );
					}

					n_posix_strcat( cat2, cat1 );

					n_win_txtbox_line_del( p, nextline );
					n_win_txtbox_line_mod( p, i, cat2 );

					n_memory_free( cat1 );
					n_memory_free( cat2 );

				} else
				if ( i == ( p->select_cch_y + p->select_cch_sy - 1 ) )
				{

					size_t line_max_cch_x = p->line_max_cch_x;
					if ( line_max_cch_x <= n_posix_strlen( text ) )
					{
						n_posix_sprintf_literal( text, "%s", &text[ line_max_cch_x ] );
						n_win_txtbox_line_mod( p, i, text );
					}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", line_max_cch_x, n_posix_strlen( text ) );

				} else {

					n_win_txtbox_line_del( p, i );

				}

				n_memory_free( text );

			} else {

				n_win_txtbox_line_del( p, i );

			}

			i--;
			if ( i < p->select_cch_y ) { break; }
		}


		// [!] : Edit Control compatible behavior

		s32 select_x = p->select_cch_x;
		s32 select_y = p->select_cch_y;

		if ( line_add )
		{
//n_win_txtbox_hwndprintf_literal( p, " A " );
			n_win_txtbox_line_add( p, select_y, N_STRING_EMPTY );
			n_win_txtbox_select( p, select_x, select_y, 0,1 );
		} else
		if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
		{
//n_win_txtbox_hwndprintf_literal( p, " B : %d : %d ", p->line_min_cch_x, select_y );
			n_win_txtbox_select( p, p->line_min_cch_x, select_y, 0,1 );
		}

		n_win_txtbox_drag_select2drag( p );

		p->shift_dragging = 0;

		n_win_txtbox_reset_line_minmax( p );

	}


	return;
}

void
n_win_txtbox_edit_cut( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sx == 0 ) { return; }

	n_win_txtbox_edit_copy( p );
	n_win_txtbox_edit_del ( p );


	return;
}

bool
n_win_txtbox_edit_paste( n_win_txtbox *p )
{

	if ( p == NULL ) { return false; }


	s32 cch = n_clipboard_text_get( p->hwnd, NULL );
	if ( cch == 0 ) { return false; }


	if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }


	n_txt txt; n_txt_zero( &txt );

	{

		n_posix_char *text = n_string_new_fast( cch );
		n_clipboard_text_get( p->hwnd, text );

		n_txt_load_onmemory( &txt, text, ( cch + 1 ) * sizeof( n_posix_char ) );

	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )||( txt.sy <= 1 ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " Single " );

		n_posix_char *line = n_txt_get( &txt, 0 );

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM )
		{
			bool ret = n_win_txtbox_filename_is_safe( line );
			if ( ret == false ) { return false; }
		}

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL )
		{
			bool ret = n_win_txtbox_filename_is_digit( line );
			if ( ret == false ) { return false; }
		}

		bool ret = false;

		if ( n_string_is_empty( line ) )
		{
			n_win_txtbox_line_add( p, p->select_cch_y, line );
		} else {
			ret = true;
			n_win_txtbox_selection_cat( p, line );
		}

		n_txt_free( &txt );

		n_win_txtbox_reset_line_minmax( p );


		return ret;
	}
//n_win_txtbox_hwndprintf_literal( p, " Multi " );


	n_posix_char *half_upper = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y ) );
	n_posix_char *half_lower = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y ) );
//n_win_txtbox_hwndprintf_literal( p, " %s : %s ", half_upper, half_lower );

	n_string_terminate( half_upper, p->select_cch_x );
	n_string_copy( &half_lower[ p->select_cch_x ], half_lower );


	size_t y = 0;
	while( 1 )
	{//break;

		n_posix_char *line = n_txt_get( &txt, y );

		if ( y == 0 )
		{

			n_posix_char *s = n_string_new_fast( n_posix_strlen( half_upper ) + n_posix_strlen( line ) );

			n_posix_sprintf_literal( s, "%s%s", half_upper, line );

			n_win_txtbox_line_mod( p, p->select_cch_y + y, s );

			n_memory_free( s );

		} else
		if ( y == ( txt.sy - 1 ) )
		{
//n_win_txtbox_hwndprintf_literal( p, " %s ", half_lower );

			s32 cch_1 = n_posix_strlen( half_lower );
			s32 cch_2 = n_posix_strlen( line       );
			s32 cch   = cch_1 + cch_2;

			n_posix_char *s = n_string_new_fast( cch );

			n_posix_sprintf_literal( s, "%s%s", line, half_lower );

			n_win_txtbox_line_add( p, p->select_cch_y + y, s );

			n_memory_free( s );

			n_win_txtbox_select( p, cch_2, p->select_cch_y + y, 0,1 );
			n_win_txtbox_drag_select2drag( p );

		} else {

			n_win_txtbox_line_add( p, p->select_cch_y + y, line );

		}

		y++;
		if ( y >= txt.sy ) { break; }
	}

	n_memory_free( half_upper );
	n_memory_free( half_lower );


	n_win_txtbox_reset_line_minmax( p );


	n_txt_free( &txt );


	n_win_txtbox_txt_stream( p, true );


	return true;
}

bool
n_win_txtbox_edit_input( n_win_txtbox *p, int vk )
{

	if ( p == NULL ) { return false; }


	p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


	BYTE         key[ 256 ]; GetKeyboardState( key );
	n_posix_char str[ 100 ];

#ifdef UNICODE

	ToUnicode( vk,0,key, str,100, 0 );

#else // #ifdef UNICODE

	WORD w;
	ToAscii  ( vk,0,key, &w, 0 );
	str[ 0 ] = w;
	str[ 1 ] = N_STRING_CHAR_NUL;

	// [x] : Buggy : ANSI version on NT : invalid character will be returned

	if ( p->is_nt )
	{
		wchar_t wstr[ 100 ];
		ToUnicode( vk,0,key, wstr,100, 0 );
		if ( wstr[ 0 ] == L'\0' ) { return false; }
	}

#endif // #ifdef UNICODE

//n_posix_debug_literal( " %d ", str[ 0 ] );

//n_posix_debug_literal( "%d : %d : %d : %x", vk, ImmGetVirtualKey( p->hwnd ), n_win_is_input( VK_CONVERT ), (int) str[ 0 ] );

	if ( n_string_is_empty( str ) ) { return false; }


	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->select_cch_x );

		if ( false == n_win_txtbox_filename_is_safe_char( str[ 0 ] ) ) { return false; }

		if (
			( str[ 0 ] == n_posix_literal( ' ' ) )
			&&
			(
				( n_string_is_empty( n_txt_get( &p->txt, 0 ) ) )
				||
				( p->select_cch_x == 0 )
				||
				(
					( p->select_cch_sx == N_WIN_TXTBOX_ALL )
					||
					( p->select_cch_sx == n_posix_strlen( n_txt_get( &p->txt, 0 ) ) )
				)
			)
		)
		{
			return false;
		}

	} else
	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ) )
	{

		if (
			( false == n_string_is_digit( str, 0 ) )
			&&
			( 0x08 != str[ 0 ] )
		)
		{
			return false;
		}

	}


	if ( 0x08 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x08 : BS

		n_win_txtbox_edit_del( p );

		p->vk = VK_LEFT;

	} else
	if ( 0x09 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x09 : TAB

		//if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { return true; }

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		n_win_txtbox_selection_cat( p, str );

		p->vk = VK_RIGHT;

	} else
	if ( 0x0d == str[ 0 ] )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { return true; }


		// [!] : ASCII Control Code : 0x0d CR

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		if ( p->select_cch_x == 0 )
		{

			n_win_txtbox_line_add( p, p->select_cch_y, N_STRING_EMPTY );
			n_win_txtbox_select  ( p, p->select_cch_x, p->select_cch_y + 1, 0, 1 );

		} else {

			n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

			n_win_txtbox_line_add( p, p->select_cch_y + 1, &line[ p->select_cch_x ] );
			n_string_terminate( line, p->select_cch_x );

			n_win_txtbox_select_set( p, 0, p->select_cch_y + 1, 0, 1, false );

		}

		//s32 last = n_win_scrollbar_position_last_unit( &p->vscr );
		//n_win_scrollbar_scroll_unit( &p->vscr, last, N_WIN_SCROLLBAR_SCROLL_SEND );

	} else
	if ( 0x1b == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x1b ESC

		return false;

	} else
	if ( 0x03 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x03 End of Text

		return false;

	} else
	if ( 0x16 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x16 Synchronous Idle

		return false;

	} else
	//
	{
//n_win_txtbox_hwndprintf_literal( p, " %s ", str );

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		n_win_txtbox_selection_cat( p, str );

		p->vk = VK_RIGHT;

	}


	return true;
}


