// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lole32




#ifndef _H_NONNON_WIN32_OLE_ISHELLFOLDER
#define _H_NONNON_WIN32_OLE_ISHELLFOLDER




#include "../../neutral/string_path.c"


//#include "./_debug.c"


#include <ole2.h>
#include <oleidl.h>
#include <shlobj.h>




const GUID n_IShellFolder_guid_IID_IShellFolder = { 0x000214E6,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };




void
n_IShellFolder_pidl_free( ITEMIDLIST *pidl )
{

	HMODULE hmod = LoadLibrary( n_posix_literal( "shell32.dll" ) );
	if ( hmod == NULL ) { return; }


	FARPROC func_CoTaskMemFree = GetProcAddress( hmod, "CoTaskMemFree" );
	FARPROC func_SHGetMalloc   = GetProcAddress( hmod, "SHGetMalloc"   );

	if ( func_CoTaskMemFree != NULL )
	{

		func_CoTaskMemFree( pidl );

	} else
	if ( func_SHGetMalloc != NULL )
	{

		IMalloc *p_IMalloc = NULL;

		HRESULT hr = func_SHGetMalloc( &p_IMalloc );

		if ( SUCCEEDED( hr ) )
		{
			p_IMalloc->lpVtbl->Free( p_IMalloc, pidl );
			p_IMalloc->lpVtbl->Release( p_IMalloc );
		}

	}


	FreeLibrary( hmod );


	return;
}

HRESULT
n_IShellFolder_path2object( const n_posix_char *arg_path_child, REFIID refiid, void **pp_void )
{

	// [Mechanism]
	//
	//	1 : SHGetDesktopFolder() returns entry point of Explorer
	//	2 : IShellFolder::BindToObject() makes chdir()'ed IShellFolder
	//	3 : a parent directory (IShellFolder_parent) has relative pidl of child items by IEnumIDList
	//	4 : IShellFolder::GetUIObjectOf() can make IID_IDataObject or IID_IDropTarget


	// [ REFIID ]
	//
	//	you can handle an IShellFolder object as an icon in Explorer
	//
	//	IID_IContextMenu : open / cut / copy / paste / delete / properties
	//	IID_IDropTarget  : drag and drop
	//	IID_IDataObject  : drag and drop


	// [!] : Reference
	//
	//	OldNewThing : GetUIObjectOfFile()
	//	http://netez.com/2xExplorer/shellFAQ/bas_xplore2.html


	// [!] : Compatibility
	//
	//	CoTaskMemFree()      : 98 or later only
	//	SHParseDisplayName() : XP or later only
	//	SHBindToParent()     : XP or later only


	if ( pp_void == NULL ) { return E_INVALIDARG; } else { (*pp_void) = NULL; }


	HRESULT hr;


	IShellFolder *p_IShellFolder = NULL;
	hr = SHGetDesktopFolder( &p_IShellFolder );
	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "SHGetDesktopFolder()" );

		return hr;
	}


	// [!] : Win98 : "C:" is not accepted

	n_posix_char *path_child = n_string_path_slash_new( arg_path_child );


	// [!] : make an absolute PIDL of the parent folder

	LPITEMIDLIST pidl_parent = NULL;

	{

		n_posix_char *path_parent = n_string_path_upperfolder_new( arg_path_child );
		n_string_path_drivename_slash_add( path_parent );


#ifdef UNICODE
		n_posix_char *s = n_string_carboncopy( path_parent );
#else // #ifdef UNICODE
		wchar_t *s = n_posix_ansi2unicode( path_parent );
#endif // #ifdef UNICODE

//n_posix_debug_literal( "%s\n%s", path_child, path_parent );

		hr = p_IShellFolder->lpVtbl->ParseDisplayName
		(
			p_IShellFolder,
			NULL, NULL, s, NULL, (void*) &pidl_parent, NULL
		);

		n_memory_free( s );


		n_string_path_free( path_parent );


		if ( FAILED( hr ) )
		{
//n_posix_debug_literal( "IShellFolder::ParseDisplayName()" );

			n_string_path_free( path_child );


			p_IShellFolder->lpVtbl->Release( p_IShellFolder );

			return hr;
		}

	}


	// [!] : for top-level folder like "C:\"

	if ( n_string_path_is_drivename( path_child ) )
	{
//n_posix_debug_literal( "Top-Level" );

		hr = p_IShellFolder->lpVtbl->GetUIObjectOf
		(
			p_IShellFolder,
			NULL, 1,
			(void*) &pidl_parent,
			refiid,
			NULL,
			(void*) pp_void
		);

		p_IShellFolder->lpVtbl->Release( p_IShellFolder );


		n_IShellFolder_pidl_free( pidl_parent );

//if ( (*pp_void) == NULL ) { n_posix_debug_literal( "ppvoid is NULL" ); }

		if ( FAILED( hr ) )
		{
//n_posix_debug_literal( "IShellFolder::GetUIObjectOf()" );
		}


		n_string_path_free( path_child );


		return hr;
	}


	// [!] : error check omitted


	// [!] : navigate to the target folder

	IShellFolder *p_IShellFolder_parent = NULL;
	hr = p_IShellFolder->lpVtbl->BindToObject
	(
		p_IShellFolder,
		pidl_parent, NULL,
		&n_IShellFolder_guid_IID_IShellFolder, (void*) &p_IShellFolder_parent
	);

	p_IShellFolder->lpVtbl->Release( p_IShellFolder );


	n_IShellFolder_pidl_free( pidl_parent );


	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "IShellFolder::BindToObject()" );

		n_string_path_free( path_child );

		return hr;

	}


	IEnumIDList *p_IEnumIDList = NULL;
	hr = p_IShellFolder_parent->lpVtbl->EnumObjects( p_IShellFolder_parent, NULL, 0xffffffff, &p_IEnumIDList );

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "IShellFolder::EnumObjects()" );

		p_IShellFolder_parent->lpVtbl->Release( p_IShellFolder_parent );

		n_string_path_free( path_child );

		return hr;
	}


	LPITEMIDLIST pidl_child = NULL;

	while( 1 )
	{//break;

		hr = p_IEnumIDList->lpVtbl->Next( p_IEnumIDList, 1, &pidl_child, NULL );

		if ( hr == S_FALSE )
		{

			hr = E_FAIL;

			break;

		} else {

			WIN32_FIND_DATA fd; ZeroMemory( &fd, sizeof( WIN32_FIND_DATA ) );

			SHGetDataFromIDList
			(
				p_IShellFolder_parent,
				pidl_child,
				SHGDFIL_FINDDATA, &fd, sizeof( WIN32_FIND_DATA )
			);

			n_posix_char *name = n_string_path_name_new( path_child );
//n_posix_debug_literal( "%s\n%s", fd.cFileName, name );

			if ( n_string_is_same( fd.cFileName, name ) )
			{

				p_IShellFolder_parent->lpVtbl->GetUIObjectOf
				(
					p_IShellFolder_parent,
					NULL, 1,
					(void*) &pidl_child,
					refiid,
					NULL,
					(void*) pp_void
				);

				n_IShellFolder_pidl_free( pidl_child );

				hr = S_OK;

				n_string_path_free( name );

				break;

			} else {

				n_IShellFolder_pidl_free( pidl_child );

				hr = E_FAIL;

				n_string_path_free( name );

			}

		}

	}


	n_string_path_free( path_child );


	p_IEnumIDList->lpVtbl->Release( p_IEnumIDList );

	p_IShellFolder_parent->lpVtbl->Release( p_IShellFolder_parent );


	return hr;
}

#define n_IShellFolder_popupmenu(  hwnd, name ) n_IShellFolder_operate( hwnd, name, "" )
#define n_IShellFolder_cut(        hwnd, name ) n_IShellFolder_operate( hwnd, name, "cut" )
#define n_IShellFolder_copy(       hwnd, name ) n_IShellFolder_operate( hwnd, name, "copy" )
#define n_IShellFolder_paste(      hwnd, name ) n_IShellFolder_operate( hwnd, name, "paste" )
#define n_IShellFolder_shortcut(   hwnd, name ) n_IShellFolder_operate( hwnd, name, "link" )
#define n_IShellFolder_recyclebin( hwnd, name ) n_IShellFolder_operate( hwnd, name, "delete" )
#define n_IShellFolder_properties( hwnd, name ) n_IShellFolder_operate( hwnd, name, "properties" )

bool
n_IShellFolder_operate( HWND hwnd, const n_posix_char *filename, const char *verb )
{

	// [Mechanism] : don't call this function from main() or WinMain()
	//
	//	nothing will happen
	//	WndProc()-based application only


	// [x] : this module is useless except for n_IShellFolder_popupmenu()


	const GUID guid_IID_IContextMenu  = { 0x000214E4,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };

	IContextMenu *p_IContextMenu = NULL;
	n_IShellFolder_path2object( filename, &guid_IID_IContextMenu, (void*) &p_IContextMenu );

	if ( p_IContextMenu == NULL )
	{
//n_posix_debug_literal( "p_IContextMenu is NULL" );

		return true;
	}

/*
	const GUID guid_IID_IContextMenu2 = { 0x000214F4,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };

	IContextMenu2 *p_IContextMenu2 = NULL;
	p_IContextMenu->lpVtbl->QueryInterface( p_IContextMenu, &guid_IID_IContextMenu2, (void*) &p_IContextMenu2 );

	if ( p_IContextMenu2 != NULL )
	{
		p_IContextMenu->lpVtbl->Release( p_IContextMenu );
		p_IContextMenu = (void*) p_IContextMenu2;
	}

	const GUID guid_IID_IContextMenu3 = { 0xbcfce0a0,0xec17,0x11d0,{ 0x8d,0x10, 0x00,0xa0,0xc9,0x0f,0x27,0x19 } };

	IContextMenu3 *p_IContextMenu3 = NULL;
	p_IContextMenu->lpVtbl->QueryInterface( p_IContextMenu, &guid_IID_IContextMenu3, (void*) &p_IContextMenu3 );

	if ( p_IContextMenu3 != NULL )
	{
		p_IContextMenu->lpVtbl->Release( p_IContextMenu );
		p_IContextMenu = (void*) p_IContextMenu3;
	}
*/


	// [!] : MinGW hasn't CMINVOKECOMMANDINFOEX

	CMINVOKECOMMANDINFO ici;
	ZeroMemory( &ici, sizeof( CMINVOKECOMMANDINFO ) );

	ici.cbSize = sizeof( CMINVOKECOMMANDINFO );
	//ici.fMask  = CMIC_MASK_MODAL;
	ici.hwnd   = hwnd;
	ici.nShow  = SW_SHOWNORMAL;

	if ( ( verb == NULL ) ||( verb[ 0 ] == '\0' ) )
	{

		HMENU hmenu = CreatePopupMenu();
		p_IContextMenu->lpVtbl->QueryContextMenu( p_IContextMenu, hmenu, 0, 1, 0x7ffff, CMF_EXPLORE );


		POINT pt;
		GetCursorPos( &pt );

		int index = TrackPopupMenuEx( hmenu, TPM_RETURNCMD, pt.x, pt.y, hwnd, NULL );


		ici.lpVerb = MAKEINTRESOURCEA( index - 1 );
		p_IContextMenu->lpVtbl->InvokeCommand( p_IContextMenu, &ici );


		DestroyMenu( hmenu );

//n_posix_debug_literal( "%d", index );

	} else {

/*
		// [!] : Vista or later only : XP or earlier returns 0x80004001(E_NOTIMPL)

		char real_verb[ 1024 ] = "";

		HRESULT hr = p_IContextMenu->lpVtbl->GetCommandString
		(
			p_IContextMenu,
			(UINT_PTR) verb,
			GCS_VERBA,
			NULL,
			real_verb,
			1024
		);

//MessageBoxA( NULL, real_verb, verb, 0 );

		ici.lpVerb = real_verb;
		p_IContextMenu->lpVtbl->InvokeCommand( p_IContextMenu, &ici );

		if ( hr != S_OK ) { n_posix_debug_literal( "%x", hr ); }
*/

		// [x] : 2000 or earlier : "paste" does not function at a top-level folder


		HMENU hmenu = CreatePopupMenu();
		p_IContextMenu->lpVtbl->QueryContextMenu( p_IContextMenu, hmenu, 0, 1, 0x7ffff, CMF_EXPLORE );


		int index = 0;

		if ( 0 == strcmp( verb, "cut"        ) ) { index = 25; } else
		if ( 0 == strcmp( verb, "copy"       ) ) { index = 26; } else
		if ( 0 == strcmp( verb, "paste"      ) ) { index = 27; } else
		if ( 0 == strcmp( verb, "link"       ) ) { index = 17; } else
		if ( 0 == strcmp( verb, "delete"     ) ) { index = 18; } else
		if ( 0 == strcmp( verb, "properties" ) ) { index = 20; }

		ici.lpVerb = MAKEINTRESOURCEA( index - 1 );
		p_IContextMenu->lpVtbl->InvokeCommand( p_IContextMenu, &ici );


		DestroyMenu( hmenu );

	}


	p_IContextMenu->lpVtbl->Release( p_IContextMenu );


	return false;
}


#endif // _H_NONNON_WIN32_OLE_ISHELLFOLDER

