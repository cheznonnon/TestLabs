// Nonnon Wheel Axl
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : Win9x
//
//	WH_MOUSE_LL is not available
//	WH_MOUSE can run but Explorer will crash then sysmte is halt


// [x] : Win10
//
//	you need to include this and call n_mousehook_init()/exit() from caller process
//	+ SendInput() or mouse_event() will hang up
//
//	SendInput() and mouse_event() beep and don't work accurately




#include "../nonnon/win32/win.c"




static HHOOK n_mousehook_hhook = NULL;
static HWND  n_mousehook_debug = NULL;




LRESULT CALLBACK
n_mousehook_LowLevelMouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{
//n_win_hwndprintf_literal( n_mousehook_debug, "%d", nCode );
//n_win_debug_count( n_mousehook_debug );


	if ( nCode != HC_ACTION )
	{
		return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
	}


	if ( wParam == WM_MOUSEWHEEL )
	{
//n_posix_debug_literal( "" );
//n_win_debug_count( n_mousehook_debug );


		MSLLHOOKSTRUCT *p = (void*) lParam;


		// [!] : 0 or -1 is set
		//if ( p->flags != 0 ) { n_posix_debug_literal( "%d", p->flags ); }

/*
HWND hwnd_pt = GetParent( GetParent( WindowFromPoint( p->pt ) ) );
n_posix_char str[ 1024 ]; str[ 0 ] = 0; GetClassName( hwnd_pt, str, 1024 );
POINT pt; GetCursorPos( &pt ); ScreenToClient( hwnd_pt, &pt );
n_win_hwndprintf_literal( n_mousehook_debug, "%s : %d %d : %d %d", str, p->pt.x, p->pt.y, pt.x, pt.y );
*/

		static u32 time_prv = 0;


		static bool lock = false;
//n_win_hwndprintf_literal( n_mousehook_debug, "%d", lock );

		if ( lock )
		{
			time_prv = n_posix_tickcount();

			return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
		}


		bool is_win_10 = n_sysinfo_version_10_or_later();
		HWND hwnd_pt   = NULL;

		if ( is_win_10 )
		{

			hwnd_pt = WindowFromPoint( p->pt );

			if (
				( n_win_class_is_same_literal( hwnd_pt, "Windows.UI.Core.CoreWindow" ) )
				||
				( n_win_class_is_same_literal( hwnd_pt, "DirectUIHWND" ) )
			)
			{

				// [!] : Start Menu / Explorer / Settings

				// [x] : not supported

				lock = false;

				return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );

			}

		}


		// [x] : don't rely on p->time
		u32 time_cur = n_posix_tickcount();


		int delta = GET_WHEEL_DELTA_WPARAM( p->mouseData );
//n_win_hwndprintf_literal( n_mousehook_debug, "%d", delta );


		static u32 axl = 0;
		static int prv = 0;

		static int move_d = 0;
		static int move_u = 0;

		if ( ( time_cur - time_prv ) < 500 )
		{

			if ( delta < 0 )
			{
//n_win_hwndprintf_literal( n_mousehook_debug, "Down" );
				move_d++;
				if ( move_u )
				{
					delta *= -1;
					prv = delta;
					move_u = move_d = 0;
				}
			} else {
//n_win_hwndprintf_literal( n_mousehook_debug, "Up" );
				move_u++;
				if ( move_d )
				{
					delta *= -1;
					prv = delta;
					move_u = move_d = 0;
				}
			}
//n_win_hwndprintf_literal( n_mousehook_debug, "D:%d U:%d", move_d, move_u );

			if ( ( move_d == 0 )&&( move_u == 0 ) )
			{
				return true;
			}

		} else {

			move_u = move_d = 0;

		}


		const int step_maximum = WHEEL_DELTA * 8;
		const int step_default = WHEEL_DELTA / 4;

		if ( delta < 0 )
		{
			if ( prv < 0 ) { axl += step_default; } else { axl = 0; }
		} else {
			if ( prv > 0 ) { axl += step_default; } else { axl = 0; }
		}
//n_win_hwndprintf_literal( n_mousehook_debug, "%d %d %d", delta, prv, axl );


		if ( ( time_cur - time_prv ) > 500 )
		{
//n_win_debug_count( n_mousehook_debug );
			axl = 0;
		} else {
			axl = n_posix_min( axl, step_maximum );
		}

//n_win_hwndprintf_literal( n_mousehook_debug, "%d", axl );


		if ( delta < 0 ) { delta -= axl; } else { delta += axl; }

		if ( delta < SHRT_MIN ) { delta = SHRT_MIN; }
		if ( delta > SHRT_MAX ) { delta = SHRT_MAX; }

		prv = delta;


		time_prv = time_cur;


		// [x] : Win8.1 : mouse_event() : lock is needed

		lock = true;


		if ( is_win_10 )
		{

			if (
				( n_win_class_is_same_literal( hwnd_pt, "Edit" ) )
				||
				( n_win_class_is_same_literal( hwnd_pt, "Internet Explorer_Server" ) )
			)
			{

				// [!] : IE and Edit controls

				// [Needed] : hwnd_pt : "Internet Explorer_Server" only

				while( 1 )
				{
					int sb;
					if ( delta < 0 ) { sb = SB_LINEDOWN; } else { sb = SB_LINEUP; }

					n_win_message_send
					(
						hwnd_pt,
						WM_VSCROLL,
						n_win_param_hilo( 0, sb ),
						NULL
					);

					if ( delta < 0 )
					{
						delta += WHEEL_DELTA;
						if ( delta >= 0 ) { break; }
					} else {
						delta -= WHEEL_DELTA;
						if ( delta <= 0 ) { break; }
					}
				}

			} else {

				// [x] : IE doesn't accept WM_MOUSEWHEEL

				// [Needed] : LPARAM : important with Firefox

				// [!] : GetActiveWindow() and GetFocus() are not available

				n_win_message_post
				(
					GetForegroundWindow(),
					WM_MOUSEWHEEL,
					n_win_param_hilo( delta, 0 ),
					n_win_param_hilo( p->pt.y, p->pt.x )
				);

			}

		} else {

/*
			// [x] : Win95 : error dialog will appear

			// [!] : the same as mouse_event()

			INPUT input; ZeroMemory( &input, sizeof( INPUT ) );

			input.type         = INPUT_MOUSE;
			input.mi.mouseData = delta;
			input.mi.dwFlags   = MOUSEEVENTF_WHEEL;

			SendInput( 1, &input, sizeof( INPUT ) );
*/

			mouse_event( MOUSEEVENTF_WHEEL, 0,0, delta, 0 );

		}

/*
		// [x] : not working : SetScrollPos() is the same

		SCROLLINFO si = { sizeof( SCROLLINFO ), SIF_ALL, 0,0, 0,0, 0 };

		GetScrollInfo( hwnd, SB_VERT, &si       );
		si.nPos += delta * 10;
		SetScrollInfo( hwnd, SB_VERT, &si, true );
*/

		lock = false;


		return true;
	}


	return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
}

void WINAPI
n_mousehook_init( HINSTANCE hinst, HWND hwnd_debug )
{

	n_win_exedir2curdir();

	n_mousehook_hhook = SetWindowsHookEx( WH_MOUSE_LL, n_mousehook_LowLevelMouseProc, hinst, 0 );
	n_mousehook_debug = hwnd_debug;

	// [x] : Win9x : ANSI Version :     DLL : ERROR_MOD_NOT_FOUND (126) will be returned
	// [x] : Win9x : ANSI Version : not DLL : zero will be returned but n_mousehook_hhook is NULL

if ( n_mousehook_hhook == NULL ) { n_posix_debug_literal( "%d", GetLastError() ); }

	return;
}

void WINAPI
n_mousehook_exit( void )
{

	UnhookWindowsHookEx( n_mousehook_hhook );

	return;
}


