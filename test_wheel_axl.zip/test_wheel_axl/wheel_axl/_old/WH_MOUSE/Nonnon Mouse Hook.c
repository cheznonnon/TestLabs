// Nonnon Wheel Axl
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : Win9x
//
//	WH_MOUSE_LL is not available
//	WH_MOUSE can run but Explorer will crash


// [x] : Win10
//
//	you need to include this and call n_mousehook_init()/exit() from caller process
//	+ SendInput() or mouse_event() will hang up
//
//	SendInput() and mouse_event() beep and don't work accurately




//#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"




static HHOOK n_mousehook_hhook __attribute__((section("shared"),shared)) = NULL;
static HWND  n_mousehook_debug __attribute__((section("shared"),shared)) = NULL;




LRESULT CALLBACK
n_mousehook_MouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{
//n_win_hwndprintf_literal( n_mousehook_debug, "%d", nCode );
//n_win_debug_count( n_mousehook_debug );

	if ( nCode != HC_ACTION ) { return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam ); }


	static bool lock = false;
//n_win_hwndprintf_literal( n_mousehook_debug, "%d", lock );

	if ( lock ) { return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam ); }


	if ( wParam == WM_MOUSEWHEEL )
	{

		typedef struct {

			POINT     pt;
			HWND      hwnd;
			UINT      wHitTestCode;
			ULONG_PTR dwExtraInfo;
			DWORD     mouseData;

		} n_MOUSEHOOKSTRUCTEX;

		n_MOUSEHOOKSTRUCTEX *p = (void*) lParam;

if ( p->hwnd == n_mousehook_debug ) { n_win_hwndprintf_literal( p->hwnd, "%d", GET_WHEEL_DELTA_WPARAM( p->mouseData ) ); }


		int delta = GET_WHEEL_DELTA_WPARAM( p->mouseData );

		if ( delta < 0 )
		{
			delta = -WHEEL_DELTA;
		} else {
			delta =  WHEEL_DELTA;
		}
//n_win_hwndprintf_literal( n_mousehook_debug, "%d %d", p->mouseData, delta );


		const int step_maximum = WHEEL_DELTA * 8;
		const int step_default = WHEEL_DELTA / 4;

		static u32 axl = 0;
		static int prv = 0;
		static u32 tmr = 0;

		if ( delta < 0 )
		{
			if ( prv < 0 ) { axl += step_default; } else { axl = 0; }
		} else {
			if ( prv > 0 ) { axl += step_default; } else { axl = 0; }
		}

		// [x] : don't rely on p->time
		u32 time_cur = n_posix_tickcount();

		if ( ( time_cur - tmr ) > 500 )
		{
//n_win_debug_count( n_mousehook_debug );
			axl = 0;
		} else {
			axl = n_posix_min( axl, step_maximum );
		}

n_win_hwndprintf_literal( n_mousehook_debug, "%d %d", axl, delta );

		if ( delta < 0 ) { delta -= axl; } else { delta += axl; }

		if ( delta < SHRT_MIN ) { delta = SHRT_MIN; }
		if ( delta > SHRT_MAX ) { delta = SHRT_MAX; }

		prv = delta;
		tmr = time_cur;


		// [x] : Win8.1 : mouse_event() : lock is needed

		lock = true;


		//HWND hwnd = GetForegroundWindow();

		// [x] : IE and Firefox don't accept WM_MOUSEWHEEL
/*
		n_win_message_post
		(
			hwnd,
			WM_MOUSEWHEEL,
			n_win_param_hilo( delta, 0 ),
			n_win_param_hilo( p->pt.x, p->pt.y )
		);
*/
/*
		// [x] : not working

		SCROLLINFO si = { sizeof( SCROLLINFO ), SIF_ALL, 0,0, 0,0, 0 };

		GetScrollInfo( hwnd, SB_VERT, &si       );
		si.nPos += delta * 10;
		SetScrollInfo( hwnd, SB_VERT, &si, true );
*/

		INPUT input; ZeroMemory( &input, sizeof( INPUT ) );

		input.type         = INPUT_MOUSE;
		input.mi.mouseData = delta;
		input.mi.dwFlags   = MOUSEEVENTF_WHEEL;

		SendInput( 1, &input, sizeof( INPUT ) );


		//mouse_event( MOUSEEVENTF_WHEEL, 0,0, delta, 0 );


		lock = false;


		return true;
	}


	return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
}

void WINAPI
n_mousehook_init( HINSTANCE hinst, HWND hwnd_debug )
{

	n_win_exedir2curdir();

	n_mousehook_hhook = SetWindowsHookEx( WH_MOUSE, n_mousehook_MouseProc, hinst, 0 );
	n_mousehook_debug = hwnd_debug;

if ( n_mousehook_hhook == NULL ) { n_posix_debug_literal( "%d", GetLastError() ); }

	return;
}

void WINAPI
n_mousehook_exit( void )
{

	UnhookWindowsHookEx( n_mousehook_hhook );

	return;
}



