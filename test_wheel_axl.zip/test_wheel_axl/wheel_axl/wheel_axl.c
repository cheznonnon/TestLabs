// Nonnon Wheel Axl
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : Support Status
//
//	Me    : NG : ANSI build : HHOOK will be NULL always
//	2000  : OK
//	XP    : OK
//	Vista : OK
//	8.1   : OK
//	10    : Patched : Win10 has so buggy




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




#include "../nonnon/game/timegettime.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_simplemenu.c"
#include "../nonnon/win32/win_systray.c"


#include "../nonnon/project/macro.c"




#ifndef N_APPS_NAME_WHEEL_AXL

#define N_APPS_OPTION_WHEEL_AXL n_posix_literal( "-wheel_axl" )

#endif // #ifndef N_APPS_NAME_WHEEL_AXL




#define N_WHEEL_AXL_APPNAME   n_posix_literal( "Nonnon Wheel Axl" )
#define N_WHEEL_AXL_MAIN_ICON n_posix_literal( "WHEEL_AXL_0_MAIN" )
#define N_WHEEL_AXL_TRAY_ICON n_posix_literal( "WHEEL_AXL_0_TRAY" )


#include "./Nonnon Mouse Hook.c"




void
n_wheel_axl_systray_callback( n_bmp *b, n_bmp *m )
{

	u32 color;
	if ( n_win_dwm_is_on() )
	{
		color = n_win_dwm_windowcolor();
	} else {
		color = n_gdi_systemcolor_ui( COLOR_BTNFACE );
	}

	{
		u32 before_1 = n_bmp_rgb(  10, 10, 10 );
		u32 before_2 = n_bmp_rgb( 128,128,128 );
		u32 after__1 = n_bmp_lightness_replace_pixel( color, 50 );
		u32 after__2 = n_bmp_blend_pixel( after__1, n_bmp_white, 0.5 );

		n_bmp_flush_replacer( b, before_1, after__1 );
		n_bmp_flush_replacer( b, before_2, after__2 );
	}


	return;
}

n_posix_char*
n_wheel_axl_startup_commandline( void )
{

	n_posix_char *exe = n_win_exepath_new();

#ifdef NONNON_APPS

	n_posix_char *ret = n_string_path_cat( exe, N_STRING_SPACE, N_APPS_OPTION_WHEEL_AXL, NULL );
	n_string_free( exe );

#else  // #ifndef NONNON_APPS

	n_posix_char *ret = exe;

#endif // #ifndef NONNON_APPS


	return ret;
}

LRESULT CALLBACK
n_wheel_axl_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HINSTANCE hinst;


	static int icon_supported[] = { 16, 24, 32, 0 };

	static NOTIFYICONDATA nid;


	static UINT n_wheel_axl_id_tray = 0;


	static n_win_simplemenu menu;


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == timer_id )
		{

			n_win_timer_exit( hwnd, timer_id );


			n_project_darkmode();

			n_win_init_background( hwnd );
			n_win_refresh( hwnd, true );

			n_win_systray_icon_change( &nid, N_WHEEL_AXL_TRAY_ICON, 0, icon_supported );

		}

	break;


	case WM_CREATE :

		// Global

		n_win_exedir2curdir();

		n_win_ime_disable( hwnd );


		if ( n_sysinfo_version_9x() )
		{
			n_project_dialog_info( hwnd, n_posix_literal( "Not Supported" ) );
			return -1;
		}

		if ( n_sysinfo_version_10_or_later() )
		{
			n_project_dialog_info( hwnd, n_posix_literal( "Not Supported" ) );
			return -1;
		}

		// [!] : WH_MOUSE_LL : DLL is not needed

		hinst = GetModuleHandle( NULL );//LoadLibrary( n_posix_literal( "Nonnon Mouse Hook.dll" ) );
		if ( hinst == NULL )
		{
			n_project_dialog_info( hwnd, n_posix_literal( "\"Nonnon Mouse Hook.dll\" is needed" ) );
			return -1;
		} else {
			n_mousehook_init( hinst, hwnd );
		}


		n_game_timegettime_init();


		n_win_systray_icon_load_callback = n_wheel_axl_systray_callback;


		n_wheel_axl_id_tray = N_PROJECT_SYSTRAY_ID_WHEEL_AXL;


		// Window and Style

		n_win_init( hwnd, N_WHEEL_AXL_APPNAME, N_WHEEL_AXL_MAIN_ICON, N_STRING_EMPTY );

		n_win_style_add( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_simplemenu_zero( &menu );
		n_win_simplemenu_init( &menu );

		n_win_simplemenu_set( &menu, 0, NULL, n_posix_literal( "[ ]Register"   ), NULL );
		n_win_simplemenu_set( &menu, 1, NULL, n_posix_literal( "[ ]Unregister" ), NULL );
		n_win_simplemenu_set( &menu, 2, NULL, n_posix_literal( "[-]"           ), NULL );
		n_win_simplemenu_set( &menu, 3, NULL, n_posix_literal( "[ ]Exit"       ), NULL );


		// Size

		{

			s32 sx,sy; n_win_desktop_size( &sx, &sy );
//sx = sy = 480;
			s32 size = n_posix_max( 333, n_posix_min( sx,sy ) / 3 );

			n_win_set( hwnd, NULL, size,size, N_WIN_SET_CENTERING );

		}


		// Display

		ShowWindow( hwnd, SW_HIDE );
		//ShowWindow( hwnd, SW_NORMAL );


		// Init

		n_win_systray_init( &nid, hwnd, n_wheel_axl_id_tray, N_WHEEL_AXL_TRAY_ICON, N_WHEEL_AXL_APPNAME, true );
		n_win_systray_icon_change( &nid, N_WHEEL_AXL_TRAY_ICON, 0, icon_supported );

	break;


	case N_WIN_SYSTRAY_MESSAGE :

		if ( wparam != n_wheel_axl_id_tray ) { break; }


		if ( lparam == WM_RBUTTONUP )
		{
			if ( n_win_is_input( VK_CONTROL ) )
			{
				// [Needed] : to disappear a popup menu
				SetForegroundWindow( hwnd );
				n_win_simplemenu_show( &menu, hwnd );
			} else {
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}
		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == menu.hwnd )
		{
			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
				//
			} else
			if ( wparam == 0 )
			{

				// [x] : Win95 : not supported
				//ShellExecute( hwnd, NULL, n_posix_literal( "shell:startup" ), NULL, NULL, SW_SHOWNORMAL );

				n_posix_char *rval = n_wheel_axl_startup_commandline();

				n_project_startup_register( N_WHEEL_AXL_APPNAME, rval );

				n_string_free( rval );

			} else
			if ( wparam == 1 )
			{

				n_project_startup_unregister( N_WHEEL_AXL_APPNAME );

			} else
			if ( wparam == 2 )
			{

				// [!] : Separator

			} else
			if ( wparam == 3 )
			{

				n_win_message_send( hwnd, WM_CLOSE, 0,0 );

			}// else
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_systray_exit( &nid );

		n_win_simplemenu_exit( &menu );

		n_mousehook_exit();
		//FreeLibrary( hinst );

		n_game_timegettime_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, &menu );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( N_WHEEL_AXL_APPNAME, n_wheel_axl_wndproc );
}

#endif // #ifndef NONNON_APPS


