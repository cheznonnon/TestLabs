//
//  AppDelegate.m
//  LINE MASHER 2 for Mac
//
//  Created by のんのん on 2023/01/31.
//

#import "AppDelegate.h"


#include "n_game.c"



@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonGame *n_game;

@end

@implementation AppDelegate




- (void)awakeFromNib
{
//NSLog( @"awakeFromNib" );

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

	[_n_game n_mac_game_canvas_resize:_window width:-1 height:-1];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}




- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}


@end
