//
//  AppDelegate.m
//  Nonnon Tools
//
//  Created by のんのん on 2022/11/07.
//

#import "AppDelegate.h"




#include "../../nonnon/neutral/bmp/all.c"
#include "../../nonnon/neutral/curico.c"

#include "../../nonnon/mac/n_textfield.c"


#include "stub.c"

#include "dotfiles_remover.c"
#include "timestamp.c"




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (strong) IBOutlet NonnonStub *n_stub;

@property (weak) IBOutlet NSTextField *n_tools_input;
@property (weak) IBOutlet NSButton *n_button_zero_timestamp;
@property (weak) IBOutlet NSButton *n_button_dotfiles_remover;

@end




@implementation AppDelegate


- (IBAction)n_button_method:(id)sender {


	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );

	n_timestamp_directory( path );

	n_string_free( path );

}
- (IBAction)n_button_dotfiles_remover_method:(id)sender {

	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );

	n_mac_tools_dotfiles_remover( path );

	n_string_free( path );

}
- (IBAction)n_button_icon_unpack:(id)sender {

	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );

	n_curico_multi_unpack( path );

	n_string_free( path );

}




- (void)NonnonDragAndDrop_dropped:(NSString*)nsstr
{
//NSLog( @"%@", nsstr );

	[_n_tools_input setStringValue:nsstr];

}




- (void)awakeFromNib
{

	_n_stub = [[NonnonStub alloc] init];
	[_n_stub setFrame:[[NSScreen mainScreen] frame]];
	[[_window contentView] addSubview:_n_stub];

	_n_stub.delegate = self;


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}


@end
