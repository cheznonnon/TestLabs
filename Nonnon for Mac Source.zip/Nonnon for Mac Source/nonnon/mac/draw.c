// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_DRAW
#define _H_NONNON_MAC_DRAW




#import <Cocoa/Cocoa.h>




void
n_mac_draw_box( NSColor *color, NSRect rect )
{

	[color set];
	//[NSBezierPath fillRect:rect];

	NSRectFill( rect );


	return;
}

void
n_mac_draw_frame( NSColor *color, NSRect rect )
{

	[color set];

	NSFrameRect( rect );


	return;
}

void
n_mac_draw_roundrect( NSColor *color, NSRect rect, CGFloat radius )
{

	NSGraphicsContext *nscontext = [NSGraphicsContext currentContext];
	CGContextRef         context = [nscontext CGContext];

	[nscontext saveGraphicsState];


 	// [!] : top-left

 	CGContextMoveToPoint( context, rect.origin.x, rect.origin.y + radius );

 	CGContextAddArcToPoint
 	(
 		context,
		rect.origin.x,
		rect.origin.y,
		rect.origin.x + radius,
		rect.origin.y,
		radius
	);


 	// [!] : top-right

 	CGContextAddArcToPoint
 	(
 		context,
		rect.origin.x + rect.size.width,
		rect.origin.y,
		rect.origin.x + rect.size.width,
		rect.origin.y + radius,
		radius
	);


 	// [!] : bottom-right
 	
 	CGContextAddArcToPoint
 	(
 		context,
		rect.origin.x + rect.size.width,
		rect.origin.y + rect.size.height,
		rect.origin.x + rect.size.width - radius,
		rect.origin.y + rect.size.height,
		radius
	);


 	// [!] : bottom-left

 	CGContextAddArcToPoint
 	(
 		context,
		rect.origin.x,
		rect.origin.y + rect.size.height,
		rect.origin.x,
		rect.origin.y,
		radius
	);

	CGContextClosePath( context );
 
 
 	[color set];
	CGContextFillPath( context );


	[nscontext restoreGraphicsState];


	return;
}

void
n_mac_draw_circle( NSColor *color, NSRect rect )
{

	NSGraphicsContext *nscontext = [NSGraphicsContext currentContext];
	CGContextRef         context = [nscontext CGContext];

	[nscontext saveGraphicsState];

	CGFloat radius_x = rect.size.width;
	CGFloat radius_y = rect.size.height;

	NSBezierPath *path = [NSBezierPath bezierPathWithRoundedRect:rect xRadius:radius_x yRadius:radius_y];
	[path addClip];

	[color set];
	CGContextFillRect( context, NSRectToCGRect( rect ) );

	[nscontext restoreGraphicsState];


	return;
}




#endif // _H_NONNON_MAC_DRAW


