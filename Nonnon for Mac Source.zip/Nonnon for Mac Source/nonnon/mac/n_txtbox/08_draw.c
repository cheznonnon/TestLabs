// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@implementation NonnonTxtbox (NonnonTxtboxDraw)


- (BOOL) isFlipped
{
	return YES;
}




- (void) NonnonTxtboxDrawScrollClamp
{

	CGFloat o                = offset;
	CGFloat inner_sy         = self.frame.size.height - ( o * 2 );
	CGFloat items_per_canvas = inner_sy / font_size.height;
	CGFloat txt_sy           = n_txt_data->sy;
	CGFloat rest             = font_size.height - fmod( inner_sy, font_size.height );
//NSLog( @"%f %f", page, txt_sy );

	if ( txt_sy <= 1 )
	{
		scroll = 0;
	} else
	if ( items_per_canvas <= txt_sy )
	{
		if ( rest ) { items_per_canvas -= 1.0; }

		CGFloat max_sy = txt_sy - items_per_canvas;

		if ( scroll <       0 ) { scroll =      0; } else
		if ( scroll >= max_sy ) { scroll = max_sy; }
	} else {
		scroll = 0;
	}

//NSLog( @"%lld : %lld %lld", n_focus, caret_fr.cch.y, caret_to.cch.y );

}




- (void) NonnonTxtboxDrawCaretCalculate
{

	// [!] : caret on the current screen

	n_caret pt = caret_fr;

	if ( caret_fr.cch.y == caret_to.cch.y )
	{
		if ( caret_fr.cch.y == n_focus )
		{
			if ( caret_fr.pxl.x == caret_to.pxl.x )
			{
//NSLog( @"==" );
				//
			} else
			if ( caret_fr.pxl.x < caret_to.pxl.x )
			{
//NSLog( @"< : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = caret_to;
			} else {
//NSLog( @"> : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = caret_to;
			}
		}
	} else
	if ( caret_fr.cch.y < caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { pt = caret_to; }
	} else
	if ( caret_fr.cch.y > caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { pt = caret_to; }
	}

	caret_pt.x = padding + pt.pxl.x;
	caret_pt.y = offset + ( ( pt.cch.y - trunc( scroll ) ) * font_size.height );


	return;
}

- (BOOL) NonnonTxtboxDrawCaretIsOnScreen
{
#ifdef N_TXTBOX_IME_ENABLE

	if ( ime_onoff )
	{
		return FALSE;
	}

#endif


	[self NonnonTxtboxDrawCaretCalculate];


	BOOL ret = FALSE;

	if ( caret_fr.cch.y == caret_to.cch.y )
	{
		if ( caret_fr.cch.y == n_focus ) { ret = TRUE; }
	} else
	if ( caret_fr.cch.y < caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { ret = TRUE; }
	} else
	if ( caret_fr.cch.y > caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { ret = TRUE; }
	}


	return ret;
}

- (void) NonnonTxtboxDrawCaretDraw:(void*)zero x:(n_type_gfx)x y:(n_type_gfx)y sx:(n_type_gfx)sx sy:(n_type_gfx)sy color_bg:(u32)color_bg color_stripe:(u32)color_stripe focus:(n_type_int)focus is_darkmode:(BOOL)is_darkmode
{
//return;

	double d;

	if ( [self window].keyWindow == FALSE )
	{
		d = 0.1;
	} else
	if ( n_txtbox_focus != self )
	{
		d = 0.1;
	} else
	if ( caret_blink_force_onoff )
	{
		d = 1.0;
	} else {
		if ( caret_blink_onoff )
		{
//NSLog( @"On %d", caret_blink_fade.percent );
			d = caret_blink_fade.percent * 0.01;
		} else {
//NSLog( @"Off %d", caret_blink_fade.percent );
			d = caret_blink_fade.percent * 0.01;
			d = 1.0 - d;
		}
	}

//NSLog( @"Percent %f", d );

	u32 color;
	if ( focus & 1 )
	{
		color = color_stripe;
	} else {
		color = color_bg;
	}

	u32 color_caret;
	if ( is_darkmode )
	{
		color_caret = n_bmp_white;
	} else {
		color_caret = n_bmp_black + 1;
	}

	color = n_bmp_blend_pixel( color, color_caret, (double) d );

	NSColor *clr = n_mac_argb2nscolor( color );
	NSRect   rct = NSMakeRect( x,y,sx,sy );
	n_mac_draw_box( clr, rct );

}

- (NSRect) NonnonTxtboxDrawTextAdjust:(NSString*) text rect:(NSRect) rect
{

	CGSize size = n_mac_image_text_pixelsize( text, font );

	CGFloat cx = ( rect.size.width  - size.width  ) / 2;
	CGFloat cy = ( rect.size.height - size.height ) / 2;

	NSRect ret = NSMakeRect(
		rect.origin.x    + cx,
		rect.origin.y    + cy,
		rect.size.width  - cx,
		rect.size.height - cy
	);

	return ret;
}

- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

//u32 tick = n_posix_tickcount();

//NSLog( @"%lld", n_test_txt.sy );


	// [!] : redraw

	BOOL is_whole_redraw;

	if (
		( self.frame.size.width  == rect.size.width  )
		&&
		( self.frame.size.height == rect.size.height )
	)
	{
		is_whole_redraw = TRUE;
	} else {
		is_whole_redraw = FALSE;
	}

	// [x] : partially redraw : too much hard to implement
	//
	//	drawRect will be called with as gray-filled image
/*
	BOOL debug = FALSE;
	if ( redraw_fy == 0 )
	{
		debug = TRUE;
	}
*/

	// [Patch] : not supported yet

	if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{
		is_whole_redraw = TRUE;
	}

	if ( is_whole_redraw )
	{
		redraw_fy = 0;
		redraw_ty = n_txt_data->sy;
	}

	//redraw_fy = 1;
	//redraw_ty = 2;


	// [!] : Metrics

	BOOL is_darkmode = n_mac_is_darkmode();

	[self NonnonTxtboxDrawScrollClamp];

	n_type_gfx csx = (n_type_gfx) self.frame.size.width;
	n_type_gfx csy = (n_type_gfx) self.frame.size.height;

	CGFloat o = offset;
//NSLog( @"%f", offset );

	CGFloat centered_offset = 0;

	if (
		( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
		||
		( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE )

	)
	{
		centered_offset = ( ( font_size.height + ( o * 2 ) ) - csy ) / 2;
	} else {
		CGFloat minim = font_size.height + ( o * 2 );
		if ( ( csx < minim )||( csy < minim ) ) { return; }
	}

	if ( caret_fr.cch.y >= n_txt_data->sy ) { caret_fr.cch.y = n_txt_data->sy - 1; }


	// [!] : Metrics 2 : Colors

	NSColor *nscolor_text;
	if ( is_darkmode )
	{
		nscolor_text = n_mac_nscolor_argb( 255,222,222,222 );
	} else {
		nscolor_text = [NSColor textColor];
	}

	NSColor *nscolor_back  = [NSColor textBackgroundColor];
	if ( is_grayed )
	{
		nscolor_text = n_mac_nscolor_blend( nscolor_back, nscolor_text, 0.55 );
		nscolor_back = n_mac_nscolor_blend( nscolor_back, nscolor_text, 0.05 );
	}

	u32        color_bg    = n_mac_nscolor2argb( nscolor_back );
	u32        color_fg    = n_mac_nscolor2argb( nscolor_text );
	u32        color_frame = n_bmp_blend_pixel( color_bg, color_fg, 0.25 );
	NSColor *nscolor_frame = n_mac_argb2nscolor( color_frame );
	NSColor *nscolor_text_normal = nscolor_text;

	NSColor *nscolor_text_highlight;
	if ( is_darkmode )
	{
		nscolor_text_highlight = nscolor_text;
	} else {
		nscolor_text_highlight = [NSColor controlHighlightColor];
	}

	u32        color_stripe;
	NSColor *nscolor_stripe;

	if ( is_darkmode )
	{
		  color_stripe = n_bmp_blend_pixel( color_bg, color_fg, 0.10 );
		nscolor_stripe = n_mac_argb2nscolor( color_stripe );
	} else {
		  color_stripe = n_bmp_blend_pixel( color_bg, color_fg, 0.05 );
		nscolor_stripe = n_mac_argb2nscolor( color_stripe );
	}
	
	u32        color_crlf = n_bmp_blend_pixel( color_bg, color_fg, 0.25 );
	NSColor *nscolor_crlf = n_mac_argb2nscolor( color_crlf );

	NSColor *nscolor_accent = [NSColor controlAccentColor];

#ifdef N_TXTBOX_IME_ENABLE
	//NSColor *nscolor_ime = [nscolor_accent blendedColorWithFraction:0.33 ofColor:nscolor_stripe];
	NSColor *nscolor_ime = nscolor_accent;
#endif


	// [!] : Contents

	if ( is_whole_redraw )
	{
		if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			//
		} else {
			n_mac_draw_box( nscolor_back, self.frame );
		}
	}
//n_mac_draw_box( n_mac_nscolor_argb( 255,0,200,255 ), self.frame );


	// [!] : Find Icon

	if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		if ( self.n_findbox_bmp_icon != NULL )
		{

			n_bmp bmp; n_bmp_carboncopy( self.n_findbox_bmp_icon, &bmp );


			CGFloat size = N_BMP_SY( &bmp );


			u32 color_replace;

			if ( n_txtbox_focus != self )
			{
				if ( is_darkmode )
				{
					color_replace = n_bmp_white;
				} else {
					color_replace = n_bmp_rgb( 33,33,33 );
				}
			} else {
				color_replace = n_bmp_color_mac( n_mac_nscolor2argb( nscolor_accent ) );
			}


			int replace_r = n_bmp_r( color_replace );
			int replace_g = n_bmp_g( color_replace );
			int replace_b = n_bmp_b( color_replace );

			n_type_gfx x = 0;
			n_type_gfx y = 0;
			n_posix_loop
			{//break;
				u32 c; n_bmp_ptr_get_fast( &bmp, x,y, &c );

				int a = n_bmp_a( c );
				if ( a != 0 )
				{
					int r = replace_r;
					int g = replace_g;
					int b = replace_b;

					c = n_bmp_argb( a,r,g,b );

					n_bmp_ptr_set_fast( &bmp, x,y, c );
				}

				x++;
				if ( x >= size )
				{
					x = 0;
					y++;
					if ( y >= size ) { break; }
				}
			}


			n_posix_loop
			{
				if ( self.frame.size.height >= N_BMP_SY( &bmp ) ) { break; }

				n_bmp_flush_antialias( &bmp, 1.0 );
				n_bmp_scaler_lil     ( &bmp, 2   );
			}


			CGFloat sz = N_BMP_SY( &bmp );
			CGFloat c  = ( self.frame.size.height - sz ) / 2;
			CGFloat pr = 0;

			if ( find_icon_is_pressed )
			{
				pr = 1;
			}

			find_icon_rect = NSMakeRect( o+pr,c+pr, sz,sz );


			if ( n_txtbox_focus == self )
			{
				NSColor *nscolor = n_mac_nscolor_blend( nscolor_back, nscolor_crlf, 0.25 );
				n_mac_draw_circle( nscolor, find_icon_rect );
			}


			NSImage *img = n_mac_image_nbmp2nsimage( &bmp );
			[img drawInRect:find_icon_rect];

			n_bmp_free_fast( &bmp );
		}
	}


	// [!] : n_txt rendering engine

//NSLog( @"%f %f", caret_fr.pxl.x, caret_to.pxl.x );

	NSMutableDictionary *attr = [NSMutableDictionary dictionary];
	[attr setObject:font forKey:NSFontAttributeName];

	NSMutableDictionary *attr_crlf = [NSMutableDictionary dictionary];
	[attr_crlf setObject:linenumber_font forKey:NSFontAttributeName];
	[attr_crlf setObject:nscolor_crlf    forKey:NSForegroundColorAttributeName];

#ifdef N_TXTBOX_IME_ENABLE

	NSMutableDictionary *attr_ime = [NSMutableDictionary dictionary];
	[attr_ime setObject:font forKey:NSFontAttributeName];
	//[attr_ime setObject:[NSNumber numberWithInt:NSUnderlineStyleDouble] forKey:NSUnderlineStyleAttributeName ];

#endif

	NSRect r = NSMakeRect( padding, o - centered_offset, self.frame.size.width - ( o * 2 ), font_size.height );

	CGFloat max_sy = self.frame.size.height - ( o * 2 );

	NSRect listbox_rect = NSMakeRect( 0,0,0,0 );

#ifdef N_TXTBOX_IME_ENABLE

	NSRect  underline_rect = NSMakeRect( -1,-1,-1,-1 );
	CGFloat underline_fx   = -1;
	CGFloat underline_tx   = -1;

#endif


	// [!] : before text rendering : for some fonts like "g"

	{

		NSRect rect = r;

		n_type_int i = scroll;
		n_posix_loop
		{//break;

			if (
				( is_whole_redraw )
				||
				( ( redraw_fy <= i )&&( i < redraw_ty ) )
			)
			{
				if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
				{
					n_mac_draw_box( nscolor_back, self.frame );
				} else
				if ( i & 1 )
				{
					n_mac_draw_box( nscolor_stripe, rect );
				} else {
					n_mac_draw_box( nscolor_back  , rect );
				}
			}

			rect.origin.y += font_size.height;
			if ( rect.origin.y > max_sy ) { break; }

			i++;
		}
	}


	n_type_int i = scroll;
//NSLog( @"%f %lld", scroll, n_mac_listbox_txt.sy );
	n_posix_loop
	{//break;

		n_posix_char *line = n_txt_get( n_txt_data, i );

		line = &line[ self.n_line_offset ];

		if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			if ( i == self.n_focus )
			{
				if ( self.n_listbox_edit_onoff )
				{
//NSLog( @"%f", o );
					listbox_rect = r;
					listbox_rect.size.width = csx - padding - o;
				} else {
					n_mac_draw_box( nscolor_accent, r );
				}
			}
		}

		if ( ( redraw_fy <= i )&&( i < redraw_ty )&&( i < n_txt_data->sy ) )
		{
//[text drawInRect:r withAttributes:attr];

			if ( ( n_txt_deco != NULL )&&( n_txt_data->sy == n_txt_deco->sy ) )
			{
				n_posix_char *deco = n_txt_get( n_txt_deco, i );

				// [x] : italic : no better way

				if ( ( self.n_listbox_edit_onoff )&&( i == n_focus ) )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.0];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				} else
				if ( deco[ 0 ] == ' ' )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.2];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				} else
				if ( deco[ 0 ] == 'B' )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.0];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				} else
				if ( deco[ 0 ] == 'u' )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.2];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleSingle];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				} else
				if ( deco[ 0 ] == 'U' )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.0];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleSingle];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				}
			}


			n_type_int index = 0;
			CGFloat    sx    = 0;
			n_type_int tab   = 0;
			n_posix_loop
			{//break;
				if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

				CGSize     char_size;
				n_type_int char_index;
				NSRect     char_rect = r;

				n_posix_char *character;
				character = n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );
//NSLog( @"#%lld : %ld", i, strlen( character ) );

				char_rect.origin.x   += sx;
				char_rect.origin.x   -= 1;
				char_rect.size.width  = char_size.width + 1;


				NSPoint pt = NSMakePoint( sx, i );

				BOOL selected = n_mac_txtbox_is_selected( pt, caret_fr.pxl.x, caret_fr.cch.y, caret_to.pxl.x, caret_to.cch.y );
				if ( ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )&&( self.n_listbox_edit_onoff == FALSE ) )
				{
					if ( i == self.n_focus )
					{
						selected = TRUE;
					}
				} else {
					if ( selected )
					{
						n_mac_draw_box( nscolor_accent, char_rect );
					}
				}


				if ( line[ index ] == N_STRING_CHAR_TAB )
				{

					NSRect r = char_rect; r.size.width = 0.5;

					n_mac_draw_box( nscolor_crlf, r );

				} else
				//
				{

					if ( selected )
					{
						[attr setObject:nscolor_text_highlight forKey:NSForegroundColorAttributeName];
					} else {
						[attr setObject:nscolor_text_normal    forKey:NSForegroundColorAttributeName];
					}

					NSString *text = n_mac_str2nsstring( character );
					char_rect = [self NonnonTxtboxDrawTextAdjust:text rect:char_rect];
					[text drawInRect:char_rect withAttributes:attr];
//NSLog( @"%@", text );

				}

//NSLog( @"%lld", char_index );
				index += char_index;
				sx    += char_size.width;
			}

			// [!] : End-of-Line Marker

			if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				//
			} else
			if ( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE )
			{
				//
			} else
			if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{
				//
			} else {
				NSRect char_rect = r;
				char_rect.origin.x += sx;

				NSString *crlf = @"\xe2\x86\xa9";
				[crlf drawInRect:char_rect withAttributes:attr_crlf];
			}

#ifdef N_TXTBOX_IME_ENABLE

			if ( ( ime_onoff )&&( i == n_focus ) )
			{

				n_posix_char *line = n_mac_nsstring2str( ime_nsstr );

				n_type_int range_f = ime_focus.location;
				n_type_int range_t = ime_focus.location + ime_focus.length;
				//if ( range_f == range_t ) { range_f = 0; }
//NSLog( @"%lld %lld", range_f, range_t );

				n_type_int index  = 0;
				CGFloat    sx     = ime_caret_fr.pxl.x;
				n_type_int tab    = 0;
				n_type_int glyph  = 0;
				n_type_int ime_sx = sx;
				n_posix_loop
				{//break;
					if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

					CGSize     char_size;
					n_type_int char_index;
					NSRect     char_rect = r;

					n_posix_char *character;
					character = n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );
//NSLog( @"#%lld : %ld", i, strlen( character ) );

					char_rect.origin.x   += sx;
					char_rect.origin.x   -= 1;
					char_rect.size.width  = char_size.width + 1;


					// [!] : underline based

					if ( ( glyph >= range_f )&&( glyph < range_t ) )
					{
						if ( underline_fx == -1 ) { underline_fx = char_rect.origin.x; }
						underline_tx = char_rect.origin.x + char_rect.size.width;
					}

					if ( i & 1 )
					{
						n_mac_draw_box( nscolor_stripe, char_rect );
					} else {
						n_mac_draw_box( nscolor_back  , char_rect );
					}
					[attr_ime setObject:nscolor_text_normal    forKey:NSForegroundColorAttributeName];

/*
					// [!] : highlight based

					if ( ( glyph >= range_f )&&( glyph < range_t ) )
					{
						[attr_ime setObject:nscolor_text_highlight forKey:NSForegroundColorAttributeName];
						n_mac_draw_box( nscolor_ime, char_rect );
					} else {
						if ( i & 1 )
						{
							n_mac_draw_box( nscolor_stripe, char_rect );
						} else {
							n_mac_draw_box( nscolor_back  , char_rect );
						}
						[attr_ime setObject:nscolor_text_normal    forKey:NSForegroundColorAttributeName];
					}
*/
					NSString *text = n_mac_str2nsstring( character );
					char_rect = [self NonnonTxtboxDrawTextAdjust:text rect:char_rect];
					[text drawInRect:char_rect withAttributes:attr_ime];

					index += char_index;
					sx    += char_size.width;
					glyph += 1;
					if ( glyph == ime_caret_offset ) { ime_sx = sx; }
				}

				n_string_free( line );


				// [!] : Underline #1

				underline_rect = NSMakeRect(
					padding + ime_caret_fr.pxl.x,
					r.origin.y + r.size.height - 2,
					sx - ime_caret_fr.pxl.x,
					2
				);


				// [!] : Fake Caret : IME version

				{
					n_type_gfx oy = (n_type_gfx) scroll * font_size.height;
					n_type_gfx  x = (n_type_gfx) padding + (n_type_gfx) ime_sx;
					n_type_gfx  y = (n_type_gfx) o + ime_caret_fr.pxl.y - oy - centered_offset;
					n_type_gfx sx = (n_type_gfx) 2;
					n_type_gfx sy = (n_type_gfx) font_size.height;

					[self NonnonTxtboxDrawCaretDraw:nil x:x y:y sx:sx sy:sy color_bg:color_bg color_stripe:color_stripe focus:n_focus is_darkmode:is_darkmode];
				}

			}
#endif

		}

		if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			if ( i == self.n_focus )
			{
				if ( self.n_listbox_edit_onoff )
				{
					NSRect rect = listbox_rect;
					rect.origin.x--;
					rect.origin.y--;
					//rect.size.width += 2;
					rect.size.height += 2;
					n_mac_draw_frame( nscolor_accent, rect );
				}
			}
		}


		r.origin.y += font_size.height;
		if ( r.origin.y > max_sy ) { break; }


		i++;
	}


	// [!] : underline
	
	if ( underline_rect.origin.x != -1 )
	{

		n_bmp_flip_onoff = n_posix_true;

		n_type_gfx  x = underline_rect.origin.x;
		n_type_gfx  y = underline_rect.origin.y;
		n_type_gfx sx = underline_rect.size.width;
		n_type_gfx sy = 4;//underline_rect.size.height;

		n_type_gfx circle = sy;
		n_type_gfx step   = circle * 1.5;

		n_type_gfx xx = 0;
		n_posix_loop
		{//break;

			NSColor *clr = n_mac_argb2nscolor( color_crlf );
			NSRect   rct = NSMakeRect( x + xx,y,circle,circle );

			if ( underline_fx != -1 )
			{
				if ( ( ( x + xx ) >= underline_fx )&&( ( x + xx ) <= underline_tx ) )
				{
					clr = nscolor_ime;
				}
			}

			n_mac_draw_circle( clr, rct );

			xx += step;
			if ( xx >= sx ) { break; }
		}

		n_bmp_flip_onoff = n_posix_false;
	}


	// [!] : Line Number

	if (1)//( is_whole_redraw )
	{
		n_bmp_flip_onoff = n_posix_true;

		n_type_int     i = 0;
		n_type_gfx pxl_y = 0;
		n_posix_loop
		{

			n_mac_txtbox_draw_linenumber
			(
				linenumber_font,
				i, scroll, n_txt_data->sy,
				(n_type_int) MIN( caret_fr.cch.y, caret_to.cch.y ),
				(n_type_int) MAX( caret_fr.cch.y, caret_to.cch.y ),
				o, o + pxl_y, linenumber_size.width, font_size.height,
				nscolor_back,
				nscolor_text,
				self.n_option_linenumber
			);

			i++;

			pxl_y += font_size.height;
			if ( pxl_y > max_sy ) { break; }

		}

		n_bmp_flip_onoff = n_posix_false;
	}


	// [!] : Fake Caret

	if ( ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )&&( self.n_listbox_edit_onoff == FALSE ) )
	{
		//
	} else
	if ( [self NonnonTxtboxDrawCaretIsOnScreen] )
	{
		caret_pt.y -= centered_offset;

		n_type_gfx  x = (n_type_gfx) caret_pt.x;
		n_type_gfx  y = (n_type_gfx) caret_pt.y;
		n_type_gfx sx = (n_type_gfx) 1;
		n_type_gfx sy = (n_type_gfx) font_size.height;

		[self NonnonTxtboxDrawCaretDraw:nil x:x y:y sx:sx sy:sy color_bg:color_bg color_stripe:color_stripe focus:n_focus is_darkmode:is_darkmode];
	}


	// [!] : delete circle

	if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		if ( 0 != n_posix_strlen( n_txt_get( n_txt_data, 0 ) ) )
		{

			NSColor *color_fg = [NSColor whiteColor];
			NSColor *color_bg;
			if ( delete_circle_is_pressed )
			{
				color_bg = [NSColor blackColor];

				delete_circle_fade.stop  =  TRUE;
				delete_circle_is_hovered = FALSE;
			} else
			if ( delete_circle_fade.stop == FALSE )
			{
//NSLog( @"%x : %d", delete_circle_fade.color_fg, delete_circle_fade.percent );

				NSColor *f;
				if ( n_txtbox_focus == self )
				{
					f = nscolor_accent;
				} else {
					f = [NSColor grayColor];
				}

				NSColor *t = n_mac_nscolor_argb( 255, 255, 0, 128 );

				if ( delete_circle_fade.color_fg == n_bmp_white )
				{
					color_bg = n_mac_nscolor_blend( f, t, delete_circle_fade.percent * 0.01 );
				} else {
					color_bg = n_mac_nscolor_blend( t, f, delete_circle_fade.percent * 0.01 );
				}
			} else
			if ( delete_circle_is_hovered )
			{
				color_bg = n_mac_nscolor_argb( 255, 255, 0, 128 );
			} else
			if ( n_txtbox_focus == self )
			{
				color_bg = nscolor_accent;
			} else {
				color_bg = [NSColor grayColor];
			}

			CGFloat sz = csy - ( o * 2 );
			delete_circle_rect = NSMakeRect( csx - sz - o,o, sz,sz );
			n_mac_draw_circle( color_bg, delete_circle_rect );


			NSString *text = @"×";

			CGSize size = n_mac_image_text_pixelsize( text, font );
			NSRect rdel = delete_circle_rect;

			rdel.origin.x += ( sz - size.width  ) / 2;
			rdel.origin.y += ( sz - size.height ) / 2;

			rdel.origin.y += font.descender;
//NSLog( @"%f %f", font.ascender, font.descender );

			if ( fmod( size.height, 2 ) == 0 ) { rdel.origin.y--; }

			CGFloat scale = [[self window] backingScaleFactor];
			rdel.origin.y += scale;
//NSLog( @"%f", scale );

			NSMutableDictionary *attr = [NSMutableDictionary dictionary];
			[attr setObject:font     forKey:NSFontAttributeName];
			[attr setObject:color_fg forKey:NSForegroundColorAttributeName];

			[text drawAtPoint:rdel.origin withAttributes:attr];

		}
	}


	// [!] : Scrollbar

	if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		//
	} else
	if ( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE )
	{
		//
	} else
	if (1)//( is_whole_redraw )
	{

		// [!] : Fake Scroller

//NSLog( @"%f %f", page, txt_sy );

		CGFloat inner_sy         = csy - ( o * 2 );
		CGFloat items_per_canvas = inner_sy / font_size.height;
		CGFloat max_count        = (CGFloat) n_txt_data->sy;
		CGFloat rest             = font_size.height - fmod( inner_sy, font_size.height );

		client_sy = csy - o;

//NSLog( @"%f %f", items_per_canvas, max_count );
		if ( trunc( items_per_canvas ) < max_count )
		{
			if ( rest ) { items_per_canvas -= 1.0; }

			CGFloat correction = font_size.height * ( client_sy / ( max_count * font_size.height ) );
//NSLog( @"%f", correction );

			CGFloat page = max_count / items_per_canvas;

			n_type_gfx scrsx = 12;
			n_type_gfx scrsy = MAX( 12, ( csy - o ) / page );
			n_type_gfx scr_x = csx - o - scrsx;
			n_type_gfx scr_y = ceil( scroll * correction );
//NSLog( @"%f %f", scroll, font_size.height ); 


			// [!] : this is a kind of cheat
			scr_y = n_posix_minmax_n_type_gfx( o, csy - scrsy + o, scr_y );


			// [!] : for hit test
//scroller_rect = NSMakeRect( 0, 0, 0, 0 );
			scroller_rect_shaft = NSMakeRect( scr_x,     o, scrsx,   csy );
			scroller_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );


			u32 color = color_fg;

			n_bmp_flip_onoff = n_posix_true;

			u32 color_shaft = n_bmp_alpha_replace_pixel( color, 16 );

			{
				NSColor *clr = n_mac_argb2nscolor( color_shaft );
				NSRect   rct = NSMakeRect( scr_x,o, scrsx,inner_sy );
				n_mac_draw_roundrect( clr, rct, scrsx / 2 );
			}


			int hot    =  64;
			int normal =  96;
			int press  = 128;

			u32 color_thumb;
			if ( scrollbar_fade_captured_onoff )
			{
//NSLog( @"scrollbar_fade_captured_onoff" );

				u32 f = n_bmp_alpha_replace_pixel( color, press  );
				u32 t = n_bmp_alpha_replace_pixel( color, hot    );
				if ( thumb_is_captured )
				{
//NSLog( @"thumb_is_captured" );
					color_thumb = n_bmp_blend_pixel( t, f, (n_type_real) scrollbar_fade.percent * 0.01 );
				} else {
//NSLog( @"else" );
					if ( thumb_is_hovered )
					{
						t = n_bmp_alpha_replace_pixel( color, hot    );
					} else {
						t = n_bmp_alpha_replace_pixel( color, normal );
					}
					color_thumb = n_bmp_blend_pixel( f, t, (n_type_real) scrollbar_fade.percent * 0.01 );
				}
//NSLog( @"%d", scrollbar_fade.percent );
			} else
			if ( scrollbar_fade_hovered_onoff )
			{
//NSLog( @"scrollbar_fade_hovered_onoff" );

				u32 f = n_bmp_alpha_replace_pixel( color, hot    );
				u32 t = n_bmp_alpha_replace_pixel( color, normal );
				if ( thumb_is_captured )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, press  );
				} else
				if ( thumb_is_hovered )
				{
					color_thumb = n_bmp_blend_pixel( t, f, (n_type_real) scrollbar_fade.percent * 0.01 );
				} else {
					color_thumb = n_bmp_blend_pixel( f, t, (n_type_real) scrollbar_fade.percent * 0.01 );
				}
			} else {
//NSLog( @"else" );

				if ( thumb_is_captured )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, press  );
				} else
				if ( thumb_is_hovered )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, hot    );
				} else {
					color_thumb = n_bmp_alpha_replace_pixel( color, normal );
				}
			}

			{
				NSColor *clr = n_mac_argb2nscolor( color_thumb );
				NSRect   rct = NSMakeRect( scr_x,scr_y, scrsx,scrsy );
				n_mac_draw_roundrect( clr, rct, scrsx / 2 );
			}

			n_bmp_flip_onoff = n_posix_false;
		}


		// [!] : right-side margin

		NSRect rect_padding = NSMakeRect( csx - o, 0, o, csy );
		n_mac_draw_box( nscolor_back, rect_padding );


		// [!] : bottom-side margin

		rect_padding = NSMakeRect( 0, csy - o, csx, o );
		n_mac_draw_box( nscolor_back, rect_padding );

	}
	

	// [!] : Frame

//if(0)
	{

		[self setWantsLayer:YES];
		[self.layer setBorderWidth:2];
		//[self.layer setBackgroundColor:[[NSColor controlLightHighlightColor] CGColor]];
		[self.layer setBackgroundColor:[nscolor_back CGColor]];
		[self.layer setBorderColor:nscolor_frame.CGColor];

		CGFloat r = 10;
		if ( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE )
		{
			r = csy / 4;
		} else
		if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			r = csy / 2;
		}
		
		[self.layer setCornerRadius:r];

	}

/*
	if ( debug )
	{
		n_mac_draw_box( [NSColor blackColor], self.frame );
	}
*/

	redraw_fy = -1;
	redraw_ty = -1;

/*
	{
		NSColor *clr = n_mac_nscolor_argb( 255, 0,200,255 );
		NSRect   rct = NSMakeRect( 100,100,200,200 );
		n_mac_draw_roundrect( clr, rct, 10 );
	}
*/
/*
	{
		NSColor *clr = n_mac_nscolor_argb( 255, 0,200,255 );
		NSRect   rct = NSMakeRect( 100,100,200,200 );
		n_mac_draw_circle( clr, rct );
	}
*/

//NSLog( @"%d", (int) n_posix_tickcount() - tick );
}


@end

