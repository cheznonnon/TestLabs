// Nonnon COM : DWebBrowserEvents2
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// [x] : MinGW : many symbols are missing
//
//	please search them
//	some patches are written in nonnon/com/com/patch.c


// [!] : Initialization Order
//
//	1 : BeforeNavigate2()   : n_HTMLDocumentEvents_exit()
//	2 : DownloadComplete()
//	3 : NavigateComplete2()
//	4 : DocumentComplete()  : n_HTMLDocumentEvents_init()
//
//	[ Problems : put n_HTMLDocumentEvents_init() at NavigateComplete2() ]
//
//	no-error but not-fully-functionable state happens
//	mouse gesture doesn't function in some sites
//
//	[ IWebBrowser2 ]
//
//	a parameter "pDisp" has not a "n_felis_wb" global variable sometimes




#ifndef _H_NONNON_WIN32_COM_DWEBBROWSEREVENTS2
#define _H_NONNON_WIN32_COM_DWEBBROWSEREVENTS2




// Instance

void
n_felis_init( n_posix_char *url )
{

	// Interfaces

	extern DWebBrowserEvents2 n_DWebBrowserEvents2_instance;

	n_com_init();

	n_WebBrowser_init( &n_felis_wb, &n_DWebBrowserEvents2_instance, &n_felis_cookie, &H_WB, H_FRAME, url );

	n_felis_webbrowser_autoresize( n_true );


	// UI

	EnableWindow( H_BACK, n_true );
	EnableWindow( H_HOME, n_true );


	return;
}

void
n_felis_exit( void )
{

	// UI

	ShowWindow( H_STOP, SW_HIDE   );
	ShowWindow( H_LOAD, SW_NORMAL );

	EnableWindow( H_BACK, n_false );
	EnableWindow( H_HOME, n_false );


	// Strings

	n_string_path_free( n_felis_url_home      );
	n_string_path_free( n_felis_url_select2go );


	// Interfaces

	n_WebBrowser_exit( n_felis_wb, &n_felis_cookie );

	n_com_exit();


	// BSTRs

	n_com_bstr_exit( n_felis_url_current );
	n_com_bstr_exit( n_felis_url_hovered );
	n_com_bstr_exit( n_felis_url_lastset );


	// Zero-Clear

	H_WB           = NULL;
	n_felis_wb     = NULL;
	n_felis_cookie = 0;

	n_felis_url_home      = NULL;
	n_felis_url_select2go = NULL;


	return;
}

void
n_felis_url_set( const BSTR bstr )
{

	n_posix_char *s1 = n_com_bstr2string( bstr );
	n_posix_char *s2 = n_com_bstr2string( bstr );
	n_posix_char *s3 = NULL;

//n_win_hwndprintf_literal( GetParent( H_BAND ), "%d", n_string_search_simple_literal( s1, "%" ) );

	// [!] : for performance

	if ( n_string_search_simple_literal( s1, "%" ) )
	{
		s3 = n_www_percentencoding_decode( s1 );
		n_memory_free( s1 );
		s1 = s3;
	}

	n_win_text_set( H_URL, s1 );
	n_win_txtbox_line_set( &n_felis_txtbox_open, 0, s2 );

	n_memory_free( s1 );
	n_memory_free( s2 );


	return;
}

static n_bool n_felis_on_navigation_lock = n_false;

void
n_felis_on_navigation_begin( void *pDisp )
{

	// [Patch] : see WM_MOUSEWHEEL @ WndProc() @ felis.c

	n_felis_on_navigation_lock = n_true;


	// Debug Center

	//int frameset_count = n_felis_frameset_count( (void*) pDisp );
	//n_win_hwndprintf_literal( n_win_hwnd_toplevel( H_WB ), "Previous : %d", frameset_count );


	// UI

	ShowWindow( H_LOAD, SW_HIDE   );
	ShowWindow( H_STOP, SW_NORMAL );


	n_felis_addressbar_progress_start( n_true, 1000 );


	// [Patch] : delayed release

	if ( n_felis_disp2release != NULL )
	{
		n_felis_HTMLDocumentEvents_exit( (void*) n_felis_disp2release );
	}

	n_felis_disp2release = pDisp;


	IHTMLDocument2 *hd = n_WebBrowser_MSHTML( (void*) n_felis_wb );
	ICustomDoc     *cd = NULL; n_com_interface( hd, n_guid_IID_ICustomDoc, (void*) &cd );

	if ( cd != NULL )
	{
		ICustomDoc_SetUIHandler( cd, &n_IDocHostUIHandler_instance );
	}

	n_com_release( cd );
	n_com_release( hd );



	return;
}

void
n_felis_on_navigation_end( void *pDisp )
{

	// Debug Center

	//n_posix_debug_literal( "n_felis_on_navigation_end()" );

	//int frameset_count = n_felis_frameset_count( (void*) pDisp );
	//n_win_hwndprintf_literal( n_win_hwnd_toplevel( H_WB ), "Current : %d", frameset_count );


	// UI

	ShowWindow( H_STOP, SW_HIDE   );
	ShowWindow( H_LOAD, SW_NORMAL );


	n_felis_addressbar_progress_stop();
	//n_felis_progress_stop_onoff = n_true;


	n_com_bstr_exit( n_felis_url_current ); n_felis_url_current = n_WebBrowser_url( n_felis_wb );
	n_com_bstr_exit( n_felis_url_hovered ); n_felis_url_hovered = n_com_bstr_init_literal( "" );
	n_com_bstr_exit( n_felis_url_lastset ); n_felis_url_lastset = n_com_bstr_init_literal( "" );

	n_felis_url_set( n_felis_url_current );


	// [Patch] : delayed release

	if ( n_felis_disp2release != NULL )
	{
		n_felis_HTMLDocumentEvents_exit( (void*) n_felis_disp2release );
		n_felis_disp2release = NULL;
	}


	n_felis_HTMLDocumentEvents_init( (void*) pDisp );


	// [Needed] : Win98 + IE5 : only with CLSID_InternetExplorer

	//H_WB = n_WebBrowser_embed( n_felis_wb, H_FRAME );
	//n_felis_WebBrowser_autoresize( n_false );


	n_WebBrowser_focus( n_felis_wb );


	// [Patch] : see WM_MOUSEWHEEL @ WndProc() @ felis.c

	n_felis_on_navigation_lock = n_false;


	return;
}




HRESULT __stdcall
n_DWebBrowserEvents2_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
//N_COM_DEBUG_LISTBOX_SET_A( "DWebBrowserEvents2_IUnknown_QueryInterface" );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID d = n_com_guid( n_guid_IID_IDispatch );
	GUID w = n_com_guid( n_guid_DIID_DWebBrowserEvents2 );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &d ) )
		||
		( IsEqualGUID( iid, &w ) )
	)
	{
//n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}

#define DISPID_BEFORENAVIGATE 100

typedef enum BrowserBeforeNavConstants {

	beforeNavigateExternalFrameTarget = 0x1

} BrowserBeforeNavConstants;

#define DISPID_BEFORENAVIGATE2 250
void
BeforeNavigate2
(
	IDispatch    *pDisp,
	VARIANT      *url,
	VARIANT      *Flags,
	VARIANT      *TargetFrameName,
	VARIANT      *PostData,
	VARIANT      *Headers,
	VARIANT_BOOL *Cancel
) 
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : BeforeNavigate2" );


	// [Mechanism]
	//
	//	V_BSTR( url )
	//	V_I4( Flags ) == beforeNavigateExternalFrameTarget
	//	V_BSTR( TargetFrameName )
	//	V_BSTR( Headers )
	//	(*Cancel) = VARIANT_TRUE;

N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( url ) );
N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( TargetFrameName ) );
N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( Headers ) );


	// [x] : buggy : IWebBrowser2_get_Busy() will be true forever when you use "(*Cancel) = VARIANT_TRUE"
	//
	//	then hang-up happens

	if ( n_felis_accesslist_is_blocklisted( V_BSTR( url ) ) )
	{
		//(*Cancel) = VARIANT_TRUE;

		n_WebBrowser_stop( (IWebBrowser2*) pDisp );
		//n_felis_on_navigation_end( pDisp );
	} else {
		n_felis_on_navigation_begin( pDisp );
	}


	return;
}

#define DISPID_CLIENTTOHOSTWINDOW 268
void
ClientToHostWindow( long *CX, long *CY )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : ClientToHostWindow" );


	return;
}

#ifndef _MSC_VER

typedef enum CommandStateChangeConstants {

	CSC_UPDATECOMMANDS  = (int) 0xFFFFFFFF,
	CSC_NAVIGATEFORWARD = 0x1,
	CSC_NAVIGATEBACK    = 0x2

} CommandStateChangeConstants;

#endif // #ifndef _MSC_VER

#define DISPID_COMMANDSTATECHANGE 105
void
CommandStateChange( long Command, VARIANT_BOOL Enable )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : CommandStateChange" );

	switch( Command ) {

	case CSC_UPDATECOMMANDS :

N_COM_DEBUG_LISTBOX_SET_A( "CSC_UPDATECOMMANDS" );

	break;

	case CSC_NAVIGATEFORWARD :

N_COM_DEBUG_LISTBOX_SET_A( "CSC_NAVIGATEFORWARD" );

	break;

	case CSC_NAVIGATEBACK :

N_COM_DEBUG_LISTBOX_SET_A( "CSC_NAVIGATEBACK" );

	break;

	}//switch


	return;
}

#define DISPID_DOCUMENTCOMPLETE 259
void
DocumentComplete( IDispatch *pDisp, VARIANT *URL )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : DocumentComplete" );


	// [Mechanism]
	//
	//	V_BSTR( url )

N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( URL ) );


	// [x] : buggy : this message will never come when cancel is used in BeforeNavigate2()

	n_felis_on_navigation_end( pDisp );


	return;
}

#define DISPID_DOWNLOADBEGIN 106
void
DownloadBegin( VOID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : DownloadBegin" );

	return;
}

#define DISPID_DOWNLOADCOMPLETE 104
void
DownloadComplete( VOID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : DownloadComplete" );


	// [Needed] : CLSID_InternetExplorer : when a unsupported file is dropped on EXE

	//n_felis_on_navigation_end( NULL );

	ShowWindow( H_STOP, SW_HIDE   );
	ShowWindow( H_LOAD, SW_NORMAL );


	return;
}

#define DISPID_FILEDOWNLOAD 270
void
FileDownload( VARIANT_BOOL *ActiveDocument, VARIANT_BOOL *Cancel )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : FileDownload" );


	return;
}

#define DISPID_FRAMEBEFORENAVIGATE    200
#define DISPID_FRAMENAVIGATECOMPLETE  201
#define DISPID_FRAMENEWWINDOW         204

#define DISPID_NAVIGATECOMPLETE 101
void
NavigateComplete( IDispatch *pDisp, VARIANT *URL )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : NavigateComplete" );


	// [!] : IE4 : never come


	return;
}

#define DISPID_NAVIGATECOMPLETE2 252
void
NavigateComplete2( IDispatch *pDisp, VARIANT *URL )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : NavigateComplete2" );


	// [Mechanism]
	//
	//	V_BSTR( URL )

N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( URL ) );


	return;
}

#define DISPID_NAVIGATEERROR 271
void
NavigateError
(
	IDispatch    *pDisp,
	VARIANT      *URL,
	VARIANT      *TargetFrameName,
	VARIANT      *StatusCode,
	VARIANT_BOOL *Cancel
)
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : NavigateError" );


	// [Mechanism]
	//
	//	V_BSTR( url )
	//	V_BSTR( TargetFrameName )
	//	V_I4( StatusCode )

N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( URL ) );
N_COM_DEBUG_LISTBOX_SET_W( V_BSTR( TargetFrameName ) );


	return;
}

#ifndef _MSC_VER

typedef enum NewProcessCauseConstants {

	ProtectedModeRedirect = 0x1

} NewProcessCauseConstants;

#endif // #ifndef _MSC_VER

#define DISPID_NEWPROCESS 284
void
NewProcess
(      
	long         lCauseFlag,
	IDispatch    *pWB2,
	VARIANT_BOOL *Cancel
)
{
N_COM_DEBUG_LISTBOX_SET_A( "IE8.0 : NewProcess" );


	// [Mechanism] : this method is called when...
	//
	//	"Protected Mode" is ON
	//	CLSID_InternetExplorer is used at CoCreateInstance()
	//
	//	use CLSID_InternetExplorerMedium to solve this problem


	// [x] : Buggy : a new window will appear

	(*Cancel) = VARIANT_TRUE;


	return;
}

#define DISPID_NEWWINDOW 107

#define DISPID_NEWWINDOW2 251
void
NewWindow2( IDispatch **ppDisp, VARIANT_BOOL *Cancel )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : NewWindow2" );


	// [Memo]
	//
	//	*ppDisp has NULL always
	//	IWebBrowser2 still has old URI
	//	the last status text is hovered URI but popup menu interferes
	//	you can patch via n_HTMLDocumentEvents_OnContextMenu()
	//
	//	[ 95 + IE4 ]
	//	anchor can be relative URI like "./file.htm"
	//	anchor also can be DOS path name
	//	CoInternetCombineUrl() will crash


	(*Cancel) = VARIANT_TRUE;

	n_WebBrowser_go( n_felis_wb, n_felis_url_lastset );

/*
	if ( 4 >= n_felis_debug_version( NULL ) )
	{

		return;

	} else {

		(*Cancel) = VARIANT_TRUE;

		BSTR bstr = n_WebBrowser_cursor2anchor( n_felis_wb, H_WB );

		n_WebBrowser_go( n_felis_wb, bstr );

		n_com_bstr_exit( bstr );

	}
*/

	return;
}

#define DISPID_NEWWINDOW3 273
void
NewWindow3
(      
	IDispatch    **ppDisp,
	VARIANT_BOOL  *Cancel,
	DWORD          dwFlags,
	BSTR           bstrUrlContext,
	BSTR           bstrUrl
)
{
N_COM_DEBUG_LISTBOX_SET_A( "IE6.0 : XP SP2 : NewWindow3" );


	// [x] : Buggy : IE8 : this will be ignored

	(*Cancel) = VARIANT_TRUE;


	// [Needed]

	IWebBrowser2_get_Application( n_felis_wb, (void*) ppDisp );


	n_WebBrowser_go( n_felis_wb, bstrUrl );


	return;
}

#define DISPID_ONADDRESSBAR 261
void
OnAddressBar( VARIANT_BOOL Visible )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnAddressBar" );


	// [!] : IWebBrowser2_put_AddressBar(); is called


	return;
}

#define DISPID_ONFULLSCREEN 258
void
OnFullScreen( VARIANT_BOOL FullScreen )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnFullScreen" );


	return;
}

#define DISPID_ONMENUBAR 256
void
OnMenuBar( VARIANT_BOOL MenuBar )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnMenuBar" );


	// [!] : IWebBrowser2_put_MenuBar(); is called


	return;
}

#define DISPID_QUIT   103
#define DISPID_ONQUIT 253
void
OnQuit( VOID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnQuit" );


	// [!] : don't use SendMessage()

	//n_win_message_post( GetParent( H_FRAME ), WM_CLOSE, 0,0 );


	// [!] : IE8 : CLSID_InternetExplorerMedium : local files and cache only

	//n_felis_exit();


	return;
}

#define DISPID_ONSTATUSBAR 257
void
OnStatusBar( VARIANT_BOOL StatusBar )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnStatusBar" );


	// [!] : IWebBrowser2_put_StatusBar(); is called


	return;
}

#define DISPID_ONTHEATERMODE 260
void
OnTheaterMode( VARIANT_BOOL TheaterMode )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnTheaterMode" );


	return;
}

#define DISPID_ONTOOLBAR 255
void
OnToolBar( VARIANT_BOOL ToolBar )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnToolBar" );


	// [!] : IWebBrowser2_put_ToolBar(); is called


	return;
}

#define DISPID_ONVISIBLE 254
void
OnVisible( VARIANT_BOOL Visible )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : OnVisible" );


	return;
}

#define DISPID_PRINTTEMPLATEINSTANTIATION 225
void
PrintTemplateInstantiation( IDispatch *pDisp )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : PrintTemplateInstantiation" );


	// [!] : Print Preview Window turns ON


	return;
}

#define DISPID_PRINTTEMPLATETEARDOWN 226
void
PrintTemplateTeardown( IDispatch *pDisp )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : PrintTemplateTeardown" );


	// [!] : Print Preview Window is closed


	return;
}

#define DISPID_PRIVACYIMPACTEDSTATECHANGE 272
void
PrivacyImpactedStateChange( VARIANT_BOOL PrivacyImpacted )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE6.0 : PrivacyImpactedStateChange" );


	// [!] : "Cookie is blocked" dialog is appeared


	return;
}

#define DISPID_PROGRESSCHANGE 108
void
ProgressChange( long Progress, long ProgressMax )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : ProgressChange" );



	// [x] : flaky : -1 sometimes

	if ( Progress < 0 ) { Progress = 0; }

//n_win_hwndprintf_literal( GetParent( H_FRAME ), " %d / %d ", Progress, ProgressMax );


	return;
}

#define DISPID_PROPERTYCHANGE 112
void
PropertyChange( BSTR szProperty )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : PropertyChange" );

N_COM_DEBUG_LISTBOX_SET_W( szProperty );

	return;
}

#define DISPID_SETPHISHINGFILTERSTATUS 282
void
SetPhishingFilterStatus( long PhishingFilterStatus )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE7.0 : SetPhishingFilterStatus" );


	return;
}

#define DISPID_SETSECURELOCKICON 269
void
SetSecureLockIcon( long SecureLockIcon )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : SetSecureLockIcon" );


	return;
}

#define DISPID_STATUSTEXTCHANGE 102
void
StatusTextChange( BSTR Text )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : StatusTextChange" );

N_COM_DEBUG_LISTBOX_SET_W( Text );


	// [!] : flicker when do SetWindowText() in many times


	// [!] : for Win95 + IE4

	if ( n_win_class_is_same_literal( n_win_cursor2hwnd(), "#32768" ) ) { return; }


	if (
		( n_felis_is_url( L"http:",   Text ) )
		||
		( n_felis_is_url( L"https:",  Text ) )
		||
		( n_felis_is_url( L"ftp:",    Text ) )
		||
		( n_felis_is_url( L"file:",   Text ) )
		||
		( n_felis_is_url( L"about:",  Text ) )
		||
		( n_felis_is_url( L"mailto:", Text ) )
	)
	{

		n_felis_is_hovered = n_true;

		if ( 0 != wcscmp( n_felis_url_hovered, Text ) )
		{
			n_com_bstr_exit( n_felis_url_hovered ); n_felis_url_hovered = SysAllocString( Text );
			n_com_bstr_exit( n_felis_url_lastset ); n_felis_url_lastset = SysAllocString( Text );
			n_felis_url_set( n_felis_url_hovered );
		}

	} else {

		n_felis_is_hovered = n_false;

		if ( 0 != wcscmp( n_felis_url_hovered, n_felis_url_current ) )
		{
			n_com_bstr_exit( n_felis_url_hovered ); n_felis_url_hovered = SysAllocString( n_felis_url_current );
			n_felis_url_set( n_felis_url_current );
		}

	}


	return;
}

#define DISPID_TITLECHANGE 113
void
TitleChange( BSTR Text )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE4.0 : TitleChange" );

N_COM_DEBUG_LISTBOX_SET_W( Text );


	return;
}

//UpdatePageStatus : MSDN says "Not implemented."

#define DISPID_WINDOWCLOSING 263
void
WindowClosing( VARIANT_BOOL IsChildWindow, VARIANT_BOOL *Cancel )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowClosing" );


	//(*Cancel) = VARIANT_TRUE;


	return;
}

#define DISPID_WINDOWSETRESIZABLE 262
void
WindowSetResizable( VARIANT_BOOL Resizable )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetResizable" );


	return;
}

#define DISPID_WINDOWSETLEFT 264
void
WindowSetLeft( long Left )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetLeft" );


	return;
}

#define DISPID_WINDOWSETTOP 265
void
WindowSetTop( long Top )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetTop" );


	return;
}

#define DISPID_WINDOWSETWIDTH 266
void
WindowSetWidth( long Width )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetWidth" );


	return;
}

#define DISPID_WINDOWSETHEIGHT 267
void
WindowSetHeight( long Height )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE5.5 : WindowSetHeight" );


	return;
}

#define DISPID_WINDOWSTATECHANGED 283
void
WindowStateChanged( DWORD dwFlags, DWORD dwValidFlagsMask )
{
N_COM_DEBUG_LISTBOX_SET_A( "IE6.0 : XP SP2 : WindowStateChanged" );

char str[ 100 ];
sprintf( str, "%x : %x", (int) dwFlags, (int) dwValidFlagsMask );
N_COM_DEBUG_LISTBOX_SET_A( str );


	return;
}

HRESULT __stdcall
n_DWebBrowserEvents2_IDispatch_Invoke
(
	void         *_this,
	DISPID        dispIdMember,
	REFIID        riid,
	LCID          lcid,
	WORD          wFlags,
	DISPPARAMS   *pDispParams,
	VARIANT      *pVarResult,
	EXCEPINFO    *pExcepInfo,
	unsigned int *puArgErr
)
{

	// DISPID_* : exdispid.h
	// VARIANT  : oaidl.h

	// IE6 calling sequence
	//
	// 01 : 112 : DISPID_PROPERTYCHANGE
	// 02 : 250 : DISPID_BEFORENAVIGATE2
	// 03 : 106 : DISPID_DOWNLOADBEGIN
	// 04 : 112 : DISPID_PROPERTYCHANGE
	// 05 : 102 : DISPID_STATUSTEXTCHANGE
	// 06 : 108 : DISPID_PROGRESSCHANGE
	// 07 : 102 : DISPID_STATUSTEXTCHANGE
	// 08 : 102 : DISPID_STATUSTEXTCHANGE
	// 09 : 270 : DISPID_FILEDOWNLOAD
	// 10 : 104 : DISPID_DOWNLOADCOMPLETE
	// 11 : 102 : DISPID_STATUSTEXTCHANGE
	// 12 : --- : hang-up when called without WndProc()

/*
	n_com_debug_IDispatch_Invoke
	(
		_this,
		dispIdMember,
		riid,
		lcid,
		wFlags,
		pDispParams,
		pVarResult,
		pExcepInfo,
		puArgErr
	);
*/

	switch( dispIdMember ) {


	case DISPID_BEFORENAVIGATE2 :

		BeforeNavigate2
		(
			pDispParams->rgvarg[6].pdispVal,
			pDispParams->rgvarg[5].pvarVal,
			pDispParams->rgvarg[4].pvarVal,
			pDispParams->rgvarg[3].pvarVal,
			pDispParams->rgvarg[2].pvarVal,
			pDispParams->rgvarg[1].pvarVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_CLIENTTOHOSTWINDOW :

		ClientToHostWindow
		(
			pDispParams->rgvarg[1].plVal,
			pDispParams->rgvarg[0].plVal
		);

	break;

	case DISPID_COMMANDSTATECHANGE :

		CommandStateChange
		(
			pDispParams->rgvarg[1].lVal,
			pDispParams->rgvarg[0].boolVal
		);

	break;

	case DISPID_DOCUMENTCOMPLETE :

		DocumentComplete
		(
			pDispParams->rgvarg[1].pdispVal,
			pDispParams->rgvarg[0].pvarVal
		);

	break;

	case DISPID_DOWNLOADBEGIN :

		DownloadBegin();

	break;

	case DISPID_DOWNLOADCOMPLETE :

		DownloadComplete();

	break;

	case DISPID_FILEDOWNLOAD :

		FileDownload
		(
			pDispParams->rgvarg[1].pboolVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_NAVIGATECOMPLETE :

		NavigateComplete
		(
			pDispParams->rgvarg[1].pdispVal,
			pDispParams->rgvarg[0].pvarVal
		);

	break;

	case DISPID_NAVIGATECOMPLETE2 :

		NavigateComplete2
		(
			pDispParams->rgvarg[1].pdispVal,
			pDispParams->rgvarg[0].pvarVal
		);

	break;

	case DISPID_NAVIGATEERROR :

		NavigateError
		(
			pDispParams->rgvarg[4].pdispVal,
			pDispParams->rgvarg[3].pvarVal,
			pDispParams->rgvarg[2].pvarVal,
			pDispParams->rgvarg[1].pvarVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_NEWPROCESS :

		NewProcess
		(      
			pDispParams->rgvarg[2].lVal,
			pDispParams->rgvarg[1].pdispVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_NEWWINDOW2 :

		NewWindow2
		(
			pDispParams->rgvarg[1].ppdispVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_NEWWINDOW3 :

		NewWindow3
		(
			pDispParams->rgvarg[4].ppdispVal,
			pDispParams->rgvarg[3].pboolVal,
			pDispParams->rgvarg[2].ulVal,
			pDispParams->rgvarg[1].bstrVal,
			pDispParams->rgvarg[0].bstrVal
		);

	break;

	case DISPID_ONADDRESSBAR :

		OnAddressBar( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_ONFULLSCREEN :

		OnFullScreen( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_ONMENUBAR :

		OnMenuBar( pDispParams->rgvarg[0].boolVal );
	break;

	case DISPID_ONQUIT :

		OnQuit();

	break;

	case DISPID_ONSTATUSBAR :

		OnStatusBar( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_ONTHEATERMODE :

		OnTheaterMode( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_ONTOOLBAR :

		OnToolBar( pDispParams->rgvarg[0].boolVal );
	break;

	case DISPID_ONVISIBLE :

		OnVisible( pDispParams->rgvarg[0].boolVal );
	break;

	case DISPID_PRINTTEMPLATEINSTANTIATION :

		PrintTemplateInstantiation( pDispParams->rgvarg[0].pdispVal );

	break;

	case DISPID_PRINTTEMPLATETEARDOWN :

		PrintTemplateTeardown( pDispParams->rgvarg[0].pdispVal );

	break;

	case DISPID_PRIVACYIMPACTEDSTATECHANGE :

		PrivacyImpactedStateChange( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_PROGRESSCHANGE :

		ProgressChange
		(
			pDispParams->rgvarg[1].lVal,
			pDispParams->rgvarg[0].lVal
		);

	break;

	case DISPID_PROPERTYCHANGE :

		PropertyChange( pDispParams->rgvarg[0].bstrVal );

	break;

	case DISPID_SETPHISHINGFILTERSTATUS :

		SetPhishingFilterStatus( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_SETSECURELOCKICON :

		SetSecureLockIcon( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_STATUSTEXTCHANGE :

		StatusTextChange( pDispParams->rgvarg[0].bstrVal );

	break;

	case DISPID_TITLECHANGE :

		TitleChange( pDispParams->rgvarg[0].bstrVal );

	break;

	case DISPID_WINDOWCLOSING :

		WindowClosing
		(
			pDispParams->rgvarg[1].boolVal,
			pDispParams->rgvarg[0].pboolVal
		);

	break;

	case DISPID_WINDOWSETHEIGHT :

		WindowSetHeight( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_WINDOWSETLEFT :

		WindowSetLeft( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_WINDOWSETRESIZABLE :

		WindowSetResizable( pDispParams->rgvarg[0].boolVal );

	break;

	case DISPID_WINDOWSETTOP :

		WindowSetTop( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_WINDOWSETWIDTH :

		WindowSetWidth( pDispParams->rgvarg[0].lVal );

	break;

	case DISPID_WINDOWSTATECHANGED :

		WindowStateChanged
		(
			pDispParams->rgvarg[1].ulVal,
			pDispParams->rgvarg[0].ulVal
		);

	break;


	default :
N_COM_DEBUG_LISTBOX_SET_A( "DISP_E_MEMBERNOTFOUND" );

//n_posix_debug_literal( "%08x : %d", dispIdMember, dispIdMember );


		return DISP_E_MEMBERNOTFOUND;

	break;


	} // switch

/*
	// [x] : stop while wheeling

	if ( n_felis_progress_start )
	{
		//RECT rect; GetClientRect( H_URL, &rect );
		//n_felis_addressbar_draw( H_URL, &rect );

		n_felis_addressbar_proc( NULL, WM_TIMER, n_felis_progress_timer_id, 0, H_URL );
	}
*/

	return S_OK;
}




const void *n_DWebBrowserEvents2_Vtbl[] = {

	n_DWebBrowserEvents2_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,
	n_com_IDispatch_GetTypeInfoCount,
	n_com_IDispatch_GetTypeInfo,
	n_com_IDispatch_GetIDsOfNames,
	n_DWebBrowserEvents2_IDispatch_Invoke

};


DWebBrowserEvents2 n_DWebBrowserEvents2_instance = { (void*) n_DWebBrowserEvents2_Vtbl };




#endif // _H_NONNON_WIN32_COM_DWEBBROWSEREVENTS2

