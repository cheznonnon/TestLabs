// Felis
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#ifndef N_COM_DEBUG_ONOFF


#define n_felis_debug_gui( a, b )


#else // #ifndef N_COM_DEBUG_ONOFF


LRESULT CALLBACK
n_felis_debug_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Debug", "", "" );

		n_project_window_resizable( hwnd );


		{

		s32 sx,sy; n_win_desktop_size( &sx, &sy );
		sx /= 4;

		n_win w; w.posx = w.posy = 0;
		n_win_set( hwnd, NULL, sx,sy, N_WIN_SET_NEEDPOS | N_WIN_SET_CLIPPING );

		n_com_debug_listbox_init( hwnd );
		n_win_move_simple( n_com_debug_listbox_hwnd, 0,0,sx,sy, n_true );

		}


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		n_win w;
		n_win_set( hwnd, &w, -1,-1, n_project_n_win_set() );
		n_win_move_simple( n_com_debug_listbox_hwnd, 0,0,w.csx,w.csy, n_true );

	}
	break;


	case WM_CLOSE :

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_felis_debug_gui( HWND hwnd, HWND *hwnd_child )
{

	n_win_gui( hwnd, WINDOW, n_felis_debug_wndproc, hwnd_child );


	return;
}


#endif // #ifndef N_COM_DEBUG_ONOFF

