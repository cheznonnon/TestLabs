// Nonnon INI2WAV
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../neutral/ini.c"
#include "../neutral/path.c"

#include "../neutral/wav/all.c"




#define N_INI2WAV_MAXCOUNT ( 32 )

typedef struct {

	n_posix_char path[ N_PATH_MAX ];
	n_wav        wav;
	int          l;
	int          r;
	int          offset;
	n_posix_char resample[ N_PATH_MAX ];
	double       resample_ratio;

} n_ini2wav_track;




n_posix_bool
n_ini2wav_load( const n_posix_char *abspath, n_wav *wav )
{

	if ( n_posix_false == n_posix_stat_is_file( abspath ) ) { return n_posix_true; }

	if ( wav == NULL ) { return n_posix_true; }


	const n_posix_char *section = n_posix_literal( "Nonnon INI2WAV" );


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, abspath );


	n_ini2wav_track track[ N_INI2WAV_MAXCOUNT ];
	n_memory_zero( track, sizeof( n_ini2wav_track ) * N_INI2WAV_MAXCOUNT );


	n_posix_char curdir[ N_PATH_MAX ]; n_path_getcwd( curdir ); n_path_chdir( abspath );


	u32 msec  = 0;
	int count = 0;
	while( 1 )
	{

		n_ini2wav_track *p = &track[ count ];


		n_posix_char sect[ N_PATH_MAX ]; n_posix_sprintf_literal( sect, "%s.%d", section, count );


		n_ini_value_str( &ini, sect, n_posix_literal( "Path" ), N_STRING_EMPTY, p->path, N_PATH_MAX );

		if ( n_wav_load( &p->wav, p->path ) ) { break; }


		p->l        = n_ini_value_int( &ini, sect, n_posix_literal( "L"         ), 0 );
		p->r        = n_ini_value_int( &ini, sect, n_posix_literal( "R"         ), 0 );
		p->offset   = n_ini_value_int( &ini, sect, n_posix_literal( "Offset"    ), 0 );

		n_ini_value_str( &ini, sect, n_posix_literal( "Resample" ), N_STRING_EMPTY, p->resample, N_PATH_MAX );
		p->resample_ratio = n_string_str2double( p->resample );

		double ms = N_WAV_MSEC( &p->wav );

		// [!] : don't shrink
		if ( p->resample_ratio != 0.0 ) { ms = n_posix_max_double( ms, ms * p->resample_ratio ); }

		msec = (u32) n_posix_max_double( msec, ms );


		count++;
		if ( count >= N_INI2WAV_MAXCOUNT ) { break; }
	}


	if ( count != 0 )
	{

		n_wav_free( wav ); n_wav_new( wav, msec );

		int i = 0;
		while( 1 )
		{

			n_ini2wav_track *p = &track[ i ];

/*
n_posix_debug_literal
(
	" Track    : %d    \n "
	" LR       : %d %d \n "
	" Offset   : %d    \n "
	" Resample : %f    \n "
	" Error    : %d    \n "
	"",
	i,
	p->l, p->r,
	p->offset,
	p->resample_ratio,
	n_wav_tool_error( &p->wav )
);
*/

			if ( p->resample_ratio != 0.0 )
			{

				n_wav w; n_wav_zero( &w ); n_wav_new( &w, msec );

				n_wav_resampler( &p->wav, &w, p->resample_ratio );

				n_wav_free( &p->wav );
				n_wav_alias( &w, &p->wav );

			}

			double l = (double) p->l * 0.01;
			double r = (double) p->r * 0.01;
			double o = (double) N_WAV_RATE( &p->wav ) / 1000.0 * p->offset;

			n_wav_copy( &p->wav, wav, 0, 0, (int) o, l,r, N_WAV_COPY_ADD );
//n_posix_char name[ 1024 ]; n_posix_sprintf_literal( name, "%d.wav", i );
//n_wav_save( &p->wav, name );

			n_wav_free( &p->wav );


			i++;
			if ( i >= count ) { break; }

		}

	}


	n_path_chdir( curdir );


	n_ini_free( &ini );


	return ( count == 0 );
}

n_posix_bool
n_ini2wav_iotest( n_posix_char *cmdline )
{

	n_wav wav; n_wav_zero( &wav );

	if ( n_ini2wav_load( cmdline, &wav ) )
	{
n_posix_debug_literal( " n_ini2wav_load() " );
		return n_posix_true;
	}

	n_wav_save_literal( &wav, "result.wav" );

	n_wav_free( &wav );


	return n_posix_false;
}

