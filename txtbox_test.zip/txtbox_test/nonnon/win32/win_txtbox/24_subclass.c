// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_caret_on_timer( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }
//if ( p->hwnd == GetFocus() ) { n_win_txtbox_debug_count( p ); }


	n_win_txtbox_metrics_caret( p );


	if ( p->hwnd != GetFocus() ) { return; }


	// [!] : Slow Mode

	//n_win_txtbox_draw( p, N_WIN_TXTBOX_CARET_ON_TIMER );
	//return;


	// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_y, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->caret_pxl_x, p->caret_pxl_y );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_min_onoff, p->partial_selection_max_onoff );

	if ( ( p->partial_selection_min_onoff )||( p->partial_selection_max_onoff ) )
	{
		n_win_txtbox_draw_selection( p, N_WIN_TXTBOX_CARET_ON_TIMER );
	} else
	if ( p->prv_caret == p->caret_pxl_y )
	{
		p->caret_only = n_posix_true;

		n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_CARET_ON_TIMER, p->select_cch_y, p->select_cch_sy );

		p->caret_only = n_posix_false;
	} else {
//n_win_txtbox_debug_count( p );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_x, p->select_cch_x );

		//p->typing_only = n_posix_true;

		//n_win_txtbox_draw( p, N_WIN_TXTBOX_CARET_ON_TIMER );

		//p->typing_only = n_posix_false;
	}

	p->prv_caret = p->caret_pxl_y;


	return;
}

void
n_win_txtbox_on_focus( n_win_txtbox *p, UINT msg, n_posix_bool is_set )
{

	if ( p == NULL ) { return; }


	//p->focus_fade_msg = msg;


	if (
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		||
		( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
		||
		( n_posix_false == n_win_fade_is_on() )
	)
	{
		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );

		n_win_txtbox_caret_on_timer( p );
		n_win_txtbox_caret_reset( p, n_posix_false );

		n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_TIMER );

		return;
	}


	n_bmp_free( &p->focus_fade_bmp_old );
	n_bmp_free( &p->focus_fade_bmp_new );



	p->bitblt_stop         = n_posix_true;
	p->optimization_stop   = n_posix_true;
	p->focus_fade_override = n_posix_true;


	s32 sel_sx = p->select_cch_sx; p->select_cch_sx = p->focus_fade_prv_sel_sx;

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->focus_fade_prv_sel_sx );

	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_GRAY_ON )
	{
		p->color_back_noselect = p->color_back_disabled;
	} else
	if ( p->grayed_onoff )
	{
		if ( p->is_grayed == n_posix_false )
		{
			p->color_back_noselect = p->color_back_disabled;
		} else {
			p->color_back_noselect = p->color_back__enabled;
		}
	}

	if ( p->style_option & N_WIN_TXTBOX_OPTION_USE_INPUT_POPUP )
	{
		//
	} else {
		p->focus_fade_override_bool = ( is_set == n_posix_false );
		n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_TIMER );
	}

	n_bmp_carboncopy( &p->bmp, &p->focus_fade_bmp_old );

	p->select_cch_sx = sel_sx;


	n_win_txtbox_caret_on_timer( p );
	n_win_txtbox_caret_reset( p, n_posix_false );
	n_win_txtbox_caret_onoff( p, n_posix_false );


	p->focus_fade_override_bool = is_set;

	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_GRAY_ON )
	{
		p->color_back_noselect = p->color_back_disabled;
	} else
	if ( p->grayed_onoff )
	{
		if ( p->is_grayed )
		{
			p->color_back_noselect = p->color_back_disabled;
		} else {
			p->color_back_noselect = p->color_back__enabled;
		}
	}

	n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_TIMER );
	n_bmp_carboncopy( &p->bmp, &p->focus_fade_bmp_new );


	p->focus_fade_override = n_posix_false;
	p->optimization_stop   = n_posix_false;
	//p->bitblt_stop         = n_posix_false; // [!] : delayed : see WM_TIMER


	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		//
	} else {
		n_bmp_alpha_visible( &p->focus_fade_bmp_old );
		n_bmp_alpha_visible( &p->focus_fade_bmp_new );
	}

/*
if ( n_win_is_input( VK_F2 ) )
{
	n_bmp_save_literal( &p->focus_fade_bmp_old, "old.bmp" );
	n_bmp_save_literal( &p->focus_fade_bmp_new, "new.bmp" );
}
*/

	if ( p->focus_fade_timer == 0 ) { p->focus_fade_timer = n_win_timer_id_get(); }
	n_win_timer_init( p->hwnd, p->focus_fade_timer, 16 );


	return;
}

// internal
LRESULT CALLBACK
#ifdef _WIN64
n_win_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	n_win_txtbox *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }
#else  // #ifdef _WIN64
	n_win_txtbox *p = (void*) n_win_property_get( hwnd, N_WIN_TXTBOX_NAMESPACE );
	if ( p == NULL ) { return 0; }
#endif // #ifdef _WIN64


	static HWND hwnd_focus = NULL;


	switch( msg ) {


	case 648 : // WM_IME_REQUEST
	{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_REQUEST : %d %x ", wparam, lparam );

		if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }
		if ( p->txt.readonly ) { break; }

		if ( wparam == IMR_RECONVERTSTRING )
		{

			if ( n_posix_false == n_win_txtbox_is_selected( p ) ) { break; }


			// [Needed] : crash prevention

			if ( p->select_cch_sy > 1 )
			{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_REQUEST : %d %d ", p->partial_selection_min_onoff, p->partial_selection_max_onoff );

				n_posix_bool min_onoff = p->partial_selection_min_onoff;
				//n_posix_bool max_onoff = p->partial_selection_max_onoff;

				n_win_txtbox_unselect( p );

				if ( min_onoff ) { p->select_cch_y--; }
				//if ( max_onoff ) { p->select_cch_y++; }

				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_IME_REQUEST );

				break;
			}


			n_posix_char *line     = n_txt_get( &p->txt, p->select_cch_y );
			n_posix_char *word     = n_string_carboncopy( &line[ p->select_cch_x ] );

			if ( p->select_cch_sx ) { n_string_terminate( word, p->select_cch_sx ); }

			s32           word_cch = n_posix_strlen( word ) + 1;
			s32           word_cb  = sizeof( n_posix_char    ) * word_cch;
			s32           rcnv_cb  = sizeof( RECONVERTSTRING );
			u8           *data     = (void*) lparam;
			LRESULT       lret     = rcnv_cb + word_cb;

			if ( data != NULL )
			{

				RECONVERTSTRING rcs = { rcnv_cb, 0, word_cch,rcnv_cb, word_cch,0, word_cch,0, };
				s32             i   = 0;

				n_memory_copy( &rcs, &data[ i ], rcnv_cb ); i += rcnv_cb;
				n_memory_copy( word, &data[ i ], word_cb ); i += word_cb;

				n_win_message_send( hwnd, WM_IME_COMPOSITION, 0,0 );

				lret = (LRESULT) data;

			}

			n_memory_free( word );
			return lret;

		} else
		if ( wparam == 0x0005 ) // IMR_CONFIRMRECONVERTSTRING
		{

			// [!] : never sent

		} else
		if ( wparam == 0x0006 ) // IMR_QUERYCHARPOSITION
		{
//n_posix_debug_literal( " ! " );

			IMECHARPOSITION *icp = (void*) lparam;
			if ( icp == NULL ) { return n_posix_false; }

			RECT            rect; n_win_rect_set( &rect, 0,0,0,0 );
			POINT           pt   = { p->ime.x, p->ime.y }; ClientToScreen( hwnd, &pt );
			IMECHARPOSITION ret  = { sizeof( IMECHARPOSITION ), 0, pt, p->cell_pxl_sy, rect };
			*icp = ret;

			return n_posix_true;

		}

	}
	break;

	case WM_IME_STARTCOMPOSITION :

		p->ime_composition_onoff = n_posix_true;

	case WM_IME_COMPOSITION :
	{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_COMPOSITION : %d %x ", wparam, lparam );

		if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }
		if ( p->txt.readonly ) { break; }

		// [!] : this message can replace WM_IME_STARTCOMPOSITION and WM_IME_ENDCOMPOSITION

		// [ Mechanism ]
		//
		//	0x01b9 : Start
		//	0x1e00 : End
		//	0x1fb9 : Auto-Confirmation : End + Start

		const int start = GCS_DELTASTART | GCS_CURSORPOS | GCS_COMPCLAUSE | GCS_COMPATTR | GCS_COMPSTR | GCS_COMPREADSTR;
		const int end   = GCS_RESULTCLAUSE | GCS_RESULTSTR | GCS_RESULTREADCLAUSE | GCS_RESULTREADSTR;

		HIMC himc = ImmGetContext( hwnd );

		if ( lparam & end )
		{

			// [ Mechanism ] : ImmGetCompositionString()
			//
			//	this API doesn't write "\0"
			//
			//	return value will always be DBCS unit
			//	an ASCII character will be 1
			//	a  kanji character will be 2

			s32           n = ImmGetCompositionString( himc, GCS_RESULTSTR, NULL, 0 );
			n_posix_char *s = n_string_new( n * 4 );
			if ( s == NULL ) { break; }

			ImmGetCompositionString( himc, GCS_RESULTSTR, s, n );

//n_win_txtbox_hwndprintf_literal( p, " %s : %d", s, n );

			if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ) )
			{
				n_posix_bool ret = n_win_txtbox_filename_is_safe( s );
				if ( ret == n_posix_false ) { n_memory_free( s ); break; }
			}

			if ( p->txt.readonly == n_posix_false )
			{

				n_win_txtbox_previous( p );

				n_win_txtbox_selection_cat( p, s );

//n_win_txtbox_hwndprintf_literal( p, " 1 " );
				s32 y,sy; n_win_txtbox_previous_calc( p, &y, &sy );
				n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_IME_COMPOSITION, y, sy );

			}

			n_memory_free( s );

			n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );

		}

		if ( ( lparam == 0 )||( lparam & start ) )
		{

			LOGFONT lf = n_win_font_hwnd2logfont( p->hwnd );
			ImmSetCompositionFont( himc, &lf );

			COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, p->ime, { 0,0,0,0 } };
			ImmSetCompositionWindow( himc, &cf );

		}

		ImmReleaseContext( hwnd, himc );


		// [!] : you cannot stop this message while fading : IME misbehaves

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->ime_fade_is_running, p->ime_onoff, n_win_ime_is_on( p->hwnd ) );

		if ( p->ime_fade_is_running )
		{
			p->bitblt_stop = n_posix_true;
			n_win_txtbox_draw( p, N_WIN_TXTBOX_IME_FADE );
			p->bitblt_stop = n_posix_false;

			n_bmp_free( &p->ime_fade_bmp_new );
			n_bmp_carboncopy( &p->bmp, &p->ime_fade_bmp_new );
		}

	}
	break;

	case WM_IME_ENDCOMPOSITION :

		p->ime_composition_onoff = n_posix_false;

	break;

	case WM_IME_NOTIFY :

		if ( wparam == IMN_SETOPENSTATUS )
		{
//n_win_txtbox_debug_count( p );

/*
			// [!] : Fade OFF

			p->ime_onoff = n_win_ime_is_on( p->hwnd );

			n_win_txtbox_ime_watch_color( p );

			n_win_txtbox_on_setcursor( p );
			n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );

			n_win_txtbox_draw( p, N_WIN_TXTBOX_IME_FADE );

			break;
*/

			// [!] : Fade ON

			n_win_txtbox_caret_onoff( p, n_posix_false );

			n_posix_bool prv_onoff = p->ime_onoff;
			n_posix_bool cur_onoff = n_win_ime_is_on( p->hwnd );

			if ( cur_onoff ) { prv_onoff = n_posix_false; } else { prv_onoff = n_posix_true; }
//n_win_txtbox_hwndprintf_literal( p, " %d : %d ", prv_onoff, cur_onoff );


			//if ( 0 )
			{
				p->bitblt_stop = n_posix_true;
				p->ime_onoff   = prv_onoff;
				n_win_txtbox_draw( p, N_WIN_TXTBOX_IME_FADE );
				p->bitblt_stop = n_posix_false;

				n_bmp_free( &p->ime_fade_bmp_old );
				n_bmp_carboncopy( &p->bmp, &p->ime_fade_bmp_old );
//n_bmp_flush( &p->ime_fade_bmp_old, n_bmp_rgb( 0,100,200 ) );

//if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) ) { n_bmp_save_literal( &p->ime_fade_bmp_old, "old.bmp" ); }
			}


			p->ime_onoff = cur_onoff;
			n_win_txtbox_ime_watch_color( p );

			n_win_txtbox_on_setcursor( p );
			n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );

			p->bitblt_stop = n_posix_true;
			n_win_txtbox_draw( p, N_WIN_TXTBOX_IME_FADE );
			p->bitblt_stop = n_posix_false;


			//if ( 0 )
			{
				n_bmp_free( &p->ime_fade_bmp_new );
				n_bmp_carboncopy( &p->bmp, &p->ime_fade_bmp_new );
//n_bmp_flush( &p->ime_fade_bmp_new, n_bmp_rgb( 0,200,255 ) );

//if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) ) { n_bmp_save_literal( &p->ime_fade_bmp_new, "new.bmp" ); }
			}


			p->ime_fade_is_running = n_posix_true;

			if ( p->ime_fade_timer == 0 ) { p->ime_fade_timer = n_win_timer_id_get(); }
			n_win_timer_init( p->hwnd, p->ime_fade_timer, 16 );

		}

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;


	case WM_SIZE :

		n_win_txtbox_metrics_canvas( p );

		n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_SIZE );

	break;


	case WM_TIMER :
//n_win_txtbox_debug_count( p );
//break;

		if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }


		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == p->caret_timer )
		{
//break;

//n_win_txtbox_debug_count( p );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->caret_timer );

			n_win_txtbox_caret_on_timer( p );

		} else
		if ( wparam == p->input_timer )
		{
//break;
			n_win_timer_exit( p->hwnd, p->input_timer );

			if ( p->txt.readonly ) { break; }

			p->input_onoff = n_posix_false;

		} else
		if ( wparam == p->ime_fade_timer )
		{
//break;
			if ( p->ime_fade_percent == 0 )
			{
				p->         bmp    .transparent_onoff = n_posix_false;
				p->ime_fade_bmp_old.transparent_onoff = n_posix_false;
				p->ime_fade_bmp_new.transparent_onoff = n_posix_false;
//n_bmp_flush( &p->ime_fade_bmp_old, n_bmp_rgb( 0,200,255 ) );
//n_bmp_flush( &p->ime_fade_bmp_new, n_bmp_rgb( 0,200,255 ) );
			}

			n_posix_bool ret = n_game_transition
			(
				&p->bmp,
				&p->ime_fade_bmp_old,
				&p->ime_fade_bmp_new,
				N_BMP_FADE_MSEC,
				&p->ime_fade_percent,
				//N_GAME_TRANSITION_WIPE_X
				N_GAME_TRANSITION_FADE
			);

			n_bmp_alpha_visible( &p->bmp );

			n_win_txtbox_draw_sync( p );

			if ( ret )
			{
				n_win_timer_exit( p->hwnd, p->ime_fade_timer );

				n_bmp_free( &p->ime_fade_bmp_old );
				n_bmp_free( &p->ime_fade_bmp_new );

				p->ime_fade_is_running = n_posix_false;

				n_win_txtbox_caret_onoff( p, n_posix_true );
			}

		} else
		if ( wparam == p->focus_fade_timer )
		{

			if ( p->focus_fade_percent == 0 )
			{
				p->           bmp    .transparent_onoff = n_posix_false;
				p->focus_fade_bmp_old.transparent_onoff = n_posix_false;
				p->focus_fade_bmp_new.transparent_onoff = n_posix_false;
			}
//n_win_txtbox_hwndprintf_literal( p, " %d ", (int) p->focus_fade_percent );

			n_posix_bool ret = n_game_transition
			(
				&p->bmp,
				&p->focus_fade_bmp_old,
				&p->focus_fade_bmp_new,
				N_BMP_FADE_MSEC,
				&p->focus_fade_percent,
				N_GAME_TRANSITION_FADE
			);

			n_win_txtbox_draw_sync( p );

			if ( ret )
			{
				n_win_timer_exit( p->hwnd, p->focus_fade_timer );

				n_bmp_free( &p->focus_fade_bmp_old );
				n_bmp_free( &p->focus_fade_bmp_new );

				p->bitblt_stop = n_posix_false;

				//n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, p->focus_fade_msg, p->hwnd );

				n_win_txtbox_caret_onoff( p, n_posix_true );
			}

		} else
		if ( wparam == p->smallbutton_timer )
		{

			n_win_txtbox_smallbutton_refresh( p );

		}

	break;


	case WM_SETFOCUS :
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->ime_onoff );
//n_win_txtbox_debug_count( p );
//break;

		hwnd_focus = p->hwnd;

//n_win_txtbox_hwndprintf_literal( p, " SET %x %x %x ", hwnd_focus, GetFocus(), wparam );


		p->ime_onoff = n_win_ime_is_on( p->hwnd );

		if ( p->ime_onoff )
		{

			HIMC himc = ImmGetContext( hwnd );

			COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, p->ime, { 0,0,0,0 } };
			ImmSetCompositionWindow( himc, &cf );

			ImmReleaseContext( hwnd, himc );

		}


		//if ( p->style & N_WIN_TXTBOX_STYLE_DELAYED )
		{
			p->focus_phase = N_WIN_TXTBOX_FOCUS_WAIT;
		}


//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_sx, p->select_cch_sx );

		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );

		n_win_txtbox_on_focus( p, msg, n_posix_true );

		n_win_txtbox_caret_onoff( p, n_posix_true );

	break;

	case WM_KILLFOCUS :

//n_win_txtbox_hwndprintf_literal( p, " KILL %x %x %x ", hwnd_focus, GetFocus(), wparam );


		//if ( p->style & N_WIN_TXTBOX_STYLE_DELAYED )
		{
			p->focus_phase = N_WIN_TXTBOX_FOCUS_NONE;
		}


		if ( p->style_option & N_WIN_TXTBOX_OPTION_USE_INPUT_POPUP )
		{

			HWND hwnd_rel = n_win_cursor2hwnd_relative( hwnd );
//n_win_txtbox_hwndprintf_literal( p, " KILL %x %x ", hwnd_focus, hwnd_rel );

			if ( hwnd_focus == hwnd_rel ) { break; }

			HWND hwnd_pop = GetParent( n_win_cursor2hwnd() );
//n_win_txtbox_hwndprintf_literal( p, " KILL %x %x %x ", hwnd_focus, hwnd_pop, wparam );

			if ( ( hwnd_rel == NULL )&&( hwnd_pop == (HWND) wparam ) ) { break; }

		}


		p->focus_fade_prv_sel_sx = p->select_cch_sx;

		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );

		n_win_txtbox_on_focus( p, msg, n_posix_false );

		n_win_txtbox_caret_onoff( p, n_posix_false );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == p->hscr.hwnd )
		{

			s32 prv = p->scroll_pxl_tabbed_x;

			p->scroll_pxl_tabbed_x = wparam;

			if ( p->is_font_monospace )
			{
				p->scroll_pxl_tabbed_x = p->scroll_pxl_tabbed_x / p->font_pxl_sx * p->font_pxl_sx;
			}

			if ( prv != p->scroll_pxl_tabbed_x )
			{
				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_COMMAND );
				n_win_scrollbar_draw_always( &p->hscr, n_posix_true );
			}

		} else
		if ( (HWND) lparam == p->vscr.hwnd )
		{
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.pixel_shaft, p->vscr.pixel_thumb );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", fmod( p->vscr.pixel_shaft, p->vscr.pixel_thumb ) / p->vscr.pixel_thumb, p->vscr.pixel_modulo );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.pixel_pos, p->vscr.unit_pos );
//n_win_txtbox_hwndprintf_literal( p, " %d : %d ", wparam, p->vscr.pressed_thumb );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_step );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_arrow );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.base_page / p->vscr.base_max, p->vscr.base_max );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_step );

//double d = ( p->vscr.pixel_max / p->vscr.pixel_page ) - ( p->vscr.pixel_max / p->vscr.pixel_thumb );
//n_win_txtbox_hwndprintf_literal( p, " %f ", d / p->vscr.pixel_max );

//double pixel_last = n_win_scrollbar_pixel_last( &p->vscr );
//n_win_txtbox_hwndprintf_literal( p, " %g %g ", pixel_last, p->vscr.pixel_pos );

			s32 prv = p->scroll_cch_tabbed_y;

			p->scroll_cch_tabbed_y = wparam / n_posix_max( 1, p->cell_pxl_sy );

			if ( prv != p->scroll_cch_tabbed_y )
			{
				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_COMMAND );
				n_win_scrollbar_draw_always( &p->vscr, n_posix_true );
			}

		}

	break;


	case WM_KEYUP :
//n_win_txtbox_debug_count( p );

		if ( n_win_simplemenu_target != NULL ) { break; }

		if ( n_win_is_input( VK_LBUTTON ) ) { break; }
		if ( n_win_is_input( VK_MBUTTON ) ) { break; }
		if ( n_win_is_input( VK_RBUTTON ) ) { break; }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			p->vk_key = 0;

			int vk = wparam;

			if ( vk == VK_SHIFT )
			{
				p->shift_dragging_start_x     = N_WIN_TXTBOX_NOT_SELECTED;
				p->shift_dragging_start_pxl_x = 0;
			}

		}


		n_win_timer_init( p->hwnd, p->input_timer, p->input_msec );

	break;

	case WM_KEYDOWN :
	{
//n_win_txtbox_debug_count( p );

//n_win_txtbox_hwndprintf_literal( p, " %d %x ", wparam, wparam );
//break;

		n_win_txtbox_caret_reset( p, n_posix_true );


		p->is_ud = p->is_lr = 0;


		if ( wparam == VK_F1  ) { break; }
		if ( wparam == VK_F2  ) { break; }
		if ( wparam == VK_F3  ) { break; }
		if ( wparam == VK_F4  ) { break; }
		if ( wparam == VK_F5  ) { break; }
		if ( wparam == VK_F6  ) { break; }
		if ( wparam == VK_F7  ) { break; }
		if ( wparam == VK_F8  ) { break; }
		if ( wparam == VK_F9  ) { break; }
		if ( wparam == VK_F10 ) { break; }
		if ( wparam == VK_F11 ) { break; }
		if ( wparam == VK_F12 ) { break; }

		// [!] : IME on/off : not VK_KANJI : VK_PROCESSKEY is 229 (0xE5)
		if ( wparam == VK_PROCESSKEY ) { break; }


		if ( n_win_simplemenu_target != NULL ) { break; }

		if ( n_win_is_input( VK_LBUTTON ) ) { break; }
		if ( n_win_is_input( VK_MBUTTON ) ) { break; }
		if ( n_win_is_input( VK_RBUTTON ) ) { break; }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			int vk = wparam;


			p->vk_key = vk;


			if ( vk == VK_SHIFT )
			{
				if ( p->shift_dragging_start_x == N_WIN_TXTBOX_NOT_SELECTED )
				{
					p->shift_dragging_start_x     = p->select_cch_x;
					p->shift_dragging_start_pxl_x = p->ime.x;
				}
			}


			// [Needed] : see WM_LBUTTONDOWN
			if ( vk == VK_SHIFT ) { break; }


			n_win_txtbox_previous( p );


			if ( vk == VK_UP )
			{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d ", p->select_cch_y );

				if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }


				n_posix_bool debug_output = n_posix_false;
				n_posix_bool debug_detail = n_posix_false;


				if ( n_win_is_input( VK_SHIFT ) )
				{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT " ); }

					p->shift_dragging = VK_UP;

					if ( ( p->partial_selection_min_onoff )||( p->partial_selection_max_onoff ) )
					{

						s32  x = p->select_cch_x;
						s32  y = p->select_cch_y;
						s32 sx = p->select_cch_sx;
						s32 sy = p->select_cch_sy;

						if ( p->partial_selection_min_onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : min " ); }

							sy--;
//n_win_txtbox_hwndprintf_literal( p, " %d ", sy );
							if ( sy == 0 )
							{

								n_win_txtbox_unselect( p );

								p->partial_selection_min_onoff = n_posix_false;
								p->partial_selection_max_onoff = n_posix_false;

							} else {
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_min_onoff, p->partial_selection_max_onoff );

								s32 target_y = y + sy - 1;
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", target_y, n_txt_get( &p->txt, target_y ) );

								 x = p->partial_selection_max_cch_x = n_win_txtbox_select_up( p, p->partial_selection_max_cch_x,target_y + 1 );
								sx = N_WIN_TXTBOX_ALL;

								n_win_txtbox_select( p, x,y,sx,sy );

								if ( sy == 1 )
								{
									p->partial_selection_min_onoff = n_posix_false;
								}

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", ( y + sy ), p->scroll_cch_tabbed_y );
								if ( ( y + sy - 1 ) <= p->scroll_cch_tabbed_y )
								{
									n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y - 1 );
								}

							}

						} else
						if ( p->partial_selection_max_onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : max " ); }

							if ( y == 0 ) { break; }

							if ( y > 0 )
							{
								y--;
								sy++;
							}

							 x = p->partial_selection_min_cch_x = n_win_txtbox_select_up( p, x,y+1 );
							sx = N_WIN_TXTBOX_ALL;

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", x, y, sx, sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_min_cch_x, p->partial_selection_max_cch_x );

							n_win_txtbox_select( p, x,y,sx,sy );

						}

					} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : else " ); }

						// [Needed] : don't use n_win_txtbox_drag_select2drag()
						//
						//	a caret will disappear

//n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : else : %d ", p->select_cch_y );

						if ( p->select_cch_y == 0 )
						{
							n_win_txtbox_unselect( p );

							p->partial_selection_min_onoff = n_posix_false;
							p->partial_selection_max_onoff = n_posix_false;
						} else
						if ( p->select_cch_y != 0 )
						{
							s32 target_x = p->select_cch_x + p->select_cch_sx;

							s32  x = n_win_txtbox_select_up( p, target_x, p->select_cch_y );
							s32 sx = N_WIN_TXTBOX_ALL;
							s32  y = p->select_cch_y  - 1;
							s32 sy = p->select_cch_sy + 1;
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", x, n_txt_get( &p->txt, p->select_cch_y ) );

							p->partial_selection_min_onoff = n_posix_false;
							p->partial_selection_max_onoff = n_posix_true;
							p->partial_selection_min_cch_x = x;
							p->partial_selection_max_cch_x = target_x;
//n_win_txtbox_hwndprintf_literal( p, " %d ", target_x );

							//n_win_txtbox_unselect( p );
							n_win_txtbox_select( p, x,y,sx,sy );
							//n_win_txtbox_drag_select2drag( p );
						}

					}

				} else {
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : else " ); }

					if ( ( p->partial_selection_min_onoff )||( p->partial_selection_max_onoff ) )
					{

						s32 x = 0;
						s32 y = 0;

						if ( p->partial_selection_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : Min " );
							x = p->partial_selection_max_cch_x;
							y = p->select_cch_y + p->select_cch_sy - 1;
						} else
						if ( p->partial_selection_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : Max " );
							x = p->partial_selection_min_cch_x;
							y = p->select_cch_y;
						}

						n_win_txtbox_unselect( p );
						x = n_win_txtbox_select_up( p, x,y );
						n_win_txtbox_select( p, x, y - 1, 0, 1 );

					} else {

						// [!] : n_win_txtbox_unselect() rewrites some members

						s32 x = p->select_cch_x;
						if ( n_win_txtbox_is_caret_tail( p ) )
						{
							x += p->select_cch_sx;
						}

						n_win_txtbox_unselect( p );

						if ( p->select_cch_y > 0 )
						{
							x = n_win_txtbox_select_up( p, x, p->select_cch_y );
							n_win_txtbox_select( p, x, p->select_cch_y - 1, 0, 1 );
						}

					}

				}

//n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d ", p->shift_dragging );

				if ( p->shift_dragging == 0 ) { p->is_ud = n_posix_true; }

			} else
			if ( vk == VK_DOWN )
			{

				if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }


				n_posix_bool debug_output = n_posix_false;
				n_posix_bool debug_detail = n_posix_false;


				if ( n_win_is_input( VK_SHIFT ) )
				{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT " ); }

					p->shift_dragging = VK_DOWN;

					if ( ( p->partial_selection_min_onoff )||( p->partial_selection_max_onoff ) )
					{

						s32  x = p->select_cch_x;
						s32  y = p->select_cch_y;
						s32 sx = p->select_cch_sx;
						s32 sy = p->select_cch_sy;

						if ( p->partial_selection_min_onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT : min " ); }

							sy++;
//n_win_txtbox_hwndprintf_literal( p, " %d ", sy );
							if ( ( y + sy ) > p->txt.sy )
							{

								n_win_txtbox_select( p, x,y,sx,sy );

							} else {

								s32 target_y = y + sy - 1;
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", target_y, n_txt_get( &p->txt, target_y ) );

								 x = p->partial_selection_max_cch_x = n_win_txtbox_select_down( p, p->partial_selection_max_cch_x,target_y - 1 );
								sx = N_WIN_TXTBOX_ALL;

								p->is_caret_tail = n_posix_false;

								n_win_txtbox_select( p, x,y,sx,sy );

								if ( sy == 1 )
								{
									//p->partial_selection_min_onoff = n_posix_false;
								}

								if ( ( y + sy ) > ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) )
								{
//n_win_txtbox_hwndprintf_literal( p, " Autoscroll On  : %d %d ", ( y + sy ), ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) );
									n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y + 1 );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->scroll_cch_tabbed_y );
								} else {
//n_win_txtbox_hwndprintf_literal( p, " Autoscroll Off : %d %d ", ( y + sy ), ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) );
								}

							}

						} else
						if ( p->partial_selection_max_onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT : max " ); }

							 y++;
							sy--;

							 x = p->partial_selection_min_cch_x = n_win_txtbox_select_down( p, p->partial_selection_min_cch_x, y-1 );
							sx = N_WIN_TXTBOX_ALL;

							n_win_txtbox_select( p, x,y,sx,sy );

						}

					} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT : else " ); }

						// [Needed] : don't use n_win_txtbox_drag_select2drag()
						//
						//	a caret will disappear

//n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : else : %d ", p->select_cch_y );

						{
							s32 target_x = p->select_cch_x;

							s32  y = p->select_cch_y;
							s32 sy = p->select_cch_sy + 1;
							s32  x = n_win_txtbox_select_down( p, target_x, y );
							s32 sx = N_WIN_TXTBOX_ALL;
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y ) );

							p->partial_selection_min_onoff = n_posix_true;
							p->partial_selection_max_onoff = n_posix_false;
							p->partial_selection_min_cch_x = target_x;
							p->partial_selection_max_cch_x = x;

							//n_win_txtbox_unselect( p );
							n_win_txtbox_select( p, x,y,sx,sy );
							//n_win_txtbox_drag_select2drag( p );

						}

					}

				} else {
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : else " ); }

					if ( ( p->partial_selection_min_onoff )||( p->partial_selection_max_onoff ) )
					{

						s32 x = 0;
						s32 y = 0;

						if ( p->partial_selection_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : Min " );
							x = p->partial_selection_max_cch_x;
							y = p->select_cch_y + p->select_cch_sy - 1;
						} else
						if ( p->partial_selection_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : Max " );
							x = p->partial_selection_min_cch_x;
							y = p->select_cch_y;
						}

						n_win_txtbox_unselect( p );
						x = n_win_txtbox_select_down( p, x,y );
						n_win_txtbox_select( p, x, y + 1, 0, 1 );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : N/A " );

						// [!] : n_win_txtbox_unselect() rewrites some members

						s32 x = p->select_cch_x;
						if ( n_win_txtbox_is_caret_tail( p ) )
						{
							x += p->select_cch_sx;
						}

						n_win_txtbox_unselect( p );

						x = n_win_txtbox_select_down( p, x, p->select_cch_y );
						n_win_txtbox_select( p, x, p->select_cch_y + 1, 0, 1 );

					}

				}

//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : %d ", p->shift_dragging );

				if ( p->shift_dragging == 0 ) { p->is_ud = n_posix_true; }

			} else
			if ( vk == VK_LEFT )
			{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT " );

				if ( n_win_is_input( VK_SHIFT ) )
				{
//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d ", p->partial_selection_min_onoff, p->partial_selection_max_onoff, p->is_caret_tail );

					p->shift_dragging = VK_LEFT;

					if ( p->select_cch_sy == 1 )
					{
//n_win_txtbox_hwndprintf_literal( p, " if ( p->select_cch_sy == 1 ) " );

						s32  x = p->select_cch_x;
						s32  y = p->select_cch_y;
						s32 sx = p->select_cch_sx;
						s32 sy = p->select_cch_sy;

						n_posix_char *line = n_txt_get( &p->txt, y );

						if ( p->shift_dragging_start_x < ( x + sx ) )
						{
							if ( p->is_caret_tail )
							{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );
								n_win_txtbox_caret_l( line, sx, &sx );
							} else {
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
								s32 px = x;
								n_win_txtbox_caret_l( line,  x,  &x );
								sx = sx + abs( px - x );
							}
						} else {
//n_win_txtbox_hwndprintf_literal( p, " 3 " );
							s32 px = x;
							n_win_txtbox_caret_l( line,  x,  &x );
							sx = sx + abs( px - x );

							p->is_caret_tail = n_posix_false;
						}

						n_win_txtbox_select( p, x,y,sx,sy );
					} else
					if ( p->partial_selection_max_onoff )
					{
//n_win_txtbox_hwndprintf_literal( p, " p->partial_selection_max_onoff " );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_min_cch_x, p->partial_selection_max_cch_x );

						s32 x = p->partial_selection_min_cch_x;
						s32 y = p->select_cch_y;

						n_posix_char *line = n_txt_get( &p->txt, y );

						n_win_txtbox_caret_l( line, x, &x );

						p->partial_selection_min_cch_x = x;
					} else
					if ( p->partial_selection_min_onoff )
					{
//n_win_txtbox_hwndprintf_literal( p, " p->partial_selection_min_onoff " );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_min_cch_x, p->partial_selection_max_cch_x );

						//s32 x = p->partial_selection_max_cch_x;
						s32 y = p->select_cch_y + p->select_cch_sy - 1;

						n_posix_char *line = n_txt_get( &p->txt, y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", line );

						// [!] : don't care about this value has large number
						//p->select_cch_sx = p->partial_selection_max_cch_x;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_max_cch_x, p->select_cch_sx );

						n_win_txtbox_caret_l( line, p->partial_selection_max_cch_x, &p->partial_selection_max_cch_x );
//p->partial_selection_max_cch_x = 10;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_min_cch_x, p->partial_selection_max_cch_x );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", p->select_cch_x, p->select_cch_y, p->select_cch_sx, p->select_cch_sy );
					} else {
//n_win_txtbox_hwndprintf_literal( p, " N/A " );
					}

				} else
				if ( n_win_is_input( VK_CONTROL ) )
				{

					if ( p->select_cch_sy != 1 ) { break; } else { n_win_txtbox_unselect( p ); }

					s32 f,t;

					f = p->select_cch_x;
					n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
					n_win_txtbox_caret_l( line, f, &f );

					n_win_txtbox_select_word( p, f, p->select_cch_y, &f, &t );

					n_win_txtbox_select_set( p, f, p->select_cch_y, 0, 1, n_posix_false );

				} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT( %d ) : %d ", VK_LEFT, p->shift_dragging );

					if ( p->shift_dragging == VK_LEFT )
					{
						n_win_txtbox_unselect( p );
					} else {
						p->select_cch_x += p->select_cch_sx;
					}

					if ( ( p->select_cch_x == 0 )&&( p->select_cch_y == 0 ) )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : full stop " );

						// [!] : full stop

					} else
					if ( p->select_cch_x <= 0 )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : if ( p->select_cch_x <= 0 ) " );

						if ( p->select_cch_y == 0 ) { break; } else { p->select_cch_y--; }

						n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
						s32           tail = n_posix_strlen( line );

						n_win_txtbox_select_set( p, tail, p->select_cch_y, 0, 1, n_posix_false );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : %d : %d : %d ", p->prv_sel_sy, p->prv_sel_y, p->drag_cch_y );

						s32  x = p->prv_sel_x;
						s32  y = p->prv_sel_y;
						s32 sx = 0;
						s32 sy = 1;

						if (
							(
								( p->partial_selection_max_onoff == n_posix_false )
								&&
								( p->prv_sel_sy > 1 )
								&&
								( n_win_txtbox_is_caret_tail( p ) )
							)
							||
							( p->partial_selection_min_onoff )
						)
						{
							y = n_posix_max_s32( 0, p->prv_sel_y + p->prv_sel_sy - 1 );
						}

						if ( p->partial_selection_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Min " );
							p->partial_selection_min_onoff = n_posix_false;

							 y = p->select_cch_y + p->select_cch_sy - 1;
							sx = 0;
							sy = 1;

						} else
						if ( p->partial_selection_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Max " );
							p->partial_selection_min_onoff = n_posix_false;
							p->partial_selection_max_onoff = n_posix_false;

							 y = p->select_cch_y;
							sx = 0;
							sy = 1;

//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Max : %d %d ", y, p->select_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Max : %d ", p->partial_selection_min_onoff );
						} else
						if ( p->prv_sel_sx != N_WIN_TXTBOX_NOT_SELECTED )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : N_WIN_TXTBOX_NOT_SELECTED " );
							if ( p->is_caret_tail )
							{
								x = p->prv_sel_x + p->prv_sel_sx;
							} else {
								x = p->prv_sel_x;
							}
						}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_min_onoff, p->partial_selection_max_onoff );

						n_posix_char *line = n_txt_get( &p->txt, y );
//n_win_txtbox_hwndprintf_literal( p, "%s", line );
						n_win_txtbox_caret_l( line, x, &x );
						n_win_txtbox_select_set( p, x,y,sx,sy, n_posix_false );

						n_win_txtbox_drag_select2drag( p );

					}


//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->prv_sel_sx, p->select_cch_sx, p->select_cch_sy );
					if ( ( p->prv_sel_sx == 0 )&&( p->select_cch_sx == 0 )&&( p->select_cch_sy == 1 ) )
					{
						p->is_lr = VK_LEFT;
					}

				}

			} else
			if ( vk == VK_RIGHT )
			{

				if ( n_win_is_input( VK_SHIFT ) )
				{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT VK_SHIFT " ); 

					p->shift_dragging = VK_RIGHT;

					if ( p->select_cch_sy == 1 )
					{
						s32  x = p->select_cch_x;
						s32  y = p->select_cch_y;
						s32 sx = p->select_cch_sx;
						s32 sy = p->select_cch_sy;

						n_posix_char *line = n_txt_get( &p->txt, y );

						if ( p->shift_dragging_start_x == x )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT VK_SHIFT : #1 " ); 
							n_win_txtbox_caret_r( line, sx, &sx );
							p->is_caret_tail = n_posix_true;
						} else {
							if ( p->shift_dragging_start_x > x )
							{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT VK_SHIFT : #2 : %d %d ", p->shift_dragging_start_x, x ); 
								s32 px = x;
								n_win_txtbox_caret_r( line,  x,  &x );
								sx -= x - px;
							} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT VK_SHIFT : #3 " ); 
								s32 px = x;
								n_win_txtbox_caret_r( line,  x,  &x );
								sx -= x - px;
							}
						}

						n_win_txtbox_select( p, x,y,sx,sy );
					} else
					if ( p->partial_selection_max_onoff )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT max : %d %d ", p->partial_selection_min_cch_x, p->partial_selection_max_cch_x );

						s32 x = p->partial_selection_min_cch_x;
						s32 y = p->select_cch_y;

						n_posix_char *line = n_txt_get( &p->txt, y );

						n_win_txtbox_caret_r( line, x, &x );

						p->partial_selection_min_cch_x = x;
					} else
					if ( p->partial_selection_min_onoff )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT min : %d %d ", p->partial_selection_min_cch_x, p->partial_selection_max_cch_x );

						//s32 x = p->partial_selection_max_cch_x;
						s32 y = p->select_cch_y + p->select_cch_sy - 1;

						n_posix_char *line = n_txt_get( &p->txt, y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", line );

						// [!] : don't care about this value has large number
						//p->select_cch_sx = p->partial_selection_max_cch_x;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_max_cch_x, p->select_cch_sx );

						n_win_txtbox_caret_r( line, p->partial_selection_max_cch_x, &p->partial_selection_max_cch_x );
//p->partial_selection_max_cch_x = 10;
					}

				} else
				if ( n_win_is_input( VK_CONTROL ) )
				{

					if ( p->select_cch_sy != 1 ) { break; } else { n_win_txtbox_unselect( p ); }

					s32 f,t;
					n_win_txtbox_select_word( p, p->select_cch_x, p->select_cch_y, &f, &t );

					n_win_txtbox_select_set( p, t, p->select_cch_y, 0, 1, n_posix_false );

				} else {

					s32 prv_partial_selection_min_onoff = p->partial_selection_min_onoff;
					s32 prv_partial_selection_max_onoff = p->partial_selection_max_onoff;
					s32 prv_partial_selection_min_cch_x = p->partial_selection_min_cch_x;
					s32 prv_partial_selection_max_cch_x = p->partial_selection_max_cch_x;


					n_win_txtbox_unselect( p );


					if ( p->is_caret_tail )
					{
						p->select_cch_x = p->prv_sel_x + p->prv_sel_sx;
					} else {
						p->select_cch_x = p->prv_sel_x;
					}


					s64 target_y = p->prv_sel_y;
					if ( n_win_txtbox_is_caret_tail( p ) )
					{
						target_y = p->prv_sel_y + p->prv_sel_sy - 1;
					}

					n_posix_char *line = n_txt_get( &p->txt, n_posix_max_s32( 0, target_y ) );
					s32           tail = n_posix_strlen( line );
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %s ", line );

					if ( p->prv_sel_x == tail )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : tail " );

						if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }

						if ( target_y >= ( p->txt.sy - 1 ) ) { break; }

						n_win_txtbox_select_set( p, 0, target_y + 1, 0, 1, n_posix_false );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %d : %d : %d ", p->prv_sel_sy, p->prv_sel_y, p->drag_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %d : %d ", p->prv_sel_x, tail );

						s32  x = p->prv_sel_x;
						s32  y = p->prv_sel_y;
						s32 sx = 0;
						s32 sy = 1;

						if (
							(
								( prv_partial_selection_max_onoff == n_posix_false )
								&&
								( p->prv_sel_sy > 1 )
								&&
								( n_win_txtbox_is_caret_tail( p ) )
							)
							||
							( prv_partial_selection_min_onoff )
						)
						{
							y = n_posix_max_s32( 0, p->prv_sel_y + p->prv_sel_sy - 1 );
						}

						if ( prv_partial_selection_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : Min " );
							x = prv_partial_selection_max_cch_x;
						} else
						if ( prv_partial_selection_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : Max " );
							x = prv_partial_selection_min_cch_x;
						} else
						if ( p->prv_sel_sx != N_WIN_TXTBOX_NOT_SELECTED )
						{
							if ( p->prv_sel_x == p->select_cch_x )
							{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : Left " );
								//
							} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : Right " );
								x = p->prv_sel_x + p->prv_sel_sx;
							}
						}

						n_posix_char *line = n_txt_get( &p->txt, y );
						n_win_txtbox_caret_r( line, x, &x );
						n_win_txtbox_select_set( p, x,y,sx,sy, n_posix_false );

					}

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->prv_sel_sx, p->select_cch_sx, p->select_cch_sy );
					if ( ( p->prv_sel_sx == 0 )&&( p->select_cch_sx == 0 )&&( p->select_cch_sy == 1 ) )
					{
						p->is_lr = VK_RIGHT;
					}

				}

			} else
			if ( vk == VK_NEXT )
			{
//n_posix_debug_literal( "" );

				if ( p->ime_composition_onoff ) { break; }

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy );

				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_KEYDOWN );
				break;

			} else
			if ( vk == VK_PRIOR )
			{

				if ( p->ime_composition_onoff ) { break; }

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y - p->page_cch_tabbed_sy );

				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_KEYDOWN );
				break;

			} else
			if ( vk == VK_HOME )
			{

				if ( n_win_is_input( VK_CONTROL ) )
				{
					n_win_txtbox_scroll( p, 0, 0 );
					n_win_txtbox_select_set( p, 0, 0, 0, 1, n_posix_false );
				} else {
					n_win_txtbox_select_set( p, 0, p->select_cch_y, 0, p->select_cch_sy, n_posix_false );
				}

			} else
			if ( vk == VK_END )
			{

				if ( n_win_is_input( VK_CONTROL ) )
				{
					n_win_txtbox_scroll( p, 0, p->last_cch_tabbed_sy );
					n_win_txtbox_select_set( p, 0, p->txt.sy - 1, 0, 1, n_posix_false );
				} else {
					n_win_txtbox_select( p, 0, p->select_cch_y, N_WIN_TXTBOX_ALL, p->select_cch_sy );
					n_win_txtbox_select_set( p, p->select_cch_sx, p->select_cch_y, 0, p->select_cch_sy, n_posix_false );
				}

			} else
			if ( vk == VK_INSERT )
			{

				// [x] : for usability

				//n_win_txtbox_menu_insert( p );

			} else
			if ( vk == VK_DELETE )
			{

				if ( n_win_is_input( VK_SHIFT ) ) { break; }

				n_win_txtbox_menu_delete( p );

			} else
			if ( n_win_is_input( VK_CONTROL ) )
			{

				if ( n_win_is_input( VK_SHIFT ) ) { break; }

				if ( vk == 'A' )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+A" );

					n_win_txtbox_menu_selectall( p );

				} else
				if ( vk == 'C' )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+C" );

					n_win_txtbox_menu_copy( p );

				} else
				if ( ( vk == 'V' )&&( p->txt.readonly == n_posix_false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+V" );

					n_win_txtbox_menu_paste( p );

				} else
				if ( ( vk == 'X' )&&( p->txt.readonly == n_posix_false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+X" );

					n_win_txtbox_menu_cut( p );

				} else
				if ( ( vk == 'Z' )&&( p->txt.readonly == n_posix_false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+Z" );

					n_win_txtbox_menu_undo( p );

				}// else


				break;

			} else
			if ( p->txt.readonly == n_posix_false )
			{

				n_win_txtbox_edit_undo( p, n_posix_false );

				if ( n_win_txtbox_edit_input( p, vk ) )
				{
					n_win_message_send( GetParent( hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );
				}

			}

			p->input_onoff = n_posix_true;

//n_win_txtbox_hwndprintf_literal( p, " 2 " );

			n_win_txtbox_edit_on_typing( p );

			n_win_txtbox_scroll_oneline_auto( p );

			if ( p->ime_fade_is_running )
			{
				// [x] : not the best solution

				p->bitblt_stop = n_posix_true;
				n_win_txtbox_draw( p, N_WIN_TXTBOX_IME_FADE );
				p->bitblt_stop = n_posix_false;

				n_bmp_free( &p->ime_fade_bmp_new );
				n_bmp_carboncopy( &p->bmp, &p->ime_fade_bmp_new );

				n_bmp_free( &p->ime_fade_bmp_old );
				n_bmp_carboncopy( &p->bmp, &p->ime_fade_bmp_old );
			} else {
				p->typing_only = n_posix_true;

				s32 y,sy; n_win_txtbox_previous_calc( p, &y, &sy );
				n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_KEYDOWN, y, sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", y, sy );

				p->typing_only = n_posix_false;
			}

		}

	}
	break;


	} // switch


	if ( p->mouse_input_stop_onoff == n_posix_false )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &p->vscr );
		}

	}


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( p->pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}


