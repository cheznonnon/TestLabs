// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_smallbutton_embed( n_win_txtbox *p, n_win_smallbutton *sb, int index, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }

	if ( n_posix_false == IsWindow( sb->hgui ) ) { return; }


	index = n_posix_max( 1, index + 1 );

	s32 ix,iy,isx,isy; n_win_location( p->hwnd, &ix,&iy,&isx,&isy );

	{

		const s32 border = 2 * p->scale;

		s32 btn = isy - ( border * 2 );

		//if ( p->debug_onoff == n_posix_false )
		{
			s32 bx = bx = ( ix + isx ) - border - ( btn * index );
			s32 by = iy + border;

			if ( n_win_darkmode_onoff )
			{
				sb->color_grayed = p->color_back_disabled;//n_bmp_rgb( 0,0,255 );
			}

			n_win_move_simple( sb->hgui, bx,by, btn,btn, redraw );
			if ( redraw ) { n_win_smallbutton_bitmap( sb ); }
		}

		p->smallbutton_margin = btn * index;

	}


	return;
}


