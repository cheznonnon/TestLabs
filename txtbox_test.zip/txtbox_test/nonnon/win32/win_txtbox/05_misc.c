// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_previous( n_win_txtbox *p )
{

	p->prv_oneline_scroll = p->scroll_pxl_tabbed_x;

	p->prv_sel_x  = p->select_cch_x;
	p->prv_sel_y  = p->select_cch_y;
	p->prv_sel_sx = p->select_cch_sx;
	p->prv_sel_sy = p->select_cch_sy;
	p->prv_txt_sy = p->txt.sy;
	p->prv_drag   = p->shift_dragging;


	return;
}

void
n_win_txtbox_previous_calc( n_win_txtbox *p, s32 *ret__y, s32 *ret_sy )
{

	// [!] : this modulue is used for cascading like carrage-return


	// [!] : Slow Mode

	s32  y = N_WIN_TXTBOX_NOT_SELECTED;
	s32 sy = N_WIN_TXTBOX_NOT_SELECTED;


	// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d : %d ", p->prv_sel_y, p->select_cch_y, p->prv_sel_sy, p->select_cch_sy, p->scroll_cch_tabbed_y );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_txt_sy, p->txt.sy );

	if ( p->prv_txt_sy > p->txt.sy )
	{
		//
	} else
	if (
		( p->prv_sel_y == p->select_cch_y )
		&&
		( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
	)
	{
		 y = p->select_cch_y;
		sy = 1;
	}


	if ( ret__y != NULL ) { (*ret__y) =  y; }
	if ( ret_sy != NULL ) { (*ret_sy) = sy; }


	return;
}

void
n_win_txtbox_previous_calc_selected( n_win_txtbox *p, s32 *ret__y, s32 *ret_sy )
{

	// [!] : Slow Mode

	s32  y = N_WIN_TXTBOX_NOT_SELECTED;
	s32 sy = N_WIN_TXTBOX_NOT_SELECTED;


	// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d : %d ", p->prv_sel_y, p->select_cch_y, p->prv_sel_sy, p->select_cch_sy, p->scroll_cch_tabbed_y );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_txt_sy, p->txt.sy );

	if ( p->prv_txt_sy > p->txt.sy )
	{
		//
	} else
	if (
		( p->prv_sel_y == p->select_cch_y )
		&&
		( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
	)
	{
		 y = p->select_cch_y;
		sy = 1;
	} else {
		s32 fy = n_posix_min_s32( p->prv_sel_y, p->select_cch_y );
		s32 ty = n_posix_max_s32( p->prv_sel_y + p->prv_sel_sy, p->select_cch_y + p->select_cch_sy );

		 y = fy;
		sy = ty - fy;
	}


	if ( ret__y != NULL ) { (*ret__y) =  y; }
	if ( ret_sy != NULL ) { (*ret_sy) = sy; }


	return;
}

void
n_win_txtbox_on_setcursor( n_win_txtbox *p )
{

	// [x] : static ownerdraw and disabled controls are excluded;

	HWND hwnd = NULL;
/*
	if ( hwnd != NULL )
	{
		if ( p->hwnd != n_win_cursor2hwnd_relative( GetParent( p->hwnd ) ) )
		{
			n_win_cursor_add( hwnd, IDC_ARROW );
			return;
		}
	}
*/
	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
	{

		n_win_cursor_add( hwnd, IDC_ARROW );

	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM )
	{

		n_win_cursor_add( hwnd, IDC_ARROW );
/*
		// [!] : no ibeam when normal, ibeam when IME is ON

		extern n_posix_bool n_win_txtbox_is_hovered( n_win_txtbox* );

		if (
			( p->ime_onoff )
			&&
			( p->menu_onoff == n_posix_false )
			&&
			( p->is_hovered_linenum == n_posix_false )
			&&
			( n_win_txtbox_is_hovered( p ) )
			&&
			( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
		)
		{
			n_win_cursor_add( hwnd, IDC_IBEAM );
		} else {
			n_win_cursor_add( hwnd, IDC_ARROW );
		}
*/
	} else {
//n_win_txtbox_hwndprintf_literal( p, " 0 " );
//n_win_cursor_add( hwnd, IDC_IBEAM ); return;

		extern n_posix_bool n_win_txtbox_is_hovered( n_win_txtbox* );

		n_posix_bool is_hovered = n_win_txtbox_is_hovered( p );

		if ( p->menu_onoff )
		{

			n_win_cursor_add( hwnd, IDC_ARROW );

		} else
		if ( is_hovered == n_posix_false )
		{

			n_win_cursor_add( hwnd, IDC_ARROW );

		} else {

			if (
				( p->smallbutton_margin == 0 )
				||
				( n_posix_false == IsWindowVisible( n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );
				n_win_cursor_add( hwnd, IDC_IBEAM );
			} else

			if (
				( p->menu_onoff         == n_posix_false )
				&&
				( p->is_hovered_linenum == n_posix_false )
				&&
				( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
				n_win_cursor_add( hwnd, IDC_IBEAM );
			}

		}

	}


	return;
}

void
n_win_txtbox_grayed( n_win_txtbox *p, n_posix_bool onoff )
{

	if ( p == NULL ) { return; }


	p->is_grayed = onoff;

	if ( onoff )
	{
		p->grayed_onoff = n_posix_true;
		p->color_back_noselect = p->color_back_disabled;
	} else {
		p->color_back_noselect = p->color_back__enabled;
	}

	n_win_txtbox_refresh( p, N_WIN_TXTBOX_GRAYED );


	return;
}

n_posix_bool
n_win_txtbox_is_caret_tail( n_win_txtbox *p )
{
	return (
		( ( p->shift_dragging == VK_RIGHT )||( p->shift_dragging == VK_DOWN ) )
		||
		( ( p->prv_drag       == VK_RIGHT )||( p->prv_drag       == VK_DOWN ) )
	);
}

void
n_win_txtbox_caret_reset( n_win_txtbox *p, n_posix_bool show_onoff )
{
//return;

	if ( show_onoff )
	{
		p->caret_blend   = 1.0;
		p->caret_fade_in = n_posix_true;
	} else {
		p->caret_blend   = 0.0;
		p->caret_fade_in = n_posix_false;
	}


	return;
}

void
n_win_txtbox_caret_onoff( n_win_txtbox *p, n_posix_bool onoff )
{

	if ( p->style_option & N_WIN_TXTBOX_STYLE_CARET_FADE_BLINK )
	{

		if ( onoff )
		{
			n_win_timer_init( p->hwnd, p->caret_timer, GetCaretBlinkTime() / 20 );
		} else {
			n_win_timer_exit( p->hwnd, p->caret_timer );
		}

	} else {

		p->caret_blend   = 1.0;
		p->caret_fade_in = n_posix_true;

		if ( onoff )
		{
			n_win_timer_init( p->hwnd, p->caret_timer, GetCaretBlinkTime() );
		} else {
			n_win_timer_exit( p->hwnd, p->caret_timer );
		}

	}


	return;
}

void
n_win_txtbox_scaling( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->scale = n_win_dpi( p->hwnd ) / 96;


	return;
}

// internal
s32
n_win_txtbox_horizontal_centering( n_win_txtbox *p )
{

	s32 ret = 0;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER )
	)
	{
		n_posix_char *text = n_txt_get( &p->txt, 0 );

		SIZE size = n_win_txtbox_size_text( p, text );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			ret = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}
	}


	return ret;
}


