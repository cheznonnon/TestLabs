// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_edit_undo( n_win_txtbox *p, n_posix_bool reverse )
{

	if ( p == NULL ) { return; }


	if ( reverse )
	{

		if ( n_txt_error( &p->txt_undo ) ) { return; }

		if ( p->undo_onoff == n_posix_false ) { return; }

		n_win_txtbox_unselect( p );

		n_win_txtbox_txt_copy( p, &p->txt_undo, &p->txt, n_posix_true );

		n_win_txtbox_select( p, p->undo_cch_x,p->undo_cch_y,p->undo_cch_sx,p->undo_cch_sy );

		p->partial_selection_min_onoff = p->undo_partial_selection_min_onoff;
		p->partial_selection_max_onoff = p->undo_partial_selection_max_onoff;
		p->partial_selection_min_cch_x = p->undo_partial_selection_min_cch_x;
		p->partial_selection_max_cch_x = p->undo_partial_selection_max_cch_x;

		p->undo_onoff = n_posix_false;

	} else {

		p->undo_cch_x  = p->select_cch_x;
		p->undo_cch_y  = p->select_cch_y;
		p->undo_cch_sx = p->select_cch_sx;
		p->undo_cch_sy = p->select_cch_sy;

		p->undo_partial_selection_min_onoff = p->partial_selection_min_onoff;
		p->undo_partial_selection_max_onoff = p->partial_selection_max_onoff;
		p->undo_partial_selection_min_cch_x = p->partial_selection_min_cch_x;
		p->undo_partial_selection_max_cch_x = p->partial_selection_max_cch_x;

		p->undo_onoff = n_posix_true;

		n_win_txtbox_txt_copy( p, &p->txt, &p->txt_undo, n_posix_false );

//n_txt_save_literal( &p->txt_undo, "undo.txt" );
	}


	return;
}

void
n_win_txtbox_edit_copy( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sy == 0 ) { return; }


	if ( p->select_cch_sy == 1 )
	{

		n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

		if ( n_string_is_empty( line ) )
		{

			n_clipboard_text_set( p->hwnd, N_STRING_CRLF );

		} else
		if ( p->select_cch_sx )
		{

			n_posix_char *text = n_string_carboncopy( line );

			s32 tail = n_win_txtbox_select_tail_get( p );

//n_posix_debug_literal( "%c", text[ tail ] );
			if ( n_win_txtbox_is_accentmark_char( text[ tail ] ) ) { tail++; }

			n_string_terminate( text, tail );
			n_clipboard_text_set( p->hwnd, &text[ p->select_cch_x ] );

			n_memory_free( text );

//n_win_txtbox_hwndprintf_literal( p, "Copy : %d %d : %d", p->select_cch_x, p->select_cch_sx, tail );

		}

	} else {

		s32 sy = p->select_cch_sy;
		if ( sy == N_WIN_TXTBOX_ALL ) { sy = p->txt.sy; }


		s32 y   = 0;
		s32 cch = 0;
		while( 1 )
		{

			n_posix_char *text = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y + y ) );

			if ( ( p->partial_selection_min_onoff )||( p->partial_selection_max_onoff ) )
			{
				if ( y == 0 )
				{
					n_posix_sprintf_literal( text, "%s", &text[ p->partial_selection_min_cch_x ] );
				} else
				if ( y == ( sy - 1 ) )
				{
					n_string_terminate( text, p->partial_selection_max_cch_x );
				}
			}

			cch += n_posix_strlen( text );

			n_memory_free( text );

			y++;
			if ( y >= sy ) { break; }

			cch += n_posix_strlen( N_STRING_CRLF );

		}

		n_posix_char *clipboard = n_string_new_fast( cch );
		if ( clipboard == NULL ) { return; }

		y = cch = 0;
		while( 1 )
		{

			n_posix_char *text = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y + y ) );

			if ( ( p->partial_selection_min_onoff )||( p->partial_selection_max_onoff ) )
			{
				if ( y == 0 )
				{
					n_posix_sprintf_literal( text, "%s", &text[ p->partial_selection_min_cch_x ] );
				} else
				if ( y == ( sy - 1 ) )
				{
					n_string_terminate( text, p->partial_selection_max_cch_x );
				}
			}

			cch += n_posix_sprintf_literal( &clipboard[ cch ], "%s", text );

			n_memory_free( text );

			y++;
			if ( y >= sy ) { break; }

			cch += n_posix_sprintf_literal( &clipboard[ cch ], "%s", N_STRING_CRLF );

		}

		n_clipboard_text_set( p->hwnd, clipboard );

		n_memory_free( clipboard );

	}


	return;
}

void
n_win_txtbox_edit_del( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sy <= 0 ) { return; }


	if ( p->select_cch_sy == 1 )
	{

		n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
		s32           cch  = n_posix_strlen( line );


		if ( cch == 0 )
		{
//n_win_txtbox_hwndprintf_literal( p, "Single : Empty Line" );

			if ( p->select_cch_y == 0 ) { return; }

			n_win_txtbox_line_del( p, p->select_cch_y );

			s32 tail = n_posix_strlen( n_txt_get( &p->txt, p->select_cch_y - 1 ) );

			n_win_txtbox_select_set( p, tail, p->select_cch_y - 1, 0, 1, n_posix_false );

		} else
		if ( p->select_cch_sx == 0 )
		{
//n_win_txtbox_hwndprintf_literal( p, "Single : Not Selected : %d %d", p->select_cch_x, p->select_cch_sx );

			if ( p->select_cch_x == 0 )
			{

				if ( p->select_cch_y == 0 ) { return; }

				n_posix_char *p_line = n_txt_get( &p->txt, p->select_cch_y - 1 );
				s32           p_cch  = n_posix_strlen( p_line );
				n_posix_char *text   = n_string_new_fast( cch + p_cch );

				if ( text != NULL )
				{
					n_posix_sprintf_literal( text, "%s%s", p_line, line );

					n_win_txtbox_line_mod( p, p->select_cch_y - 1, text );
					n_win_txtbox_line_del( p, p->select_cch_y );

					n_memory_free( text );

					n_win_txtbox_select_set( p, p_cch, p->select_cch_y - 1, 0, 1, n_posix_false );
				}

			} else {

				s32 unit = p->select_cch_x;
				n_win_txtbox_caret_l( line, p->select_cch_x, &unit );
				unit = p->select_cch_x - unit;

				n_string_copy( &line[ p->select_cch_x ], &line[ p->select_cch_x - unit ] );

				n_win_txtbox_select_set( p,  p->select_cch_x - unit, p->select_cch_y, 0, 1, n_posix_false );

			}

		} else {
//n_win_txtbox_hwndprintf_literal( p, "Single : Selected : %d %d : %d", p->select_cch_x, p->select_cch_sx, cch );
//n_win_txtbox_hwndprintf_literal( p, "Single : Selected : %d %d", p->partial_selection_min_onoff, p->partial_selection_max_onoff );

			s32 tail = n_win_txtbox_select_tail_get( p );

			n_string_copy( &line[ tail ], &line[ p->select_cch_x ] );

			if ( n_posix_false == n_win_txtbox_is_caret_tail( p ) )
			{
				n_win_txtbox_unselect( p );
			}

			n_win_txtbox_select_set( p,  p->select_cch_x, p->select_cch_y, 0, 1, n_posix_false );

		}

	} else {

		//const n_posix_bool min_onoff = p->partial_selection_min_onoff;
		//const n_posix_bool max_onoff = p->partial_selection_max_onoff;
		const n_posix_bool min_cch_x = p->partial_selection_min_cch_x;
		const n_posix_bool max_cch_x = p->partial_selection_max_cch_x;
		const n_posix_bool carettail = n_win_txtbox_is_caret_tail( p );

		s32  x = 0;
		s32  y = p->select_cch_y;
		s32 sx = 0;
		s32 sy = p->select_cch_sy;

		s32 fy = y;
		s32 ty = y + sy - 1;

//n_win_txtbox_hwndprintf_literal( p, " Multiple : %d : %d %d : %d %d ", carettail, y, sy , min_onoff, max_onoff );
//n_win_txtbox_hwndprintf_literal( p, " Multiple : %d : %d %d : %d %d ", carettail, min_onoff, max_onoff, min_cch_x, max_cch_x );

		n_posix_char *cat_fy = NULL;
		n_posix_char *cat_ty = NULL;

		if (
			(
				( n_posix_false != carettail )
				&&
				( p->partial_selection_min_onoff )
			)
			||
			(
				( n_posix_false == carettail )
				&&
				( p->partial_selection_max_onoff )
			)
		)
		{
			n_posix_char *line = n_txt_get( &p->txt, ty );

			n_posix_sprintf_literal( line, "%s", &line[ max_cch_x ] );
			cat_ty = n_string_carboncopy( line );

			p->partial_selection_min_onoff = n_posix_false;
			p->partial_selection_max_cch_x = 0;
		}


		// [!] : "min_cch_x" might have -1

		if ( min_cch_x >= 0 )
		{
			n_posix_char *line = n_txt_get( &p->txt, fy );
//n_win_txtbox_hwndprintf_literal( p, " %s ", line );

			n_string_terminate( line, min_cch_x );
			cat_fy = n_string_carboncopy( line );

			x = p->partial_selection_min_cch_x;

			p->partial_selection_min_cch_x = 0;
		} else {
			cat_ty = n_string_carboncopy( N_STRING_EMPTY );
		}


		s32 count = abs( fy - ty );
		s32 del_y = 0;
		while( 1 )
		{//break;

			n_txt_del( &p->txt, fy );

			del_y++;
			if ( del_y > count ) { break; }
		}


		if ( ( cat_fy != NULL )&&( cat_ty != NULL ) )
		{
//n_posix_debug_literal( "%s\n%s", cat_fy, cat_ty );

			int           cch = n_posix_strlen( cat_fy ) + n_posix_strlen( cat_ty );
			n_posix_char *str = n_string_new( cch );

			n_posix_sprintf_literal( str, "%s%s", cat_fy, cat_ty );

			n_txt_add_fast( &p->txt, fy, str );

		}


		n_memory_free( cat_fy );
		n_memory_free( cat_ty );

		n_win_txtbox_select( p, x,y,sx,1 );


		n_win_txtbox_drag_select2drag( p );

		p->shift_dragging = 0;

		n_win_txtbox_reset_partial_selection_minmax( p );

	}


	return;
}

void
n_win_txtbox_edit_cut( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sx == 0 ) { return; }

	n_win_txtbox_edit_copy( p );
	n_win_txtbox_edit_del ( p );


	return;
}

n_posix_bool
n_win_txtbox_edit_paste( n_win_txtbox *p )
{

	if ( p == NULL ) { return n_posix_false; }


	s32 cch = n_clipboard_text_get( p->hwnd, NULL );
	if ( cch == 0 ) { return n_posix_false; }


	if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }


	n_txt txt; n_txt_zero( &txt );

	{

		n_posix_char *text = n_string_new_fast( cch );
		if ( text != NULL )
		{
			n_clipboard_text_get( p->hwnd, text );

			n_txt_load_onmemory( &txt, text, ( cch + 1 ) * sizeof( n_posix_char ) );
		} else {
			n_txt_new( &txt );
		}

	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )||( txt.sy <= 1 ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " Single " );

		n_posix_char *line = n_txt_get( &txt, 0 );

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM )
		{
			n_posix_bool ret = n_win_txtbox_filename_is_safe( line );
			if ( ret == n_posix_false ) { return n_posix_false; }
		}

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL )
		{
			n_posix_bool ret = n_win_txtbox_filename_is_digit( line );
			if ( ret == n_posix_false ) { return n_posix_false; }
		}

		n_posix_bool ret = n_posix_false;

		if ( n_string_is_empty( line ) )
		{
			n_win_txtbox_line_add( p, p->select_cch_y, line );
		} else {
			ret = n_posix_true;
			n_win_txtbox_selection_cat( p, line );
		}

		n_txt_free( &txt );

		n_win_txtbox_reset_partial_selection_minmax( p );


		return ret;
	}
//n_win_txtbox_hwndprintf_literal( p, " Multi " );


	n_posix_char *half_upper = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y ) );
	n_posix_char *half_lower = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y ) );
//n_win_txtbox_hwndprintf_literal( p, " %s : %s ", half_upper, half_lower );

	n_string_terminate( half_upper, p->select_cch_x );
	n_string_copy( &half_lower[ p->select_cch_x ], half_lower );


	s64 y = 0;
	while( 1 )
	{//break;

		n_posix_char *line = n_txt_get( &txt, y );

		if ( y == 0 )
		{

			n_posix_char *s = n_string_new_fast( n_posix_strlen( half_upper ) + n_posix_strlen( line ) );
			if ( s != NULL )
			{
				n_posix_sprintf_literal( s, "%s%s", half_upper, line );

				n_win_txtbox_line_mod( p, p->select_cch_y + y, s );
			}
			n_memory_free( s );

		} else
		if ( y == ( txt.sy - 1 ) )
		{
//n_win_txtbox_hwndprintf_literal( p, " %s ", half_lower );

			s32 cch_1 = n_posix_strlen( half_lower );
			s32 cch_2 = n_posix_strlen( line       );
			s32 cch   = cch_1 + cch_2;

			n_posix_char *s = n_string_new_fast( cch );
			if ( s != NULL )
			{
				n_posix_sprintf_literal( s, "%s%s", line, half_lower );

				n_win_txtbox_line_add( p, p->select_cch_y + y, s );
			}
			n_memory_free( s );

			n_win_txtbox_select( p, cch_2, p->select_cch_y + y, 0,1 );
			n_win_txtbox_drag_select2drag( p );

		} else {

			n_win_txtbox_line_add( p, p->select_cch_y + y, line );

		}

		y++;
		if ( y >= txt.sy ) { break; }
	}

	n_memory_free( half_upper );
	n_memory_free( half_lower );


	n_win_txtbox_reset_partial_selection_minmax( p );


	n_txt_free( &txt );


	n_win_txtbox_txt_stream( p, n_posix_true );


	return n_posix_true;
}

void
n_win_txtbox_edit_on_typing( n_win_txtbox *p )
{

	// [!] : keyboard input only
	//
	//	mouse input uses n_win_txtbox_drag()

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );


	s32 stop_sx = p->select_cch_x; if ( p->is_caret_tail ) { stop_sx += p->select_cch_sx; }
	s32 stop_sy = p->select_cch_y;

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->is_caret_tail );

//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, stop_sy ) );

	if ( p->partial_selection_min_onoff ) { stop_sy += p->select_cch_sy - 1; }
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", stop_sy, p->select_cch_y );

	s32 fx = p->scroll_pxl_tabbed_x / p->font_pxl_sx;
	s32 tx = 0; n_win_txtbox_tabbedmetrics( p, stop_sy, -1,stop_sx,-1, NULL,NULL,&tx );
	s32 fy = p->scroll_cch_tabbed_y;
	s32 ty = p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy;


//n_win_txtbox_hwndprintf_literal( p, " N/A : %d ", tx );

	if ( stop_sy <  fy )
	{
//n_win_txtbox_hwndprintf_literal( p, " Top : %d ", ty );

		n_win_txtbox_scroll( p, fx * p->font_pxl_sx, p->select_cch_y );

	} else
	if ( stop_sy >= ty )
	{
//n_win_txtbox_hwndprintf_literal( p, " Bottom : %d ", ty );

		n_win_txtbox_scroll( p, fx * p->font_pxl_sx, p->select_cch_y - p->page_cch_tabbed_sy + 1 );

	}


	// [Needed] : for combination x and y

	fy = p->scroll_cch_tabbed_y;


//n_win_txtbox_hwndprintf_literal( p, "  %d ", p->vk_key );

	s32 slide_sx = p->font_pxl_sx;
	if ( p->is_font_monospace == n_posix_false ) { slide_sx = p->size_halfwidth.cx / 2; }

	s32 usability_cch = 5;
	s32 usability     = ( usability_cch * slide_sx );

//n_win_txtbox_hwndprintf_literal( p, "  %d %d ", ( tx * slide_sx ), ( p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx - usability ) );

	if (
		( ( p->vk_key == VK_RIGHT )||( p->vk_mouse == VK_LBUTTON ) )
		&&
		( ( tx * slide_sx ) >= ( p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx - usability ) )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " Usability Right : %d ", tx );

		s32 p_scroll = p->scroll_pxl_tabbed_x;

		n_win_txtbox_scroll( p, ( tx * slide_sx ) - p->page_pxl_tabbed_sx + usability, fy );

		if ( p->vk_mouse == VK_LBUTTON )
		{
			POINT pt; GetCursorPos( &pt );
			SetCursorPos( pt.x - ( p->scroll_pxl_tabbed_x - p_scroll ), pt.y );
		}

	} else
	if ( ( tx * slide_sx ) >= ( ( p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx ) ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " Right : %d ", tx );

		n_win_txtbox_scroll( p, ( tx * slide_sx ) - p->page_pxl_tabbed_sx, fy );

	} else
	if (
		( ( p->vk_key == VK_LEFT )||( p->vk_mouse == VK_LBUTTON ) )
		&&
		//( fx != 0 )
		//&&
		( fx > ( tx - usability_cch ) )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " Usability Left : %d ", tx );

		s32 p_scroll = p->scroll_pxl_tabbed_x;

		n_win_txtbox_scroll( p, ( tx * slide_sx ) - usability, fy );

		if ( p->vk_mouse == VK_LBUTTON )
		{
			POINT pt; GetCursorPos( &pt );
			SetCursorPos( pt.x + ( p_scroll - p->scroll_pxl_tabbed_x ), pt.y );
		}

	} else
	if ( fx > tx )
	{
//n_win_txtbox_hwndprintf_literal( p, " Left : %d ", tx );

		n_win_txtbox_scroll( p, ( tx * slide_sx ), fy );

	}


	return;
}

n_posix_bool
n_win_txtbox_edit_input( n_win_txtbox *p, int vk )
{

	if ( p == NULL ) { return n_posix_false; }


	p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


	BYTE         key[ 256 ]; GetKeyboardState( key );
	n_posix_char str[ 100 ];

#ifdef UNICODE

	ToUnicode( vk,0,key, str,100, 0 );

#else // #ifdef UNICODE

	WORD w;
	ToAscii  ( vk,0,key, &w, 0 );
	str[ 0 ] = w;
	str[ 1 ] = N_STRING_CHAR_NUL;

	// [x] : Buggy : ANSI version on NT : invalid character will be returned

	if ( p->is_nt )
	{
		wchar_t wstr[ 100 ];
		ToUnicode( vk,0,key, wstr,100, 0 );
		if ( wstr[ 0 ] == L'\0' ) { return n_posix_false; }
	}

#endif // #ifdef UNICODE

//n_posix_debug_literal( " %d ", str[ 0 ] );

//n_posix_debug_literal( "%d : %d : %d : %x", vk, ImmGetVirtualKey( p->hwnd ), n_win_is_input( VK_CONVERT ), (int) str[ 0 ] );

	if ( n_string_is_empty( str ) ) { return n_posix_false; }


	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->select_cch_x );

		if ( n_posix_false == n_win_txtbox_filename_is_safe_char( str[ 0 ] ) ) { return n_posix_false; }

		if (
			( str[ 0 ] == n_posix_literal( ' ' ) )
			&&
			(
				( n_string_is_empty( n_txt_get( &p->txt, 0 ) ) )
				||
				( p->select_cch_x == 0 )
				||
				(
					( p->select_cch_sx == N_WIN_TXTBOX_ALL )
					||
					( p->select_cch_sx == n_posix_strlen( n_txt_get( &p->txt, 0 ) ) )
				)
			)
		)
		{
			return n_posix_false;
		}

	} else
	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ) )
	{

		if (
			( n_posix_false == n_string_is_digit( str, 0 ) )
			&&
			( 0x08 != str[ 0 ] )
		)
		{
			return n_posix_false;
		}

	}


	p->is_carrage_return = n_posix_false;
	p->is_backspace      = n_posix_false;

	p->carrage_return_cch_y = -1;
	p->backspace_cch_y      = -1;


	if ( 0x08 == str[ 0 ] )
	{
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_y, p->select_cch_y );

		// [!] : ASCII Control Code : 0x08 : BS

		p->is_backspace = n_posix_true;

		n_win_txtbox_previous( p );

		n_win_txtbox_edit_del( p );

		p->vk_key = VK_LEFT;


//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->is_backspace, p->backspace_cch_y );

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_y, p->select_cch_y );

	} else
	if ( 0x09 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x09 : TAB

		//if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { return n_posix_true; }

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		n_win_txtbox_selection_cat( p, str );

		p->vk_key = VK_RIGHT;

	} else
	if ( 0x0d == str[ 0 ] )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { return n_posix_true; }


		// [!] : ASCII Control Code : 0x0d CR

		p->is_carrage_return    = n_posix_true;
		p->carrage_return_cch_y = p->select_cch_y;

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		if ( p->select_cch_x == 0 )
		{

			n_win_txtbox_line_add( p, p->select_cch_y, N_STRING_EMPTY );
			n_win_txtbox_select  ( p, p->select_cch_x, p->select_cch_y + 1, 0, 1 );

		} else {

			n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

			n_win_txtbox_line_add( p, p->select_cch_y + 1, &line[ p->select_cch_x ] );
			n_string_terminate( line, p->select_cch_x );

			n_win_txtbox_select_set( p, 0, p->select_cch_y + 1, 0, 1, n_posix_false );

		}

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_y, p->select_cch_y );

		//s32 last = n_win_scrollbar_position_last_unit( &p->vscr );
		//n_win_scrollbar_scroll_unit( &p->vscr, last, N_WIN_SCROLLBAR_SCROLL_SEND );

	} else
	if ( 0x1b == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x1b ESC

		return n_posix_false;

	} else
	if ( 0x03 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x03 End of Text

		return n_posix_false;

	} else
	if ( 0x16 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x16 Synchronous Idle

		return n_posix_false;

	} else
	//
	{
//n_win_txtbox_hwndprintf_literal( p, " %s ", str );

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		n_win_txtbox_selection_cat( p, str );

		p->vk_key = VK_RIGHT;

	}


	p->shift_dragging_start_x     = p->select_cch_x;
	p->shift_dragging_start_pxl_x = p->ime.x;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->shift_dragging_start_x, p->shift_dragging_start_pxl_x );


	return n_posix_true;
}


