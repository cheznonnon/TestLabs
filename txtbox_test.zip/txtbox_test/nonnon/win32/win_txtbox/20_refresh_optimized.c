// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_refresh_optimized_init( n_win_txtbox *p )
{

	// [!] : some members are used as typing

	//p->prv_scr_x  = p->scroll_pxl_tabbed_x;
	//p->prv_scr_y  = p->scroll_cch_tabbed_y;
	p->prv_sel_x  = p->select_cch_x;
	p->prv_sel_y  = p->select_cch_y;
	p->prv_sel_sx = p->select_cch_sx;
	p->prv_sel_sy = p->select_cch_sy;
	p->prv_drag   = p->shift_dragging;
	//p->prv_caret  = p->caret_pxl_x;


	return;
}

void
n_win_txtbox_refresh_optimized_exit( n_win_txtbox *p )
{

	// [!] : optimization is implemented in n_win_txtbox_draw(), draw_singleline() now

	n_win_txtbox_draw( p, N_WIN_TXTBOX_REFRESH_OPTIMIZED_EXIT );


	return;
}


