// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_select_get( n_win_txtbox *p, s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	if ( p == NULL ) { return; }

	if (  x != NULL ) { (* x) = p->select_cch_x;  }
	if (  y != NULL ) { (* y) = p->select_cch_y;  }
	if ( sx != NULL ) { (*sx) = p->select_cch_sx; }
	if ( sy != NULL ) { (*sy) = p->select_cch_sy; }


	return;
}

#define n_win_txtbox_select( p, x,y,sx,sy ) n_win_txtbox_select_set( p, x,y,sx,sy, n_posix_true )

void
n_win_txtbox_select_set( n_win_txtbox *p, s32 x, s32 y, s32 sx, s32 sy, n_posix_bool clamp_onoff )
{

	if ( p == NULL ) { return; }

	if ( clamp_onoff )
	{

		if ( sy == N_WIN_TXTBOX_ALL ) { sy = p->txt.sy; }

		p->select_cch_y  = n_posix_minmax( 0, p->txt.sy -               1,  y );
		p->select_cch_sy = n_posix_minmax( 0, p->txt.sy - p->select_cch_y, sy );


		// [!] : the last character is accessible

		s32 cch = p->txt.sx;
		if ( sy <= 1 ) { cch = n_posix_strlen( n_txt_get( &p->txt, p->select_cch_y ) ); }

		if ( sx == N_WIN_TXTBOX_ALL ) { sx = cch; }

		p->select_cch_x  = n_posix_minmax( 0, cch,                    x );
		p->select_cch_sx = n_posix_minmax( 0, cch - p->select_cch_x, sx );

	} else {

		p->select_cch_x  = x;
		p->select_cch_y  = y;
		p->select_cch_sx = sx;
		p->select_cch_sy = sy;

	}


	return;
}

void
n_win_txtbox_select_search( n_win_txtbox *p, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( p == NULL ) { return; }


	n_win_txtbox_select( p, x, y, sx, sy );

	p->shift_dragging = VK_RIGHT;


	return;
}

s32
n_win_txtbox_select_tail_get( n_win_txtbox *p )
{

	if ( p == NULL ) { return 0; }


	n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
	s32           cch  = n_posix_strlen( line );

	if ( p->select_cch_sx == N_WIN_TXTBOX_ALL ) { p->select_cch_sx = cch; }
	p->select_cch_sx = n_posix_minmax( 0, cch - p->select_cch_x, p->select_cch_sx );
 

	return p->select_cch_x + p->select_cch_sx;
}

void
n_win_txtbox_select_tail_set( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
	s32           cch  = n_posix_strlen( line );

	p->select_cch_sx = 0;
	p->select_cch_x  = cch;

	n_win_txtbox_scroll( p, cch * p->font_pxl_sx, p->scroll_cch_tabbed_y );


	return;
}

void
n_win_txtbox_select_word( n_win_txtbox *p, s32 x, s32 y, s32 *from, s32 *to )
{

	n_posix_char *line = n_txt_get( &p->txt, y );

	if ( line[ x ] == N_STRING_CHAR_NUL ) { x = n_posix_max_s32( 0, x - 1 ); }

	s32 f = x;
	s32 t = x;

	n_posix_bool is_blank = n_string_char_is_blank( line[ f ] );

	while( 1 )
	{

		n_posix_bool b = n_string_char_is_blank( line[ f ] );

		if ( is_blank )
		{
			if ( b == n_posix_false ) { f++; break; }
		} else {
			if ( b != n_posix_false ) { f++; break; }
		}

		f--;
		if ( f < 0 ) { f = 0; break; }
	}

	while( 1 )
	{

		if ( line[ t ] == N_STRING_CHAR_NUL ) { break; }

		n_posix_bool b = n_string_char_is_blank( line[ t ] );

		if ( is_blank )
		{
			if ( b == n_posix_false ) { break; }
		} else {
			if ( b != n_posix_false ) { break; }
		}

		t++;
	}

//n_win_txtbox_hwndprintf_literal( p, "%d : %d %d", x, f,t );

	if ( from != NULL ) { (*from) = f; }
	if ( to   != NULL ) { (*to  ) = t; }


	return;
}

#define n_win_txtbox_select_up(   p, x,y ) n_win_txtbox_select_updown( p, x,y, n_posix_true  )
#define n_win_txtbox_select_down( p, x,y ) n_win_txtbox_select_updown( p, x,y, n_posix_false )

s32
n_win_txtbox_select_updown( n_win_txtbox *p, s32 x, s32 y, n_posix_bool is_up )
{

	if ( p == NULL ) { return 0; }
	if ( x ==    0 ) { return 0; }


	s32 delta; if ( is_up ) { delta = -1; } else { delta = 1; }


	s32 f = 0; n_win_txtbox_tabbedmetrics( p, y        , -1,  x, -1,   &f, NULL, NULL );
	s32 t = 0; n_win_txtbox_tabbedmetrics( p, y + delta,  f, -1, -1, NULL,   &t, NULL );


	return t;
}

void
n_win_txtbox_unselect( n_win_txtbox *p )
{

	// [Needed] : partial selection

	//if ( n_posix_false == n_win_txtbox_is_selected( p ) ) { return; }


//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );

	if ( p->shift_dragging == VK_LEFT  )
	{
		//
		p->select_cch_y += p->select_cch_sy - 1;
	} else
	if ( p->shift_dragging == VK_RIGHT )
	{
		p->select_cch_x += p->select_cch_sx;
		p->select_cch_y += p->select_cch_sy - 1;
	} else
	if ( p->shift_dragging == VK_UP    )
	{
		//
		//
	} else
	if ( p->shift_dragging == VK_DOWN  )
	{
		p->select_cch_x += p->select_cch_sx;
		p->select_cch_y += p->select_cch_sy;
	}

	p->select_cch_sx = 0;
	p->select_cch_sy = 1;

	p->shift_dragging = p->prv_drag = 0;


	extern void n_win_txtbox_reset_line_minmax( n_win_txtbox* );
	n_win_txtbox_reset_line_minmax( p );


	return;
}


