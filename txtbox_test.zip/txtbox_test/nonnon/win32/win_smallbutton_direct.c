// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Usage ]
//
//	Init       : n_win_smallbutton_direct_zero()
//	WM_CREATE  : n_win_smallbutton_direct_init()
//	WM_CLOSE   : n_win_smallbutton_direct_exit()
//
//	[ Optional ]
//
//	WM_SETTINGCHANGE : n_win_smallbutton_direct_on_settingchange()
//
//	[ Icon Resource ]
//
//	a gray-scaled icon will be a system-colored icon automatically
//	see n_win_smallbutton_direct_bitmap() for details
//
//	[ Tips ]
//
//	Not Used        : .m and .icon is not used in main purpose
//
//	init_by_data()  : you can use a on-the-fly resource : see win32/win_combobox.c
//
//	.show_onoff     : EnableWindow()-like behavior
//	.bmp_canvas     : direct render mode




#ifndef _H_NONNON_WIN32_WIN_SMALLBUTTON_DIRECT
#define _H_NONNON_WIN32_WIN_SMALLBUTTON_DIRECT




#include "../neutral/bmp/fade.c"
#include "../neutral/bmp/filter.c"
#include "../neutral/bmp/transform.c"

#include "./win.c"
#include "./gdi/bitmap.c"
#include "./gdi/color.c"




#define N_WIN_SMALLBUTTON_DIRECT_NONE    ( 0 << 0 )
#define N_WIN_SMALLBUTTON_DIRECT_NORMAL  ( 1 << 0 )
#define N_WIN_SMALLBUTTON_DIRECT_HOVERED ( 1 << 1 )
#define N_WIN_SMALLBUTTON_DIRECT_PRESSED ( 1 << 2 )


typedef struct {

	HWND         hwnd_draw;
	HWND         hwnd_timer;
	HWND         hwnd_msg;
	int          id;
	int          scale;
	s32          x,y,sx,sy;
	int          state;
	n_posix_bool show_onoff;

	HICON        hicon;
	n_bmp        b,m;
	n_bmp        bmp_default;
	n_bmp        bmp;
	n_bmp       *bmp_canvas;

	n_posix_bool make_default;

	n_bmp_fade   fade;
	u32          fade_timer;
	n_posix_bool fade_onoff;
	double       fade_blend;

	// [!] : you can override colors

	u32          color_fg;
	u32          color_bg;
	u32          color_pressed;
	u32          color_hovered;

	n_posix_bool upside_down;

double blend;

} n_win_smallbutton_direct;


#define n_win_smallbutton_direct_zero( p ) n_memory_zero( p, sizeof( n_win_smallbutton_direct ) )




void
n_win_smallbutton_direct_bitmap_make( const u8 *data, n_bmp *bmp_ret, s32 scale, u32 color_bg )
{

	s32 sx = 16;
	s32 sy = 16;

	n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_1st_fast( &bmp, sx,sy );
	n_bmp_flush( &bmp, color_bg );

	s32 x = 0;
	s32 y = 0;
	while( 1 )
	{

		int value = data[ x + ( y * sx ) ];

		u32 color;
		if ( value == 255 )
		{
			color = color_bg;
		} else {
			color = n_bmp_rgb( value,value,value );
		}

		n_bmp_ptr_set_fast( &bmp, x,y, color );

		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}

	s32 size = 32 * scale;
	n_bmp_resizer( &bmp, size,size, color_bg, N_BMP_RESIZER_CENTER );

	n_bmp_free_fast( bmp_ret );
	n_bmp_alias( &bmp, bmp_ret );


	return;
}

void
n_win_smallbutton_direct_bitmap_reverse( n_win_smallbutton_direct *p, n_bmp *bmp )
{

	u64 c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	u64 i = 0;
	while( 1 )
	{

		u32 color = N_BMP_PTR( bmp )[ i ];

		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		N_BMP_PTR( bmp )[ i ] = n_bmp_rgb( r,g,b );

		i++;
		if ( i >= c ) { break; }
	}


	return;
}

void
n_win_smallbutton_direct_bitmap_contour( n_win_smallbutton_direct *p, int ox, int oy, u32 color_fg )
{

	n_bmp bmp_tmp; n_bmp_carboncopy( &p->bmp_default, &bmp_tmp );

	s32 m = p->scale * 2;
	s32 x = -m;
	s32 y = -m;
	while( 1 )
	{

		n_bmp_rasterizer( &bmp_tmp, &p->bmp, ox + x, oy + y, n_bmp_white, n_posix_false );

		x++;
		if ( x > m )
		{
			x = -m;

			y++;
			if ( y > m ) { break; }
		}
	}

	n_bmp_antialias( &p->bmp, ox-m,oy-m, p->sx+(m*2),p->sy+(m*2), 1.0 );

	n_bmp_rasterizer( &bmp_tmp, &p->bmp, ox,oy, color_fg, n_posix_false );

	n_bmp_free_fast( &bmp_tmp );


	return;
}

void
n_win_smallbutton_direct_bitmap_draw( n_win_smallbutton_direct *p )
{

	if ( p == NULL ) { return; }


	if ( p->show_onoff )
	{
		if ( ( p->bmp_canvas != NULL )&&( NULL != N_BMP_PTR( p->bmp_canvas ) ) )
		{
			n_bmp_blendcopy  ( &p->bmp, p->bmp_canvas,  0,0,p->sx,p->sy, p->x,p->y, p->fade_blend );
		} else {
			n_gdi_bitmap_draw( p->hwnd_draw, &p->bmp, 0,0,p->sx,p->sy, p->x,p->y );
		}

//n_bmp_box( p->bmp_canvas, 0, 0, 1000, 1000, n_bmp_rgb( 0,200,255 ) );
//n_bmp_box( p->bmp_canvas, p->x, p->y, p->sx, p->sy, n_bmp_rgb( 0,200,255 ) );
//n_bmp_save_literal( &p->bmp, "bitmap_draw.bmp" );
	}


	return;
}

void
n_win_smallbutton_direct_bitmap_init( n_win_smallbutton_direct *p )
{

	if ( p == NULL ) { return; }


	if ( p->make_default )
	{
		p->make_default = n_posix_false;

		n_bmp_free( &p->bmp_default );
		n_bmp_carboncopy( &p->b, &p->bmp_default );

		if ( p->upside_down ) { n_bmp_flush_mirror( &p->bmp_default, N_BMP_MIRROR_UPSIDE_DOWN ); }

		n_bmp_scaler_big( &p->bmp_default, p->scale );

		n_bmp_resizer( &p->bmp_default, p->sx,p->sy, p->color_bg, N_BMP_RESIZER_CENTER );

		n_win_smallbutton_direct_bitmap_reverse( p, &p->bmp_default );
//n_bmp_save_literal( &p->bmp_default, "bmp_default.bmp" );
	}


	s32 ox = 0;
	s32 oy = 0;

	if ( p->state & N_WIN_SMALLBUTTON_DIRECT_PRESSED )
	{
		if ( p->upside_down )
		{
			ox =  p->scale;
			oy = -p->scale;
		} else {
			ox =  p->scale;
			oy =  p->scale;
		}
	}


	u32 color_fg;

	if ( p->state & N_WIN_SMALLBUTTON_DIRECT_PRESSED )
	{

		color_fg = p->color_pressed;

	} else {

		color_fg = n_bmp_fade_engine( &p->fade, n_win_fade_is_on() );
//if ( p->id == 1 ) { n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd_draw ), " %d ", p->fade.percent ); }

	}


	n_bmp_free( &p->bmp );
	n_bmp_new_fast( &p->bmp, p->sx,p->sy );
	n_bmp_flush( &p->bmp, p->color_bg );

	n_win_smallbutton_direct_bitmap_contour( p, ox,oy, color_fg );
//n_bmp_save_literal( &p->bmp, "contour.bmp" );


	return;
}

#define n_win_smallbutton_direct_on_settingchange(         p, i ) n_win_smallbutton_direct_on_settingchange_internal( p, i, NULL )
#define n_win_smallbutton_direct_on_settingchange_by_data( p, d ) n_win_smallbutton_direct_on_settingchange_internal( p, 0,    d )

void
n_win_smallbutton_direct_on_settingchange_internal( n_win_smallbutton_direct *p, int index, const u8 *data )
{

	// Resource

	p->scale = n_win_dpi( GetDesktopWindow() ) / 96;

	n_win_stdsize_icon_large( &p->sx, &p->sy );

	if ( data == NULL )
	{
		p->hicon = n_win_icon_init( NULL, index, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_win_icon_hicon2bmp_1st( p->hicon, p->sx,p->sy, &p->b, &p->m );
//n_bmp_save_literal( &p->b, "ret.bmp" );

		// [x] : High-DPI : Patch
		n_bmp_fill( &p->b, 0,0, p->color_bg );
	} else {
		n_win_smallbutton_direct_bitmap_make( data, &p->b, p->scale, n_bmp_white_invisible );
//n_bmp_free( &p->b );
//n_bmp_new( &p->b, 32,32 );
	}


	// [!] : default colors

	p->color_bg = n_bmp_white_invisible;

	if ( ( n_win_darkmode_onoff )||( n_win_color_is_highcontrast() ) )
	{
		p->color_fg      = n_gdi_systemcolor( COLOR_BTNHIGHLIGHT );
		p->color_pressed = n_gdi_systemcolor( COLOR_3DDKSHADOW   );
		p->color_hovered = n_gdi_systemcolor( COLOR_HIGHLIGHT    );
		p->color_hovered = n_bmp_hsl_replace_pixel( p->color_hovered, -1, 255, 128 );
	} else {
		p->color_fg      = n_gdi_systemcolor( COLOR_GRAYTEXT     );
		p->color_pressed = n_gdi_systemcolor( COLOR_3DDKSHADOW   );
		p->color_hovered = n_gdi_systemcolor( COLOR_HIGHLIGHT    );
		p->color_hovered = n_bmp_hsl_replace_pixel( p->color_hovered, -1, 255, 128 );
	}


	// [!] : default bitmap : delayed for override p->color_bg

	p->make_default = n_posix_true;


	return;
}

#define n_win_smallbutton_direct_init(         p, hd, ht, hm, id, i ) n_win_smallbutton_direct_init_internal( p, hd, ht, hm, id, i, NULL )
#define n_win_smallbutton_direct_init_by_data( p, hd, ht, hm, id, d ) n_win_smallbutton_direct_init_internal( p, hd, ht, hm, id, 0,    d )

void
n_win_smallbutton_direct_init_internal
(
	n_win_smallbutton_direct *p,
	HWND                      hwnd_draw,
	HWND                      hwnd_timer,
	HWND                      hwnd_msg,
	int                       id,
	int                       index,
	const u8                 *data
)
{

	n_win_smallbutton_direct_on_settingchange_internal( p, index, data );

	p->hwnd_draw  = hwnd_draw;
	p->hwnd_timer = hwnd_timer;
	p->hwnd_msg   = hwnd_msg;
	p->id         = id;
	p->state      = N_WIN_SMALLBUTTON_DIRECT_NONE;

	n_bmp_fade_init( &p->fade, p->color_fg );

	return;
}

void
n_win_smallbutton_direct_exit( n_win_smallbutton_direct *p )
{

	// Resource

	n_win_icon_exit( p->hicon );

	n_bmp_free( &p->b );
	n_bmp_free( &p->m );

	n_bmp_free( &p->bmp_default );
	n_bmp_free( &p->bmp         );


	// Cleanup

	n_win_smallbutton_direct_zero( p );


	return;
}

n_posix_bool
n_win_smallbutton_direct_is_hovered( n_win_smallbutton_direct *p )
{
	return n_win_is_hovered_offset( p->hwnd_draw, p->x, p->y, p->sx, p->sy );
}

n_posix_bool
n_win_smallbutton_direct_is_pressed( n_win_smallbutton_direct *p )
{
	return ( p->state & N_WIN_SMALLBUTTON_DIRECT_PRESSED );
}

void
n_win_smallbutton_direct_hide( n_win_smallbutton_direct *p, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }


	p->show_onoff = n_posix_false;
	p->state      = N_WIN_SMALLBUTTON_DIRECT_NONE;
	p->fade_blend = 0.0;

	n_bmp_fade_init( &p->fade, p->color_fg );


	if ( redraw )
	{
		n_win_smallbutton_direct_bitmap_init( p );
	}


	return;
}

void
n_win_smallbutton_direct_press( n_win_smallbutton_direct *p, n_posix_bool onoff, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }


	if ( onoff )
	{
		p->state |=  N_WIN_SMALLBUTTON_DIRECT_PRESSED;
	} else {
		p->state &= ~N_WIN_SMALLBUTTON_DIRECT_PRESSED;
	}


	if ( redraw )
	{
		n_win_smallbutton_direct_bitmap_init( p );
	}


	return;
}

void
n_win_smallbutton_direct_hover( n_win_smallbutton_direct *p, n_posix_bool onoff, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }


	n_posix_bool p_state = p->state;

	if ( onoff )
	{
		p->state |=  N_WIN_SMALLBUTTON_DIRECT_HOVERED;
	} else {
		p->state &= ~N_WIN_SMALLBUTTON_DIRECT_HOVERED;
	}


	if ( p_state != p->state )
	{
//n_posix_debug_literal( " Changed " );

		u32 bg,fg;
		if ( p->state & N_WIN_SMALLBUTTON_DIRECT_HOVERED )
		{
			bg = p->color_fg;
			fg = p->color_hovered;
		} else {
			bg = p->color_hovered;
			fg = p->color_fg;
		}

		n_bmp_fade_init( &p->fade, bg );
		n_bmp_fade_go  ( &p->fade, fg );

		if ( p->fade_timer == 0 ) { p->fade_timer = n_win_timer_id_get(); }
		n_win_timer_init( p->hwnd_timer, p->fade_timer, 33 );
	}


	if ( redraw )
	{
		n_win_smallbutton_direct_bitmap_init( p );
	}


	return;
}

void
n_win_smallbutton_direct_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_smallbutton_direct *p )
{

	switch( msg ) {


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( p->fade_timer == wparam )
		{
//n_posix_debug_literal( " WM_TIMER " );
			n_win_smallbutton_direct_bitmap_init( p );
			n_win_smallbutton_direct_bitmap_draw( p );

			if ( p->fade.stop ) { n_win_timer_exit( p->hwnd_timer, p->fade_timer ); }

		}

	break;


	case WM_PAINT :

		// [!] : you need to control manually

		//n_win_smallbutton_direct_bitmap_draw( p );

	break;


	case WM_LBUTTONDOWN :
	{

		if ( p->show_onoff == n_posix_false ) { break; }

		n_posix_bool onoff = n_win_smallbutton_direct_is_hovered( p );
		if ( onoff )
		{
			n_win_smallbutton_direct_press( p, n_posix_true, n_posix_true );
			n_win_smallbutton_direct_bitmap_draw( p );
		}
	}
	break;

	case WM_LBUTTONUP :

		if ( p->show_onoff == n_posix_false ) { break; }

		if ( n_win_smallbutton_direct_is_pressed( p ) )
		{
			n_win_smallbutton_direct_press( p, n_posix_false, n_posix_true );
			n_win_smallbutton_direct_bitmap_draw( p );

			if ( n_win_smallbutton_direct_is_hovered( p ) )
			{
				n_win_message_post( p->hwnd_msg, WM_COMMAND, p->id, p->hwnd_msg );
			}
		}

	break;

	case WM_MOUSEMOVE :
	{

		if ( p->show_onoff == n_posix_false ) { break; }

		int p_state = p->state;

		n_posix_bool onoff = n_win_smallbutton_direct_is_hovered( p );
		if ( onoff == n_posix_false )
		{
			if ( n_win_smallbutton_direct_is_pressed( p ) )
			{
				n_win_smallbutton_direct_press( p, n_posix_false, n_posix_true );
			}
		}

		n_win_smallbutton_direct_hover( p, onoff, n_posix_true );

		if ( p_state != p->state )
		{
			n_win_smallbutton_direct_bitmap_draw( p );
		}

	}
	break;

	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_SMALLBUTTON_DIRECT


