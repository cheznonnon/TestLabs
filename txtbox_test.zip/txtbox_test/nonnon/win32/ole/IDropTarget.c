// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Optional : inlucde this before win32/win.c


// Link : -lole32




#ifndef _H_NONNON_WIN32_OLE_IDROPTARGET
#define _H_NONNON_WIN32_OLE_IDROPTARGET




#include "../../neutral/posix.c"


#include <objbase.h>
#include <oleidl.h>
#include <shlobj.h>




static HWND          n_IDropTarget_hwnd_target = NULL;
static n_posix_char *n_IDropTarget_path        = NULL;
static s64           n_IDropTarget_path_cch    = 0;
static DWORD         n_IDropTarget_keystate    = 0;
static DWORD         n_IDropTarget_timer       = 0;
static n_posix_bool  n_IDropTarget_is_running  = n_posix_false;




const GUID n_IDropTarget_guid_IID_IUnknown    = { 0x00000000,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };
const GUID n_IDropTarget_guid_IID_IDropTarget = { 0x00000122,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };




HWND
n_IDropTarget_hwnd_toplevel( HWND hwnd )
{

	// [!] : Win95 hasn't GetAncestor()

	while( 1 )
	{
		if ( NULL == GetParent( hwnd ) ) { break; }

		hwnd = GetParent( hwnd );
	}


	return hwnd;
}

#define n_IDropTarget_path_count( df, p ) n_IDropTarget_path_main( df, p, n_posix_true  )
#define n_IDropTarget_path_set(   df, p ) n_IDropTarget_path_main( df, p, n_posix_false )

// internal
s64
n_IDropTarget_path_main( const DROPFILES *df, const void *p, n_posix_bool cch_needed )
{

	      s64      f = 0;
	      s64      t = 0;
	const char    *c = p;// MessageBoxA( NULL, c,  "", 0 );
	const wchar_t *w = p;// MessageBoxW( NULL, w, L"", 0 );
	while( 1 )
	{

		if ( df->fWide )
		{

			if ( w[ f ] == L'\0' ) { break; }

#ifdef UNICODE
			wchar_t *s     = n_string_carboncopy ( &w[ f ] );
			s64      cch_f = 0;
			if ( cch_needed )
			{
				cch_f = wcslen( s );
			} else {
				cch_f = swprintf( &n_IDropTarget_path[ t ], L"%s", s );
			}
			s64     cch_t = cch_f;
#else  // #ifdef UNICODE
			char    *s     = n_posix_unicode2ansi( &w[ f ] );
			s64      cch_f = wcslen( &w[ f ] );
			s64      cch_t = 0;
			if ( cch_needed )
			{
				cch_t = strlen( s );
			} else {
				cch_t = sprintf( &n_IDropTarget_path[ t ],  "%s", s );
			}
#endif // #ifdef UNICODE

			f += cch_f + 1;
			t += cch_t + 1;

//n_posix_debug_literal( "%s : %d", s, i );// break;

			n_memory_free( s );

		} else {

			if ( c[ f ] == '\0' ) { break; }

#ifdef UNICODE
			wchar_t *s     = n_posix_ansi2unicode( &c[ f ] );
			s64      cch_f = strlen( &c[ f ] );
			s64      cch_t = 0;
			if ( cch_needed )
			{
				cch_t = wcslen( s );
			} else {
				cch_t = swprintf( &n_IDropTarget_path[ t ], L"%s", s );
			}
#else  // #ifdef UNICODE
			char    *s     = n_string_carboncopy ( &c[ f ] );
			s64      cch_f = 0;
			if ( cch_needed )
			{
				cch_f = strlen( s );
			} else {
				cch_f = sprintf( &n_IDropTarget_path[ t ],  "%s", s );
			}
			s64      cch_t = cch_f;
#endif // #ifdef UNICODE

			f += cch_f + 1;
			t += cch_t + 1;

			n_memory_free( s );

		}

	}


	return n_posix_max_s64( f, t ) + 2;
}

void
n_IDropTarget_foreground_set( HWND hwnd )
{

	// [!] : this behavior might be not recommended by MS

	HMODULE hmod = LoadLibrary( n_posix_literal( "user32.dll" ) );
	if ( hmod != NULL )
	{

		DWORD n_ASFW_ANY    = ( (DWORD) -1 );
		//UINT  n_LSFW_LOCK   = 1;
		UINT  n_LSFW_UNLOCK = 2;


		FARPROC func;


		func = GetProcAddress( hmod, "AllowSetForegroundWindow" );
		if ( func != NULL )
		{
			func( n_ASFW_ANY );
		}

		func = GetProcAddress( hmod, "LockSetForegroundWindow" );
		if ( func != NULL )
		{
			func( n_LSFW_UNLOCK );
		}

	}

	FreeLibrary( hmod );


	SetForegroundWindow( hwnd );


	return;
}

HRESULT __stdcall
n_IDropTarget_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{

	(*ppvObject) = NULL;

	if (
		( n_memory_is_same( iid, &n_IDropTarget_guid_IID_IUnknown,    sizeof( GUID ) ) )
		||
		( n_memory_is_same( iid, &n_IDropTarget_guid_IID_IDropTarget, sizeof( GUID ) ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}

ULONG __stdcall
n_IDropTarget_AddRef( void *_this )
{
	return S_OK;
}

ULONG __stdcall
n_IDropTarget_Release( void *_this )
{
	return S_OK;
}

HRESULT __stdcall
n_IDropTarget_DragEnter( void *_this, IDataObject *pDataObject, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect )
{
//n_posix_debug_literal( "n_IDropTarget_DragEnter() : %d", grfKeyState );
//n_win_hwndprintf_literal( n_IDropTarget_hwnd_target, "DragEnter" );


	n_IDropTarget_is_running = n_posix_true;


	if ( pdwEffect != NULL ) { (*pdwEffect) = DROPEFFECT_COPY; }


	// [x] : conflict with n_IDropSource_start()
	//
	//	[ Explorer => Application ]
	//	grfKeyState has value
	//
	//	[ Application => Application ]
	//	grfKeyState has zero

	n_IDropTarget_keystate = grfKeyState;

/*
	if ( n_win_is_input( VK_LBUTTON ) ) { n_IDropTarget_keystate |= MK_LBUTTON; }
	if ( n_win_is_input( VK_MBUTTON ) ) { n_IDropTarget_keystate |= MK_MBUTTON; }
	if ( n_win_is_input( VK_RBUTTON ) ) { n_IDropTarget_keystate |= MK_RBUTTON; }
	if ( n_win_is_input( VK_SHIFT   ) ) { n_IDropTarget_keystate |= MK_SHIFT;   }
	if ( n_win_is_input( VK_CONTROL ) ) { n_IDropTarget_keystate |= MK_CONTROL; }
*/

	n_IDropTarget_timer = n_posix_tickcount() + GetDoubleClickTime();


	return S_OK;
}

HRESULT __stdcall
n_IDropTarget_DragOver( void *_this, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect )
{
//n_posix_debug_literal( "n_IDropTarget_DragOver() : %d", grfKeyState );
//n_win_hwndprintf_literal( n_IDropTarget_hwnd_target, "DragOver" );


	n_IDropTarget_is_running = n_posix_true;


	if ( pdwEffect != NULL ) { (*pdwEffect) = DROPEFFECT_COPY; }


	if (
		( n_IDropTarget_timer <= n_posix_tickcount() )
		&&
		( n_IDropTarget_hwnd_target != NULL )
		&&
		( n_posix_false == IsZoomed( n_IDropTarget_hwnd_target ) )
	)
	{
		n_IDropTarget_foreground_set( n_IDropTarget_hwnd_target );
	}


	return S_OK;
}

HRESULT __stdcall
n_IDropTarget_DragLeave( void *_this )
{

	n_IDropTarget_is_running = n_posix_false;


	return S_OK;
}

HRESULT __stdcall
n_IDropTarget_Drop( void *_this, IDataObject *pDataObject, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect )
{
//n_posix_debug_literal( "n_IDropTarget_Drop()" );


	n_IDropTarget_is_running = n_posix_false;


	FORMATETC fe = { CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL  };
	STGMEDIUM sm = { TYMED_HGLOBAL, { NULL }, NULL };

	if ( pDataObject == NULL ) { return E_NOTIMPL; }
	pDataObject->lpVtbl->GetData( pDataObject, &fe, &sm );

	if ( fe.cfFormat != CF_HDROP         ) { return E_NOTIMPL; }
	if ( fe.ptd      != NULL             ) { return E_NOTIMPL; }
	if ( fe.dwAspect != DVASPECT_CONTENT ) { return E_NOTIMPL; }
	if ( fe.lindex   != -1               ) { return E_NOTIMPL; }
	if ( fe.tymed    != TYMED_HGLOBAL    ) { return E_NOTIMPL; }
	if ( sm.tymed    != TYMED_HGLOBAL    ) { return E_NOTIMPL; }

	//if ( sm.pUnkForRelease != NULL ) { return E_NOTIMPL; }


	// [!] : Details : see n_win_dropfiles() @ win32/win/commandline.c


	u8 *p = GlobalLock( sm.hGlobal );
	if ( p == NULL ) { return E_NOTIMPL; }

	DROPFILES df; n_memory_copy( p, &df, sizeof( DROPFILES ) );

	n_string_free( n_IDropTarget_path );

	n_IDropTarget_path_cch = n_IDropTarget_path_count( &df, &p[ df.pFiles ] );
	n_IDropTarget_path     = n_string_new( n_IDropTarget_path_cch );

	n_IDropTarget_path_set( &df, &p[ df.pFiles ] );

//if ( df->pFiles != sizeof( DROPFILES ) ) { n_posix_debug_literal( "!" ); }

	GlobalUnlock( sm.hGlobal );


#ifdef _H_NONNON_WIN32_OLE_DEBUG

	n_posix_debug_literal
	(
		"%d \n"
		"X = %d : Y = %d \n"
		"NonClient = %d \n"
		"Unicode = %d \n",
		df.pFiles,
		df.pt.x, df.pt.y,
		df.fNC,
		df.fWide
	);

#endif // #ifndef _H_NONNON_WIN32_OLE_DEBUG


	// [Needed] : Application => Another Application

	// [Mechanism] : don't use Win3.x DnD together
	//
	//	a : DragAcceptFiles( hwnd, n_posix_true );
	//	b : WS_EX_ACCEPTFILES
	//
	//	WM_DROPFILES will be sent twice

	{

		// [!] : don't rely on DROPFILES.pt member, use parameter "POINTL pt"

		// [!] : VC++ 2017 : POINTL and POINT are not compatible
		// [!] : VC++ 2017 : HDROP is missing

		POINT  point = { pt.x, pt.y };
		HWND   hwnd  = n_IDropTarget_hwnd_toplevel( WindowFromPoint( point ) );
		HANDLE hdrop = NULL;//(HANDLE) sm.hGlobal;

		SendMessage( hwnd, WM_DROPFILES, (WPARAM) hdrop, 0 );

	}


	if ( pdwEffect != NULL ) { (*pdwEffect) = DROPEFFECT_NONE; }

	return S_OK;
}




// [!] : members are overridable

static void *n_IDropTarget_Vtbl[] = {

	n_IDropTarget_QueryInterface,
	n_IDropTarget_AddRef,
	n_IDropTarget_Release,

	n_IDropTarget_DragEnter,
	n_IDropTarget_DragOver,
	n_IDropTarget_DragLeave,
	n_IDropTarget_Drop,

};

static IDropTarget n_IDropTarget_instance = { (void*) n_IDropTarget_Vtbl };




void
n_IDropTarget_init( HWND hwnd )
{

	OleInitialize( NULL );


	n_IDropTarget_hwnd_target = hwnd;
	n_IDropTarget_path        = NULL;
	n_IDropTarget_path_cch    = 0;
	n_IDropTarget_keystate    = 0;
	n_IDropTarget_timer       = 0;
	n_IDropTarget_is_running  = n_posix_false;


	RegisterDragDrop( hwnd, &n_IDropTarget_instance );


	return;
}

void
n_IDropTarget_exit( HWND hwnd )
{

	RevokeDragDrop( hwnd );


	n_memory_free( n_IDropTarget_path );

	n_IDropTarget_hwnd_target = NULL;
	n_IDropTarget_path        = NULL;
	n_IDropTarget_path_cch    = 0;
	n_IDropTarget_keystate    = 0;
	n_IDropTarget_timer       = 0;
	n_IDropTarget_is_running  = n_posix_false;


	OleUninitialize();


	return;
}

s64
n_IDropTarget_path_get( n_posix_char *str, s64 cch )
{

	if ( str == NULL ) { return 0; }


	if ( cch >= n_IDropTarget_path_cch )
	{
		n_string_zero( str, n_IDropTarget_path_cch );
		n_memory_copy( n_IDropTarget_path, str, n_IDropTarget_path_cch * sizeof( n_posix_char ) );
	}


	return n_IDropTarget_path_cch;
}


#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

