// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Link ]
//
//		-limm32
//
//			for Input Method Editor support
//
//
//	[ Notification ]
//
//		[ WM_COMMAND ]
//
//			WPARAM : WM_*BUTTON* / WM_KEYDOWN / WM_SETFOCUS / WM_KILLFOCUS
//			LPARAM : HWND of Txtbox
//
//
//	[ Style ]
//
//		[ N_WIN_TXTBOX_STYLE_LISTBOX ]
//
//			listbox-like behavior
//
//		[ N_WIN_TXTBOX_STYLE_ONELINE ]
//
//			edit-like behavior : one liner
//
//		[ N_WIN_TXTBOX_STYLE_EDITBOX ]
//
//			edit-like behavior : multiple lines
//
//		[ N_WIN_TXTBOX_STYLE_HSCROLL/VSCROLL ]
//
//			scrollbar on/off
//
//		[ N_WIN_TXTBOX_STYLE_NO_BRDR ]
//
//			border will be off
//
//		[ N_WIN_TXTBOX_STYLE_NO_PDNG ]
//
//			padding will be off
//
//		[ N_WIN_TXTBOX_STYLE_STRIPED ]
//
//			striped background
//
//		[ N_WIN_TXTBOX_STYLE_VISIBLE ]
//
//			for drawing on a DWM transparent window
//
//		[ N_WIN_TXTBOX_STYLE_TRANSBG ]
//
//			for drawing on a DWM transparent window
//
//		[ N_WIN_TXTBOX_STYLE_FLATBDR ]
//
//			flat border in classic style
//			made for win32/win_combobox.c
//
//		[ N_WIN_TXTBOX_STYLE_CMB_BDR ]
//
//			combobox border
//			made for win32/win_combobox.c
//
//
//	[ Style Option ]
//
//		[ N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS ]
//
//			strings started with "[?]" will be applied
//
//			+ [ ] : not applied
//			+ [B] : bold
//			+ [I] : italic
//			+ [U] : underline
//			+ [S] : strikeout
//
//		[ N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL ]
//
//			keep selection when out-of-bound area is clicked
//
//			+ this is listbox compatible behavior
//
//		[ N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL ]
//
//			auto-highlight a hovered item
//
//		[ N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ]
//
//			text will be centered when N_WIN_TXTBOX_OPTION_EDITBOX_ONELINE
//
//		[ N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ]
//
//			input filename safe characters only
//
//		[ N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ]
//
//			input digit only
//
//		[ N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ]
//
//			line number on/off
//			+ N_WIN_TXTBOX_OPTION_ZEROBASED_INDEX : from zero
//
//		[ N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM ]
//
//			a cursor doesn't use ibeam
//
//		[ N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET ]
//
//			a caret will be disappeared when no focus
//
//		[ N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ]
//
//			editbox but edit functions off
//
//		[ N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ]
//
//			turn off focus-border-change
//
//		[ N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ]
//
//			a little different rendering between fast mode and slow mode
//
//		[ N_WIN_TXTBOX_STYLE_NO_DELAYED_FOCUS ]
//
//			don't use middle button delayed focus
//
//		[ N_WIN_TXTBOX_STYLE_CARET_FADE_BLINK ]
//
//			fade blinking for caret : default is ON
//
//
//	[ More Option ]
//
//		[ .placeholder ]
//
//			placeholder text for N_WIN_TXTBOX_OPTION_EDITBOX_ONELINE
//
//		[ .tab_mark ]
//
//			TAB Marker for N_WIN_TXTBOX_STYLE_EDITBOX
//			+ "auto" is special
//
//		[ .eol_mark ]
//
//			End-Of-Line Marker for N_WIN_TXTBOX_STYLE_EDITBOX
//			+ "auto" is special
//
//		[ .virtual_padding_pxl_sx ]
//
//			for text offset
//			currently, N_WIN_TXTBOX_STYLE_LISTBOX only supported
//
//		[ .mouse_input_stop_onoff ]
//
//			stop mouse input
//			for combobox slide
//
//
//	[ etc ]
//
//		[ middle button ]
//
//			delayed selection when focus is set
//
//		[ grayed background ]
//
//			use n_win_txtbox_grayed()
//
// 		[ when you use subclass ]
//
//			call n_win_txtbox_proc_menu_editbox( txtbox.hwnd, WM_CREATE, 0, 0, &txtbox );
//
//		[ initialization trouble shooter ]
//
//			check initialization order
//			call n_win_txtbox_init() before other controls
//
//		[ redraw is delayed after selecting when you use simplemenu ]
//
//			use callback, see below n_win_txtbox_callback()
//
//		[ n_win_txtbox_line_add() ]
//
//			don't use with N_WIN_TXTBOX_STYLE_LISTBOX
//			use n_win_txtbox_line_set()




#ifndef _H_NONNON_WIN32_TXTBOX
#define _H_NONNON_WIN32_TXTBOX




#ifdef _MSC_VER

#pragma comment( lib, "imm32" )

#endif // #ifdef _MSC_VER




#include "../neutral/bmp/filter.c"
#include "../neutral/txt.c"


#include "../game/transition.c"


#include "./clipboard.c"
#include "./uxtheme.c"
#include "./win.c"
#include "./win_menu.c"
#include "./win_scrollbar.c"
#include "./win_smallbutton.c"
#include "./win_simplemenu.c"




// [!] : Components

#include "./win_txtbox/00_helper.c"
#include "./win_txtbox/01_extern.c"
#include "./win_txtbox/02_debug.c"
#include "./win_txtbox/03_string.c"
#include "./win_txtbox/04_codec.c"
#include "./win_txtbox/05_misc.c"
#include "./win_txtbox/06_ime.c"
#include "./win_txtbox/07_metrics.c"
#include "./win_txtbox/08_scroll.c"
#include "./win_txtbox/09_select.c"
#include "./win_txtbox/10_drag.c"
#include "./win_txtbox/11_highlight.c"
#include "./win_txtbox/12_line.c"
#include "./win_txtbox/13_autofocus.c"
#include "./win_txtbox/14_reset.c"
#include "./win_txtbox/15_is_hovered.c"
#include "./win_txtbox/16_smallbutton.c"
#include "./win_txtbox/17_draw.c"
#include "./win_txtbox/18_selection.c"
#include "./win_txtbox/19_edit.c"
#include "./win_txtbox/20_refresh_optimized.c"
#include "./win_txtbox/21_menu.c"
#include "./win_txtbox/22_proc_mouse.c"
#include "./win_txtbox/23_proc.c"
#include "./win_txtbox/24_subclass.c"




void
n_win_txtbox_callback( void *data )
{

	n_win_txtbox *p = data;
//n_win_txtbox_debug_count( p );

	//n_win_txtbox_refresh( p );
	n_win_message_send( p->hwnd, WM_PAINT, 0, 0 );


	return;
}

void
n_win_txtbox_init( n_win_txtbox *p, HWND hwnd_parent, int style, int style_option )
{

	if ( p == NULL ) { return; }

	if ( hwnd_parent == NULL ) { return; }


	// Debug

	p->debug_onoff = n_posix_false;//n_posix_true;


	// Default

	p->style        = style;
	p->style_option = style_option;

	if (
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX ) )
		&&
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		&&
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
	)
	{
		return;
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { p->style |= N_WIN_TXTBOX_STYLE_EDITBOX; }


	p->caret_blend   = 1.0;
	p->caret_fade_in = n_posix_true;

	if ( n_win_fade_is_on() )
	{
		p->style_option |= N_WIN_TXTBOX_STYLE_CARET_FADE_BLINK;
	}


	p->color___dwm_contour = RGB(  50, 50, 50 );
	p->color___dwm_textclr = RGB( 255,255,255 );


	// UI

	n_win_gui_literal( hwnd_parent, N_WIN_GUI_CANVAS, "", &p->hwnd );


#ifdef _WIN64
	SetWindowSubclass( p->hwnd, n_win_txtbox_subclass, 0, (DWORD_PTR) p );
#else  // #ifdef _WIN64
	p->pfunc = n_win_gui_subclass_set( p->hwnd, n_win_txtbox_subclass );
	n_win_property_init( p->hwnd, N_WIN_TXTBOX_NAMESPACE, (int) p );
#endif // #ifdef _WIN64


	//n_win_scrollbar_direct_render = n_posix_true;

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_init( &p->hscr, p->hwnd, N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL, 0 );
		p->hscr.option |= N_WIN_SCROLLBAR_OPTION_CLAMP_BIG_THUMB;

		p->hscr.menu.callback      = n_win_txtbox_callback;
		p->hscr.menu.callback_data = p;
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_init( &p->vscr, p->hwnd, N_WIN_SCROLLBAR_LAYOUT_VERTICAL  , 0 );
		p->vscr.option |= N_WIN_SCROLLBAR_OPTION_CLAMP_BIG_THUMB;

		p->vscr.menu.callback      = n_win_txtbox_callback;
		p->vscr.menu.callback_data = p;
	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{
		n_win_stdfont_init( &p->hwnd, 1 );
	}



	// [Needed] : after p->hwnd is made
	// [Needed] : after scrollbars are made

	n_win_txtbox_metrics( p );
	n_win_txtbox_reset  ( p );


	n_win_simplemenu_init( &p->menu_editbox );
	n_win_simplemenu_init( &p->menu_linenum );

	p->menu_editbox.callback      = n_win_txtbox_callback;
	p->menu_editbox.callback_data = p;

	p->menu_linenum.callback      = n_win_txtbox_callback;
	p->menu_linenum.callback_data = p;

	n_win_txtbox_proc_menu_editbox_init( p );
	n_win_txtbox_proc_menu_linenum_init( p );


	p->partial_selection_onoff = n_posix_true;
	p-> updown_selection_onoff = n_posix_true;
	p->reverse_selection_onoff = n_posix_true;

	n_win_txtbox_reset_line_minmax( p );


	p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


	n_win_txtbox_reset_undo( p );


	p->focus_phase_is_first = N_WIN_TXTBOX_FOCUS_GO;


	return;
}

void
n_win_txtbox_exit( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_win_timer_exit( p->hwnd, p->caret_timer );


#ifdef _WIN64
	RemoveWindowSubclass( p->hwnd, n_win_txtbox_subclass, 0 );
#else  // #ifdef _WIN64
	n_win_gui_subclass_set( p->hwnd, p->pfunc );
	n_win_property_exit( p->hwnd, N_WIN_TXTBOX_NAMESPACE );
#endif // #ifdef _WIN64


	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_exit( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_exit( &p->vscr );
	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{
		n_win_stdfont_exit( &p->hwnd, 1 );
	}


	n_win_simplemenu_exit( &p->menu_editbox );
	n_win_simplemenu_exit( &p->menu_linenum );


	DestroyWindow( p->hwnd );


	n_txt_free( &p->txt      );
	n_txt_free( &p->txt_undo );


	n_gdi_dibsection_exit( &p->hbmp, &p->bmp );


	n_win_txtbox_zero( p );


	return;
}


#endif // _H_NONNON_WIN32_TXTBOX

