// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_smallbutton_direct.c"


#include "../nonnon/project/small_close.c"
#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_smallbutton_direct sb1;
	static n_win_smallbutton_direct sb2;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Tutorial", "MAIN_ICON", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );


		n_win_smallbutton_direct_zero( &sb1 );
		n_win_smallbutton_direct_init_by_data( &sb1, hwnd, 1, n_project_small_close );

		sb1.x = ( 256 - 32 ) / 2; sb1.x -= 16;
		sb1.y = ( 256 - 32 ) / 2;

		sb1.color_bg   = n_gdi_systemcolor( COLOR_BTNFACE );
		sb1.show_onoff = n_posix_true;

		n_win_smallbutton_direct_bitmap_init( &sb1 );


		n_win_smallbutton_direct_zero( &sb2 );
		n_win_smallbutton_direct_init_by_data( &sb2, hwnd, 2, n_project_small_close );

		sb2.x = ( 256 - 32 ) / 2; sb2.x += 16;
		sb2.y = ( 256 - 32 ) / 2;

		sb2.color_bg   = n_gdi_systemcolor( COLOR_BTNFACE );
		sb2.show_onoff = n_posix_true;

		n_win_smallbutton_direct_bitmap_init( &sb2 );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_PAINT :

		n_win_smallbutton_direct_bitmap_draw( &sb1 );
		n_win_smallbutton_direct_bitmap_draw( &sb2 );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == hwnd )
		{
			if ( wparam == sb1.id )
			{
				n_posix_debug_literal( " 1 " );
			} else
			if ( wparam == sb2.id )
			{
				n_posix_debug_literal( " 2 " );
			}// else
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &sb1 );
	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &sb2 );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


