// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_OC_HOVER2TOOLTIP_PHASE_NEUTRAL ( 0 )
#define N_OC_HOVER2TOOLTIP_PHASE_FADE_IN ( 1 )
#define N_OC_HOVER2TOOLTIP_PHASE_FADEOUT ( 2 )




void
n_oc_item_hover2tooltip_folder_count( const n_posix_char *path, s64 *fldrs, s64 *files )
{

	if ( fldrs != NULL ) { (*fldrs) = 0; }
	if ( files != NULL ) { (*files) = 0; }


	n_posix_DIR *dp = n_posix_opendir_nodot( path );
	if ( dp == NULL ) { return; }


	n_posix_char *curdir = n_string_path_folder_current_new();
	n_string_path_folder_change_fast( path );


	s64 a = 0;
	s64 b = 0;

	while( 1 )
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }


		//if ( FILE_ATTRIBUTE_DIRECTORY & GetFileAttributes( dirent->d_name ) )
		if ( FILE_ATTRIBUTE_DIRECTORY & dirent->dwFileAttributes )
		{
			a++;
		} else {
			b++;
		}

	}


	n_string_path_folder_change_fast( curdir );
	n_string_path_free( curdir );


	n_posix_closedir( dp );


	if ( fldrs != NULL ) { (*fldrs) = a; }
	if ( files != NULL ) { (*files) = b; }


	return;
}

void
n_oc_item_hover2tooltip_fade_on( n_oc_item *p )
{

	n_bmp_fade_always_on( &p->tooltip_fade, n_bmp_black, n_bmp_white );


	return;
}

n_bool
n_oc_item_hover2tooltip_multifocus_is_on( n_oc_item *p )
{

	if (
		( 1 < n_oc_item_multifocus_count( p ) )
		&&
		( p->tooltip_hover != N_ORANGECAT_NOTHING )
		&&
		( p->multifocus[ p->tooltip_hover ] )
	)
	{
		return n_true;
	}


	return n_false;
}

int
n_oc_item_hover2tooltip_multifocus_count( n_oc_item *p, s64 *fldrs, s64 *files )
{

	s64 a = 0;
	s64 b = 0;

	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] )
		{
			if ( n_posix_stat_is_dir( n_dir_name( &p->dir, i ) ) ) { a++; } else { b++; }
		}

		i++;
	}

	if ( fldrs != NULL ) { (*fldrs) = a; }
	if ( files != NULL ) { (*files) = b; }


	return n_false;
}

void
n_oc_item_hover2tooltip_multifocus_size_drive( n_oc_item *p, double *ret_size_main, double *ret_size_used, double *ret_size_free )
{

	double size_main = 0;
	double size_free = 0;

	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] )
		{
			if ( oc.view_is_computer )
			{
				u64 disksize = 0;
				u64 freesize = 0;
				n_sysinfo_drive_size( n_dir_name( &p->dir, i ), &disksize, &freesize );

				size_main += disksize;
				size_free += freesize;
			}
		}

		i++;
	}

	if ( ret_size_main != NULL ) { (*ret_size_main) = size_main; }
	if ( ret_size_used != NULL ) { (*ret_size_used) = size_main - size_free; }
	if ( ret_size_free != NULL ) { (*ret_size_free) = size_free; }


	return;
}

n_bool
n_oc_item_hover2tooltip_multifocus_size_file( n_oc_item *p, n_posix_structstat_size_t *ret_size )
{

	n_posix_structstat_size_t size = 0;

	n_bool overflow = n_false;

	int i = 0;
	while( 1 )
	{
		if ( i >= p->count ) { break; }

		if ( p->multifocus[ i ] )
		{
			if ( oc.view_is_computer )
			{

				//

			} else {

				n_posix_char *path = n_dir_path( &p->dir, i );
				n_posix_char *name = n_dir_name( &p->dir, i );
				n_posix_char *str  = n_string_path_make_new( path, name );

				if ( n_posix_stat_is_file( str ) )
				{
					n_posix_structstat_size_t byte = n_posix_stat_size( str );
//n_posix_debug_literal( "%s : %lu", str, byte );
					if ( ( byte == 0 )&&( n_posix_stat_size_is_overflowed( str ) ) )
					{
						overflow = n_true;
						n_string_path_free( str );
						break;
					}


					n_posix_structstat_size_t prv_size = size;

					size += byte;

					if ( prv_size > size )
					{
						overflow = n_true;
						n_string_path_free( str );
						break;
					}
				}

				n_string_path_free( str );

			}
		}

		i++;
	}


	if ( ret_size != NULL ) { (*ret_size) = size; }


	return overflow;
}

void
n_oc_item_hover2tooltip_rich_folder( n_oc_item *p, s64 count_fldr, s64 count_file, n_posix_char *ret_size )
{

	n_posix_char *str_fldr = n_posix_literal( "folder" );
	n_posix_char *str_file = n_posix_literal( "file" );

	if ( count_fldr > 1 ) { str_fldr = n_posix_literal( "folders" ); }
	if ( count_file > 1 ) { str_file = n_posix_literal( "files"   ); }

	if ( ( count_fldr == 0 )&&( count_file == 0 ) )
	{
		n_posix_sprintf_literal( ret_size, " (empty)" );
	} else
	if ( ( count_fldr != 0 )&&( count_file != 0 ) )
	{
		n_posix_sprintf_literal( ret_size, " (%lld %s, %lld %s)", count_fldr, str_fldr, count_file, str_file );
	} else
	if ( count_fldr != 0 )
	{
		n_posix_sprintf_literal( ret_size, " (%lld %s)", count_fldr, str_fldr );
	} else
	if ( count_file != 0 )
	{
		n_posix_sprintf_literal( ret_size, " (%lld %s)", count_file, str_file );
	}


	return;
}

void
n_oc_item_hover2tooltip_size( n_oc_item *p, s64 byte, n_posix_char *ret_size )
{

	const s64 kb = 1000;
	const s64 mb = 1000 * 1000;
	const s64 gb = 1000 * 1000 * 1000;

	double kilobyte = (double) byte / 1000;
	double megabyte = (double) byte / 1000 / 1000;
	double gigabyte = (double) byte / 1000 / 1000 / 1000;


	if ( byte >= gb )
	{
		n_posix_sprintf_literal( ret_size, " (%.0f GB)", gigabyte );
	} else
	if ( byte >= mb )
	{
		n_posix_sprintf_literal( ret_size, " (%.0f MB)", megabyte );
	} else
	if ( byte >= kb )
	{
		n_posix_sprintf_literal( ret_size, " (%.0f KB)", kilobyte );
	} else {
		n_posix_sprintf_literal( ret_size, " (%lld Byte)", byte );
	}


	return;
}

void
n_oc_item_hover2tooltip_rich( n_oc_item *p, const n_posix_char *name, n_posix_char *ret_size )
{

	n_string_truncate( ret_size );

	if ( oc.tooltip_richtip_onoff == n_false ) { return; }

	if ( oc.view_is_computer )
	{

		if ( n_oc_item_hover2tooltip_multifocus_is_on( p ) )
		{

			double disksize = 0;
			double usedsize = 0;
			double freesize = 0;

			n_oc_item_hover2tooltip_multifocus_size_drive( p, &disksize, &usedsize, &freesize );

			double gb_disk = (double) disksize / 1000 / 1000 / 1000;
			//double gb_used = (double) usedsize / 1000 / 1000 / 1000;
			//double gb_free = (double) freesize / 1000 / 1000 / 1000;

			double percent = (double) usedsize / disksize * 100;

			n_posix_sprintf_literal( ret_size, "Multiple Drives (%.3f GB, %d%% used)", gb_disk, (int) percent );

			return;
		}


		if ( p->tooltip_hover == N_ORANGECAT_NOTHING ) { return; }


		if ( n_oc_item_comnputer_is_drive( p, p->tooltip_hover ) )
		{

			u64 disksize = 0;
			u64 usedsize = 0;
			u64 freesize = 0;

			n_sysinfo_drive_size( n_dir_name( &p->dir, p->tooltip_hover ), &disksize, &freesize );
			usedsize = disksize - freesize;

			double gb_disk = (double) disksize / 1000 / 1000 / 1000;
			//double gb_used = (double) usedsize / 1000 / 1000 / 1000;
			//double gb_free = (double) freesize / 1000 / 1000 / 1000;

			double percent = (double) usedsize / disksize * 100;

			n_posix_sprintf_literal( ret_size, " (%.3f GB, %d%% used)", gb_disk, (int) percent );

		}

	} else {
//n_posix_char *folder = n_string_path_folder_current_new();
//n_game_hwndprintf_literal( "%s", folder );
//n_string_path_free( folder );

		if ( n_oc_item_hover2tooltip_multifocus_is_on( p ) )
		{

			int cch = n_posix_sprintf_literal( ret_size, "Multiple Items " );

			s64 count_fldr = 0;
			s64 count_file = 0;

			n_oc_item_hover2tooltip_multifocus_count( p, &count_fldr, &count_file );
			n_oc_item_hover2tooltip_rich_folder( p, count_fldr, count_file, &ret_size[ cch ] );

			if ( count_file != 0 )
			{
				n_posix_structstat_size_t size = 0;

				n_bool overflow = n_oc_item_hover2tooltip_multifocus_size_file( p, &size );
				if ( overflow )
				{
					n_posix_strcat( ret_size, N_STRING_SPACE );
					n_posix_strcat( ret_size, n_posix_literal( "(Overflowed)" ) );
				} else {
					n_posix_char str_size[ 100 ];
					n_oc_item_hover2tooltip_size( p, size, str_size );

					n_posix_strcat( ret_size, N_STRING_SPACE );
					n_posix_strcat( ret_size, str_size );
				}
			}

			return;
		}

		if (
			( p->tooltip_thread != NULL )
			||
			( n_posix_stat_is_dir( name ) )
		)
		{

			s64 count_fldr = 0;
			s64 count_file = 0;

			n_oc_item_hover2tooltip_folder_count( name, &count_fldr, &count_file );
			n_oc_item_hover2tooltip_rich_folder( p, count_fldr, count_file, ret_size );

		} else {

			s64 byte = n_posix_stat_size( name );
			if ( ( byte == 0 )&&( n_posix_stat_size_is_overflowed( name ) ) )
			{
				n_posix_sprintf_literal( ret_size, " (Overflowed)" );
			} else {
				n_oc_item_hover2tooltip_size( p, byte, ret_size );
			}

		}

	}


	return;
}

typedef struct {

	n_oc_item    *item;
	n_posix_char *str;

	n_bool        str_free;
	int           str_cch;
	n_posix_char *str_rich;

} n_oc_item_hover2tooltip_make_thread_struct;

static n_bool n_oc_item_hover2tooltip_make_thread_onoff = n_false;

n_thread_return
n_oc_item_hover2tooltip_make_thread( n_thread_argument arg )
{

	n_oc_item_hover2tooltip_make_thread_struct *p = arg;


	if ( oc.tooltip_richtip_onoff )
	{
		p->str_free = n_true;
		p->str_cch  = n_posix_strlen( p->str );
		p->str_rich = n_string_alloccopy( p->str_cch + 100, p->str );

		if ( n_oc_item_hover2tooltip_multifocus_is_on( p->item ) )
		{
			n_oc_item_hover2tooltip_rich( p->item, p->str,  p->str_rich               );
		} else {
			n_oc_item_hover2tooltip_rich( p->item, p->str, &p->str_rich[ p->str_cch ] );
		}
	} else {
		p->str_rich = p->str;
	}


	n_oc_item_hover2tooltip_make_thread_onoff = n_false;


	return 0;
}

void
n_oc_item_hover2tooltip_make( n_oc_item *p, n_posix_char *str )
{
//return;

	if ( p->drag2select_onoff ) { return; }

	if ( str == NULL ) { return; }

	if ( p->tooltip_phase ) { return; }


	// [Needed] : single core

	n_bool        str_free = n_false;
	n_posix_char *str_rich = NULL;

	if (
//(0)&&
		( n_thread_is_available )
		&&
		( n_sysinfo_version_vista_or_later() )
		&&
		( n_posix_stat_is_dir( str ) )
	)
	{

		n_oc_item_hover2tooltip_make_thread_struct t = { p, str, n_false, 0, NULL };


		n_oc_item_hover2tooltip_make_thread_onoff = n_true;


		p->tooltip_thread = n_thread_init( n_oc_item_hover2tooltip_make_thread, &t );

		u32 timeout = n_posix_tickcount() + N_ORANGECAT_INTERVAL_BASE;
		while( 1 )
		{//break;
			if ( timeout < n_posix_tickcount() )
			{
				str_rich = str;

				break;
			}

			if ( n_oc_item_hover2tooltip_make_thread_onoff == n_false )
			{
				str_free = t.str_free;
				str_rich = t.str_rich;

				break;
			}

			n_posix_sleep( 1 );
		}

		//n_thread_wait( p->tooltip_thread );
		n_thread_exit( p->tooltip_thread );
		p->tooltip_thread = NULL;

	} else {

		if ( oc.tooltip_richtip_onoff )
		{
			s64 str_cch = n_posix_strlen( str );

			str_free = n_true;
			str_rich = n_string_alloccopy( str_cch + 100, str );

			if ( n_oc_item_hover2tooltip_multifocus_is_on( p ) )
			{
				n_oc_item_hover2tooltip_rich( p, str,  str_rich            );
			} else {
				n_oc_item_hover2tooltip_rich( p, str, &str_rich[ str_cch ] );
			}
		} else {
			str_rich = str;
		}

	}


	if ( oc.tooltip_mode & N_ORANGECAT_TOOLTIP_TOOLTIP )
	{

		u32 bg;
		if ( oc.dwm_onoff )
		{
			bg = n_bmp_argb( 16, 255,255,255 );
		} else {
			bg = n_bmp_alpha_replace_pixel( n_win_darkmode_systemcolor_rgb2pal( COLOR_INFOBK ), (double) 255 * 0.9 );
		}

		n_gdi gdi; n_gdi_zero( &gdi );

		gdi.base_color_bg       = bg;
		gdi.base_style          = N_GDI_BASE_SOLID;

		gdi.frame_style         = N_GDI_FRAME_SIMPLE;
		gdi.frame_round         = 0;

		if ( n_IShellLink_is_shortcut( str ) )
		{
			s64 c = 2 + n_posix_strlen( str_rich );
			s64 d = 2;
			s64 e = 2;
			s64 f = N_ISHELLLINK_LNK2PATH_CCH_PATH;
			s64 g = N_ISHELLLINK_LNK2PATH_CCH_ARGS;

			n_posix_char *s = n_string_new( c + d + e + f + g );
			n_posix_char *t = n_string_new( f );
			n_posix_char *u = n_string_new( g );

			n_IShellLink_lnk2path( str, t, u, NULL, NULL );

			if ( n_string_search_simple( t, N_STRING_SPACE ) )
			{
				n_posix_sprintf_literal( s, "%s (\"%s\" %s)", str_rich, t, u );
			} else {
				n_posix_sprintf_literal( s, "%s (%s %s)", str_rich, t, u );
			}

			if ( str_free ) { n_string_free( str_rich ); }

			str_rich = s;
			str_free = n_true;

			n_string_free( t );
			n_string_free( u );
		}

		gdi.text                = str_rich;
		gdi.text_font           = n_oc_font_name;
		gdi.text_size           = n_oc_font_size;
		gdi.text_color_main     = n_win_darkmode_systemcolor_rgb2pal( COLOR_INFOTEXT );
		gdi.text_style          = n_oc_font_smooth &~N_GDI_TEXT_BOLD;

		if ( oc.dwm_onoff )
		{
			gdi.text_color_main    = oc_color.item_text;
			gdi.text_color_contour = oc_color.item_shadow;
			gdi.text_style         = n_oc_font_smooth;
			gdi.text_fxsize1       = 0;
			gdi.text_fxsize2       = oc.view_text_fxsize + oc.unit_scal;

		}

		gdi.style |=  N_GDI_CALCONLY;
		n_gdi_bmp( &gdi, &p->tooltip_bmp );
		gdi.style &= ~N_GDI_CALCONLY;


		s32 p_sx = gdi.sx;

		gdi.sx = n_posix_min_s32( gdi.sx, p->sx );

		if ( p_sx != gdi.sx ) { gdi.align = N_GDI_ALIGN_LEFT; }


		n_gdi_bmp( &gdi, &p->tooltip_bmp );


		p->tooltip_phase = N_OC_HOVER2TOOLTIP_PHASE_FADE_IN;
		n_oc_item_hover2tooltip_fade_on( p );

	}


	if ( oc.tooltip_mode & N_ORANGECAT_TOOLTIP_CAPTION )
	{
		n_game_hwndprintf_literal( "%s", str_rich );
	}


	if ( str_free ) { n_string_free( str_rich ); }


	p->tooltip_index = p->tooltip_hover;


	return;
}

void
n_oc_item_hover2tooltip_make_tip( n_oc_item *p )
{

	n_bool        is_allocated = n_false;
	n_posix_char *s;

	if ( p->find_onoff )
	{
		s = n_oc_item_index2path_new( p, p->tooltip_hover );
		is_allocated = n_true;
	} else {
		s = n_dir_name( &p->dir, p->tooltip_hover );

		if ( oc.view_is_computer )
		{
			if ( n_string_path_is_abspath( s ) )
			{
				s = n_oc_item_drivename_new( p, s );
				is_allocated = n_true;
			}
		}
	}

	n_oc_item_hover2tooltip_make( p, s );

	if ( is_allocated ) { n_string_free( s ); }


	return;
}

void
n_oc_item_hover2tooltip_erase( n_oc_item *p )
{

	if ( p->drag2select_onoff ) { return; }


	// [!] : Slow Mode

	if (
		( p->view_type != N_ORANGECAT_VIEW_TYPE_LOGO )
		&&
		( p->view_type != N_ORANGECAT_VIEW_TYPE_ICON )
	)
	{

		n_oc_item_erase( &item );
		n_oc_item_draw ( &item );

		return;
	}


	// [!] : Fast Mode

	s32 fx =           N_BMP_SX( &p->tooltip_bmp );
	s32 fy = game.sy - N_BMP_SY( &p->tooltip_bmp );

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		fy -= oc.unit_scrl;
	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{
		if ( fx > ( game.sx - oc.unit_scrl ) ) { return; }
	}


	n_bool *index = n_memory_new( p->count * sizeof( n_bool ) );
	n_memory_zero( index, p->count * sizeof( n_bool ) );


	n_bool debug_onoff = n_false;


	s32 index_f, index_t; n_oc_item_scan_index( &item, &index_f, &index_t, n_false );
	s32 start_f = index_f;
	while( 1 )
	{//break;

		if ( index_f >= index_t ) { break; }

		n_bmp *t = &p->bmp[ index_f ];
		if ( NULL != N_BMP_PTR( t ) )
		{

			s32  x = 0;
			s32  y = 0;
			//s32 sx = n_oc_item_lineselection( p, N_BMP_SX( t ) );
			s32 sy = N_BMP_SY( t ); 

			n_oc_item_position_calculate( p, index_f, &x, &y, n_true );

			if (
				( ( x +  0 ) <  fx )
				&&
				( ( y + sy ) >= fy )
			)
			{
if ( debug_onoff ) { n_bmp_box( &game.bmp, x,y,N_BMP_SX( t ),N_BMP_SY( t ), n_bmp_rgb( 0,200,255 ) ); }
				index[ index_f ] = n_true;
			}

		}

		index_f++;

	}


	{
		s32 sx = N_BMP_SX( &p->tooltip_bmp );
		s32 sy = N_BMP_SY( &p->tooltip_bmp );

		//u32 c  = n_bmp_rgb( 0,200,255 );
		u32 c  = n_oc_item_color_bg( p, 0 );

		s32 x = 0;
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
		{
			if ( n_win_is_lefthanded() ) { x = n_posix_max( oc.unit_scrl, game.sx - sx ); }
		}

		n_bmp_box( &game.bmp, x,fy,sx,sy, c );
	}


	index_f = start_f;
	while( 1 )
	{

		if ( index_f >= index_t ) { break; }

		if ( ( debug_onoff == n_false )&&( index[ index_f ] ) )
		{
			//n_bmp_fade_redraw( &p->fade[ index_f ] );
			n_oc_item_draw_single( p, index_f, n_true );
		}

		index_f++;

	}


	n_memory_free( index );


	return;
}

void
n_oc_item_hover2tooltip_position( n_oc_item *p, s32 *x, s32 *y )
{

	s32 bmpsx = N_BMP_SX( &p->tooltip_bmp );
	s32 bmpsy = N_BMP_SY( &p->tooltip_bmp );

	s32 fx = 0;
	s32 fy = game.sy - bmpsy;

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{
		if ( n_win_is_lefthanded() ) { fx = n_posix_max( oc.unit_scrl, game.sx - bmpsx ); }
	}

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO ) { fy -= oc.unit_scrl; }
	if ( p->view_type >= N_ORANGECAT_VIEW_TYPE_PATH ) { fx = game.sx - oc.unit_scrl - bmpsx; }


	if ( x != NULL ) { (*x) = fx; }
	if ( y != NULL ) { (*y) = fy; }


	return;
}

void
n_oc_item_hover2tooltip_draw( n_oc_item *p, n_bool always_draw )
{
//n_game_hwndprintf_literal( " %d %d ", p->hover, p->tooltip_hover );


	if ( p->drag2select_onoff ) { return; }


	n_bmp_fade *fade = &p->tooltip_fade;


//n_game_hwndprintf_literal( " %d %d ", p->tooltip_hover, p->tooltip_phase );

	if ( ( always_draw == n_false )&&( p->tooltip_hover != p->tooltip_index ) )
	{

		if ( p->tooltip_hover == N_ORANGECAT_NOTHING )
		{
//n_game_hwndprintf_literal( " %d %d ", p->tooltip_index, p->tooltip_phase );

			if ( p->tooltip_phase == N_OC_HOVER2TOOLTIP_PHASE_FADE_IN )
			{
				p->tooltip_phase = N_OC_HOVER2TOOLTIP_PHASE_FADEOUT;
				n_oc_item_hover2tooltip_fade_on( p );
			} else
			if ( p->tooltip_phase == N_OC_HOVER2TOOLTIP_PHASE_FADEOUT )
			{
				if ( fade->percent == 100 )
				{
					p->tooltip_phase = N_OC_HOVER2TOOLTIP_PHASE_NEUTRAL;
				}
			}

		} else {

			n_oc_item_hover2tooltip_erase( p );

			p->tooltip_phase = N_OC_HOVER2TOOLTIP_PHASE_NEUTRAL;

			n_oc_item_hover2tooltip_make_tip( p );

		}

	}


	n_bmp_fade_engine( fade, oc.fade_onoff );

//n_game_hwndprintf_literal( " %08x %08x %08x : %08x ", fade->color_fg, fade->color_bg, fg, oc_color.bg );


	if ( always_draw )
	{
		p->tooltip_phase = N_OC_HOVER2TOOLTIP_PHASE_NEUTRAL;
		n_oc_item_hover2tooltip_make_tip( p );

		p->tooltip_phase = N_OC_HOVER2TOOLTIP_PHASE_FADE_IN;
		fade->percent    = 100;
	}


	s32 bmpsx = N_BMP_SX( &p->tooltip_bmp );
	s32 bmpsy = N_BMP_SY( &p->tooltip_bmp );
//n_game_hwndprintf_literal( " %d ", game.sx - oc.unit_scrl - bmpsx );

	if ( ( game.sx - oc.unit_scrl - bmpsx ) < 0 ) { return; }
	if ( ( game.sy - oc.unit_path - bmpsy ) < 0 ) { return; }

//return;

	if ( p->tooltip_phase == N_OC_HOVER2TOOLTIP_PHASE_FADE_IN )
	{

		if ( p->tooltip_percent != fade->percent )
		{
			p->tooltip_percent = fade->percent;

			double ratio = (double) ( 100 - fade->percent ) / 100;
//n_game_hwndprintf_literal( " %d ", fade->percent );

			s32 fx,fy; n_oc_item_hover2tooltip_position( p, &fx,&fy );

			n_oc_item_hover2tooltip_erase( p );

			if ( n_false == n_win_is_hovered_offset( game.hwnd, fx,fy, bmpsx,bmpsy ) )
			{
				n_bmp_blendcopy( &p->tooltip_bmp, &game.bmp, 0,0,bmpsx,bmpsy, fx,fy, ratio );
			}

			n_game_refresh_on();

		}

	} else
	if ( p->tooltip_phase == N_OC_HOVER2TOOLTIP_PHASE_FADEOUT )
	{

		if ( p->tooltip_percent != fade->percent )
		{
			p->tooltip_percent = fade->percent;

			double ratio = (double) ( fade->percent ) / 100;
//n_game_hwndprintf_literal( " %d ", fade->percent );

			s32 fx,fy; n_oc_item_hover2tooltip_position( p, &fx,&fy );

			n_oc_item_hover2tooltip_erase( p );

			if ( n_false == n_win_is_hovered_offset( game.hwnd, fx,fy, bmpsx,bmpsy ) )
			{
				n_bmp_blendcopy( &p->tooltip_bmp, &game.bmp, 0,0,bmpsx,bmpsy, fx,fy, ratio );
			}

			n_game_refresh_on();
		}

	}


	return;
}

void
n_oc_item_hover2tooltip_collision( n_oc_item *p )
{
//return;

	// [!] : this module causes too many redrawing while delayed loading
	//n_oc_item_on_click( p );


	int    hover_index = N_ORANGECAT_NOTHING;
	n_bool hover_onoff = n_false;

	n_oc_item_collision( p, &hover_index, &hover_onoff, n_false );
//n_game_hwndprintf_literal( " %d %d ", hover_onoff, hover_index );

	if ( ( hover_onoff )&&( hover_index != N_ORANGECAT_NOTHING ) )
	{
		p->tooltip_hover   = hover_index;
		p->tooltip_percent = N_ORANGECAT_NOTHING;

		n_oc_item_hover2tooltip_draw( p, n_true );
	}


	return;
}

void
n_oc_item_hover2tooltip_main( n_oc_item *p )
{
//return;
//n_game_hwndprintf_literal( " %d %d ", oc.event, p->tooltip_phase );


	if ( p->drag2select_onoff ) { return; }


	if ( oc.tooltip_mode == N_ORANGECAT_TOOLTIP_NONE ) { return; }


	static n_bool once = n_false;

	if ( ( oc.view_prev == N_ORANGECAT_VIEW_FILE )&&( oc.view == N_ORANGECAT_VIEW_INFO ) )
	{

		once = n_true;

		p->tooltip_phase = N_OC_HOVER2TOOLTIP_PHASE_NEUTRAL;

		return;
	} else
	if ( ( oc.view_prev == N_ORANGECAT_VIEW_INFO )&&( oc.view == N_ORANGECAT_VIEW_FILE ) )
	{
		if ( once )
		{
			once = n_false;

			if ( oc.transition_onoff == n_false )
			{
				n_oc_item_hover2tooltip_collision( p );
				return;
			}
		}
	}


	p->tooltip_hover = p->hover;

	if ( oc.view_is_key_operation )
	{
		p->tooltip_hover = n_oc_item_multifocus_single( p );
	}


//n_game_hwndprintf_literal( " %d %d ", p->hover_prv, p->tooltip_hover );

	if ( p->hover_prv != p->tooltip_hover )
	{

		if ( p->tooltip_hover != N_ORANGECAT_NOTHING )
		{
//n_game_hwndprintf_literal( " 1 " );
			n_oc_item_hover2tooltip_make_tip( p );
		} else {
//n_game_hwndprintf_literal( " 2 " );
			if ( oc.tooltip_mode & N_ORANGECAT_TOOLTIP_CAPTION )
			{
				n_game_hwndprintf_literal( "%s", N_ORANGECAT_APPNAME );
			}
		}

	} else {
//n_game_hwndprintf_literal( " 3 " );
	}

	p->hover_prv = p->tooltip_hover;


	if ( oc.tooltip_mode & N_ORANGECAT_TOOLTIP_TOOLTIP )
	{
		n_oc_item_hover2tooltip_draw( p, n_false );
	}


	return;
}


