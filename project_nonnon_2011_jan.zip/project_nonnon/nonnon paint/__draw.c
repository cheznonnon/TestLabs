// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/bmp.c"
#include "../nonnon/neutral/bmp/all.c"




void
n_bmp_line_reverse( n_bmp *bmp, n_bmp *bmp_onoff, s32 fx, s32 fy, s32 tx, s32 ty )
{

	if ( n_bmp_error( bmp ) ) { return; }


	double step = 0;
	double unit = (double) abs( fy - ty ) / n_posix_max_s32( 1, abs( fx - tx ) );


	while( 1 )
	{

		// [!] : need to draw the first pos

		u32 onoff;
		n_bmp_ptr_get( bmp_onoff, fx,fy, &onoff );
		if ( onoff == 0 )
		{

			n_bmp_ptr_set( bmp_onoff, fx,fy, 1 );


			u32 color;
			n_bmp_ptr_get( bmp, fx,fy, &color );

			int a = 255 - n_bmp_a( color );
			int r = 255 - n_bmp_r( color );
			int g = 255 - n_bmp_g( color );
			int b = 255 - n_bmp_b( color );

			color = n_bmp_argb( a,r,g,b );

			n_bmp_ptr_set( bmp, fx,fy, color );

		}


		// [!] : need to draw tx,ty once or more

		if ( ( fx == tx )&&( fy == ty ) ) { break; }


		// [!] : don't use "else" : avoid zig-zag

		if ( step < 1 )
		{
			step += unit;
			if ( fx > tx ) { fx--; } else if ( fx < tx ) { fx++; }
		}

		if ( step >= 1 )
		{
			step -= 1;
			if ( fy > ty ) { fy--; } else if ( fy < ty ) { fy++; }
		}

	}


	return;
}

void
n_bmp_frame_reverse( n_bmp *bmp, n_bmp *bmp_onoff, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32 fx = x;
	s32 fy = y;
	s32 tx = x + sx - 1;
	s32 ty = y + sy - 1;


	// Top
	n_bmp_line_reverse( bmp, bmp_onoff, fx,fy-0,tx,fy-0 );
	n_bmp_line_reverse( bmp, bmp_onoff, fx,fy-1,tx,fy-1 );

	// Bottom
	n_bmp_line_reverse( bmp, bmp_onoff, fx,ty+0,tx,ty+0 );
	n_bmp_line_reverse( bmp, bmp_onoff, fx,ty+1,tx,ty+1 );


	fy++;
	ty--;

	// Left
	n_bmp_line_reverse( bmp, bmp_onoff, fx-0,fy,fx-0,ty );
	n_bmp_line_reverse( bmp, bmp_onoff, fx-1,fy,fx-1,ty );

	// Right
	n_bmp_line_reverse( bmp, bmp_onoff, tx+0,fy,tx+0,ty );
	n_bmp_line_reverse( bmp, bmp_onoff, tx+1,fy,tx+1,ty );


	return;
}

u32
n_bmp_checker_pixel( s32 x, s32 y, s32 sx, s32 sy, u32 color )
{

	// [!] : ( n & 31 ) == ( n % 32 )


	s32 mod_sx = ( sx & 31 ) / 2;
	s32 mod_sy = ( sy & 31 ) / 2;

	x -= mod_sx;
	y -= mod_sy;


	s32 mod_x = ( x & 31 );
	s32 mod_y = ( y & 31 );

	if (
		( ( 16 >  mod_x )&&( 16 >  mod_y ) )
		||
		( ( 16 <= mod_x )&&( 16 <= mod_y ) )
	)
	{
		double ratio = 0.75;//n_bmp_blend_alpha2ratio( color );
		color = n_bmp_blend_pixel( n_bmp_white, color, ratio );
	}


	return color;
}

void
n_draw_line( n_bmp *bmp, s32 fx, s32 fy, s32 tx, s32 ty, u32 color, s32 circle_step, s32 real_step )
{

	if ( n_bmp_error( bmp ) ) { return; }


	double step = 0;
	double unit = (double) abs( fy - ty ) / n_posix_max_s32( 1, abs( fx - tx ) );


	s32 full = circle_step;
	s32 half = real_step / 2;


	s32 i = 0;
	while( 1 )
	{

		// [!] : need to draw the first pos

		if ( ( i == 0 )||( 0 == ( i % full ) ) )
		{
			n_bmp_circle( bmp, fx - half, fy - half, full, full, full, color );
		}


		// [!] : need to draw tx,ty once or more

		if ( ( fx == tx )&&( fy == ty ) ) { break; }


		// [!] : don't use "else" : avoid zig-zag

		if ( step < 1 )
		{
			step += unit;
			if ( fx > tx ) { fx--; } else if ( fx < tx ) { fx++; }
		}

		if ( step >= 1 )
		{
			step -= 1;
			if ( fy > ty ) { fy--; } else if ( fy < ty ) { fy++; }
		}


		i++;

	}


	return;
}

void
n_draw_frame( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, u32 fg, u32 bg )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32 fx  = x;
	s32 fy  = y;
	s32 tx  = x + sx - 1;
	s32 ty  = y + sy - 1;


	// Top
	n_bmp_line_dot( bmp, fx,fy,tx,fy, fg, 1 );
	n_bmp_line_dot( bmp, fx,fy,tx,fy, bg, 2 );

	// Bottom
	n_bmp_line_dot( bmp, fx,ty,tx,ty, fg, 1 );
	n_bmp_line_dot( bmp, fx,ty,tx,ty, bg, 2 );


	fy++;
	ty--;

	// Left
	n_bmp_line_dot( bmp, fx,fy,fx,ty, fg, 1 );
	n_bmp_line_dot( bmp, fx,fy,fx,ty, bg, 2 );

	// Right
	n_bmp_line_dot( bmp, tx,fy,tx,ty, fg, 1 );
	n_bmp_line_dot( bmp, tx,fy,tx,ty, bg, 2 );


	return;
}

void
n_draw_gdi_box( HDC hdc, s32 fx, s32 fy, s32 tx, s32 ty, HGDIOBJ hb )
{

	RECT r = { fx,fy,tx,ty };


	FillRect( hdc, &r, hb );
	ExcludeClipRect( hdc, fx,fy,tx,ty );


	return;
}

void
n_draw_gdi_frame2canvas( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, RECT r, COLORREF fg, COLORREF bg )
{

	s32 size = 2;

	s32 fx,tx,fy,ty;


	HGDIOBJ hb_fg = CreateSolidBrush( fg );
	HGDIOBJ hb_bg = CreateSolidBrush( bg );


	// [!] : Top / Bottom

	fx = x - size;
	tx = x + sx;
	fy = y - size;
	ty = y + sy;

	while( 1 )
	{

		POINT pt_u = { fx, fy };
		POINT pt_d = { fx, ty };

		if ( PtInRect( &r, pt_u ) )
		{
			n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_fg );
		}
		if ( PtInRect( &r, pt_d ) )
		{
			n_draw_gdi_box( hdc, fx, ty, fx + size, ty + size, hb_fg );
		}

		fx += size;

		if ( PtInRect( &r, pt_u ) )
		{
			n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_bg );
		}
		if ( PtInRect( &r, pt_d ) )
		{
			n_draw_gdi_box( hdc, fx, ty, fx + size, ty + size, hb_bg );
		}

		fx += size;

		if ( fx >= tx ) { break; }
	}


	// [!] : Left / Right

	fx = x - size;
	tx = x + sx;
	fy = y - size;
	ty = y + sy;

	while( 1 )
	{//break;

		POINT pt_l = { fx, fy };
		POINT pt_r = { tx, fy };

		if ( PtInRect( &r, pt_l ) ) { n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_fg ); }
		if ( PtInRect( &r, pt_r ) ) { n_draw_gdi_box( hdc, tx, fy, tx + size, fy + size, hb_fg ); }

		fy += size;

		if ( PtInRect( &r, pt_l ) ) { n_draw_gdi_box( hdc, fx, fy, fx + size, fy + size, hb_bg ); }
		if ( PtInRect( &r, pt_r ) ) { n_draw_gdi_box( hdc, tx, fy, tx + size, fy + size, hb_bg ); }

		fy += size;

		if ( fy >= ty ) { break; }
	}


	DeleteObject( hb_fg );
	DeleteObject( hb_bg );


	return;
}

void
n_draw_gdi_clear( HDC hdc, HWND hwnd, COLORREF color )
{

	// [!] : Classic Theme : alpha value causes black-out

	color &= 0x00ffffff;


	HBRUSH hb = CreateSolidBrush( color );
	RECT   r;   GetClientRect( hwnd, &r );

	FillRect( hdc, &r, hb );

	DeleteObject( hb );


	return;
}

void
n_draw_gdi_clear_simple( HWND hwnd, COLORREF color )
{

	HDC hdc = GetDC( hwnd );

	n_draw_gdi_clear( hdc, hwnd, color );

	ReleaseDC( hwnd, hdc );


	return;
}

void
n_draw_gdi_mask( HDC hdc, HWND hgui )
{

	s32 x,y,sx,sy;
	n_win_location( hgui, &x, &y, &sx, &sy );

	ExcludeClipRect( hdc, x, y, x + sx, y + sy );


	return;
}

