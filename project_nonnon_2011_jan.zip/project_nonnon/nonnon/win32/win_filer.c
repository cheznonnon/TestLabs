// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_FILER
#define _H_NONNON_WIN32_WIN_FILER




#include "../neutral/filer.c"


#include "./win_richdialog.c"

#include "./sysinfo/version.c"




// internal
int
n_win_filer_text_style( void )
{
	return N_GDI_TEXT_BOLD;
}

// internal
s32
n_win_filer_text_minsx( void )
{

	s32 sx,sy; n_win_desktop_size( &sx, &sy );

	return (double) n_posix_min_s32( sx, sy ) * 0.4;
}

// internal
void
n_win_filer_text_precalc( n_gdi *gdi, s32 *sx, s32 *sy )
{

	n_gdi g = (*gdi);

	g.style |= N_GDI_CALCONLY; n_gdi_bmp( &g, NULL );

	if ( sx != NULL ) { (*sx) = g.sx; }
	if ( sy != NULL ) { (*sy) = g.sy; }


	return;
}

#define n_win_filer_text_space_add( s, c ) n_win_filer_text_space( s, c,  true )
#define n_win_filer_text_space_del( s, c ) n_win_filer_text_space( s, c, false )

// internal
void
n_win_filer_text_space( n_posix_char *str, size_t count, bool is_add )
{

	// [!] : unsafe module

	if ( str == NULL ) { return; }

	if ( count == 0 ) { return; }


	size_t cch = n_posix_strlen( str );


	size_t i = 0;
	while( 1 )
	{

		if ( is_add )
		{
			str[ cch + i + 0 ] = N_STRING_CHAR_SPACE;
			str[ cch + i + 1 ] = N_STRING_CHAR_NUL;
		} else {
			str[ cch - i + 0 ] = N_STRING_CHAR_NUL;

		}

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

// internal
void
n_win_filer_text_separator( n_gdi *gdi, s32 max_sx )
{

	s32 space_sx; n_win_stdsize_text( NULL, N_STRING_SPACE, &space_sx, NULL );

	n_win_filer_text_space_add( gdi->text, max_sx / space_sx );


	// [!] : don't use bool

	int move = 0;

	// [x] : buggy : doesn't reach break; in some cases

	int cch = n_posix_strlen( gdi->text );

	int i = 0;
	while( 1 )
	{

		s32 sx; n_win_filer_text_precalc( gdi, &sx, NULL );
		if ( sx == max_sx )
		{
			break;
		} else
		if ( sx < max_sx )
		{
			if ( move == -1 ) { break; } else { i++; move =  1; }
			n_win_filer_text_space_add( gdi->text, 1 );
		} else
		if ( sx > max_sx )
		{
			n_win_filer_text_space_del( gdi->text, 1 );
			if ( move ==  1 ) { break; } else { i++; move = -1; }
		}

		if ( i >= cch ) { break; }
	}


	return;
}

// internal
void
n_win_filer_ui( const n_posix_char *title, const n_posix_char *f, const n_posix_char *t )
{


	n_win_richdialog_init( &n_win_richdialog_instance, 8, title );


	n_gdi *gdi = n_win_richdialog_instance.gdi;


	int o_f = 0;
	int o_t = 4;


	s32 max_sx;

	{

		gdi[ o_f + 1 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ o_f + 1 ].icon        = n_string_carboncopy( f );
		gdi[ o_f + 1 ].text        = n_string_carboncopy( f );
		gdi[ o_f + 1 ].text_style |= n_win_filer_text_style();

		gdi[ o_t + 1 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ o_t + 1 ].icon        = n_string_carboncopy( t );
		gdi[ o_t + 1 ].text        = n_string_carboncopy( t );
		gdi[ o_t + 1 ].text_style |= n_win_filer_text_style();


		s32 f_sx; n_win_filer_text_precalc( &gdi[ o_f + 1 ], &f_sx, NULL );
		s32 t_sx; n_win_filer_text_precalc( &gdi[ o_t + 1 ], &t_sx, NULL );

		max_sx = n_posix_max_s32( n_win_filer_text_minsx(), n_posix_max_s32( f_sx, t_sx ) );

	}


	{

		gdi[ o_f + 0 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ o_f + 0 ].text        = n_string_new( 4 + max_sx );
		gdi[ o_f + 0 ].text_style |= N_GDI_TEXT_UNDERLINE;

		gdi[ o_t + 0 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ o_t + 0 ].text        = n_string_new( 4 + max_sx );
		gdi[ o_t + 0 ].text_style |= N_GDI_TEXT_UNDERLINE;


		n_posix_sprintf_literal( gdi[ o_f + 0 ].text, "From" );
		n_posix_sprintf_literal( gdi[ o_t + 0 ].text, "To  " );

		n_win_filer_text_separator( &gdi[ o_f + 0 ], max_sx );
		n_win_filer_text_separator( &gdi[ o_t + 0 ], max_sx );

	}


	if ( n_posix_stat_is_dir( f ) )
	{

		gdi[ o_f + 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_f + 2 ].text        = n_string_new( 100 );

		gdi[ o_t + 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_t + 2 ].text        = n_string_new( 100 );

		n_posix_sprintf_literal( gdi[ o_f + 2 ].text, "%s", n_posix_literal( "Folder" ) );
		n_posix_sprintf_literal( gdi[ o_t + 2 ].text, "%s", n_posix_literal( "Folder" ) );

	} else {

		gdi[ o_f + 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_f + 2 ].text        = n_string_new( 100 );

		gdi[ o_t + 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_t + 2 ].text        = n_string_new( 100 );


		size_t size_f = n_posix_stat_size( f );
		size_t size_t = n_posix_stat_size( t );

		n_posix_sprintf_literal( gdi[ o_f + 2 ].text, "%lu Byte", (u32) size_f );
		n_posix_sprintf_literal( gdi[ o_t + 2 ].text, "%lu Byte", (u32) size_t );


		if ( size_f > size_t )
		{
			gdi[ o_f + 2 ].text_style |= n_win_filer_text_style();
			n_posix_strcat( gdi[ o_f + 2 ].text, n_posix_literal(" (Larger)" ) );
			n_posix_strcat( gdi[ o_t + 2 ].text, n_posix_literal(" (Smaller)") );
		} else
		if ( size_f < size_t )
		{
			gdi[ o_t + 2 ].text_style |= n_win_filer_text_style();
			n_posix_strcat( gdi[ o_f + 2 ].text, n_posix_literal(" (Smaller)") );
			n_posix_strcat( gdi[ o_t + 2 ].text, n_posix_literal(" (Larger)" ) );
		}

	}


	if ( n_posix_stat_is_dir( f ) )
	{

		//

	} else {

		gdi[ o_f + 3 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_f + 3 ].text        = n_string_new( 100 );

		gdi[ o_t + 3 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_t + 3 ].text        = n_string_new( 100 );


		n_time_string_mtime( f, gdi[ o_f + 3 ].text );
		n_time_string_mtime( t, gdi[ o_t + 3 ].text );


		int ret = n_time_compare_mtime( f, t );
		if ( ret ==  1 )
		{
			gdi[ o_f + 3 ].text_style |= n_win_filer_text_style();
			n_posix_strcat( gdi[ o_f + 3 ].text, n_posix_literal(" (Newer)") );
			n_posix_strcat( gdi[ o_t + 3 ].text, n_posix_literal(" (Older)") );
		}
		if ( ret == -1 )
		{
			gdi[ o_t + 3 ].text_style |= n_win_filer_text_style();
			n_posix_strcat( gdi[ o_f + 3 ].text, n_posix_literal(" (Older)") );
			n_posix_strcat( gdi[ o_t + 3 ].text, n_posix_literal(" (Newer)") );
		}

	}


	return;
}

bool
n_win_filer_replace( HWND hwnd, const n_posix_char *f, const n_posix_char *t, bool *is_cancelled )
{

	if ( is_cancelled != NULL ) { (*is_cancelled) = false; }


	if ( false == n_posix_stat_is_exist( f ) ) { return true; }
	if ( false == n_posix_stat_is_exist( t ) )
	{

		n_win_cursor_add( NULL, IDC_WAIT );

		bool ret = n_filer_copy( f, t );

		n_win_cursor_add( NULL, IDC_ARROW );

		return ret;
	}

	if ( n_string_is_same( f, t ) ) { return true; }

	if ( n_filer_is_locked( t ) ) { return true; }


	n_win_filer_ui( n_posix_literal( "Replace" ), f, t );


	bool is_ok = n_win_richdialog_go( &n_win_richdialog_instance, hwnd );
//n_posix_debug_literal( " %d ", is_ok );

	if ( is_ok )
	{

		n_win_cursor_add( NULL, IDC_WAIT );


		n_posix_char *dir = n_string_path_upperfolder_new( t );
		n_posix_char *tmp = n_string_path_tmpname_new( N_STRING_EMPTY );
		n_posix_char *nam = n_string_path_make_new( dir, tmp );


		bool ret = n_string_path_rename( t, nam );
		if ( ret )
		{

			// [!] : Error : nothing to do

		} else {

			ret = n_filer_copy( f, t );
			if ( ret )
			{

				// [!] : Failed : restore an old one

				ret = n_filer_remove( t );
				if ( ret == false ) { ret = n_string_path_rename( nam, t ); }

			} else {

				// [!] : Succeeded : remove an old one

				ret = n_filer_remove( nam );

			}

		}


		n_string_path_free( dir );
		n_string_path_free( tmp );
		n_string_path_free( nam );


		n_win_cursor_add( NULL, IDC_ARROW );


		return ret;
	}


	// [!] : Cancelled

	if ( is_cancelled != NULL ) { (*is_cancelled) = true; }


	return false;
}

bool
n_win_filer_merge( HWND hwnd, const n_posix_char *f, const n_posix_char *t, bool *is_cancelled )
{

	if ( is_cancelled != NULL ) { (*is_cancelled) = false; }


	if ( false == n_posix_stat_is_exist( f ) ) { return true; }
	if ( false == n_posix_stat_is_exist( t ) )
	{
		
		n_win_cursor_add( NULL, IDC_WAIT );

		bool ret = n_filer_copy( f, t );

		n_win_cursor_add( NULL, IDC_ARROW );

		return ret;
	}

	if ( n_string_is_same( f, t ) ) { return true; }

	if ( n_filer_is_locked( t ) ) { return true; }


	n_win_filer_ui( n_posix_literal( "Merge" ), f, t );


	bool is_ok = n_win_richdialog_go( &n_win_richdialog_instance, hwnd );
//n_posix_debug_literal( " %d ", is_ok );

	if ( is_ok )
	{

		n_win_cursor_add( NULL, IDC_WAIT );


		n_filer_merge( f, t );


		n_win_cursor_add( NULL, IDC_ARROW );


		return false;
	}


	// [!] : Cancelled

	if ( is_cancelled != NULL ) { (*is_cancelled) = true; }


	return false;
}

bool
n_win_filer_move( HWND hwnd, const n_posix_char *f, const n_posix_char *t, bool *is_cancelled )
{
//n_posix_debug_literal( "%s\n%s", f, t );

	if ( is_cancelled != NULL ) { (*is_cancelled) = false; }


	if ( n_string_is_empty( f ) ) { return true; }
	if ( n_string_is_empty( t ) ) { return true; }

	if ( false == n_posix_stat_is_exist( f ) ) { return true; }
	if ( false == n_posix_stat_is_exist( t ) )
	{
		// [!] : same drives => simply rename

		if ( f[ 0 ] == t[ 0 ] )
		{

			return ( -1 == n_posix_rename( f, t ) );

		} else {

			n_win_cursor_add( NULL, IDC_WAIT );

			bool ret = n_filer_is_locked( f );
			if ( ret == false )
			{
				ret = n_filer_copy( f, t );
				if ( ret == false )
				{
					ret = n_filer_remove( f );
				}

			}

			n_win_cursor_add( NULL, IDC_ARROW );

			return ret;
		}
	}

	if ( n_string_is_same( f, t ) ) { return true; }

	if ( n_filer_is_locked( t ) ) { return true; }


	n_win_filer_ui( n_posix_literal( "Move" ), f, t );


	bool is_ok = n_win_richdialog_go( &n_win_richdialog_instance, hwnd );
//n_posix_debug_literal( " %d ", is_ok );

	if ( is_ok )
	{

		n_win_cursor_add( NULL, IDC_WAIT );


		n_posix_char *dir = n_string_path_upperfolder_new( t );
		n_posix_char *tmp = n_string_path_tmpname_new( N_STRING_EMPTY );
		n_posix_char *nam = n_string_path_make_new( dir, tmp );


		bool ret = n_string_path_rename( t, nam );
		if ( ret )
		{

			// [!] : Error : nothing to do

		} else
		if ( false == n_filer_is_locked( f ) )
		{

			ret = n_filer_copy( f, t );
			if ( ret )
			{

				// [!] : Failed : restore an old one

				ret = n_filer_remove( t );
				if ( ret == false ) { ret = n_string_path_rename( nam, t ); }

			} else {

				// [!] : Succeeded : remove an old one

				ret = n_filer_remove( nam );


				// [!] : integrity checker

				if ( n_filer_is_same( f, t ) )
				{

					// [!] : Succeeded

					ret = false;
					n_filer_remove( f );

				} else {

					// [!] : Failed : cleanup is needed

					ret = true;
					n_filer_remove( t );

				}

			}

		}


		n_string_path_free( dir );
		n_string_path_free( tmp );
		n_string_path_free( nam );


		n_win_cursor_add( NULL, IDC_ARROW );


		return ret;
	}


	// [!] : Cancelled

	if ( is_cancelled != NULL ) { (*is_cancelled) = true; }


	return false;
}

bool
n_win_filer_delete( HWND hwnd, const n_posix_char *t, bool *is_cancelled )
{

	if ( is_cancelled != NULL ) { (*is_cancelled) = false; }


	if ( false == n_posix_stat_is_exist( t ) ) { return true; }

	if ( n_filer_is_locked( t ) ) { return true; }


	n_win_richdialog_init( &n_win_richdialog_instance, 5, n_posix_literal( "Delete" ) );


	n_gdi *gdi = n_win_richdialog_instance.gdi;


	s32 max_sx;

	{

		gdi[ 1 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ 1 ].icon        = n_string_carboncopy( t );
		gdi[ 1 ].text        = n_string_carboncopy( t );
		gdi[ 1 ].text_style |= n_win_filer_text_style();

		s32 sx; n_win_filer_text_precalc( &gdi[ 1 ], &sx, NULL );
		max_sx = n_posix_max_s32( n_win_filer_text_minsx(), sx );

	}


	{

		gdi[ 0 ].text = n_string_new( max_sx );

		n_win_filer_text_separator( &gdi[ 0 ], max_sx );

		gdi[ 4 ] = gdi[ 0 ];

	}


	{

		gdi[ 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ 2 ].text        = n_string_new( 100 );

		size_t size = n_posix_stat_size( t );

		n_posix_sprintf_literal( gdi[ 2 ].text, "%lu Byte", (u32) size );

	}


	{

		gdi[ 3 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ 3 ].text        = n_string_new( 100 );

		n_time_string_mtime( t, gdi[ 3 ].text );

	}


	bool is_ok = n_win_richdialog_go( &n_win_richdialog_instance, hwnd );
	if ( is_ok )
	{

		n_win_cursor_add( NULL, IDC_WAIT );

		bool ret = n_filer_remove( t );

		n_win_cursor_add( NULL, IDC_ARROW );

		return ret;
	}


	// [!] : Cancelled

	if ( is_cancelled != NULL ) { (*is_cancelled) = true; }


	return false;
}


#endif // _H_NONNON_WIN32_WIN_FILER

