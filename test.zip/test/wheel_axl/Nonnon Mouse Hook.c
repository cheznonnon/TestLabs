// Nonnon Wheel Axl
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : Win9x
//
//	WH_MOUSE_LL is not available
//	WH_MOUSE can run but Explorer will crash then system is halt


// [x] : Win10
//
//	you need to include this and call n_mousehook_init()/exit() from caller process
//	+ SendInput() or mouse_event() will hang up
//
//	SendInput() and mouse_event() beep and don't work accurately




#include "../nonnon/win32/win.c"




static HHOOK n_mousehook_hhook = NULL;
static HWND  n_mousehook_debug = NULL;
//static int   n_mousehook_shwnd = SW_NORMAL;
static int   n_mousehook_shwnd = SW_HIDE;




#define n_mousehook_is_d( n ) ( n < 0 )
#define n_mousehook_is_u( n ) ( n > 0 )

LRESULT CALLBACK
n_mousehook_LowLevelMouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{
//n_win_hwndprintf_literal( n_mousehook_debug, "%d", nCode );
//n_win_debug_count( n_mousehook_debug );


	if ( nCode != HC_ACTION )
	{
		return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
	}


	if ( wParam == WM_MOUSEWHEEL )
	{
//n_posix_debug_literal( "" );
//n_win_debug_count( n_mousehook_debug );


		// [!] : shared

		// [x] : don't rely on p->time

		MSLLHOOKSTRUCT *p = (void*) lParam;

		static int jitter_delta_prv = 0;
		static int prv              = 0;
		static u32 axl              = 0;

//n_win_hwndprintf_literal( n_mousehook_debug, "%d %d", jitter_delta_prv, prv );

		u32 time_cur = n_posix_tickcount();
		int delta    = GET_WHEEL_DELTA_WPARAM( p->mouseData );
//n_win_hwndprintf_literal( n_mousehook_debug, "%d", delta );


		// [!] : 0 or -1 is set
		//if ( p->flags != 0 ) { n_posix_debug_literal( "%d", p->flags ); }


		// [!] : prevent recursive call

		static n_bool lock = n_false;
//n_win_hwndprintf_literal( n_mousehook_debug, "%d", lock );

		if ( lock )
		{
			return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
		} else {
			lock = n_true;
		}

/*
		static int debug_history[ 5 ] = { 0,0,0,0,0 };

n_win_hwndprintf_literal
(
	n_mousehook_debug,
	"%d %d %d %d %d",
	debug_history[ 4 ] < 0,
	debug_history[ 3 ] < 0,
	debug_history[ 2 ] < 0,
	debug_history[ 1 ] < 0,
	delta              < 0
);

		debug_history[ 4 ] = debug_history[ 3 ];
		debug_history[ 3 ] = debug_history[ 2 ];
		debug_history[ 2 ] = debug_history[ 1 ];
		debug_history[ 1 ] = delta;
*/

		// [!] : timeout

		static u32 time_prv_all = 0;
		if ( time_prv_all == 0 ) { time_prv_all = time_cur; }

		if ( ( time_cur - time_prv_all ) > 500 )
		{
			jitter_delta_prv = delta;
			prv              = delta;
			axl              = 0;

			time_prv_all = time_cur;

			lock = n_true;
			mouse_event( MOUSEEVENTF_WHEEL, 0,0, delta, 0 );
			lock = n_false;

			return n_true;//CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
		}

		time_prv_all = time_cur;


		// [!] : jitter prevention

		int jitter_delta_cur = delta;

//n_win_hwndprintf_literal( n_mousehook_debug, "" );

		static u32 time_prv_jtr = 0;
		if ( time_prv_jtr == 0 ) { time_prv_jtr = time_cur; }

		if ( n_mousehook_is_d( jitter_delta_prv ) )
		{
//n_win_hwndprintf_literal( n_mousehook_debug, "Down" );

			if ( n_mousehook_is_u( jitter_delta_cur ) )
			{
				if ( ( time_cur - time_prv_jtr ) < 250 )
				{
//n_win_hwndprintf_literal( n_mousehook_debug, "D  On" );
					delta = delta * -1;
				} else {
//n_win_hwndprintf_literal( n_mousehook_debug, "D Off" );
					axl = 0;
				}
			} else {
				time_prv_jtr = time_cur;
			}

		} else
		if ( n_mousehook_is_u( jitter_delta_prv ) )
		{
//n_win_hwndprintf_literal( n_mousehook_debug, "Up" );

			if ( n_mousehook_is_d( jitter_delta_cur ) )
			{
				if ( ( time_cur - time_prv_jtr ) < 250 )
				{
//n_win_hwndprintf_literal( n_mousehook_debug, "U  On" );
					delta = delta * -1;
				} else {
//n_win_hwndprintf_literal( n_mousehook_debug, "U Off" );
					axl = 0;
				}
			} else {
				time_prv_jtr = time_cur;
			}

		}

		// [!] : zigzag : using "delta" : stable but weak with up-down

		jitter_delta_prv = delta;//jitter_delta_cur;


		// [!] : calc engine

		n_bool engine_onoff = n_false;

		if ( n_mousehook_is_d( delta ) )
		{
			if ( n_mousehook_is_d( prv ) ) { engine_onoff = n_true; }
		} else
		if ( n_mousehook_is_u( delta ) )
		{
			if ( n_mousehook_is_u( prv ) ) { engine_onoff = n_true; }
		}


		if ( engine_onoff )
		{

			const int step_maximum = WHEEL_DELTA * 4;

			if ( axl == 0 ) { axl = 1; } else { axl += axl; }

			axl = n_posix_min_double( axl, step_maximum );

//n_win_hwndprintf_literal( n_mousehook_debug, "%d", axl );
		}

//n_win_hwndprintf_literal( n_mousehook_debug, "%d", axl );


		if ( n_mousehook_is_d( delta ) ) { delta -= axl; } else
		if ( n_mousehook_is_u( delta ) ) { delta += axl; }

		if ( delta < SHRT_MIN ) { delta = SHRT_MIN; }
		if ( delta > SHRT_MAX ) { delta = SHRT_MAX; }

		prv = delta;


		// [!] : input engine

		if ( delta ) { mouse_event( MOUSEEVENTF_WHEEL, 0,0, delta, 0 ); }

/*
		// [x] : Win95 : error dialog will appear

		// [!] : the same as mouse_event()

		INPUT input; ZeroMemory( &input, sizeof( INPUT ) );

		input.type         = INPUT_MOUSE;
		input.mi.mouseData = delta;
		input.mi.dwFlags   = MOUSEEVENTF_WHEEL;

		SendInput( 1, &input, sizeof( INPUT ) );
*/

/*
		// [x] : not working : SetScrollPos() is the same

		SCROLLINFO si = { sizeof( SCROLLINFO ), SIF_ALL, 0,0, 0,0, 0 };

		GetScrollInfo( hwnd, SB_VERT, &si         );
		si.nPos += delta * 10;
		SetScrollInfo( hwnd, SB_VERT, &si, n_true );
*/

		lock = n_false;


		return n_true;
	}


	return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
}

void WINAPI
n_mousehook_init( HINSTANCE hinst, HWND hwnd_debug )
{

	n_win_exedir2curdir();

	n_mousehook_hhook = SetWindowsHookEx( WH_MOUSE_LL, n_mousehook_LowLevelMouseProc, hinst, 0 );
	n_mousehook_debug = hwnd_debug;

	// [x] : Win9x : ANSI Version :     DLL : ERROR_MOD_NOT_FOUND (126) will be returned
	// [x] : Win9x : ANSI Version : not DLL : zero will be returned but n_mousehook_hhook is NULL

if ( n_mousehook_hhook == NULL ) { n_posix_debug_literal( "%d", GetLastError() ); }

	return;
}

void WINAPI
n_mousehook_exit( void )
{

	UnhookWindowsHookEx( n_mousehook_hhook );

	return;
}


