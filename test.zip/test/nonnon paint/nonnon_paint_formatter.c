// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/neutral/curico.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_checkbox.c"
#include "../nonnon/win32/win_iconbutton.c"
#include "../nonnon/win32/win_scrollbar.c"
#include "../nonnon/win32/win_scroller.c"

#include "../nonnon/project/macro.c"




// rc.h

#define H_ICON    n_paint_formatter_hgui[ 0 ]
#define H_BTN_GO  n_paint_formatter_hgui[ 1 ]
#define H_LABEL   n_paint_formatter_hgui[ 2 ]
#define GUI_MAX                           3

#define H_CHECK  ( &n_paint_formatter_check )


#define H_SCR_X  ( &n_paint_formatter_hscr[ 0 ] )
#define H_SCR_Y  ( &n_paint_formatter_hscr[ 1 ] )
#define H_SCR_Q  ( &n_paint_formatter_hscr[ 2 ] )
#define SCR_MAX                             3




// internal

static HWND           n_paint_formatter_hgui[ GUI_MAX ];
static n_win_scroller n_paint_formatter_hscr[ SCR_MAX ];
static n_win_check    n_paint_formatter_check;

static s32            n_paint_formatter_scr_x = 0;
static s32            n_paint_formatter_scr_y = 0;
static s32            n_paint_formatter_scr_q = 0;




void
n_paint_formatter_resize( HWND hwnd, int nwset )
{

	const n_bool redraw = n_false;


	HWND h_check = H_CHECK->hwnd;


	s32 ctl,ico,m;
	n_win_stdsize( hwnd, &ctl, &ico, &m );
	ico = n_posix_max_s32( ico, ctl * 2 );


	s32 csy = ico + ctl;
	s32 csx = ico * 4;


	n_win_set( hwnd, NULL, csx + m, csy + m, nwset );


	ShowWindow( H_LABEL, SW_HIDE );
	ShowWindow( h_check, SW_HIDE );
	nwscr_show( H_SCR_X, SW_HIDE );
	nwscr_show( H_SCR_Y, SW_HIDE );


	s32 ssx = csx - ico;

	n_win_move( H_ICON,     0,     0, ico,   ico, redraw );
	n_win_move( H_BTN_GO,   0,   ico, csx,   ctl, redraw );
	n_win_move( H_LABEL,  ico, 0*ctl, ssx, 2*ctl, redraw );
	n_win_move( h_check,  ico, 0*ctl, ssx, 2*ctl, redraw );
	nwscr_move( H_SCR_X,  ico, 0*ctl, ssx, 1*ctl, redraw );
	nwscr_move( H_SCR_Y,  ico, 1*ctl, ssx, 1*ctl, redraw );
	nwscr_move( H_SCR_Q,  ico, 0*ctl, ssx, 2*ctl, redraw );

	if ( n_paint_format_is_bmp( n_paint_formatter_name ) )
	{
		ShowWindow( H_LABEL, SW_NORMAL );
		ShowWindow( h_check, SW_HIDE   );
		nwscr_show( H_SCR_X, SW_HIDE   );
		nwscr_show( H_SCR_Y, SW_HIDE   );
		nwscr_show( H_SCR_Q, SW_HIDE   );
	} else
	if ( n_paint_format_is_ico( n_paint_formatter_name ) )
	{
		ShowWindow( H_LABEL, SW_HIDE   );
		ShowWindow( h_check, SW_NORMAL );
		nwscr_show( H_SCR_X, SW_HIDE   );
		nwscr_show( H_SCR_Y, SW_HIDE   );
		nwscr_show( H_SCR_Q, SW_HIDE   );
	} else
	if ( n_paint_format_is_cur( n_paint_formatter_name ) )
	{
		ShowWindow( H_LABEL, SW_HIDE   );
		ShowWindow( h_check, SW_HIDE   );
		nwscr_show( H_SCR_X, SW_NORMAL );
		nwscr_show( H_SCR_Y, SW_NORMAL );
		nwscr_show( H_SCR_Q, SW_HIDE   );
	} else
	if ( n_paint_format_is_jpg( n_paint_formatter_name ) )
	{
		ShowWindow( H_LABEL, SW_HIDE   );
		ShowWindow( h_check, SW_HIDE   );
		nwscr_show( H_SCR_X, SW_HIDE   );
		nwscr_show( H_SCR_Y, SW_HIDE   );
		nwscr_show( H_SCR_Q, SW_NORMAL );
	} else
	if ( n_paint_format_is_png( n_paint_formatter_name ) )
	{
		ShowWindow( H_LABEL, SW_NORMAL );
		ShowWindow( h_check, SW_HIDE   );
		nwscr_show( H_SCR_X, SW_HIDE   );
		nwscr_show( H_SCR_Y, SW_HIDE   );
		nwscr_show( H_SCR_Q, SW_HIDE   );
	} else
	if ( n_paint_format_is_lyr( n_paint_formatter_name ) )
	{
		ShowWindow( H_LABEL, SW_NORMAL );
		ShowWindow( h_check, SW_HIDE   );
		nwscr_show( H_SCR_X, SW_HIDE   );
		nwscr_show( H_SCR_Y, SW_HIDE   );
		nwscr_show( H_SCR_Q, SW_HIDE   );
	}// else


	return;
}

void
n_paint_formatter_save( void )
{

	n_win_cursor_add( NULL, IDC_WAIT );


	n_bool ret = n_false;


	if ( n_posix_false == n_paint_format_is_lyr( n_paint_formatter_name ) )
	{
		s32 bmpsx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
		s32 bmpsy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

		n_bmp_new( &n_paint_layer_as_one, bmpsx, bmpsy );
		n_bmp_layercopy( n_paint_layer_data, &n_paint_layer_as_one, 0,0,bmpsx,bmpsy, 0,0, n_false );

		n_paint_formatter_bmp = &n_paint_layer_as_one;
	}


	if ( n_paint_format_is_bmp( n_paint_formatter_name ) )
	{

		ret = n_bmp_save( n_paint_formatter_bmp, n_paint_formatter_name );

	} else
	if ( n_paint_format_is_ico( n_paint_formatter_name ) )
	{

		n_paint_curico.type = N_CURICO_TYPE_ICO;

		if ( n_win_check_is_checked( H_CHECK ) )
		{
			n_curico_favicon_onoff = N_CURICO_FAVICON_ON;
		} else {
			n_curico_favicon_onoff = N_CURICO_FAVICON_OFF;
		}

		ret = n_curico_save( &n_paint_curico, n_paint_formatter_bmp, n_paint_formatter_name );

	} else
	if ( n_paint_format_is_cur( n_paint_formatter_name ) )
	{

		n_paint_curico.type     = N_CURICO_TYPE_CUR;
		n_paint_curico.hotspotx = n_paint_formatter_scr_x;
		n_paint_curico.hotspoty = n_paint_formatter_scr_y;

		ret = n_curico_save( &n_paint_curico, n_paint_formatter_bmp, n_paint_formatter_name );

	} else
	if ( n_paint_format_is_jpg( n_paint_formatter_name ) )
	{

		n_jpg_quality = n_paint_formatter_scr_q;

		ret = n_jpg_bmp2jpg( n_paint_formatter_name, n_paint_formatter_bmp );

	} else
	if ( n_paint_format_is_png( n_paint_formatter_name ) )
	{

		n_png png = n_png_template;

		ret  = n_png_compress( &png, n_paint_formatter_bmp );
		ret += n_png_save( &png, n_paint_formatter_name );

		n_png_free( &png );

	} else
	if ( n_paint_format_is_lyr( n_paint_formatter_name ) )
	{

		extern void n_paint_layer_save( void );
		n_paint_layer_save();

	} //else


	if ( ret )
	{

		n_paint_dialog_info( n_project_string_error );

	} else {

		n_explorer_refresh( n_false );

		n_paint_grabber_reset();
		n_paint_grabber_status();

		n_paint_tool_grabber_blend_zero();

		n_paint_layer_grabber_check_enable( n_true );

	}


	if ( grabber ) { n_paint_grabber_reset(); }


	n_paint_pen_cursor_default( NULL );


	return;
}

LRESULT CALLBACK
n_paint_formatter_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_scroller_on_settingchange( H_SCR_X );
		n_win_scroller_on_settingchange( H_SCR_Y );
		n_win_scroller_on_settingchange( H_SCR_Q );

		n_win_refresh( H_LABEL, n_true );

		n_win_check_on_settingchange( H_CHECK );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_ICON   );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_GO );

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_scroller_zero( H_SCR_X );
		n_win_scroller_zero( H_SCR_Y );
		n_win_scroller_zero( H_SCR_Q );

		n_win_check_zero( H_CHECK );


		// Window

		n_win_init_literal( hwnd, "Formatter", "", "" );

		n_win_gui_literal( hwnd, FICOBTN, "", &H_ICON   );
		n_win_gui_literal( hwnd, FBTN,    "", &H_BTN_GO );
		n_win_gui_literal( hwnd, LABEL,   "", &H_LABEL  );

		n_win_scroller_init_literal( H_SCR_X, hwnd, "X" );
		n_win_scroller_init_literal( H_SCR_Y, hwnd, "Y" );
		n_win_scroller_init_literal( H_SCR_Q, hwnd, "Q" );

		n_win_text_set( H_BTN_GO, n_project_string_go );

		n_win_check_init_literal( H_CHECK, hwnd, "Favicon", 0 );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		// [!] : don't use static SS_ICON : GDI handle leak will occur

		//n_win_style_add( H_ICON, SS_ICON | SS_CENTERIMAGE | WS_BORDER );

		n_win_iconbutton_init( hwnd, H_ICON   );
		n_win_iconbutton_init( hwnd, H_BTN_GO );

		if ( n_paint_format_is_bmp( n_paint_formatter_name ) )
		{
			n_win_icon_add( H_ICON, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 0 );
			if ( n_posix_stat_is_exist( n_paint_formatter_name ) )
			{
				n_win_text_set( H_LABEL, n_project_string_overwrite );
			} else {
				n_win_text_set( H_LABEL, n_project_string_really_ok );
				if ( grabber )
				{
					n_paint_formatter_save();
					return -1;
				}
			}
		} else
		if ( n_paint_format_is_ico( n_paint_formatter_name ) )
		{
			n_win_icon_add( H_ICON, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 21 );
		} else
		if ( n_paint_format_is_cur( n_paint_formatter_name ) )
		{
			n_win_icon_add( H_ICON, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 22 );
		} else
		if ( n_paint_format_is_jpg( n_paint_formatter_name ) )
		{
			n_win_icon_add( H_ICON, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  8 );
		} else
		if ( n_paint_format_is_png( n_paint_formatter_name ) )
		{
			n_win_icon_add( H_ICON, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  9 );
			if ( n_posix_stat_is_exist( n_paint_formatter_name ) )
			{
				n_win_text_set( H_LABEL, n_project_string_overwrite );
			} else {
				n_win_text_set( H_LABEL, n_project_string_really_ok );
				if ( grabber )
				{
					n_paint_formatter_save();
					return -1;
				}
			}
		} else
		if ( n_paint_format_is_lyr( n_paint_formatter_name ) )
		{
			n_win_icon_add( H_ICON, NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 10 );
			if ( n_posix_stat_is_exist( n_paint_formatter_name ) )
			{
				n_win_text_set( H_LABEL, n_project_string_overwrite );
			} else {
				n_win_text_set( H_LABEL, n_project_string_really_ok );
			}
		} //else


		n_win_style_add( H_LABEL, SS_CENTER | SS_CENTERIMAGE );
		n_win_style_add( H_CHECK->hwnd, BS_CENTER );


		n_win_stdfont_init( n_paint_formatter_hgui, GUI_MAX );


		n_project_defaultbutton( H_BTN_GO );
		SetFocus( H_BTN_GO );


		// Size

		n_paint_formatter_resize( hwnd, N_WIN_SET_CENTERING );

		n_paint_formatter_scr_x = n_paint_curico.hotspotx;
		n_paint_formatter_scr_y = n_paint_curico.hotspoty;
		n_paint_formatter_scr_q = n_jpg_quality;

		n_win_scroller_scroll_parameter( H_SCR_X, 1, 10, 255, n_paint_formatter_scr_x, n_true );
		n_win_scroller_scroll_parameter( H_SCR_Y, 1, 10, 255, n_paint_formatter_scr_y, n_true );
		n_win_scroller_scroll_parameter( H_SCR_Q, 1, 10, 100, n_paint_formatter_scr_q, n_true );


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, n_false );
		EnableWindow( hwnd_layr, n_false );
		EnableWindow( hwnd_main, n_false );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else

		if ( wparam == N_PAINT_KEY_E )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_X ) )
		{

			n_paint_formatter_scr_x = wparam;

			n_win_hwndprintf_literal( H_SCR_X->value, "%3d", n_paint_formatter_scr_x );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_Y ) )
		{

			n_paint_formatter_scr_y = wparam;

			n_win_hwndprintf_literal( H_SCR_Y->value, "%3d", n_paint_formatter_scr_y );

		}

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_Q ) )
		{

			n_paint_formatter_scr_q = wparam;

			n_win_hwndprintf_literal( H_SCR_Q->value, "%3d", n_paint_formatter_scr_q );

		} else

		if ( h == H_BTN_GO )
		{

			n_paint_formatter_save();
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	}
	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, n_true );
		EnableWindow( hwnd_layr, n_true );
		EnableWindow( hwnd_main, n_true );

		ShowWindow( hwnd, SW_HIDE );


		// [!] : when operation is canceled

		if ( grabber ) { n_paint_grabber_position_reset(); }


		// [Needed] : HICON will leak

		n_win_icon_del( H_ICON );


		n_win_iconbutton_exit( hwnd, H_ICON   );
		n_win_iconbutton_exit( hwnd, H_BTN_GO );

		n_win_stdfont_exit( n_paint_formatter_hgui, GUI_MAX );

		n_win_check_exit( H_CHECK );

		n_win_scroller_exit( H_SCR_X );
		n_win_scroller_exit( H_SCR_Y );
		n_win_scroller_exit( H_SCR_Q );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}

	n_win_check_proc( hwnd, msg, wparam, lparam, H_CHECK );

	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_X );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_Y );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_Q );

	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_ICON   );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_GO );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_ICON
#undef H_BTN_GO
#undef H_LABEL
#undef GUI_MAX

#undef H_CHECK

#undef H_SCR_X
#undef H_SCR_Y
#undef H_SCR_Q
#undef SCR_MAX


