// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_win_txtbox_draw_box( n_win_txtbox *p, HDC hdc, RECT *rect, COLORREF color )
{
//return;

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{

		s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

		if ( color == p->color_back_selected )
		{
			// [!] : for contour
			 x -= p->scale;
			sx += p->scale * 2;
		}

		int a = 222; if ( color == 0 ) { a = 0; }
		int r = GetRValue( color );
		int g = GetGValue( color );
		int b = GetBValue( color );

		n_bmp_box( &p->bmp, x,y,sx,sy, n_bmp_argb( a,r,g,b ) );

	} else {

//color = RGB( 0,200,255 );

		n_win_box( NULL, hdc, rect, color );

	}


	return;
}

// internal
void
n_win_txtbox_draw_box_invert( n_win_txtbox *p, n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, double blend )
{

	// [!] : InvertRect() only supports black and white


	s32 xx = 0;
	s32 yy = 0;
	while( 1 )
	{

		u32 color; n_bmp_ptr_get( bmp, x+xx,y+yy, &color );

		int a =       n_bmp_a( color );
		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		color = n_bmp_blend_pixel( color, n_bmp_argb( a,r,g,b ), blend );

		n_bmp_ptr_set( bmp, x+xx,y+yy, color );

		xx++;
		if ( xx >= sx )
		{

			xx = 0;

			yy++;
			if ( yy >= sy ) { break; }
		}
	}


	return;
}

// internal
void
n_win_txtbox_draw_alpha_visible( n_win_txtbox *p, s32 x, s32 y, s32 sx, s32 sy )
{

	s32 xx = 0;
	s32 yy = 0;
	while( 1 )
	{

		if ( n_bmp_ptr_is_accessible( &p->bmp, x+xx,y+yy ) )
		{
			u32 color; n_bmp_ptr_get_fast( &p->bmp, x+xx,y+yy, &color );

			int a = n_bmp_a( color );

			if ( a != N_BMP_ALPHA_CHANNEL_VISIBLE )
			{
				n_bmp_ptr_set_fast( &p->bmp, x+xx,y+yy, n_bmp_alpha_visible_pixel( color ) );
			}
		}

		xx++;
		if ( xx >= sx )
		{

			xx = 0;

			yy++;
			if ( yy >= sy ) { break; }
		}
	}


	return;
}

// internal
void
n_win_txtbox_draw_text( n_win_txtbox *p, HDC hdc, const n_posix_char *str, int cch, RECT *rect, int dt )
{

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{

#ifdef UNICODE
		n_posix_char *s = n_string_carboncopy ( str );
#else  // #ifdef UNICODE
		     wchar_t *s = n_posix_ansi2unicode( str ); cch = -1;
#endif // #ifdef UNICODE

		//p->uxtheme.DrawThemeText( p->uxtheme.htheme, hdc, 0,0, s,cch, dt,0, rect );

		{

			// [!] : Win8 or later : effect will be ignored

			DTTOPTS dttopts; ZeroMemory( &dttopts, sizeof( DTTOPTS ) );

			dttopts.dwSize  = sizeof( DTTOPTS );
			dttopts.dwFlags = DTT_COMPOSITED;

			dttopts.dwFlags = dttopts.dwFlags | DTT_TEXTCOLOR;
			dttopts.crText  = p->color___dwm_contour;

			// [x] : buggy

			s32 x = -p->scale;
			s32 y = -p->scale;
			while( 1 )
			{break;

				if ( ( x == 0 )&&( y == 0 ) )
				{
					//
				} else {
					RECT r = { rect->left + x, rect->top + y, rect->right + x, rect->bottom + y };
					p->uxtheme.DrawThemeTextEx( p->uxtheme.htheme, hdc, 0,0, s,cch, dt, &r, &dttopts );
				}

				x++;
				if ( x > p->scale )
				{
					x = -p->scale;

					y++;
					if ( y > p->scale ) { break; }
				}
			}

			dttopts.crText = p->color___dwm_textclr;

			p->uxtheme.DrawThemeTextEx( p->uxtheme.htheme, hdc, 0,0, s,cch, dt, rect, &dttopts );

		}

		n_string_free( s );

	} else {

		DrawText( hdc, str, cch, rect, dt );
		//ExtTextOut( hdc, rect->left, rect->top, 0, rect, str, cch, NULL );

	}


	return;
}

// internal
void
n_win_txtbox_draw_border( n_win_txtbox *p, HDC hdc, COLORREF color, n_posix_bool is_flat )
{
//return;
//n_win_txtbox_debug_count( p );


	s32 sx,sy; n_win_size_client( p->hwnd, &sx, &sy );

	int i = 0;
	while( 1 )
	{

		n_win_txtbox_frame( hdc, i,i,sx-(i*2),sy-(i*2), color );

		i++;
		if ( i >= p->scale ) { break; }
	}

	if ( is_flat ) { return; }

	while( 1 )
	{//break;


		n_win_txtbox_frame( hdc, i,i,sx-(i*2),sy-(i*2), p->color_back__enabled );

		i++;
		if ( i >= ( p->scale * 2 ) ) { break; }
	}


	return;
}

// internal
void
n_win_txtbox_draw_eol( n_win_txtbox *p, HDC hdc, s32 x, s32 y, u32 bg, n_posix_char *eol )
{

	if ( p == NULL ) { return; }


	SetBkColor  ( hdc, bg );
	SetTextColor( hdc, p->color_text_eol_mark );

	SIZE size = n_win_txtbox_size_text_fast( p, hdc, eol );
	RECT rect = n_win_rect_set( NULL, x, y, size.cx, size.cy );

	n_win_txtbox_draw_text( p, hdc, eol, -1, &rect, p->drawtext_modes );


	return;
}

// internal
void
n_win_txtbox_draw_caret( n_win_txtbox *p, HDC hdc, n_bmp *bmp )
{

	// [!] : fake caret

	// [x] : system caret is buggy
	//
	//	interfere with other edit controls' caret


	if ( p == NULL ) { return; }


	s32  x = p->caret_pxl_x;
	s32  y = p->caret_pxl_y;
	s32 sx = p->caret_pxl_sx;
	s32 sy = p->caret_pxl_sy;
	s32 fx = p->border_pxl_sx;
	s32 tx = p->canvas_pxl_sx;

	if ( p->number_pxl_sx != 0 ) { fx += p->pad_pxl_sx + p->number_pxl_sx; }

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d : %d ", x, y, sx, sy, fx, tx );

	if ( x < fx ) { return; }
	if ( x > tx ) { return; }


	// [!] : Win9x/NT4        : "sx" is 2px
	// [!] : Win2000 or later : "sx" is 1px by default (you can change this)

	if ( p->is_2k_or_later )
	{
		if ( ( p->ime_onoff )&&( sx == 1 ) ) { sx = 2; }
	} else {
		//
	}


	{

		n_posix_bool draw = n_posix_true;

		if ( p->hwnd != GetFocus() )
		{

			if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET )
			{
				draw = n_posix_false;
			}

			n_win_txtbox_caret_reset( p, n_posix_true );

		} else {

			if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF ) )
			{

				// [!] : fade-in -> stay for a while -> fade-out

				if ( p->caret_fade_in )
				{
					p->caret_blend += 0.1;
					if ( p->caret_blend >=  2.0 ) { p->caret_blend = 2.0; p->caret_fade_in = n_posix_false; }
				} else {
					p->caret_blend -= 0.1;
					if ( p->caret_blend <= -1.0 ) { p->caret_blend = 0.0; p->caret_fade_in = n_posix_true ; }
				}

			} else {
//static int i = 0;
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %f ", i, p->caret_fade_in, p->caret_blend );
//i++;
				// [!] : fade-in -> stay for a while -> fade-out

				if ( p->caret_fade_in )
				{
					p->caret_blend = 1.0;
					p->caret_fade_in = n_posix_false;
				} else {
					p->caret_blend = 0.0;
					p->caret_fade_in = n_posix_true ;
				}

			}

		}

//draw = n_posix_false;
		if ( draw )
		{

			double blend = p->caret_blend;
			if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF ) )
			{
				if ( blend > 1.0 ) { blend = 1.0; }
				if ( blend < 0.0 ) { blend = 0.0; }
			}

			if ( p->hwnd != GetFocus() ) { blend = 0.25; }

			if ( p->caret_blend_override_onoff ) { blend = p->caret_blend_override_value; }

			n_win_txtbox_draw_box_invert( p, bmp, x,y,sx,sy, blend );

			ExcludeClipRect( hdc, x, y, x + sx, y + sy );

		}


	}


	// [!] : remember the last position

	POINT pt = { x, y }; p->ime = pt;


	return;
}

// internal
void
n_win_txtbox_draw_linenumber
(
	n_win_txtbox *p,
	         HDC  hdc,
	         s64  text_y,
	         s32   x,
	         s32   y,
	         s32  sx,
	         s32  sy,
	n_posix_bool  is_underline,
	       HFONT  hf_noline
)
{

	if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) ) { return; }


	RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx, y, p->number_pxl_sx, sy );

	if ( text_y < p->txt.sy )
	{
		int cch_y = text_y;

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ZEROBASED_INDEX )
		{
			//
		} else {
			cch_y++;
		}

		n_posix_bool over_ten_thousand = n_posix_false;
		if ( cch_y >= 10000 ) { over_ten_thousand = n_posix_true; }

		if ( cch_y >= 10000 ) { cch_y = cch_y % 10000; }

		n_posix_char str[ 6 + 1 ];

		// [Patch] : not working accurately

		if ( cch_y < 1000 )
		{
			if ( over_ten_thousand )
			{
				n_posix_sprintf_literal( str, " %04d ", cch_y );
			} else {
				n_posix_sprintf_literal( str, " % 4d ", cch_y );
			}
		} else {
			n_posix_sprintf_literal( str, " %d "  , cch_y );
		}

		COLORREF bg = p->color_back_linenum1;
		COLORREF fg = p->color_text_linenum1;

//if ( text_y == 0 ) { n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->select_cch_sy ); }

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->select_cch_sy );

		n_posix_bool is_curline = n_posix_false;

		if (
			( ( p->partial_selection_from_onoff )&&( text_y == ( p->select_cch_y + p->select_cch_sy - 1 ) ) )
			||
			( ( p->partial_selection_to___onoff )&&( text_y ==   p->select_cch_y                          ) )
			||
			(
				( ( p->partial_selection_from_onoff == n_posix_false )&&( p->partial_selection_to___onoff == n_posix_false ) )
				&&
				( text_y == p->select_cch_y )
			)
		)
		{
			is_curline = n_posix_true;
			bg = p->color_back_linenum2;
		}

		n_posix_bool is_sel_line = n_posix_false;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->empty_line_selection, p->select_cch_y );

		if (
			(
				( p->empty_line_selection != N_WIN_TXTBOX_NOT_SELECTED )
				&&
				( p->empty_line_selection == p->select_cch_y )
				&&
				( text_y == p->select_cch_y )
			)
			||
			(
				(                1 != p->txt.sy )
				&&
				( p->select_cch_sy == p->txt.sy )
			)
			||
			( ( p->partial_selection_from_onoff )&&( text_y == p->select_cch_y ) )
			||
			( ( p->partial_selection_to___onoff )&&( text_y == p->select_cch_y ) )
			||
			( ( p->select_cch_sx != 0 )&&( text_y == p->select_cch_y ) )
			||
			( n_win_txtbox_is_highlighted( p, N_WIN_TXTBOX_NOT_SELECTED, text_y ) )
		)
		{
			is_sel_line = n_posix_true;
			bg = p->color_back_linenum2;
		}

		n_win_txtbox_draw_box( p, hdc, &rect, bg );


		HFONT hf = SelectObject( hdc, hf_noline );

		s32 offset = p->number_pxl_sx / 6;

		int i = 5;
		while( 1 )
		{

			RECT rect_one = n_win_rect_set( NULL, p->pad_pxl_sx + ( offset * i ), y, offset, sy );

			n_posix_char str_number[ 2 ] = { str[ i ], N_STRING_CHAR_NUL };

			if ( ( is_curline )||( is_sel_line ) )
			{

				RECT r = rect_one; n_win_rect_move( &r, 1, 1 );
				SetTextColor( hdc, p->color_back_noselect );
				n_win_txtbox_draw_text( p, hdc, str_number, 1, &r, p->drawtext_modes | DT_CENTER );

				fg = p->color_text_linenum2;

				SetTextColor( hdc, fg );

				n_win_txtbox_draw_text( p, hdc, str_number, 1, &rect_one, p->drawtext_modes | DT_CENTER );

			} else {

				s32 sx = N_BMP_SX( &p->bmp_linenumber[ 0 ] );
				s32 sy = N_BMP_SY( &p->bmp_linenumber[ 0 ] );
				s32 tx = rect_one.left;
				s32 ty = rect_one.top;

				int index = str[ i ] - n_posix_literal( '0' );

				n_bmp_fastcopy( &p->bmp_linenumber[ index ], &p->bmp, 0,0,sx,sy, tx,ty );

			}

			i--;
			if ( i < 0 ) { break; }
		}

		SelectObject( hdc, hf );


		if ( is_underline )
		{
			s32  m = n_win_dpi( p->hwnd ) / 96;
			RECT r = n_win_rect_set( NULL, p->pad_pxl_sx, y + sy - m, p->number_pxl_sx, m );

			n_win_txtbox_draw_box( p, hdc, &r, p->color_text_linenum2 );
		}


		if ( is_sel_line )
		{
			s32    fx = p->pad_pxl_sx + p->number_pxl_sx - ( p->number_pad_pxl_sx / 2 );
			RECT rect = n_win_rect_set( NULL, fx, y, p->number_pad_pxl_sx, sy );

			n_win_txtbox_draw_box( p, hdc, &rect, p->color_back_linenum3 );
		}

	} else {

		rect.right++;
		n_win_txtbox_draw_box( p, hdc, &rect, p->color_back_linenum1 );

	}

	// [Needed] : padding between line number and text
	{
		COLORREF color = p->color_back_noselect;
		if ( p->debug_onoff ) { color = RGB( 0,255,0 ); }

		RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx + p->number_pxl_sx, y, p->pad_pxl_sx, sy );
		n_win_txtbox_draw_box( p, hdc, &rect, color );
	}


	return;
}

void
n_win_txtbox_draw_background
(
	n_win_txtbox *p,
	         HDC  hdc,
	         s32  text_y,
	         s32  x,
	         s32  y,
	         s32  sx,
	         s32  sy,
	    COLORREF *ret_bg,
	n_posix_bool  bg_input
)
{

	// [!] : Stripe Background

	COLORREF bg;

	if ( bg_input )
	{
		bg = (*ret_bg);
	} else {
		bg = p->color_back_noselect;

		if ( p->style & N_WIN_TXTBOX_STYLE_STRIPED )
		{
			if ( text_y & 1 ) { bg = p->color_back_striping; }
		}
	}
//bg = RGB( 200,200,200 );

	p->color_text_backgrnd = bg;

	if ( ret_bg != NULL ) { (*ret_bg) = bg; }


	COLORREF color;
	if (
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
		&&
		( n_win_txtbox_is_highlighted( p, 0, text_y ) )
	)
	{
		color = p->color_back_selected;
//n_win_txtbox_hwndprintf_literal( p, " %d ", text_y );
	} else {
		color = bg;
		if ( p->debug_onoff ) { color = RGB( 222,222,255 ); }
	}
//if ( color ) {}

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{ 
		color = 0;
	}

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", y, sy, p->client_pxl_sy );


	RECT rect = n_win_rect_set( NULL, x, y, sx, sy );
	n_win_txtbox_draw_box( p, hdc, &rect, color );


	return;
}

// internal
void
n_win_txtbox_draw_singleline
(
	n_win_txtbox *p,
	         HDC  hdc,
	         s32  text_y,
	         s32  x,
	         s32  y,
	         s32  sx,
	         s32  sy
)
{
//return;

	if ( p == NULL ) { return; }


	if ( text_y < ( p->scroll_cch_tabbed_y                         ) ) { return; }
	if ( text_y > ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) ) { return; }


	n_posix_bool editbox = ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX );


//if ( p->debug_onoff ) { return; }


	int p_bkmode = GetBkMode( hdc );
	SetBkMode( hdc, TRANSPARENT );


	// [!] : Background

	COLORREF bg = 0;

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		//
	} else {
		s32 tx  =  x;
		s32 ty  =  y;
		s32 tsx = sx;
		s32 tsy = sy;

		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_NONE )
		{
			//
		} else
		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL )
		{
			//
		} else
		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART )
		{
			tx  = p->caret_redraw_x;
			tsx = p->caret_redraw_sx;
		}

		// [Needed] : ONELINE patch : "sy" needs to have more size

		s32 bg_x  = tx;
		s32 bg_y  = ty;
		s32 bg_sx = tsx;
		s32 bg_sy = tsy;

		if ( p->scroll_pxl_tabbed_x != 0 ) { bg_x = 0; bg_sx = sx; }

		n_win_txtbox_draw_background( p, hdc, text_y, bg_x, bg_y, bg_sx, bg_sy, &bg, n_posix_false );

		s32 dsy = abs( p->cell_pxl_sy - p->client_pxl_sy );
		if ( dsy != 0 )
		{
			COLORREF bg_margin;
			if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			{
				bg_margin = p->color_back_noselect;
			} else
			if ( p->color_text_backgrnd == p->color_back_noselect )
			{
				bg_margin = p->color_back_striping;
			} else {
				bg_margin = p->color_back_noselect;
			}

			s32 dy = ty + tsy;
			n_win_txtbox_draw_background( p, hdc, text_y, bg_x, dy, bg_sx, dsy, &bg_margin, n_posix_true );
		}

	}


	n_posix_bool tab_onoff = ( n_posix_false == n_string_is_empty( p->tab_mark ) );
	n_posix_bool eol_onoff = ( n_posix_false == n_string_is_empty( p->eol_mark ) );


	n_posix_bool tab_auto = n_posix_false;

	if ( tab_onoff )
	{
		tab_auto = n_string_is_same_literal( "auto", p->tab_mark );
	}


	n_posix_char *eol_str = n_win_txtbox_eol_string_get( p );


	n_posix_char *text = n_txt_get( &p->txt, text_y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", text ); return;

	n_posix_bool effect_onoff      = n_posix_false;
	HFONT        effect_hfont_main = NULL;
	HFONT        effect_hfont_noln = NULL;

	n_posix_bool is_bold      = n_posix_false;
	n_posix_bool is_italic    = n_posix_false;
	n_posix_bool is_underline = n_posix_false;
	n_posix_bool is_strikeout = n_posix_false;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS )
	)
	{

		if (
			( text[ 1 ] == n_posix_literal( 'B' ) )
			||
			( text[ 1 ] == n_posix_literal( 'I' ) )
			||
			( text[ 1 ] == n_posix_literal( 'U' ) )
			||
			( text[ 1 ] == n_posix_literal( 'S' ) )
		)
		{
			effect_onoff = is_bold = n_posix_true;
		}

		if (
			( text[ 1 ] == n_posix_literal( 'i' ) )
			||
			( text[ 1 ] == n_posix_literal( 'I' ) )
		)
		{
			effect_onoff = is_italic = n_posix_true;
		} else
		if (
			( n_string_match_literal( text, "[u]" ) )
			||
			( n_string_match_literal( text, "[U]" ) )
		)
		{
			effect_onoff = is_underline = n_posix_true;
		} else
		if (
			( text[ 1 ] == n_posix_literal( 'u' ) )
			||
			( text[ 1 ] == n_posix_literal( 'U' ) )
		)
		{
			effect_onoff = is_underline = n_posix_true;
		} else
		if (
			( text[ 1 ] == n_posix_literal( 's' ) )
			||
			( text[ 1 ] == n_posix_literal( 'S' ) )
		)
		{
			effect_onoff = is_strikeout = n_posix_true;
		}


		if ( effect_onoff )
		{
			HFONT  hf_base    = n_win_font_get( p->hwnd );
			HFONT  hf_effect  = n_win_txtbox_font_effect( hf_base, is_bold, is_italic,  is_underline, is_strikeout );
			effect_hfont_noln = n_win_txtbox_font_effect( hf_base, is_bold, is_italic, n_posix_false, is_strikeout );
			effect_hfont_main = SelectObject( hdc, hf_effect );
		}

		if ( 3 <= n_posix_strlen( text ) ) { text = &text[ 3 ]; }

	}


	// Fast Mode

	int          text_cch           = 0;
	int          text_cch_ret       = 0;
	n_posix_bool text_tab_is_exist  = n_posix_false;
	n_posix_bool text_fullwidth     = n_posix_false;
	n_posix_bool text_surrogatepair = n_posix_false;
	n_posix_bool text_accent_mark   = n_posix_false;

	n_win_txtbox_tab2space
	(
		 p, text,
		 p->tabstop,
		&text_cch,
		&text_cch_ret,
		&text_tab_is_exist,
		&text_fullwidth,
		&text_surrogatepair,
		&text_accent_mark,
		 n_posix_false
	);


	extern n_posix_bool n_win_txtbox_is_selected( n_win_txtbox *p );

/*
if ( n_win_txtbox_is_selected( p ) )
{
	n_win_txtbox_hwndprintf_literal
	(
		p,
		" %d %d %d %d %d : %d %d %d ",
		text_fullwidth,
		text_surrogatepair,
		text_accent_mark,
		tab_auto,
		eol_onoff,
		p->select_cch_sx, p->select_cch_y, text_y
	);
}
*/
/*
if ( text_y == 1 )
{
	n_win_txtbox_hwndprintf_literal
	(
		p,
		" %d %d ",
		p->select_cch_sx,
		text_cch_ret
	);
}
*/
	if (
//(0)&&
		( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ) )
		&&
		( text_fullwidth     == n_posix_false )
		&&
		( text_surrogatepair == n_posix_false )
		&&
		( text_accent_mark   == n_posix_false )
		&&
		(
			( tab_auto          == n_posix_false )
			||
			( text_tab_is_exist == n_posix_false )
		)
		&&
		//( eol_onoff == n_posix_false )
		//&&
		(
			( editbox == n_posix_false )
			||
			(
				( editbox )
				&&
				( p->is_font_monospace )
				&&
				( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
				&&
				( p->scroll_pxl_tabbed_x == 0 )
				&&
				(
					( p->partial_selection_from_onoff == n_posix_false )
					&&
					( p->partial_selection_to___onoff == n_posix_false )
				)
				&&
				(
					( ( text_y < p->select_cch_y )||( text_y >= ( p->select_cch_y + p->select_cch_sy ) ) )
					||
					( ( text_y > p->select_cch_y )&&( text_y <  ( p->select_cch_y + p->select_cch_sy ) ) )
					//||
					//( ( text_y == p->select_cch_y )&&( p->select_cch_sy == 1 )&&( p->select_cch_sx == text_cch_ret ) )
				)
			)
		)
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " Fast Mode " );


		// Line Number

		HFONT hf_tmp;
		if ( ( effect_onoff )&&( is_bold ) )
		{
			hf_tmp = effect_hfont_main;
		} else {
			hf_tmp = SelectObject( hdc, n_win_font_get( p->hwnd ) );
		}

		n_win_txtbox_draw_linenumber( p, hdc, text_y, x,y,sx,sy, is_underline, effect_hfont_noln );

		s32 linenum_osx = 0;
		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
		{
			linenum_osx = -p->border_pxl_sx + p->number_pxl_sx + p->number_pad_pxl_sx;
		}
		x = n_posix_max_s32( p->pad_pxl_sx + linenum_osx, x );

		if ( ( effect_onoff )&&( is_bold ) )
		{
			//
		} else {
			SelectObject( hdc, hf_tmp );
		}


		// Text

		//n_posix_char *s = n_win_txtbox_tab2space( p, text, p->tabstop, &text_cch, &text_cch_ret, NULL,NULL,NULL,NULL, n_posix_true );
		n_posix_char *s = n_win_txtbox_tab2space_fast( p, text, p->tabstop, text_cch, n_posix_true );


		s32  pxl_x  = p->border_pxl_sx + p->virtual_padding_pxl_sx + p->pad_pxl_sx + linenum_osx;
		s32  pxl_sx = p->client_pxl_sx;
		RECT rect   = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );

		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{

			// [!] : hard to implement : undefined stat is zero

			if ( ( p->listbox_is_selected )&&( text_y == p->select_cch_y ) )
			{
				SetTextColor( hdc, n_win_color_blend( p->color_text_selected, p->color_back_selected, p->text_fade_ratio ) );
			} else {
				SetTextColor( hdc, n_win_color_blend( p->color_text_noselect, p->color_back_noselect, p->text_fade_ratio ) );
			}

		} else {

			if ( ( text_y > p->select_cch_y )&&( text_y <  ( p->select_cch_y + p->select_cch_sy ) ) )
			{
				RECT r; n_win_rect_set( &r, pxl_x, y, ( text_cch_ret * p->font_pxl_sx ),sy );
				n_win_txtbox_draw_box( p, hdc, &r, p->color_back_selected );

				SetTextColor( hdc, n_win_color_blend( p->color_text_selected, p->color_back_selected, p->text_fade_ratio ) );
			} else
			if ( ( text_y == p->select_cch_y )&&( p->select_cch_sy == 1 )&&( p->select_cch_sx == text_cch_ret ) )
			{
				// [!] : currently not reached because of caret fader

				RECT r; n_win_rect_set( &r, pxl_x, y, ( text_cch_ret * p->font_pxl_sx ),sy );
				n_win_txtbox_draw_box( p, hdc, &r, p->color_back_selected );

				SetTextColor( hdc, n_win_color_blend( p->color_text_selected, p->color_back_selected, p->text_fade_ratio ) );
			} else {
				SetTextColor( hdc, n_win_color_blend( p->color_text_noselect, p->color_back_noselect, p->text_fade_ratio ) );
			}

		}

		n_win_txtbox_draw_text( p, hdc, s,-1, &rect, p->drawtext_modes );


		n_memory_free( s );


		// End-Of-Line Marker

		if ( ( eol_onoff )&&( (u32) text_y < p->txt.sy ) )
		{
			n_win_txtbox_draw_eol( p, hdc, pxl_x + ( text_cch_ret * p->font_pxl_sx ), y, bg, eol_str );
		}


		if ( effect_onoff )
		{
			n_win_font_exit( SelectObject( hdc, effect_hfont_main ) );
			n_win_font_exit(                    effect_hfont_noln   );
		}


		SetBkMode( hdc, p_bkmode );

		return;

	} else
	if (
//(0)&&
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( p->oneline_placeholder_onoff )
		&&
		( n_posix_false == n_string_is_empty( p->placeholder ) )
		&&
		( n_string_is_empty( text ) )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " ONELINE : Place Holder " );

		s32 pxl_x  = x;
		s32 pxl_sx = sx;

		SIZE size = n_win_txtbox_size_text( p, p->placeholder );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			pxl_x = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}

		SetTextColor( hdc, p->color___placeholder );

		RECT rect = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );

		n_win_txtbox_draw_text( p, hdc, p->placeholder,-1, &rect, p->drawtext_modes );

		SetBkMode( hdc, p_bkmode );

		return;

	}


	// Slow Mode
	//
	//	+ tabstop support
	//	+ CJK fixed pitch patch

//n_win_txtbox_hwndprintf_literal( p, " Slow Mode " );

	SIZE size     = { 0,0 };
	s32  cch      = 0;
	s32  tab      = 0;

	s32  caret_fx = -1;
	s32  caret_tx = -1;
	s32  text_x   =  0;
	s32  tail_x   =  0;
	s32  horz_x   = n_win_txtbox_horizontal_centering( p );

	if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
	{
		tail_x = p->pad_pxl_sx + p->number_pxl_sx + p->number_pad_pxl_sx;
	} else {
		tail_x = p->border_pxl_sx + p->pad_pxl_sx;
	}

	tail_x += p->virtual_padding_pxl_sx;

	tail_x -= p->scroll_pxl_tabbed_x;
	tail_x += horz_x;

	s32 ctl_sy; n_win_size_client( p->hwnd, NULL, &ctl_sy );


	p->selection_onoff = n_posix_false;
	n_win_rect_set( &p->selection_rect, 0,0,0,0 );


	while( 1 )
	{//break;

//n_win_txtbox_hwndprintf_literal( p, " %d ", tail_x );
//n_posix_sleep( 10 );

		n_posix_char *character = n_win_txtbox_character( p, hdc, text, text_x, &size, &cch, &tab );

		if ( n_string_is_empty( character ) )
		{

			if ( caret_fx == -1 ) { caret_fx = tail_x; }
			if ( caret_tx == -1 ) { caret_tx = tail_x; }

			break;

		}


		// [!] : DrawText() will be slowdown without manual clipping

		n_posix_bool is_highlighted = n_win_txtbox_is_highlighted( p, text_x, text_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", is_highlighted );

		if ( is_highlighted )
		{
			SetTextColor( hdc, n_win_color_blend( p->color_text_selected, p->color_back_noselect, p->text_fade_ratio ) );
		} else {
			SetTextColor( hdc, n_win_color_blend( p->color_text_noselect, p->color_back_noselect, p->text_fade_ratio ) );
		}
//if ( color_bg ) {}
//size.cx *= 2;

		{

			n_posix_bool draw_text_onoff = n_posix_false;

			if ( p->optimization_onoff )
			{

				if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL )
				{

					draw_text_onoff = n_posix_true;

				} else
				if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART )
				{

					if ( ( tail_x >= ( p->caret_redraw_x - p->size_fullwidth.cx ) )&&( tail_x <= ( p->caret_redraw_x + p->caret_redraw_sx ) ) )
					{
						draw_text_onoff = n_posix_true;
					}

				} else {

					draw_text_onoff = n_posix_true;

				}

			} else {

				draw_text_onoff = n_posix_true;

			}

			if ( tail_x < ( 0 - p->size_fullwidth.cx ) )
			{
				draw_text_onoff = n_posix_false;
			} else
			if ( tail_x > ( p->client_pxl_sx * p->size_fullwidth.cx ) )
			{
				draw_text_onoff = n_posix_false;
			}

//draw_text_onoff = n_posix_true;

			if ( draw_text_onoff )
			{

				if ( is_highlighted )
				{

					// [x] : ExcludeClipRect() is not working when you use n_bmp_*() functions

					s32 tx,ty,tsx,tsy;
					if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
					{
						 tx = tail_x;
						 ty = p->caret_pxl_y;
						tsx = size.cx;
						tsy = p->caret_pxl_sy;
					} else {
						 tx = tail_x;
						 ty = y;
						tsx = size.cx;
						tsy = p->cell_pxl_sy;
					}

					RECT rect = n_win_rect_set( NULL, tx, ty, tsx, tsy );

					if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
					{
						// [!] : delayed : see n_win_txtbox_draw_bitblt()

						if ( p->selection_onoff == n_posix_false )
						{
							p->selection_onoff = n_posix_true;
						}
					} else {
						COLORREF bg = n_win_color_blend( p->color_back_selected, p->color_back_noselect, p->text_fade_ratio );
						n_win_txtbox_draw_box( p, hdc, &rect, bg );
					}

				}


				if ( tab_onoff )
				{
					if ( text[ text_x ] == N_STRING_CHAR_TAB )
					{
						if ( tab_auto )
						{
							RECT rect = n_win_rect_set( NULL, tail_x, y, 1, size.cy );
							n_win_txtbox_draw_box( p, hdc, &rect, p->color_text_tab_mark );
						} else {
							SetTextColor( hdc, p->color_text_tab_mark );
							character[ 0 ] = p->tab_mark[ 0 ];
						}
					}
				}


				RECT rect = n_win_rect_set( NULL, tail_x, y, size.cx, p->cell_pxl_sy );

				if ( p->debug_draw_onoff )
				{
					n_win_box( p->hwnd, hdc, &rect, RGB( 0,n_random_range( 255 ),n_random_range( 255 ) ) );
				}

				n_win_txtbox_draw_text( p, hdc, character, cch, &rect, p->drawtext_modes | DT_CENTER );

			}

		}


		if ( is_highlighted )
		{

			if ( caret_fx == -1 ) { caret_fx = tail_x; }
			caret_tx = tail_x + size.cx;

		} else {

			if (
				( ( p->partial_selection_from_onoff )&&( text_x == p->partial_selection_to___cch_x ) )
				||
				( ( p->partial_selection_to___onoff )&&( text_x == p->partial_selection_from_cch_x ) )
				||
				( text_x == p->select_cch_x )
			)
			{
				if ( p->select_cch_sx == 0 ) { caret_fx = tail_x; }
				caret_tx = tail_x;
			}

		}

		int inc = n_string_doublebyte_increment( text[ text_x ] );
		if (
			( n_unicode_surrogatepair_is_hi( character[ 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( character[ 1 ] ) )
		)
		{
			inc = 2;
		}

		text_x += inc;
		tail_x += size.cx;

	}


	// [!] : delayed : see n_win_txtbox_draw_bitblt()

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		n_win_rect_set( &p->selection_rect, caret_fx, y, caret_tx - caret_fx, sy );
	}


	if ( editbox )
	{

		// End-Of-Line Marker

		if ( ( eol_onoff )&&( (u32) text_y < p->txt.sy ) )
		{
			n_win_txtbox_draw_eol( p, hdc, tail_x,y, bg, eol_str );
		}


		// Caret

		// [!] : don't use p->hover_cch_y : value will be changed when scrolled

		s32 line_fy = n_posix_minmax_s32( 0, p->txt.sy - 1, p->drag_cch_y - ( p->select_cch_sy - 1 ) );
		s32 line_ty = p->select_cch_y + p->select_cch_sy - 1;

		if ( p->partial_selection_from_onoff )
		{
			line_fy = p->select_cch_y + p->select_cch_sy - 1;
		} else
		if ( p->partial_selection_to___onoff )
		{
			line_fy = p->select_cch_y;
		}


		// [ Mechanism ]
		//
		//	#define VK_LEFT  37
		//	#define VK_UP    38
		//	#define VK_RIGHT 39
		//	#define VK_DOWN  40

		s32 line    = line_ty;
		s32 caret_x = caret_tx;
		s32 caret_y = y;
		if ( p->partial_selection_from_onoff )
		{

			//

		} else
		if ( p->partial_selection_to___onoff )
		{

			line    = line_fy;
			caret_x = caret_fx;

		} else {

			if ( ( p->shift_dragging == VK_LEFT )||( p->shift_dragging == VK_RIGHT ) )
			{
				if ( p->is_caret_tail )
				{
					caret_x = caret_tx;
				} else {
					caret_x = caret_fx;
				}
			} else
			if ( p->shift_dragging == VK_UP )
			{
				line    = line_fy;
				caret_x = caret_fx;
			}

		}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", caret_fx, caret_tx );

		if ( ( line == text_y )&&( caret_x != -1 ) )
		{
//n_win_txtbox_hwndprintf_literal( p, " %d ", caret_x );

			p->caret_pxl_x = caret_x;
			p->caret_pxl_y = caret_y;

			// [!] : delayed : see n_win_txtbox_draw_bitblt()

			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
				//
			} else {
				n_win_txtbox_draw_caret( p, hdc, &p->bmp );
			}
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->ime.x );

		}

//n_win_txtbox_hwndprintf_literal( p, " %d ", line );

	}


	// Line Number

	n_win_txtbox_draw_linenumber( p, hdc, text_y, x,y,sx,sy, is_underline, effect_hfont_noln );


	if ( effect_onoff )
	{
		n_win_font_exit( SelectObject( hdc, effect_hfont_main ) );
		n_win_font_exit(                    effect_hfont_noln   );
	}


	SetBkMode( hdc, p_bkmode );


	return;
}

// internal
void
n_win_txtbox_draw_frame( n_win_txtbox *p, HDC hdc, n_posix_bool is_selected, n_posix_bool border_onoff )
{
//return;

	if ( p == NULL ) { return; }


	COLORREF color_border       = p->color_base__padding;
	COLORREF color_border_mask  = p->color_base__padding;

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		color_border       = 0;
		color_border_mask  = 0;
	}


	// Border

//n_win_txtbox_hwndprintf_literal( p, "%d %d", p->client_pxl_sx,p->client_pxl_sy );

	if (
		( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
		&&
		( border_onoff )
	)
	{

		RECT r = n_win_rect_set( NULL, 0,0,p->client_pxl_sx,p->client_pxl_sy );

		// [!] : WS_EX_CLIENTEDGE causes flickering

		if ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
		{
			is_selected = n_posix_false;
		}

		if ( is_selected )
		{

			if ( n_win_darkmode_onoff )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border__focus, n_posix_true );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border__focus, n_posix_true );
			} else
			if ( p->uxtheme.onoff )
			{
				int state = EPSN_FOCUSED;
				int ep    = EP_EDITBORDER_NOSCROLL;

				p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, ep, state, &r, NULL );

				if ( n_posix_false == n_sysinfo_version_8_or_later() )
				{
					s32 x = N_BMP_SX( &p->bmp ) - 1;
					s32 y = N_BMP_SY( &p->bmp ) - 1;

					n_bmp_ptr_set( &p->bmp, 0,0, p->color_base__padding );
					n_bmp_ptr_set( &p->bmp, x,0, p->color_base__padding );
					n_bmp_ptr_set( &p->bmp, 0,y, p->color_base__padding );
					n_bmp_ptr_set( &p->bmp, x,y, p->color_base__padding );
				}
			} else {
				DrawEdge( hdc, &r, EDGE_SUNKEN, BF_RECT );
			}

		} else {

			if ( n_win_darkmode_onoff )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border___flat, n_posix_false );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
				n_win_txtbox_draw_border( p, hdc, n_bmp_white, n_posix_true );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border___flat, n_posix_true );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BDR )
			{
				n_win_txtbox_draw_border( p, hdc, p->color_border___flat, n_posix_false );
			} else
			if ( p->uxtheme.onoff )
			{
				int state = EPSN_NORMAL;
				int ep    = EP_EDITBORDER_NOSCROLL;

				p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, ep, state, &r, NULL );

				if ( n_posix_false == n_sysinfo_version_8_or_later() )
				{
					s32 x = N_BMP_SX( &p->bmp ) - 1;
					s32 y = N_BMP_SY( &p->bmp ) - 1;

					n_bmp_ptr_set( &p->bmp, 0,0, p->color_base__padding );
					n_bmp_ptr_set( &p->bmp, x,0, p->color_base__padding );
					n_bmp_ptr_set( &p->bmp, 0,y, p->color_base__padding );
					n_bmp_ptr_set( &p->bmp, x,y, p->color_base__padding );
				}
			} else {
				DrawEdge( hdc, &r, EDGE_SUNKEN, BF_RECT );
			}

		}

		if ( p->debug_onoff )
		{
			n_win_txtbox_draw_box( p, hdc, &r, color_border );
		}

	}

	// Mask Border

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	{

		// [Needed] : for text clipping

		s32 bx = p->border_pxl_sx;
		s32 by = p->border_pxl_sy;
		s32  x = 0;
		s32  y = 0;
		s32 sx = p->client_pxl_sx;
		s32 sy = p->client_pxl_sy;
		s32 ox = sx - bx;
		s32 oy = sy - by;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", sx, sy );

		ExcludeClipRect( hdc,  x,  y,      sx,      by );
		ExcludeClipRect( hdc,  x, oy,      sx, oy + by );
		ExcludeClipRect( hdc,  x,  y,      bx,      sy );
		ExcludeClipRect( hdc, ox,  y, ox + bx,      sy );

	}


	return;
}

// internal
void
n_win_txtbox_draw_scrollbars( n_win_txtbox *p )
{
//return;

	if ( p == NULL ) { return; }


	// Scrollbars

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{

		// Horizontal / X

		s32 sx = p->client_pxl_sx;
		s32 sy = p->scrollbar_pxl_sy;
		s32  x = 0;
		s32  y = p->client_pxl_sy - p->scrollbar_pxl_sy - p->offset_pxl_y;

		x  += p->border_pxl_sx;
		y  -= p->border_pxl_sy;
		sx -= p->border_pxl_sx * 2;
		//sy -= p->border_pxl_sy * 2;

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= p->scrollbar_pxl_sx; }


		n_bmp_box( &p->bmp, x,y,sx,sy, p->color_back_noselect );

		n_win_scrollbar_move( &p->hscr, x,y,sx,sy, n_posix_false );


		n_posix_bool onoff;

		if ( p->is_font_monospace )
		{
			onoff = ( (u32) ( p->page_pxl_tabbed_sx / p->font_pxl_sx ) < p->txt.sx );
		} else {
			SIZE size = n_win_txtbox_size_text( p, n_txt_get( &p->txt, p->txt_maxwidth_y ) );
			onoff = ( p->page_pxl_tabbed_sx < size.cx );
		}

		if ( onoff )
		{

			s32 pos  = p->scroll_pxl_tabbed_x;
			s32 page = p->  page_pxl_tabbed_sx;
			s32 max  = p->  last_pxl_tabbed_sx;

			n_win_scrollbar_parameter( &p->hscr, p->font_pxl_sx, page, max, pos, n_posix_false );

		}

		n_win_scrollbar_enable( &p->hscr, onoff, n_posix_false );

		n_win_scrollbar_draw_always( &p->hscr, n_posix_true );

	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{

		// Vertical / Y

		s32 sx = p->scrollbar_pxl_sx;
		s32 sy = p->client_pxl_sy;
		s32  x = p->client_pxl_sx - p->scrollbar_pxl_sx;
		s32  y = -p->offset_pxl_y;

		x  -= p->border_pxl_sx;
		y  += p->border_pxl_sy;
		//sx -= p->border_pxl_sx * 2;
		sy -= p->border_pxl_sy * 2;

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= p->scrollbar_pxl_sy; }


		n_bmp_box( &p->bmp, x,y,sx,sy, p->color_back_noselect );

		n_win_scrollbar_move( &p->vscr, x,y,sx,sy, n_posix_false );


		n_posix_bool onoff = ( (u32) p->page_cch_tabbed_sy < p->txt.sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->page_cch_tabbed_sy, p->txt.sy );

		if ( onoff )
		{

			s32 step = p->cell_pxl_sy;
			s32 pos  = p->cell_pxl_sy * p->scroll_cch_tabbed_y;
			s32 page = p->cell_pxl_sy * p->  page_cch_tabbed_sy;
			s32 max  = p->cell_pxl_sy * p->  last_cch_tabbed_sy;

//n_win_txtbox_hwndprintf_literal( p, " %g %g ", p->vscr.pixel_thumb_original, p->vscr.pixel_thumb );

			n_win_scrollbar_parameter( &p->vscr, step, page, max, pos, n_posix_false );

		}

		n_win_scrollbar_enable( &p->vscr, onoff, n_posix_false );

		n_win_scrollbar_draw_always( &p->vscr, n_posix_true );


//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " %g ", p->vscr.rect_main.y );

	}


	return;
}

// internal
void
n_win_txtbox_bmp_alpha_enhancer( n_bmp *bmp, double ratio )
{

	if ( n_bmp_error( bmp ) ) { return; }


	u64 c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	u64 i = 0;
	while( 1 )
	{

		u32 color = N_BMP_PTR( bmp )[ i ];
		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE != n_bmp_a( color ) )
		{
			N_BMP_PTR( bmp )[ i ] = n_bmp_blend_pixel( color, n_bmp_white, ratio );
		}

		i++;
		if ( i >= c ) { break; }
	}


	return;
}

// internal
void
n_win_txtbox_bmp_alpha_reducer( n_bmp *bmp, double ratio )
{

	if ( n_bmp_error( bmp ) ) { return; }


	u64 c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	u64 i = 0;
	while( 1 )
	{

		u32 color = N_BMP_PTR( bmp )[ i ];
		if ( color != n_bmp_white )
		{
			N_BMP_PTR( bmp )[ i ] = n_bmp_blend_pixel( color, n_bmp_black, ratio );
		}

		i++;
		if ( i >= c ) { break; }
	}


	return;
}

// internal
void
n_win_txtbox_draw_bitblt( n_win_txtbox *p, HDC hdc_main, HDC hdc_cmpt, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
//return;
		s32 bmpsx = N_BMP_SX( &p->bmp );
		s32 bmpsy = N_BMP_SY( &p->bmp );

		s32 fx  = p->border_pxl_sx + p->pad_pxl_sx;
		s32 fy  = p->border_pxl_sy + p->pad_pxl_sy;
		s32 fsx = bmpsx - ( fx * 2 ) - p->smallbutton_margin;
		s32 fsy = bmpsy - ( fy * 2 );

		n_bmp bmp_fog; n_bmp_carboncopy( &p->bmp, &bmp_fog );
		n_bmp bmp_txt; n_bmp_carboncopy( &p->bmp, &bmp_txt );

		n_bmp_free( &p->bmp_oneline ); n_bmp_carboncopy( &p->bmp, &p->bmp_oneline );

		n_bmp_box( &bmp_fog, sx - p->smallbutton_margin, 0, p->smallbutton_margin, sy, 0 );

		if ( p->selection_onoff )
		{
			COLORREF bg = n_win_color_blend( p->color_back_selected, p->color_back_noselect, p->text_fade_ratio );

			s32 bx,by,bsx,bsy; n_win_rect_expand_size( &p->selection_rect, &bx,&by,&bsx,&bsy );

			u32 color = n_bmp_alpha_visible_pixel( n_bmp_rgb2pal( bg ) );

			n_bmp_box( &p->bmp_oneline, bx,by,bsx,bsy, color );
		}

		n_bmp_antialias( &bmp_fog, fx,fy,fsx,fsy, 1.0 );
		n_win_txtbox_bmp_alpha_enhancer( &bmp_fog, 0.33 );
		n_win_txtbox_bmp_alpha_reducer ( &bmp_txt, 0.10 );
		n_bmp_rasterizer_all( &bmp_fog, &p->bmp_oneline, fx,fy,fsx,fsy, fx,fy, NULL,n_bmp_rgb(  10, 10, 10 ), NULL,0,0, n_posix_false );
		n_bmp_rasterizer_all( &bmp_txt, &p->bmp_oneline, fx,fy,fsx,fsy, fx,fy, NULL,n_bmp_rgb( 255,255,255 ), NULL,0,0, n_posix_false );

		n_win_txtbox_draw_caret( p, hdc_cmpt, &p->bmp_oneline );

		n_bmp_mirror( &p->bmp_oneline, fx,fy,fsx,fsy, N_BMP_MIRROR_UPSIDE_DOWN );

		n_gdi_bitmap_draw_main( p->hwnd, hdc_main, &p->bmp_oneline, x,y,sx,sy, x,y );

		n_bmp_free_fast( &bmp_fog );
		n_bmp_free_fast( &bmp_txt );

		p->bmp_backbuffer = &p->bmp_oneline;

	} else {

		if ( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
		{
//n_win_txtbox_hwndprintf_literal( p, "STYLE_VISIBLE" );

			//n_bmp_alpha_visible( &p->bmp );

			n_win_txtbox_draw_alpha_visible( p, x,y,sx,sy );
		}

		BitBlt( hdc_main, x,y,sx,sy, hdc_cmpt, x,y, SRCCOPY );

		p->bmp_backbuffer = &p->bmp;

	}


	return;
}

// internal
void
n_win_txtbox_draw_sync( n_win_txtbox *p )
{

	HDC hdc_main = GetDC( p->hwnd );
	HDC hdc_cmpt = CreateCompatibleDC( hdc_main );

	HBITMAP hbmp_old = SelectObject( hdc_cmpt, p->hbmp );

	n_win_txtbox_draw_bitblt( p, hdc_main, hdc_cmpt, 0,0,N_BMP_SX( &p->bmp ),N_BMP_SY( &p->bmp )  );

	SelectObject( hdc_cmpt, hbmp_old );

	DeleteObject( hdc_cmpt );
	ReleaseDC( p->hwnd, hdc_main );


	return;
}

#define n_win_txtbox_draw_selection( p, id ) n_win_txtbox_draw_partial( p, id, (p)->select_cch_y, (p)->select_cch_sy )
#define n_win_txtbox_draw(           p, id ) n_win_txtbox_draw_partial( p, id, N_WIN_TXTBOX_NOT_SELECTED, N_WIN_TXTBOX_NOT_SELECTED )

// internal
void
n_win_txtbox_draw_partial( n_win_txtbox *p, int id, s32 line_y, s32 line_sy )
{
if ( n_win_txtbox_debug_enabled_id( p, id ) ) { n_win_txtbox_hwndprintf_literal( p, " Draw : %d ", id ); }


	if ( p == NULL ) { return; }

	if ( n_txt_error( &p->txt ) ) { return; }


	// [!] : Metrics

	// [Needed] : ONELINE needs this
	n_win_txtbox_metrics_caret( p );


	if ( p->metrics_changed )
	{
		// [!] : this module is very heavy : you need to call manually
		n_win_txtbox_metrics_canvas( p );
	}


	// [Patch] : where is an accurate place?

	if ( p->style_option & N_WIN_TXTBOX_OPTION_COMBOBOX_NOGRAY )
	{
		//
	} else {
		if ( p->hwnd != GetFocus() )
		{
			p->color_back_selected = p->color_sel_focus_off;
		}
	}


	SIZE halfwidth = { p->font_pxl_sx * 1, p->cell_pxl_sy };
	SIZE fullwidth = { p->font_pxl_sx * 2, p->cell_pxl_sy };

	p->size_halfwidth = halfwidth;
	p->size_fullwidth = fullwidth;


	s32 sx = p->client_pxl_sx;
	s32 sy = p->client_pxl_sy;


	// [!] : HDC

	HDC hdc_main;
	HDC hdc_cmpt;

	if ( p->hdc_printclient == NULL )
	{
		hdc_main = GetDC( p->hwnd );
	} else {
		hdc_main = p->hdc_printclient;
	}

	hdc_cmpt = CreateCompatibleDC( hdc_main );

//n_win_box( p->hwnd, hdc_main, NULL, RGB( 0,200,255 ) );


	// [!] : selection

	const int nosel = N_WIN_TXTBOX_NOT_SELECTED;


	// Debug Center

	p->optimization_onoff = n_posix_true;
	p->optimization_type  = N_WIN_TXTBOX_OPTIMIZATION_NONE;
	p->optimization_sync  = N_WIN_TXTBOX_OPTIMIZATION_SYNC_NONE;

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		//p->optimization_onoff = n_posix_false;
	}

	if ( p->optimization_stop )
	{
		p->optimization_onoff = n_posix_false;
	}

	if ( p->optimization_onoff == n_posix_false )
	{
		line_y = line_sy = nosel;
	}

//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d %d ", p->drag_phase, p->drag_cch_y, p->select_cch_y, p->select_cch_sy );

	p->debug_draw_onoff = n_posix_false;

	n_posix_bool debug_output = n_posix_false;
	n_posix_bool debug_detail = n_posix_false;


	if ( p->optimization_onoff )
	{
//n_win_txtbox_hwndprintf_literal( p, " %d : %d : %d %d ", p->drag_phase, p->drag_cch_y, p->select_cch_y, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_scr_x, p->scroll_pxl_tabbed_x );

		if ( p->prv_txt_sy > p->txt.sy )
		{
//n_win_txtbox_debug_count( p );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->scroll_cch_tabbed_y, p->prv_scr_y, p->last_cch_tabbed_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->scroll_cch_tabbed_y, p->prv_txt_sy, p->txt.sy );

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_OTHERS;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

			line_y  = nosel;
			line_sy = nosel;

			n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );

		} else
		if (
			( p->prv_scr_x != p->scroll_pxl_tabbed_x )
			||
			( p->prv_scr_y != p->scroll_cch_tabbed_y )
		)
		{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_SCROLL " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_SCROLL;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

			// [!] : Slow Mode

			line_y  = nosel;
			line_sy = nosel;

			p->prv_scr_x  = p->scroll_pxl_tabbed_x;
			p->prv_scr_y  = p->scroll_cch_tabbed_y;

		} else
		if ( n_win_is_input( VK_SHIFT ) )
		{
//if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_SHIFT " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_SHIFT;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

			// [!] : Slow Mode

			line_y  = nosel;
			line_sy = nosel;

			p->caret_redraw_x  = 0;
			p->caret_redraw_sx = sx;

			// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_sx, p->select_cch_sx );

			if ( n_win_is_input( VK_BACK ) )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " SHIFT : is_backspace " ); }

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

				if ( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
				{
					p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;
					p->caret_redraw_x    = p->ime.x;
				}
			} else
			if ( n_win_is_input( VK_RETURN ) )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " SHIFT : is_carrage_return " ); }

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

			} else
			if ( p->is_caret_tail )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " SHIFT : p->is_caret_tail " ); }

				p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;

				n_win_txtbox_previous_calc_selected( p, &line_y, &line_sy );

				// [x] : something is wrong
				if ( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
				{
					//p->caret_redraw_x  = p->shift_dragging_start_pxl_x;
					//p->caret_redraw_sx = p->size_fullwidth.cx * p->shift_dragging_start_x;
				}

			} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " SHIFT : Others " ); }

				n_win_txtbox_previous_calc_selected( p, &line_y, &line_sy );

				if ( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
				{
					p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;
					p->caret_redraw_x    = p->ime.x;
					if ( p->is_caret_tail == n_posix_false )
					{
						p->caret_redraw_x = 0;
					}
				}
			}

		} else
		if ( p->drag_phase == N_WIN_TXTBOX_DRAG_PHASE_STARTED )
		{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_DRAG " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_DRAG;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

/*
			// [!] : Slow Mode

			line_y  = nosel;
			line_sy = nosel;

			p->drag_cch_min = 0;
			p->drag_cch_max = p->page_cch_tabbed_sy;
*/

			// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->drag_cch_y, p->drag_cch_min, p->select_cch_y, p->select_cch_sy );

			if (
				( p->scroll_pxl_tabbed_x == 0 )
				&&
				( p->prv_scr_y == p->scroll_cch_tabbed_y )
			)
			{
//if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " OPTIMIZATION_DRAG : Fast : %d %d ", p->prv_scr_y, p->scroll_cch_tabbed_y ); }

				line_y  = n_posix_min_s32( p->drag_cch_min, p->select_cch_y );
				line_sy = n_posix_max_s32( p->drag_cch_max, abs( p->drag_cch_min - p->select_cch_y ) + p->select_cch_sy );

				p->drag_cch_min = line_y;
				p->drag_cch_max = line_sy;

if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " OPTIMIZATION_DRAG : Fast : %d %d ", p->drag_cch_min, p->drag_cch_max ); }
			} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " OPTIMIZATION_DRAG : Slow : %d %d ", p->prv_scr_y, p->scroll_cch_tabbed_y ); }

				line_y  = nosel;
				line_sy = nosel;

				p->drag_cch_min = 0;
				p->drag_cch_max = p->page_cch_tabbed_sy;
			}

			p->prv_scr_x  = p->scroll_pxl_tabbed_x;
			p->prv_scr_y  = p->scroll_cch_tabbed_y;

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", line_y, line_sy, p->drag_cch_min, p->drag_cch_max );
//line_y = line_sy = nosel;

		} else
		if ( p->typing_only )
		{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_TYPING " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_TYPING;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->prv_sel_y, p->select_cch_y, p->prv_sel_sy, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->vk_key, p->is_backspace, p->is_carrage_return );

			if ( p->is_backspace )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_backspace " ); }

				// [!] : Slow Mode

				//line_y  = nosel;
				//line_sy = nosel;


				// [!] : Fast Mode

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

			} else
			if ( p->is_carrage_return )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_carrage_return " ); }

				// [!] : Slow Mode

				//line_y  = nosel;
				//line_sy = nosel;


				// [!] : Fast Mode

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

			} else
			if ( p->is_ud )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP or VK_DOWN " ); }

				p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d ", p->select_cch_y, p->select_cch_sy, p->prv_sel_y );

				// [!] : Slow Mode

				line_y  = nosel;
				line_sy = nosel;

				p->caret_redraw_x  = 0;
				p->caret_redraw_sx = sx;

				if ( p->prv_scr_y != p->scroll_cch_tabbed_y )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP or VK_DOWN : Scrolled " ); }

					//
				} else
				if ( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP or VK_DOWN : Fast Mode " ); }

					line_y  = n_posix_min_s32( p->prv_sel_y, p->select_cch_y );
					line_sy = 2;

					p->caret_redraw_x  = 0;
					p->caret_redraw_sx = sx;

					//p->caret_redraw_x  = p->ime.x;
					//p->caret_redraw_sx = p->caret_pxl_sx + 1;

					if ( p->vk_key == VK_UP )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d %d ", line_y, line_sy ); }

					} else
					if ( p->vk_key == VK_DOWN )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : %d %d ", line_y, line_sy ); }
					}

				}

//line_y  = 0;
//line_sy = 1;

			} else
			if ( p->is_lr )
			{
//if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr " ); }

				p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;

//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d ", p->vk_key, line_y, line_sy );

				if ( p->prv_scr_x != p->scroll_pxl_tabbed_x )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr : Scroll X " ); }

					line_y  = nosel;
					line_sy = nosel;

				} else
				if ( p->prv_scr_y != p->scroll_cch_tabbed_y )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr : Scroll Y " ); }

					line_y  = nosel;
					line_sy = nosel;

				} else {

					if ( line_sy == 1 )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr : ( line_sy == 1 ) " ); }

						if ( p->is_lr == VK_LEFT )
						{
							p->caret_redraw_x  = p->ime.x - p->size_fullwidth.cx;
							p->caret_redraw_sx = p->size_fullwidth.cx * 2;
						} else
						if ( p->is_lr == VK_RIGHT )
						{
							p->caret_redraw_x  = p->ime.x;
							p->caret_redraw_sx = p->caret_pxl_sx + 1;
						}
					} else {

						p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_OTHERS;
						p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

						// [!] : Slow Mode

						//line_y  = nosel;
						//line_sy = nosel;

						p->caret_redraw_x  = 0;
						p->caret_redraw_sx = sx;

						// [!] : Fast Mode

						line_y  = n_posix_min_s32( p->prv_sel_y, p->select_cch_y );
						line_sy = 2;

						p->is_lr = 0;

if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr : between lines : %d %d : %d %d ", p->prv_sel_y, p->select_cch_y, line_y, line_sy ); }
					}

				}

			} else {

				p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_OTHERS;
				p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

				// [!] : Slow Mode

				//line_y  = nosel;
				//line_sy = nosel;

				p->caret_redraw_x  = 0;
				p->caret_redraw_sx = sx;

				// [!] : Fast Mode

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " TYPING : Others : ID %d : %d %d ", id, line_y, line_sy ); }
			}

//n_win_txtbox_hwndprintf_literal( p, " %d/%d %d/%d  ", p->prv_scr_x, p->scroll_pxl_tabbed_x, p->prv_scr_y, p->scroll_cch_tabbed_y );

			p->prv_scr_x  = p->scroll_pxl_tabbed_x;
			p->prv_scr_y  = p->scroll_cch_tabbed_y;

			n_win_txtbox_previous( p );

//n_win_txtbox_hwndprintf_literal( p, " %d  ", p->vk_key );
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d ", p->is_carrage_return, line_y, line_sy );
		} else
		if ( p->optimization_click_onoff )
		{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_CLICK " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_CLICK;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;

			// [x] : conflict with .empty_line_selection on/off

			//p->caret_redraw_x  = p->ime.x;
			//p->caret_redraw_sx = p->size_fullwidth.cx * 2;

			{
				p->caret_redraw_x  = 0;
				p->caret_redraw_sx = sx;
			}
		} else {

if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " Others : ID %d : %d %d ", id, line_y, line_sy ); }

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->partial_selection_from_onoff, p->partial_selection_to___onoff, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

		}

	} else {

if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " p->optimization_onoff : false : %d %d ", line_y, line_sy ); }

	}

	n_posix_bool is_partial = n_posix_false;

	if ( p->optimization_onoff )
	{
		is_partial = ( line_y != nosel );
	}

	if ( line_y  == nosel ) { line_y  = p->scroll_cch_tabbed_y ; }
	if ( line_sy == nosel ) { line_sy = p->  page_cch_tabbed_sy; }

	line_y  = n_posix_max( line_y , p->scroll_cch_tabbed_y  );
	line_sy = n_posix_min( line_sy, p->  page_cch_tabbed_sy );


	// [!] : back buffer

	n_posix_bool draw_frame_onoff = n_posix_false;

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		   draw_frame_onoff = n_posix_true;
	}

	if ( p->draw_frame_onoff )
	{
		p->draw_frame_onoff = n_posix_false;
		   draw_frame_onoff = n_posix_true;
	}

	if (
		( p->metrics_changed ) 
		||
		( ( p->client_prv_sx != sx )||( p->client_prv_sy != sy ) )
		||
		( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	)
	{

		p->metrics_changed = n_posix_false;


		draw_frame_onoff = n_posix_true;

		n_gdi_dibsection_exit( &p->hbmp, &p->bmp );
		n_gdi_dibsection_init( &p->hbmp, &p->bmp, p->hwnd, hdc_cmpt, sx,sy );
//n_bmp_flush( &p->bmp, n_bmp_rgb( 0,200,255 ) );

		p->client_prv_sx = sx;
		p->client_prv_sy = sy;

	}
//n_bmp_save_literal( &p->bmp, "ret.bmp" );

	HBITMAP hbmp_old = SelectObject( hdc_cmpt, p->hbmp );


	// [!] : draw


	// [!] : border

	n_posix_bool is_selected = ( p->hwnd == GetFocus() );
	if ( p->focus_fade_override ) { is_selected = p->focus_fade_override_bool; }

	n_win_txtbox_draw_frame( p, hdc_cmpt, is_selected, draw_frame_onoff );


	if (
		( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		&&
		( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	)
	{

		// [!] : blank at bottom-right corner

		s32  tsx = p->scrollbar_pxl_sx;
		s32  tsy = p->scrollbar_pxl_sy;
		s32   tx = p->client_pxl_sx - p->scrollbar_pxl_sx - p->border_pxl_sx;
		s32   ty = p->client_pxl_sy - p->scrollbar_pxl_sy - p->border_pxl_sy;
		RECT   r = n_win_rect_set( NULL, tx, ty, tsx, tsy );

		if ( p->debug_onoff )
		{
			n_bmp_mixer( p->debug_bmp, tx, ty, tsx, tsy, p->color_base__padding, 0.5 );
		} else {
			n_win_txtbox_draw_box( p, hdc_cmpt, &r, p->color_base__padding );
		}

		ExcludeClipRect( hdc_cmpt, r.left, r.top, r.right, r.bottom );

	}


	s32 ox = (           p->scroll_pxl_tabbed_x );
	s32 oy = ( line_y  - p->scroll_cch_tabbed_y ) * p->cell_pxl_sy;

	s32 nx = p->border_pxl_sx + p->pad_pxl_sx;
	s32 ny = p->border_pxl_sy + p->pad_pxl_sy;

	s32  x = nx + ox;
	s32  y = ny + oy;

	// [Needed] : ONELINE patch : "y" needs to move to upper

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		y = abs( p->client_pxl_sy - p->cell_pxl_sy ) / 2;
	}

	s32 redraw_y  = y;
	s32 redraw_sy = p->cell_pxl_sy;

	if ( p->optimization_onoff )
	{

		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_NONE )
		{
			//
		} else
		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL  )
		{
			redraw_sy += p->cell_pxl_sy * ( line_sy - 1 );
		} else
		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART )
		{
			redraw_sy += p->cell_pxl_sy * ( line_sy - 1 );
		}

	}

	{

		s32 text_fy = line_y;
		s32 text_ty = line_y + line_sy;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", text_fy, text_ty );

		// Debug Center
		//text_fy = 10;
		//text_ty = 20;

		HFONT hf_old = SelectObject( hdc_cmpt, n_win_font_get( p->hwnd ) );

		while( 1 )
		{//break;
//n_win_txtbox_debug_count( p );

			n_win_txtbox_draw_singleline( p, hdc_cmpt, text_fy, x, y, sx, p->cell_pxl_sy );

			//ExcludeClipRect( hdc_cmpt, x, y, x + sx, y + p->cell_pxl_sy );

			text_fy++;
			if ( text_fy >= text_ty )
			{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );

				// [Patch] : when condition is bad then caret will disappear

				if (
					( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
					&&
					( line_y == 0 )
				)
				{
					y += p->cell_pxl_sy;

					n_win_txtbox_draw_singleline( p, hdc_cmpt, text_fy, x, y, sx, p->cell_pxl_sy );
					//ExcludeClipRect( hdc_cmpt, x, y, x + sx, y + p->cell_pxl_sy );
				}

				break;
			}

			y += p->cell_pxl_sy;
			if ( y >= sy )
			{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
				break;
			}

		}

		SelectObject( hdc_cmpt, hf_old );

	}


	// [!] : padding

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		//
	} else {
		COLORREF color_padding = p->color_back_noselect;
		if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG ) { color_padding = 0; }
//p->debug_onoff=1;
		if ( p->debug_onoff ) { color_padding = RGB( 0,200,255 ); }

		s32 ncx, ncy;

		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{
			s32 scr_sx = 0;
			s32 scr_sy = 0;

			if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { scr_sx = p->scrollbar_pxl_sx + p->pad_pxl_sx; }
			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { scr_sy = p->scrollbar_pxl_sy + p->pad_pxl_sy; }

			ncx = scr_sx + ( p->border_pxl_sx * 2 ) + p->pad_pxl_sx;
			ncy = scr_sy + ( p->border_pxl_sy * 2 ) + p->pad_pxl_sy;
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			ncx = ncy = 0;
		} else {
			s32 scr_sx = 0;
			s32 scr_sy = 0;

			if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { scr_sx = p->scrollbar_pxl_sx + ( p->pad_pxl_sx * 2 ); }
			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { scr_sy = p->scrollbar_pxl_sy + ( p->pad_pxl_sy * 2 ); }

			ncx = scr_sx + ( p->border_pxl_sx * 2 ) + p->pad_pxl_sx;
			ncy = scr_sy + ( p->border_pxl_sy * 2 ) + p->pad_pxl_sy;
		}

		ExcludeClipRect( hdc_cmpt, nx, ny, nx + sx - ncx, ny + sy - ncy );

		RECT rect; n_win_rect_set( &rect, 0,0,p->client_pxl_sx,p->client_pxl_sy );
		n_win_box( p->hwnd, hdc_cmpt, &rect, color_padding );
	}


	// [!] : small buttons

	int i = 0;
	while( 1 )
	{//break;

		n_win_smallbutton_direct *sb = p->smallbutton[ i ];

		if ( sb != NULL )
		{
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", sb->x, sb->y, sb->sx, sb->sy );

			// [Needed] : CatPad : input field resizer
			n_win_txtbox_smallbutton_direct_rearrange( p, sb, i );

			n_win_smallbutton_direct_bitmap_draw( sb );
		}

		i++;
		if ( i >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) { break; }
	}


	// [!] : sync

	if ( p->bitblt_stop == n_posix_false )
	{

		s32 tx  = 0;
		s32 ty  = 0;
		s32 tsx = sx;
		s32 tsy = sy;

		if ( p->optimization_onoff )
		{

			if ( is_partial )
			{
				ty  = redraw_y;
				tsy = redraw_sy;
			}

			if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL  )
			{
				//
			} else
			if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART )
			{
				tx  = p->caret_redraw_x;
				tsx = p->caret_redraw_sx;
			}

		}

		n_win_txtbox_draw_bitblt( p, hdc_main, hdc_cmpt, tx,ty,tsx,tsy  );

	}


	SelectObject( hdc_cmpt, hbmp_old );


	// [Needed] : after drawn

	n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );
	n_win_txtbox_draw_scrollbars( p );


	// [!] : cleanup

	DeleteObject( hdc_cmpt );

	if ( p->hdc_printclient == NULL )
	{
		ReleaseDC( p->hwnd, hdc_main );
	}

	p->is_backspace = p->is_carrage_return = n_posix_false;


	return;
}


