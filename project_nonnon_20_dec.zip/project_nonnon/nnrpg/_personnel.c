// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "./__window.c"


#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"


#include "../nonnon/neutral/wav/all.c"




// [Mechanism] : Character Bitmap
//
//	X #0 Normal
//	X #1 Hit
//	X #2 Attack
//	X #3 Magic
//	X #4 Pinch
//	X #5 Exhausted
//
//	Y    frames for animation


#define N_NNRPG_PERSONNEL_FRAME_NORMAL    0
#define N_NNRPG_PERSONNEL_FRAME_HIT       1
#define N_NNRPG_PERSONNEL_FRAME_ATTACK    2
#define N_NNRPG_PERSONNEL_FRAME_MAGIC     3
#define N_NNRPG_PERSONNEL_FRAME_PINCH     4
#define N_NNRPG_PERSONNEL_FRAME_EXHAUSTED 5
#define N_NNRPG_PERSONNEL_FRAME_MAX       6


#define N_NNRPG_PERSONNEL_PINCH_THRESHOLD 20


#define N_NNRPG_PERSONNEL_FOCUS_OFF n_posix_literal( " " )
#ifdef UNICODE
#define N_NNRPG_PERSONNEL_FOCUS_ON  n_posix_literal( "\x2022" )
#else // #ifdef UNICODE
#define N_NNRPG_PERSONNEL_FOCUS_ON  n_posix_literal( ">" )
#endif // #ifdef UNICODE


#define N_NNRPG_COMMAND_NONE   -1
#define N_NNRPG_COMMAND_ATTACK  0
#define N_NNRPG_COMMAND_MAGIC   1
#define N_NNRPG_COMMAND_HEAL    2
#define N_NNRPG_COMMAND_COUNT   3


typedef struct {

	n_posix_char focus[ 100 ];
	n_posix_char  name[ 100 ];
	n_game_sound sound;

} n_nnrpg_command;




typedef struct {

	n_posix_char    name[ 16 ];

	n_game_chara    chr;
	n_bmp           bmp;
	n_bmp           bmp_attack;
	n_bmp           bmp_magic;
	n_nnrpg_window  win;
	n_nnrpg_window  tip;
	u32             tip_color;
	u32             tip_color_delayed;
	n_nnrpg_command cmd[ N_NNRPG_COMMAND_COUNT ];
	int             frame;

	s32             shadow_x, shadow_y, shadow_sx, shadow_sy;

	u32             color_attack;
	u32             color_magic;
	u32             color_heal;


	// [!] : all parameters use percentage (0-100)

	int hp;
	int mp;

	int physical;
	int magical;
	int weight;


	// [!] : for ActiveTimeBattle-like system

	int wait;

} n_nnrpg_personnel;




#define n_nnrpg_personnel_zero( p ) n_memory_zero( p, sizeof( n_nnrpg_personnel ) )

void
n_nnrpg_personnel_exit( n_nnrpg_personnel *p )
{

	n_bmp_free( &p->bmp        );
	n_bmp_free( &p->bmp_attack );
	n_bmp_free( &p->bmp_magic  );

	n_nnrpg_window_exit( &p->tip );
	n_nnrpg_window_exit( &p->win );


	int i = 0;
	while( 1 )
	{

		n_game_sound_exit( &p->cmd[ i ].sound );

		i++;
		if ( i >= N_NNRPG_COMMAND_COUNT ) { break; }
	}


	n_nnrpg_personnel_zero( p );


	return;
}

int
n_nnrpg_personnel_command_get( n_nnrpg_personnel *p )
{

	int select = 0;


	int i = 0;
	while( 1 )
	{

		if ( n_string_is_same( N_NNRPG_PERSONNEL_FOCUS_ON, p->cmd[ i ].focus ) )
		{
			select = i;
			break;
		}

		i++;
		if ( i >= N_NNRPG_COMMAND_COUNT ) { break; }
	}


	return select;
}

#define n_nnrpg_personnel_command_up(   p ) n_nnrpg_personnel_command_set( p, n_nnrpg_personnel_command_get( p ) - 1 )
#define n_nnrpg_personnel_command_down( p ) n_nnrpg_personnel_command_set( p, n_nnrpg_personnel_command_get( p ) + 1 )

void
n_nnrpg_personnel_command_set( n_nnrpg_personnel *p, int value )
{

	int select = ( N_NNRPG_COMMAND_COUNT + value ) % N_NNRPG_COMMAND_COUNT;


	int i = 0;
	while( 1 )
	{

		if ( i == select )
		{
			n_string_copy( N_NNRPG_PERSONNEL_FOCUS_ON,  p->cmd[ i ].focus );
		} else {
			n_string_copy( N_NNRPG_PERSONNEL_FOCUS_OFF, p->cmd[ i ].focus );
		}

		i++;
		if ( i >= N_NNRPG_COMMAND_COUNT ) { break; }
	}


	return;
}

#define n_nnrpg_personnel_command_erase( p ) n_nnrpg_window_erase( &( p )->win )

void
n_nnrpg_personnel_command_draw( n_nnrpg_personnel *p )
{

	n_nnrpg_window_draw( &p->win );
	n_nnrpg_window_focus( &p->win, n_nnrpg_personnel_command_get( p ), N_NNRPG_COMMAND_COUNT );


	return;
}

void
n_nnrpg_personnel_command_bitmap( n_nnrpg_personnel *p )
{

	int i, cch;


	i = cch = 0;
	while( 1 )
	{

		cch += n_posix_sprintf_literal
		(
			&p->win.msg[ cch ],
			"%s%s%s",
			N_STRING_SPACE,//p->cmd[ i ].focus,
			p->cmd[ i ].name,
			N_STRING_CRLF
		);


		i++;
		if ( i >= N_NNRPG_COMMAND_COUNT ) { break; }
	}


	n_nnrpg_window_bitmap( &p->win );


	return;
}

void
n_nnrpg_personnel_neutral( n_nnrpg_personnel *p, bool tip_off )
{

	// [!] : tip_color : n_bmp_trans means "Don't draw"

	if ( tip_off )
	{
		p->tip_color = p->tip_color_delayed = n_bmp_trans;
	}

	p->chr.srcx = 0;
	p->chr.srcy = 0;


	return;
}

void
n_nnrpg_personnel_resource_resize( n_nnrpg_personnel *p, n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }

	if ( n_nnrpg_metric.zoom == 2 ) { return; }


	u32 frame     = n_bmp_rgb( 0,200,255 );
	u32 trans_old; n_bmp_ptr_get_fast( bmp, 0,0, &trans_old );
	u32 trans_new = n_nnrpg_metric.color_trans;


	n_bmp_transparent_onoff( bmp, false );


	n_bmp_flush_replacer( bmp,       frame, trans_old );
	n_bmp_flush_replacer( bmp, n_bmp_trans, trans_new );

	if ( n_nnrpg_metric.zoom == 1 )
	{
		n_bmp_flush_antialias( bmp, 1.0 );
		n_bmp_flush_antialias( bmp, 1.0 );

		n_bmp_flush_replacer( bmp, trans_new, trans_old );

		n_bmp_scaler_lil( bmp, 2 );
	} else
	if ( n_nnrpg_metric.zoom > 2 )
	{
		n_bmp_scaler_big_pixelart( bmp, n_nnrpg_metric.scale );

		n_bmp_flush_replacer( bmp, trans_new, trans_old );
	}


	n_bmp_transparent_onoff( bmp,  true );


	return;
}

#define n_nnrpg_personnel_init_literal( p, p_0, p_1, p_2, p_3, p_4, p_5, p_6, p_7, p_8, p_9, p_10, p_11, p_12 ) \
	n_nnrpg_personnel_init( p, n_posix_literal( p_0 ), p_1, p_2, p_3, \
		p_4, p_5, p_6, \
		n_posix_literal( p_7  ), n_posix_literal( p_8  ), n_posix_literal( p_9  ),\
		n_posix_literal( p_10 ), n_posix_literal( p_11 ), n_posix_literal( p_12 ) )

void
n_nnrpg_personnel_init
(
	      n_nnrpg_personnel *p,
	const n_posix_char      *name,
	      int                physical,
	      int                magical,
	      int                weight,
	      u32                color_attack,
	      u32                color_magic,
	      u32                color_heal,
	const n_posix_char      *rc_bitmap,
	const n_posix_char      *rc_bitmap_attack,
	const n_posix_char      *rc_bitmap_magic,
	const n_posix_char      *rc_sound_0,
	const n_posix_char      *rc_sound_1,
	const n_posix_char      *rc_sound_2
)
{

	n_nnrpg_personnel_exit( p );


	// Personalizer

	n_string_copy( name, p->name );

	p->hp       = 100;
	p->mp       = 100;
	p->physical = physical;
	p->magical  = magical;
	p->weight   = weight;
	p->wait     = 0;


	// Command Window

	n_nnrpg_window_init_command( &p->win );

	n_string_copy_literal( "Attack", p->cmd[ 0 ].name );
	n_string_copy_literal( "Magic",  p->cmd[ 1 ].name );
	n_string_copy_literal( "Heal",   p->cmd[ 2 ].name );

	n_nnrpg_personnel_command_set( p, N_NNRPG_COMMAND_ATTACK );


	// Colors

	p->color_attack = color_attack;
	p->color_magic  = color_magic;
	p->color_heal   = color_heal;


	// Resources

	n_game_rc_load_bmp( &p->bmp       , rc_bitmap        );
	n_game_rc_load_bmp( &p->bmp_attack, rc_bitmap_attack );
	n_game_rc_load_bmp( &p->bmp_magic , rc_bitmap_magic  );

	n_nnrpg_personnel_resource_resize( p, &p->bmp        );
	n_nnrpg_personnel_resource_resize( p, &p->bmp_attack );
	n_nnrpg_personnel_resource_resize( p, &p->bmp_magic  );


	n_game_chara_bmp( &p->chr, NULL, &p->bmp, NULL, 0 );
	n_game_chara_src( &p->chr, 0,0,n_nnrpg_metric.unit_bmp,n_nnrpg_metric.unit_bmp, 0,0 );

	p->chr.mx = p->chr.my = n_nnrpg_metric.unit_pad;


	n_game_sound_init( &p->cmd[ 0 ].sound, game.hwnd, rc_sound_0 ); n_wav_smoother( &p->cmd[ 0 ].sound.wav );
	n_game_sound_init( &p->cmd[ 1 ].sound, game.hwnd, rc_sound_1 ); n_wav_smoother( &p->cmd[ 1 ].sound.wav );
	n_game_sound_init( &p->cmd[ 2 ].sound, game.hwnd, rc_sound_2 ); n_wav_smoother( &p->cmd[ 2 ].sound.wav );


	n_nnrpg_personnel_neutral( p, true );


	return;
}

void
n_nnrpg_personnel_rectangle_get( n_nnrpg_personnel *p, s32 *ret_x, s32 *ret_y, s32 *ret_sx, s32 *ret_sy )
{

	s32  x = p->chr.x;
	s32  y = p->chr.y;
	s32 sx = p->chr.sx;
	s32 sy = p->chr.sy;

	// x += p->chr.mx;
	// y += p->chr.mx;
	//sx -= p->chr.mx * 2;
	//sy -= p->chr.my * 2;

	if ( ret_x  != NULL ) { (*ret_x ) =  x; }
	if ( ret_y  != NULL ) { (*ret_y ) =  y; }
	if ( ret_sx != NULL ) { (*ret_sx) = sx; }
	if ( ret_sy != NULL ) { (*ret_sy) = sy; }


	return;
}

// internal
void
n_nnrpg_personnel_draw_tip( n_nnrpg_personnel *p )
{

	if ( p->tip_color == n_bmp_trans ) { return; }


	n_nnrpg_window_draw( &p->tip );


	return;
}

// internal
void
n_nnrpg_personnel_draw_effect( n_nnrpg_personnel *p )
{

	if ( p->tip_color == n_bmp_trans ) { return; }


	const s32 fx  = p->chr.srcx + p->chr.mx;
	const s32 fy  = p->chr.srcy + p->chr.my;
	const s32 fsx = p->chr.sx - ( p->chr.mx * 2 );
	const s32 fsy = p->chr.sy - ( p->chr.my * 2 );
	const s32 tx  = p->chr.x + p->chr.mx;
	const s32 ty  = p->chr.y + p->chr.my;


	n_bmp obj; n_bmp_zero( &obj ); n_bmp_1st_fast( &obj, fsx,fsy );

	int r = n_bmp_r( p->tip_color ); if ( r != 0 ) { r = 255; }
	int g = n_bmp_g( p->tip_color ); if ( g != 0 ) { g = 255; }
	int b = n_bmp_b( p->tip_color ); if ( b != 0 ) { b = 255; }

	n_bmp_fastcopy( &p->bmp, &obj, fx,fy,fsx,fsy, 0,0 );
	n_bmp_flush_mixer( &obj, n_bmp_rgb( r,g,b ), 0.25 );

	n_bmp_transcopy( &obj, n_nnrpg_metric.canvas, 0,0,fsx,fsy, tx,ty );

	n_bmp_free_fast( &obj );


	return;
}

void
n_nnrpg_personnel_frame( n_nnrpg_personnel *p, int type, bool reset )
{

	p->chr.srcx = n_nnrpg_metric.unit_bmp * type;

	if ( reset )
	{
		p->frame = 0;
	}


	return;
}

void
n_nnrpg_personnel_animation( n_nnrpg_personnel *p, int frame_max, bool rotate )
{

	p->frame++;
	if ( p->frame >= frame_max )
	{
		if ( rotate )
		{
			p->frame = 0;
		} else {
			p->frame = frame_max - 1;
		}
	}

	p->chr.srcy = p->frame * n_nnrpg_metric.unit_bmp;


	return;
}

void
n_nnrpg_personnel_erase( n_nnrpg_personnel *p )
{

	{

		s32 x  = p->shadow_x;
		s32 y  = p->shadow_y;
		s32 sx = p->shadow_sx;
		s32 sy = p->shadow_sy;

		n_bmp_fastcopy( n_nnrpg_metric.bg, n_nnrpg_metric.canvas, x,y,sx,sy, x,y );

	}

	p->chr.bg   = n_nnrpg_metric.bg;
	p->chr.main = n_nnrpg_metric.canvas;
	n_game_chara_erase( &p->chr );

	n_nnrpg_window_erase( &p->tip );


	return;
}

#define n_nnrpg_personnel_draw( p, focus ) n_nnrpg_personnel_draw_main( p, focus, true, true )

void
n_nnrpg_personnel_draw_main( n_nnrpg_personnel *p, bool focus, bool shadow, bool effect )
{

	if ( shadow )
	{

		s32 sx = n_nnrpg_metric.unit_bmp - ( n_nnrpg_metric.unit_pad * 2 );
		s32 sy = n_nnrpg_metric.unit_bmp - ( n_nnrpg_metric.unit_pad * 2 );

		n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );

		s32 src_x = p->chr.srcx + n_nnrpg_metric.unit_pad;
		s32 src_y = p->chr.srcy + n_nnrpg_metric.unit_pad;

		n_bmp_fastcopy( p->chr.chara, &b, src_x,src_y,sx,sy, 0,0 );
		n_bmp_flush_antialias( &b, 1.0 );

		n_bmp_flush_mirror( &b, N_BMP_MIRROR_UPSIDE_DOWN );
		n_bmp_resampler( &b, 1.0, 0.33 );

		s32 x = n_nnrpg_metric.unit_pad + p->chr.x;
		s32 y = ( p->chr.y + p->chr.sy ) - n_nnrpg_metric.unit_pad;

		n_bmp_blendcopy( &b, n_nnrpg_metric.canvas, 0,0,sx,sy, x,y, 0.5 );

		p->shadow_x  = x;
		p->shadow_y  = y;
		p->shadow_sx = sx;
		p->shadow_sy = N_BMP_SY( &b );

		n_bmp_free( &b );

	}


	p->chr.main = n_nnrpg_metric.canvas;
	n_game_chara_draw( &p->chr );


	if ( effect )
	{
		n_nnrpg_personnel_draw_effect( p );
	}


	return;
}

void
n_nnrpg_personnel_sound( n_nnrpg_personnel *p )
{

	n_game_sound_loop( &p->cmd[ n_nnrpg_personnel_command_get( p ) ].sound );


	return;
}

void
n_nnrpg_personnel_tip_init( n_nnrpg_personnel *p, int value, u32 tip_color )
{

	p->tip_color = tip_color;

	if ( value == -1 )
	{
		n_posix_sprintf_literal( p->tip.msg, "Miss" );
	} else {
		n_posix_sprintf_literal( p->tip.msg, "%d", value );
	}

	n_nnrpg_window_tip( &p->tip, &p->chr, p->tip_color );


	return;
}

void
n_nnrpg_personnel_tip_exit( n_nnrpg_personnel *p )
{

	n_nnrpg_window_exit( &p->tip );


	return;
}

bool
n_nnrpg_personnel_attack( n_nnrpg_personnel *f, n_nnrpg_personnel *t )
{

	bool   is_done = false;
	double offense = f->physical;
	double defense = (double) t->physical / 100;
	double damage  = ceil( n_posix_max_double( 0, offense * ( 1.0 - defense ) ) );

	if ( ( f->hp > 0 )&&( damage != 0 ) )
	{
//damage = 0;

		is_done = true;

		t->hp = n_posix_max( 0, t->hp - damage );

		// [!] : "t" is delayed
		n_nnrpg_personnel_frame( f, N_NNRPG_PERSONNEL_FRAME_ATTACK, true );
		//n_nnrpg_personnel_frame( t, N_NNRPG_PERSONNEL_FRAME_HIT   , true );

		// [!] : a tip is delayed
		n_nnrpg_personnel_tip_init( t, damage, f->color_attack );
		t->tip_color_delayed = f->color_attack;
		t->tip_color         = n_bmp_trans;

		// [!] : delayed
		//n_nnrpg_personnel_sound( f );

	} else {

		is_done = false;

		n_nnrpg_personnel_frame( f, N_NNRPG_PERSONNEL_FRAME_ATTACK, true );
		n_nnrpg_personnel_frame( t, N_NNRPG_PERSONNEL_FRAME_NORMAL, true );

		// [!] : a tip is delayed
		n_nnrpg_personnel_tip_init( t, -1, f->color_attack );
		t->tip_color_delayed = f->color_attack;
		t->tip_color         = n_bmp_trans;

		// [!] : no sound

	}


	return is_done;
}

bool
n_nnrpg_personnel_magic( n_nnrpg_personnel *f, n_nnrpg_personnel *t )
{

	bool   is_done = false;
	double offense = ( f->magical * 2 );
	double defense = (double) ( t->physical + t->magical ) / 100;
	double damage  = ceil( n_posix_max_double( 0, offense * ( 1.0 - defense ) ) );

	if ( ( f->mp > 0 )&&( damage != 0 ) )
	{
//damage = 0;

		is_done = true;

		t->hp = n_posix_max( 0, t->hp - damage );
		f->mp = n_posix_max( 0, f->mp - damage );

		// [!] : "t" is delayed
		n_nnrpg_personnel_frame( f, N_NNRPG_PERSONNEL_FRAME_MAGIC, true );
		//n_nnrpg_personnel_frame( t, N_NNRPG_PERSONNEL_FRAME_HIT  , true );

		// [!] : a tip is delayed
		n_nnrpg_personnel_tip_init( t, damage, f->color_magic );
		t->tip_color_delayed = f->color_magic;
		t->tip_color         = n_bmp_trans;

		n_nnrpg_personnel_sound( f );
	} else {

		is_done = false;

		n_nnrpg_personnel_frame( f, N_NNRPG_PERSONNEL_FRAME_HIT   , true );
		n_nnrpg_personnel_frame( t, N_NNRPG_PERSONNEL_FRAME_NORMAL, true );

		// [!] : a tip is delayed
		n_nnrpg_personnel_tip_init( t, -1, f->color_magic );
		t->tip_color_delayed = f->color_magic;
		t->tip_color         = n_bmp_trans;

		// [!] : no sound

	}


	return is_done;
}

bool
n_nnrpg_personnel_heal( n_nnrpg_personnel *p )
{

	bool   is_done = false;
	double heal    = 0;


	if ( p->mp > 0 )
	{

		is_done = true;


		heal = p->magical;


		// Smart Healer

		if ( ( p->hp + heal ) > 100 ) { heal = 100 - p->hp; }
//heal = 0;

		p->hp = n_posix_min( 100, p->hp + heal );
		p->mp = n_posix_max(   0, p->mp - heal );

		n_nnrpg_personnel_frame( p, N_NNRPG_PERSONNEL_FRAME_MAGIC, true );

		// [!] : a tip is delayed
		n_nnrpg_personnel_tip_init( p, heal, p->color_heal );
		p->tip_color_delayed = p->color_heal;
		p->tip_color         = n_bmp_trans;

		//n_nnrpg_personnel_sound( p );

	} else {

		is_done = false;

		n_nnrpg_personnel_frame( p, N_NNRPG_PERSONNEL_FRAME_MAGIC, true );

		// [!] : a tip is delayed
		n_nnrpg_personnel_tip_init( p, heal, p->color_heal );
		p->tip_color_delayed = p->color_heal;
		p->tip_color         = n_bmp_trans;

		// [!] : no sound

	}


	return is_done;
}

void
n_nnrpg_personnel_bulk_wait( n_nnrpg_personnel *p, int count )
{

	int i = 0;
	while( 1 )
	{

		// [!] : small value causes "always-same-value" problem

		p[ i ].wait += n_random_range( 1 + p[ i ].weight );


		i++;
		if ( i >= count ) { break; }
	}


	return;
}

void
n_nnrpg_personnel_bulk_wait_reset( n_nnrpg_personnel *p, int count )
{

	int i = 0;
	while( 1 )
	{

		p[ i ].wait = 0;


		i++;
		if ( i >= count ) { break; }
	}


	return;
}

int
n_nnrpg_personnel_bulk_wait_focus( n_nnrpg_personnel *p, int count )
{

	int focus = -1;
	int minim = SHRT_MAX;
	int i;


	// [Patch] : when HP is zero

	i = 0;
	while( 1 )
	{

		if ( p[ i ].hp == 0 ) { p[ i ].wait = SHRT_MAX; }

		i++;
		if ( i >= count ) { break; }
	}


	// [Patch] : all values are the same

	int same_value = p[ 0 ].wait;
	int same_count = 0;
	i = 0;
	while( 1 )
	{

		if ( same_value == p[ i ].wait ) { same_count++; }

		i++;
		if ( i >= count ) { break; }
	}

	if ( count == same_count ) { return focus; }


	i = 0;
	while( 1 )
	{

		if ( minim > p[ i ].wait )
		{
			minim = p[ i ].wait;
			focus = i;
		}


		i++;
		if ( i >= count ) { break; }
	}


	return focus;
}

